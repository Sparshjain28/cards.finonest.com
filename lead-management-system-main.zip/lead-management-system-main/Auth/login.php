<?php
ob_start();
require_once '../config/database_updated.php';
require_once '../includes/auth.php';

$error = '';
$rememberedEmail = $_COOKIE['remember_email'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);

    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {
        try {
            $database = new Database();
            $db = $database->getConnection();
            
            $stmt = $db->prepare("SELECT id, name, email, password, channel_code, is_admin, user_type, approved FROM users WHERE email = ? LIMIT 1");
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($user = $result->fetch_assoc()) {
                $stmt->close();
                
                if (strtolower($user['user_type'] ?? '') !== 'dsa' && (int)$user['approved'] !== 1) {
                    $error = 'Your signup request is pending admin approval.';
                } elseif (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['channel_code'] = $user['channel_code'];
                    $_SESSION['is_admin'] = (int)$user['is_admin'];

                    if ($remember) {
                        setcookie('remember_email', $email, time() + (7 * 24 * 60 * 60), "/");
                    } else {
                        setcookie('remember_email', '', time() - 3600, "/");
                    }

                    // Role-based redirect with fallback
                    try {
                        require_once '../includes/role_manager.php';
                        $roleManager = new RoleManager($db);
                        $role = $roleManager->getUserRole($user['id']);
                        
                        if ($role) {
                            switch($role['name']) {
                                case 'admin':
                                    header('Location: /admin/dashboard.php');
                                    break;
                                case 'manager':
                                    header('Location: /manager/dashboard.php');
                                    break;
                                default:
                                    header('Location: /adviser/dashboard.php');
                            }
                        } else {
                            // Assign default role if user has none
                            $defaultRoleId = $user['is_admin'] ? 1 : 3; // admin or adviser
                            $roleManager->assignRole($user['id'], $defaultRoleId);
                            
                            if ($user['is_admin']) {
                                header('Location: /admin/dashboard.php');
                            } else {
                                header('Location: /adviser/dashboard.php');
                            }
                        }
                    } catch (Exception $e) {
                        // Fallback to old method if role system fails
                        error_log('Role system error: ' . $e->getMessage());
                        header('Location: ' . (!empty($_SESSION['is_admin']) ? '/admin/dashboard.php' : '/adviser/dashboard.php'));
                    }
                    exit();
                } else {
                    $error = 'Invalid email or password.';
                }
            } else {
                $error = 'Invalid email or password.';
            }
        } catch (Exception $e) {
            $error = 'Login failed. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/loading.css">
</head>
<body class="min-h-screen bg-gradient-to-r from-blue-600 via-blue-300 to-white">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="min-h-screen flex">
        <!-- Left Content Section -->
        <div class="hidden lg:flex lg:w-1/2 relative overflow-hidden">
            <div class="relative z-10 flex flex-col justify-center px-12 text-white">
                <div class="mb-8">
                    <img src="/assets/logo.jpeg" alt="Fino Cards" class="h-20 w-auto mb-6 filter brightness-0 invert">
                    <h1 class="text-5xl font-bold mb-6">Welcome to Fino Cards</h1>
                    <p class="text-xl mb-8 opacity-90">Your gateway to premium financial solutions and seamless banking experience.</p>
                </div>
                
                <div class="space-y-6">
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                            <i class="fas fa-credit-card text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold">Premium Credit Cards</h3>
                            <p class="opacity-80">Access exclusive benefits and rewards</p>
                        </div>
                    </div>
                    
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                            <i class="fas fa-chart-line text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold">Smart Analytics</h3>
                            <p class="opacity-80">Track your performance with detailed insights</p>
                        </div>
                    </div>
                    
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                            <i class="fas fa-shield-alt text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold">Secure Platform</h3>
                            <p class="opacity-80">Bank-grade security for all transactions</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Right Login Form Section -->
        <div class="w-full lg:w-1/2 flex items-center justify-center px-4 sm:px-6 lg:px-8 bg-white bg-opacity-95">
            <div class="max-w-md w-full space-y-8">
                <div class="bg-white rounded-2xl shadow-xl p-8">
                    <div class="text-center mb-8">
                        <div class="lg:hidden mb-4">
                            <img src="/assets/logo.jpeg" alt="Fino Cards" class="mx-auto h-16 w-auto">
                        </div>
                        <h2 class="text-3xl font-bold text-gray-900">Sign In</h2>
                        <p class="mt-2 text-gray-600">Access your dashboard</p>
                    </div>

                <?php if ($error): ?>
                    <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
                        <i class="fas fa-exclamation-circle mr-2"></i>
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['timeout'])): ?>
                    <div class="bg-yellow-50 border border-yellow-200 text-yellow-700 px-4 py-3 rounded-lg mb-6">
                        <i class="fas fa-clock mr-2"></i>
                        Your session has expired. Please login again.
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['required'])): ?>
                    <div class="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-lg mb-6">
                        <i class="fas fa-info-circle mr-2"></i>
                        Please login to access this page.
                    </div>
                <?php endif; ?>

                <form method="POST" class="space-y-6">
                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-envelope mr-2 text-blue-500"></i>Email Address
                        </label>
                        <input type="email" id="email" name="email" required 
                               value="<?php echo htmlspecialchars($rememberedEmail); ?>"
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                               placeholder="Enter your email">
                    </div>

                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-lock mr-2 text-blue-500"></i>Password
                        </label>
                        <div class="relative">
                            <input type="password" id="password" name="password" required
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors pr-12"
                                   placeholder="Enter your password">
                            <button type="button" id="togglePassword" 
                                    class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700">
                                <i class="fas fa-eye" id="eyeIcon"></i>
                            </button>
                        </div>
                    </div>

                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <input type="checkbox" id="remember" name="remember" 
                                   class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                   <?php echo isset($_COOKIE['remember_email']) ? 'checked' : ''; ?>>
                            <label for="remember" class="ml-2 text-sm text-gray-700">Remember me</label>
                        </div>
                    </div>

                    <button type="submit" 
                            class="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 px-4 rounded-lg hover:from-blue-700 hover:to-indigo-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-200 font-medium">
                        <i class="fas fa-sign-in-alt mr-2"></i>Sign In
                    </button>
                </form>

                    <div class="mt-6 text-center space-y-2">
                        <p class="text-sm text-gray-600">
                            New here? 
                            <a href="/Auth/signup.php" class="text-blue-600 hover:text-blue-700 font-medium">Create an account</a>
                        </p>
                        <a href="/index.php" class="text-sm text-gray-500 hover:text-gray-700">
                            <i class="fas fa-arrow-left mr-1"></i>Back to Home
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
                    <a href="/index.php" class="text-sm text-gray-500 hover:text-gray-700">
                        <i class="fas fa-arrow-left mr-1"></i>Back to Home
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        const togglePassword = document.getElementById('togglePassword');
        const passwordField = document.getElementById('password');
        const eyeIcon = document.getElementById('eyeIcon');
        
        togglePassword.addEventListener('click', () => {
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                eyeIcon.className = 'fas fa-eye-slash';
            } else {
                passwordField.type = 'password';
                eyeIcon.className = 'fas fa-eye';
            }
        });
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
