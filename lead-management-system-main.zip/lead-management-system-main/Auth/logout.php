<?php
require_once __DIR__ . '/../includes/auth.php';

// Clear all cookies
clearAllCookies();
session_unset();
session_destroy();
header('Location: /Auth/login.php?logout=1');
exit();
