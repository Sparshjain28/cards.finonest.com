<?php
require_once '../includes/auth.php';

$error = '';
$success = '';
$referral_code = $_GET['ref'] ?? $_POST['referral_code'] ?? '';
$referrer_name = $_GET['referrer'] ?? $_POST['referrer_name'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['firstName'] ?? '';
    $lastName = $_POST['lastName'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';
    $userType = $_POST['userType'] ?? '';
    $agreeToTerms = isset($_POST['agreeToTerms']);
    $referral_code = $_POST['referral_code'] ?? '';

    if (empty($firstName) || empty($lastName) || empty($email) || empty($password) || empty($confirmPassword) || empty($userType)) {
        $error = 'Please fill in all required fields';
    } elseif ($password !== $confirmPassword) {
        $error = 'Passwords do not match';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long';
    } elseif (!$agreeToTerms) {
        $error = 'Please agree to the Terms of Service and Privacy Policy';
    } elseif (!preg_match('/^\d{10}$/', $phone)) {
        $error = 'Phone number must be exactly 10 digits.';
    } else {
        $fullName = $firstName . ' ' . $lastName;
        require_once '../config/database_updated.php';
        $database = new Database();
        $db = $database->getConnection();
        // Check if email or phone already exists
        $query = "SELECT id, approved FROM users WHERE email = ? OR phone = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param("ss", $email, $phone);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if ($row['approved'] == 0 && $row['userType'] === 'dsa') {
                $error = 'Signup request is pending admin approval.';
            } else {
                $error = 'Email or phone already exists.';
            }
        } else {
            $channel_code = 'CH' . strtoupper(bin2hex(random_bytes(4)));
            $referral_code_gen = 'REF' . strtoupper(bin2hex(random_bytes(3)));
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            // DSA requires admin approval, DST and admin do not
            $user_type = ($_POST['userType'] === 'dsa') ? 'dsa' : (($_POST['userType'] === 'admin') ? 'admin' : 'dst');
            $is_admin = ($user_type === 'admin') ? 1 : 0;
            $approved = ($user_type === 'dsa') ? 0 : 1;
            $query = "INSERT INTO users (name, email, password, phone, channel_code, referral_code, referred_by, is_admin, user_type, approved) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $db->prepare($query);
            $referred_by = !empty($referral_code) ? $referral_code : null;
            $stmt->bind_param("sssssssssi", $fullName, $email, $hashed_password, $phone, $channel_code, $referral_code_gen, $referred_by, $is_admin, $user_type, $approved);
            if ($stmt->execute()) {
                $new_user_id = $db->insert_id;
                
                // Generate OTP
                $otp = sprintf('%06d', mt_rand(100000, 999999));
                $otp_expiry = date('Y-m-d H:i:s', strtotime('+10 minutes'));
                $update_otp_query = "UPDATE users SET email_otp = ?, otp_expiry = ? WHERE id = ?";
                $otp_stmt = $db->prepare($update_otp_query);
                $otp_stmt->bind_param("ssi", $otp, $otp_expiry, $new_user_id);
                $otp_stmt->execute();
                
                // Send OTP email
                require_once '../classes/EmailNotification.php';
                $emailNotification = new EmailNotification();
                $emailNotification->emailVerificationOTP($email, $otp);
                // Handle referral tracking if referral code exists
                if (!empty($referral_code)) {
                    // Find referrer by referral code
                    $referrer_stmt = $db->prepare("SELECT id, name FROM users WHERE referral_code = ?");
                    $referrer_stmt->bind_param("s", $referral_code);
                    $referrer_stmt->execute();
                    $referrer_result = $referrer_stmt->get_result();
                    
                    if ($referrer_row = $referrer_result->fetch_assoc()) {
                        // Insert into referral_users table
                        $ref_user_stmt = $db->prepare("INSERT INTO referral_users (referrer_user_id, referred_user_id, referral_code, referrer_name, status) VALUES (?, ?, ?, ?, 'active')");
                        $ref_user_stmt->bind_param("iiss", $referrer_row['id'], $new_user_id, $referral_code, $referrer_row['name']);
                        if ($ref_user_stmt->execute()) {
                            // Update referral link stats
                            $update_link_stmt = $db->prepare("UPDATE referral_links SET signups = signups + 1 WHERE referral_code = ? AND user_id = ?");
                            $update_link_stmt->bind_param("si", $referral_code, $referrer_row['id']);
                            $update_link_stmt->execute();
                            $update_link_stmt->close();
                        }
                        $ref_user_stmt->close();
                    }
                    $referrer_stmt->close();
                }
                
                // Create referral link for new user
                $ref_link_stmt = $db->prepare("INSERT INTO referral_links (user_id, referral_code, referral_url) VALUES (?, ?, ?)");
                $referral_url = "https://cards.finonest.com/signup.php?ref=" . urlencode($referral_code_gen) . "&referrer=" . urlencode($fullName);
                $ref_link_stmt->bind_param("iss", $new_user_id, $referral_code_gen, $referral_url);
                if (!$ref_link_stmt->execute()) {
                    error_log("Error inserting referral link in signup.php: " . $ref_link_stmt->error);
                    $error = "Failed to create referral link.";
                }
                $ref_link_stmt->close();
                
                if ($approved) {
                    // All users: login immediately and redirect to Aadhaar verification
                    $_SESSION['user_id'] = $new_user_id;
                    $_SESSION['user_name'] = $fullName;
                    $_SESSION['user_email'] = $email;
                    $_SESSION['channel_code'] = $channel_code;
                    $_SESSION['is_admin'] = false;
                    
                    // Assign default role based on user type
                    require_once '../includes/role_manager.php';
                    $roleManager = new RoleManager($db);
                    $defaultRoleId = ($user_type === 'dsa') ? 3 : 3; // adviser role
                    $roleManager->assignRole($new_user_id, $defaultRoleId);
                    
                    // Send signup notification
                    require_once '../includes/notification_helper.php';
                    notifyUser('user_signup', $email, ['user_name' => $fullName]);
                    
                    header('Location: /pages/complete_verification.php?email=' . urlencode($email));
                    exit();
                } else {
                    // DSA: show approval message
                    $success = 'Account created! Please check your email for the OTP to verify your account.';
                }
            } else {
                $error = 'Failed to create account. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join Fino Cards - Create Account</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/loading.css">
</head>
<body class="min-h-screen bg-gradient-to-r from-blue-600 via-blue-300 to-white">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="min-h-screen flex">
        <!-- Left Content Section -->
        <div class="hidden lg:flex lg:w-1/2 relative overflow-hidden">
            <div class="relative z-10 flex flex-col justify-center px-12 text-white">
                <div class="mb-8">
                    <img src="/assets/logo.jpeg" alt="Fino Cards" class="h-20 w-auto mb-6 filter brightness-0 invert">
                    <h1 class="text-5xl font-bold mb-6">Join Fino Cards</h1>
                    <p class="text-xl mb-8 opacity-90">Start your journey with premium financial solutions and unlock exclusive opportunities.</p>
                </div>
                
                <div class="space-y-6">
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                            <i class="fas fa-user-plus text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold">Quick Registration</h3>
                            <p class="opacity-80">Get started in just a few minutes</p>
                        </div>
                    </div>
                    
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                            <i class="fas fa-handshake text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold">Referral Program</h3>
                            <p class="opacity-80">Earn rewards by referring friends</p>
                        </div>
                    </div>
                    
                    <div class="flex items-center space-x-4">
                        <div class="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                            <i class="fas fa-rocket text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold">Instant Access</h3>
                            <p class="opacity-80">Start earning from day one</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Right Signup Form Section -->
        <div class="w-full lg:w-1/2 flex items-center justify-center px-4 sm:px-6 lg:px-8 bg-white bg-opacity-95">
            <div class="max-w-md w-full space-y-8">
                <div class="bg-white rounded-2xl shadow-xl p-8">
                    <div class="text-center mb-8">
                        <div class="lg:hidden mb-4">
                            <img src="/assets/logo.jpeg" alt="Fino Cards" class="mx-auto h-16 w-auto">
                        </div>
                        <h2 class="text-3xl font-bold text-gray-900">Create Account</h2>
                        <p class="mt-2 text-gray-600">Join Fino Cards today</p>
                    </div>
                <?php if ($error): ?>
                    <div class="bg-red-50 border border-red-200 text-red-800 p-3 rounded-lg mb-6 flex items-center gap-2">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo htmlspecialchars($error); ?></span>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="bg-green-50 border border-green-200 text-green-800 p-3 rounded-lg mb-6 flex items-center gap-2">
                        <i class="fas fa-check-circle"></i>
                        <span><?php echo htmlspecialchars($success); ?></span>
                    </div>
                    <script>
                        setTimeout(() => window.location.href = '/index.php', 5000);
                    </script>
                <?php endif; ?>

                <?php if ($referral_code): ?>
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-gift text-blue-600"></i>
                            <div>
                                <p class="text-blue-800 font-semibold text-sm">Referral Signup!</p>
                                <p class="text-blue-700 text-sm">Referred by <strong><?= htmlspecialchars($referrer_name ?: 'a friend') ?></strong></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                

                <form method="POST" class="space-y-4">
                    <?php if ($referral_code): ?>
                        <input type="hidden" name="referral_code" value="<?= htmlspecialchars($referral_code) ?>">
                        <input type="hidden" name="referrer_name" value="<?= htmlspecialchars($referrer_name) ?>">
                    <?php endif; ?>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1">First Name</label>
                            <input type="text" name="firstName" required 
                                   class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                   placeholder="John" value="<?php echo htmlspecialchars($_POST['firstName'] ?? ''); ?>">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-1">Last Name</label>
                            <input type="text" name="lastName" required 
                                   class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                   placeholder="Doe" value="<?php echo htmlspecialchars($_POST['lastName'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Account Type</label>
                        <select name="userType" required class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">Choose your role</option>
                            <option value="dst" <?php echo (isset($_POST['userType']) && $_POST['userType']==='dst') ? 'selected' : ''; ?>>DST (Finonest Staff)</option>
                            <option value="dsa" <?php echo (isset($_POST['userType']) && $_POST['userType']==='dsa') ? 'selected' : ''; ?>>DSA (Sales Agent)</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
                        <input type="email" name="email" required 
                               class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                               placeholder="john@example.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                        <input type="tel" name="phone" required pattern="\d{10}" maxlength="10"
                               class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                               placeholder="9876543210" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Password</label>
                        <input type="password" name="password" required 
                               class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                               placeholder="Create a strong password">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Confirm Password</label>
                        <input type="password" name="confirmPassword" required 
                               class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                               placeholder="Confirm your password">
                    </div>

                    <div class="flex items-start space-x-2">
                        <input type="checkbox" name="agreeToTerms" required class="mt-1" <?php echo isset($_POST['agreeToTerms']) ? 'checked' : ''; ?>>
                        <label class="text-sm text-slate-600">
                            I agree to the <a href="#" class="text-blue-600 hover:text-blue-800">Terms of Service</a> and <a href="#" class="text-blue-600 hover:text-blue-800">Privacy Policy</a>
                        </label>
                    </div>

                    <button type="submit" class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors font-medium">
                        Create Account
                    </button>
                </form>

                    <div class="mt-6 text-center">
                        <p class="text-gray-600">
                            Already have an account?
                            <a href="/Auth/login.php" class="text-blue-600 hover:text-blue-700 font-medium">Sign in here</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
