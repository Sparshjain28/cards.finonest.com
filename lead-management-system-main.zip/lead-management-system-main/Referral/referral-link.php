<?php
require_once 'includes/auth.php';
requireLogin();

$user = getCurrentUser();
$referral_link = "https://cards.finonest.com/signup.php?ref=" . urlencode($user['referral_code']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Referral Link</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include 'includes/header.php'; ?>
    
    <main class="max-w-2xl mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow p-6">
            <h2 class="text-2xl font-bold mb-6">My Referral Program</h2>
            
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <h3 class="font-semibold text-blue-900 mb-2">How it works:</h3>
                <ul class="text-blue-800 text-sm space-y-1">
                    <li>• Share your referral link with others</li>
                    <li>• When they sign up and their lead gets activated, you earn 5% bonus</li>
                    <li>• Bonus is calculated from their commission amount</li>
                </ul>
            </div>
            
            <div class="mb-6">
                <label class="block text-sm font-medium mb-2">Your Referral Link:</label>
                <div class="flex gap-2">
                    <input type="text" id="referralLink" value="<?= htmlspecialchars($referral_link) ?>" class="flex-1 px-3 py-2 border rounded-lg bg-gray-50" readonly>
                    <button onclick="copyLink()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                        <i class="fas fa-copy mr-2"></i>Copy
                    </button>
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button onclick="shareWhatsApp()" class="bg-green-600 text-white px-4 py-3 rounded-lg hover:bg-green-700">
                    <i class="fab fa-whatsapp mr-2"></i>Share on WhatsApp
                </button>
                <button onclick="shareEmail()" class="bg-gray-600 text-white px-4 py-3 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-envelope mr-2"></i>Share via Email
                </button>
            </div>
        </div>
    </main>
    
    <script>
        function copyLink() {
            const link = document.getElementById('referralLink');
            link.select();
            document.execCommand('copy');
            alert('Referral link copied to clipboard!');
        }
        
        function shareWhatsApp() {
            const link = encodeURIComponent(document.getElementById('referralLink').value);
            const text = encodeURIComponent('Hi! I\'m inviting you to join Fino Cards - a great platform for financial services. Use my referral link to sign up and start earning: ');
            window.open(`https://wa.me/?text=${text}${link}`, '_blank');
        }
        
        function shareEmail() {
            const link = encodeURIComponent(document.getElementById('referralLink').value);
            const subject = encodeURIComponent('Join Fino Cards - Referral Invitation');
            const body = encodeURIComponent(`Hi,\n\nI'd like to invite you to join Fino Cards, a great platform for financial services.\n\nUse my referral link to sign up: ${document.getElementById('referralLink').value}\n\nBest regards`);
            window.open(`mailto:?subject=${subject}&body=${body}`, '_blank');
        }
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>