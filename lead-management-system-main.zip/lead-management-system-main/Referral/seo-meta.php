<?php
// SEO Meta Tags Helper
function getSEOMeta($page = 'home') {
    $seo = [
        'home' => [
            'title' => 'Fino Cards | Credit Cards & Personal Loans Online Application',
            'description' => 'Fino Cards - Apply for credit cards and personal loans online. Quick approval, competitive rates. Official Fino Cards website for financial services in India.',
            'keywords' => 'fino cards, finocards, credit cards online, personal loans, fino card application, credit card apply online, loan application',
            'canonical' => '/'
        ],
        'login' => [
            'title' => 'Login - Fino Cards Financial Platform',
            'description' => 'Access your Fino Cards account to manage financial leads and applications securely.',
            'keywords' => 'login, financial platform, secure access',
            'canonical' => '/login.php'
        ],
        'signup' => [
            'title' => 'Join Fino Cards - Financial Lead Management',
            'description' => 'Create your Fino Cards account and start managing financial leads effectively.',
            'keywords' => 'signup, register, financial advisor, lead management',
            'canonical' => '/signup.php'
        ],
        'apply' => [
            'title' => 'Apply for Credit Cards & Personal Loans - Fino Cards',
            'description' => 'Apply for credit cards and personal loans through Fino Cards. Quick approval process with competitive rates.',
            'keywords' => 'credit card application, personal loan, financial services, loan application',
            'canonical' => '/forms/apply.php'
        ],
        'emi_calculator' => [
            'title' => 'EMI Calculator - Calculate Loan EMI - Fino Cards',
            'description' => 'Calculate your loan EMI with our free EMI calculator. Get instant results for personal loans and credit cards.',
            'keywords' => 'EMI calculator, loan calculator, personal loan EMI, credit card EMI',
            'canonical' => '/pages/emi_calculator.php'
        ]
    ];
    
    return $seo[$page] ?? $seo['home'];
}

function renderSEOMeta($page = 'home', $customTitle = null, $customDescription = null) {
    $meta = getSEOMeta($page);
    $title = $customTitle ?? $meta['title'];
    $description = $customDescription ?? $meta['description'];
    
    echo '<title>' . htmlspecialchars($title) . '</title>' . "\n";
    echo '<meta name="description" content="' . htmlspecialchars($description) . '">' . "\n";
    echo '<meta name="keywords" content="' . htmlspecialchars($meta['keywords']) . '">' . "\n";
    echo '<link rel="canonical" href="https://cards.finonest.com' . $meta['canonical'] . '">' . "\n";
    
    // Open Graph
    echo '<meta property="og:title" content="' . htmlspecialchars($title) . '">' . "\n";
    echo '<meta property="og:description" content="' . htmlspecialchars($description) . '">' . "\n";
    echo '<meta property="og:type" content="website">' . "\n";
    echo '<meta property="og:url" content="https://cards.finonest.com' . $meta['canonical'] . '">' . "\n";
    echo '<meta property="og:image" content="https://cards.finonest.com/assets/logo.jpeg">' . "\n";
    
    // Twitter Card
    echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
    echo '<meta name="twitter:title" content="' . htmlspecialchars($title) . '">' . "\n";
    echo '<meta name="twitter:description" content="' . htmlspecialchars($description) . '">' . "\n";
    echo '<meta name="twitter:image" content="https://cards.finonest.com/assets/logo.jpeg">' . "\n";
}
?>