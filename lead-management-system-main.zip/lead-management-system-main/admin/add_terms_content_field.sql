-- Add missing terms_content field to products table
ALTER TABLE products 
ADD COLUMN terms_content TEXT DEFAULT NULL 
AFTER pin_codes;
