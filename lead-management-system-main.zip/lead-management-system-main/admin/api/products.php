<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../config/database_updated.php';

$database = new Database();
$conn = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'GET':
        if (isset($_GET['action'])) {
            switch ($_GET['action']) {
                case 'stats':
                    $stats = [];
                    
                    // Total products
                    $result = $conn->query("SELECT COUNT(*) as total FROM products");
                    $stats['total'] = $result->fetch_assoc()['total'];
                    
                    // Active products
                    $result = $conn->query("SELECT COUNT(*) as active FROM products WHERE status = 'active'");
                    $stats['active'] = $result->fetch_assoc()['active'];
                    
                    // Inactive products
                    $stats['inactive'] = $stats['total'] - $stats['active'];
                    
                    // Average commission
                    $result = $conn->query("SELECT AVG(commission_rate) as avg_commission FROM products");
                    $stats['avg_commission'] = round($result->fetch_assoc()['avg_commission'], 2);
                    
                    // Category breakdown
                    $result = $conn->query("SELECT category, COUNT(*) as count FROM products GROUP BY category");
                    $stats['categories'] = [];
                    while ($row = $result->fetch_assoc()) {
                        $stats['categories'][$row['category']] = $row['count'];
                    }
                    
                    echo json_encode(['success' => true, 'stats' => $stats]);
                    break;
                    
                case 'history':
                    if (!isset($_GET['product_id'])) {
                        echo json_encode(['success' => false, 'message' => 'Product ID required']);
                        exit;
                    }
                    
                    $productId = intval($_GET['product_id']);
                    $stmt = $conn->prepare("SELECT * FROM product_history WHERE product_id = ? ORDER BY changed_at DESC LIMIT 100");
                    $stmt->bind_param('i', $productId);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    $history = [];
                    while ($row = $result->fetch_assoc()) {
                        $history[] = $row;
                    }
                    $stmt->close();
                    
                    echo json_encode(['success' => true, 'history' => $history]);
                    break;
                    
                default:
                    // Get all products with filters
                    $whereClause = "WHERE 1=1";
                    $params = [];
                    $types = "";
                    
                    if (isset($_GET['search']) && !empty($_GET['search'])) {
                        $search = '%' . $_GET['search'] . '%';
                        $whereClause .= " AND (name LIKE ? OR variant LIKE ? OR category LIKE ?)";
                        $params = array_merge($params, [$search, $search, $search]);
                        $types .= "sss";
                    }
                    
                    if (isset($_GET['category']) && !empty($_GET['category'])) {
                        $whereClause .= " AND category = ?";
                        $params[] = $_GET['category'];
                        $types .= "s";
                    }
                    
                    if (isset($_GET['status']) && !empty($_GET['status'])) {
                        $whereClause .= " AND status = ?";
                        $params[] = $_GET['status'];
                        $types .= "s";
                    }
                    
                    $sql = "SELECT * FROM products $whereClause ORDER BY created_at DESC";
                    $stmt = $conn->prepare($sql);
                    if (!empty($params)) {
                        $stmt->bind_param($types, ...$params);
                    }
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    $products = [];
                    while ($row = $result->fetch_assoc()) {
                        $products[] = $row;
                    }
                    $stmt->close();
                    
                    echo json_encode(['success' => true, 'products' => $products]);
            }
        }
        break;
        
    case 'POST':
        if (isset($input['action'])) {
            switch ($input['action']) {
                case 'bulk_apply_logo':
                    if (!isset($input['lender']) || !isset($input['image_data'])) {
                        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
                        exit;
                    }
                    
                    $lender = trim($input['lender']);
                    $imageData = $input['image_data'];
                    
                    // Handle image upload
                    if (!preg_match('/^data:image\/(\w+);base64,/', $imageData, $matches)) {
                        echo json_encode(['success' => false, 'message' => 'Invalid image data']);
                        exit;
                    }
                    
                    $imageType = $matches[1];
                    $imageData = substr($imageData, strpos($imageData, ',') + 1);
                    $imageData = base64_decode($imageData);
                    
                    if ($imageData === false) {
                        echo json_encode(['success' => false, 'message' => 'Failed to decode image']);
                        exit;
                    }
                    
                    $filename = 'variant_' . time() . '_' . rand(1000, 9999) . '.' . $imageType;
                    $uploadPath = __DIR__ . '/../../assets/cards/' . $filename;
                    
                    if (file_put_contents($uploadPath, $imageData)) {
                        $imagePath = 'assets/cards/' . $filename;
                        
                        $stmt = $conn->prepare("UPDATE products SET variant_image = ? WHERE variant = ?");
                        $stmt->bind_param('ss', $imagePath, $lender);
                        $stmt->execute();
                        $affected = $stmt->affected_rows;
                        $stmt->close();
                        
                        echo json_encode(['success' => true, 'count' => $affected]);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Failed to save image']);
                    }
                    break;
                    
                default:
                    echo json_encode(['success' => false, 'message' => 'Invalid action']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'No action specified']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}

$conn->close();
?>