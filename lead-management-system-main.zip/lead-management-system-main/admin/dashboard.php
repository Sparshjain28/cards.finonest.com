<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../includes/notices_component.php';

requireLogin();

// Strict Role Check for Admin Dashboard
if (!isAdmin()) {
    require_once '../includes/role_manager.php';
    // If user is manager, redirect to manager dashboard
    if (function_exists('isManager') && isManager()) {
        header('Location: ../manager/dashboard.php');
        exit();
    }
    // Otherwise adviser dashboard
    header('Location: ../adviser/dashboard.php');
    exit();
}


$user = getCurrentUser();
$database = new Database();
$conn = $database->getConnection();
$is_admin = !empty($user['is_admin']);

// Handle notice dismissal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dismiss_notice'])) {
    markNoticeAsRead($conn, $user['id'], $_POST['dismiss_notice']);
    exit;
}

// Get KPIs for dashboard (admin sees all, adviser sees own only)
function getKPIs($conn, $user, $is_admin) {
    $where = '';
    $params = [];
    $types = '';
    if (!$is_admin) {
        $where = 'WHERE channel_code = ?';
        $params[] = $user['channel_code'];
        $types .= 's';
    }
    $query = "SELECT 
        COUNT(*) as total_leads,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status = 'declined' THEN 1 ELSE 0 END) as rejected,
        SUM(CASE WHEN status IN ('generated', 'yet_to_start', 'in_process') THEN 1 ELSE 0 END) as work_in_progress,
        SUM(CASE WHEN MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE()) THEN 1 ELSE 0 END) as this_month,
        SUM(CASE WHEN MONTH(created_at) = MONTH(CURDATE()) - 1 AND YEAR(created_at) = YEAR(CURDATE()) THEN 1 ELSE 0 END) as last_month
        FROM leads $where";
    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $kpis = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    // Bonus/Commission summary (adviser: only activated/disbursed, admin: all)
    if ($is_admin) {
        $bonus_query = "SELECT 
            SUM(CASE WHEN status = 'pending' THEN commission_amount + bonus_amount ELSE 0 END) as pending_bonus,
            SUM(CASE WHEN status = 'paid' AND MONTH(payout_date) = MONTH(CURDATE()) THEN commission_amount + bonus_amount ELSE 0 END) as paid_this_month,
            SUM(CASE WHEN status = 'paid' THEN commission_amount + bonus_amount ELSE 0 END) as total_paid
            FROM payouts";
        $bonus_stmt = $conn->prepare($bonus_query);
    } else {
        $bonus_query = "SELECT 
            SUM(CASE WHEN status = 'pending' AND lead_id IN (SELECT id FROM leads WHERE channel_code = ? AND status IN ('activated','disbursed')) THEN commission_amount + bonus_amount ELSE 0 END) as pending_bonus,
            SUM(CASE WHEN status = 'paid' AND lead_id IN (SELECT id FROM leads WHERE channel_code = ? AND status IN ('activated','disbursed')) AND MONTH(payout_date) = MONTH(CURDATE()) THEN commission_amount + bonus_amount ELSE 0 END) as paid_this_month,
            SUM(CASE WHEN status = 'paid' AND lead_id IN (SELECT id FROM leads WHERE channel_code = ? AND status IN ('activated','disbursed')) THEN commission_amount + bonus_amount ELSE 0 END) as total_paid
            FROM payouts";
        $bonus_stmt = $conn->prepare($bonus_query);
        $bonus_stmt->bind_param('sss', $user['channel_code'], $user['channel_code'], $user['channel_code']);
    }
    $bonus_stmt->execute();
    $bonus_data = $bonus_stmt->get_result()->fetch_assoc();
    $bonus_stmt->close();
    return array_merge($kpis, $bonus_data);
}

$kpis = getKPIs($conn, $user, $is_admin);

// Get product counts by category (admin: all, adviser: only own leads)
$product_counts = ['Credit Card' => 0, 'Personal Loan' => 0, 'Car Loan' => 0];
if ($is_admin) {
    $prod_query = "SELECT category, COUNT(*) as cnt FROM products WHERE status = 'active' GROUP BY category";
    $prod_res = $conn->query($prod_query);
    if ($prod_res) {
        while ($row = $prod_res->fetch_assoc()) {
            $product_counts[$row['category']] = (int)$row['cnt'];
        }
    }
} else {
    $prod_query = "SELECT p.category, COUNT(*) as cnt FROM leads l JOIN products p ON l.product_id = p.id WHERE l.channel_code = ? GROUP BY p.category";
    $prod_stmt = $conn->prepare($prod_query);
    $prod_stmt->bind_param('s', $user['channel_code']);
    $prod_stmt->execute();
    $prod_res = $prod_stmt->get_result();
    while ($row = $prod_res->fetch_assoc()) {
        $product_counts[$row['category']] = (int)$row['cnt'];
    }
    $prod_stmt->close();
}

// Recent leads (admin: all, adviser: only own)
if ($is_admin) {
    $recent_query = "SELECT l.lead_id, l.customer_name, l.mobile, l.status, p.name as product_name, l.created_at 
                     FROM leads l 
                     JOIN products p ON l.product_id = p.id 
                     ORDER BY l.created_at DESC LIMIT 5";
    $recent_stmt = $conn->prepare($recent_query);
} else {
    $recent_query = "SELECT l.lead_id, l.customer_name, l.mobile, l.status, p.name as product_name, l.created_at 
                     FROM leads l 
                     JOIN products p ON l.product_id = p.id 
                     WHERE l.channel_code = ?
                     ORDER BY l.created_at DESC LIMIT 5";
    $recent_stmt = $conn->prepare($recent_query);
    $recent_stmt->bind_param('s', $user['channel_code']);
}
$recent_stmt->execute();
$recent_leads = $recent_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$recent_stmt->close();

if (isset($_GET['logout'])) {
    logout();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partner Dashboard - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="/assets/css/loading.css">

</head>
<body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>

    <div class="w-full max-w-7xl mx-auto px-4 py-4">
        <?php 
        $notices = getActiveNotices($conn, $user['id']);
        echo renderNotices($notices);
        ?>
        
        <!-- Banner Section -->
        <div class="mb-4">
            <div class="bg-orange-50 border-l-4 border-orange-400 rounded-lg p-3 flex items-center gap-2">
                <span class="text-2xl"></span>
                <span class="text-orange-800 text-sm font-medium font-bold">Admin Dashboard &mdash; Full Control Panel</span>
            </div>
        </div>

        <!-- Admin Quick Actions -->
        <div class="mb-6 grid grid-cols-2 md:grid-cols-9 gap-3">
            <a href="../admin/users.php" class="group bg-white rounded-lg shadow-sm border-2 border-blue-100 p-3 flex flex-col items-center hover:border-blue-300 hover:shadow-md transition-all">
                <div class="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <i class="fas fa-user-tie text-white text-sm"></i>
                </div>
                <span class="font-semibold text-slate-900 text-xs text-center">Manage Users</span>
                <span class="text-xs text-slate-500 mt-0.5 text-center">Advisers & Staff</span>
            </a>
            <a href="../admin/role_management.php" class="group bg-white rounded-lg shadow-sm border-2 border-red-100 p-3 flex flex-col items-center hover:border-red-300 hover:shadow-md transition-all">
                <div class="w-10 h-10 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <i class="fas fa-user-shield text-white text-sm"></i>
                </div>
                <span class="font-semibold text-slate-900 text-xs text-center">Role Management</span>
                <span class="text-xs text-slate-500 mt-0.5 text-center">Permissions</span>
            </a>
            <a href="../admin/products.php" class="group bg-white rounded-lg shadow-sm border-2 border-emerald-100 p-3 flex flex-col items-center hover:border-emerald-300 hover:shadow-md transition-all">
                <div class="w-10 h-10 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <i class="fas fa-cube text-white text-sm"></i>
                </div>
                <span class="font-semibold text-slate-900 text-xs text-center">Manage Products</span>
                <span class="text-xs text-slate-500 mt-0.5 text-center">Cards & Loans</span>
            </a>
            
            <a href="../admin/payouts.php" class="group bg-white rounded-lg shadow-sm border-2 border-purple-100 p-3 flex flex-col items-center hover:border-purple-300 hover:shadow-md transition-all">
                <div class="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <i class="fas fa-hand-holding-usd text-white text-sm"></i>
                </div>
                <span class="font-semibold text-slate-900 text-xs text-center">Manage Payouts</span>
                <span class="text-xs text-slate-500 mt-0.5 text-center">Commission & Bonus</span>
            </a>
            <a href="../admin/terms_and_conditions.php" class="group bg-white rounded-lg shadow-sm border-2 border-indigo-100 p-3 flex flex-col items-center hover:border-indigo-300 hover:shadow-md transition-all">
                <div class="w-10 h-10 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <i class="fas fa-file-contract text-white text-sm"></i>
                </div>
                <span class="font-semibold text-slate-900 text-xs text-center">Terms & Conditions</span>
                <span class="text-xs text-slate-500 mt-0.5 text-center">Legal Content</span>
            </a>
            <a href="../admin/privacy_policy.php" class="group bg-white rounded-lg shadow-sm border-2 border-teal-100 p-3 flex flex-col items-center hover:border-teal-300 hover:shadow-md transition-all">
                <div class="w-10 h-10 bg-gradient-to-br from-teal-500 to-teal-600 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <i class="fas fa-shield-alt text-white text-sm"></i>
                </div>
                <span class="font-semibold text-slate-900 text-xs text-center">Privacy Policy</span>
                <span class="text-xs text-slate-500 mt-0.5 text-center">Data Protection</span>
            </a>
            <a href="/account-aggregator.php" class="group bg-white rounded-lg shadow-sm border-2 border-cyan-100 p-3 flex flex-col items-center hover:border-cyan-300 hover:shadow-md transition-all">
                <div class="w-10 h-10 bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <i class="fas fa-university text-white text-sm"></i>
                </div>
                <span class="font-semibold text-slate-900 text-xs text-center">Account Aggregator</span>
                <span class="text-xs text-slate-500 mt-0.5 text-center">Financial Data</span>
            </a>
            <a href="../leads/leads_updated.php" class="group bg-white rounded-lg shadow-sm border-2 border-orange-100 p-3 flex flex-col items-center hover:border-orange-300 hover:shadow-md transition-all">
                <div class="w-10 h-10 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <i class="fas fa-chart-network text-white text-sm"></i>
                </div>
                <span class="font-semibold text-slate-900 text-xs text-center">CRM / Leads</span>
                <span class="text-xs text-slate-500 mt-0.5 text-center">Customer Management</span>
            </a>
            <a href="../admin/profile_management.php" class="group bg-white rounded-lg shadow-sm border-2 border-pink-100 p-3 flex flex-col items-center hover:border-pink-300 hover:shadow-md transition-all">
                <div class="w-10 h-10 bg-gradient-to-br from-pink-500 to-pink-600 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <i class="fas fa-user-cog text-white text-sm"></i>
                </div>
                <span class="font-semibold text-slate-900 text-xs text-center">Profile Management</span>
                <span class="text-xs text-slate-500 mt-0.5 text-center">KYC & Status</span>
            </a>
        </div>

        <!-- Product Portfolio -->
        <div class="mb-6">
            <h2 class="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <div class="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                    <i class="fas fa-briefcase text-white text-sm"></i>
                </div>
                Product Portfolio
            </h2>
            <div class="grid grid-cols-2 lg:grid-cols-3 gap-3">
                <a href="../forms/apply_card.php" class="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-lg shadow-sm p-3 hover:border-blue-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-credit-card text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-blue-700"><?php echo $product_counts['Credit Card']; ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-blue-800">Credit Cards</h3>
                        <p class="text-xs text-blue-600">Premium cards</p>
                    </div>
                </a>
                
                <a href="../forms/apply_personal.php" class="group bg-gradient-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-200 rounded-lg shadow-sm p-3 hover:border-emerald-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-coins text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-emerald-700"><?php echo $product_counts['Personal Loan']; ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-emerald-800">Personal Loans</h3>
                        <p class="text-xs text-emerald-600">Quick loans</p>
                    </div>
                </a>
                
                <a href="../forms/apply_car.php" class="group bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-200 rounded-lg shadow-sm p-3 hover:border-orange-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-car-side text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-orange-700"><?php echo isset($product_counts['Car Loan']) ? $product_counts['Car Loan'] : 0; ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-orange-800">Car Loans</h3>
                        <p class="text-xs text-orange-600">Auto financing</p>
                    </div>
                </a>

                <!-- Offline Personal Loan -->
                <a href="../forms/offline_pl_form.php" class="group bg-gradient-to-br from-indigo-50 to-indigo-100 border-2 border-indigo-200 rounded-lg shadow-sm p-3 hover:border-indigo-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-money-bill-wave text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-indigo-700"><?php echo isset($product_counts['Offline Personal Loan']) ? $product_counts['Offline Personal Loan'] : 0; ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-indigo-800">Offline Personal Loan</h3>
                        <p class="text-xs text-indigo-600">Direct processing</p>
                    </div>
                </a>

                <!-- Business Loan -->
                <a href="../forms/business_loan_form.php" class="group bg-gradient-to-br from-teal-50 to-teal-100 border-2 border-teal-200 rounded-lg shadow-sm p-3 hover:border-teal-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-teal-500 to-teal-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-briefcase text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-teal-700"><?php echo isset($product_counts['Business Loan']) ? $product_counts['Business Loan'] : 0; ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-teal-800">Business Loan</h3>
                        <p class="text-xs text-teal-600">Business growth</p>
                    </div>
                </a>
            </div>
        </div>
        
        <!-- Key Performance Indicators -->
        <div class="mb-6">
            <h2 class="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <div class="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                    <i class="fas fa-chart-line text-white text-sm"></i>
                </div>
                Key Performance Indicators
            </h2>
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
                <a href="../leads/leads_updated.php" class="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-lg shadow-sm p-3 hover:border-blue-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-users text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-blue-700"><?php echo number_format($kpis['total_leads']); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-blue-800">Total Leads</h3>
                        <p class="text-xs text-blue-600">All applications</p>
                    </div>
                </a>
                
                <a href="../leads/leads_updated.php?status=approved" class="group bg-gradient-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-200 rounded-lg shadow-sm p-3 hover:border-emerald-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-check-circle text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-emerald-700"><?php echo number_format($kpis['approved']); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-emerald-800">Approved</h3>
                        <p class="text-xs text-emerald-600">Successfully processed</p>
                    </div>
                </a>
                
                <a href="../leads/leads_updated.php?status=declined" class="group bg-gradient-to-br from-red-50 to-red-100 border-2 border-red-200 rounded-lg shadow-sm p-3 hover:border-red-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-times-circle text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-red-700"><?php echo number_format($kpis['rejected']); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-red-800">Rejected</h3>
                        <p class="text-xs text-red-600">Applications declined</p>
                    </div>
                </a>
                
                <a href="../leads/leads_updated.php?status=in_process" class="group bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-200 rounded-lg shadow-sm p-3 hover:border-amber-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-spinner text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-amber-700"><?php echo number_format($kpis['work_in_progress']); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-amber-800">In Progress</h3>
                        <p class="text-xs text-amber-600">Under processing</p>
                    </div>
                </a>
            </div>
        </div>

        <!-- Monthly Performance -->
        <div class="mb-6">
            <h2 class="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <div class="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                    <i class="fas fa-calendar-check text-white text-sm"></i>
                </div>
                Monthly Performance
            </h2>
            <div class="grid grid-cols-2 lg:grid-cols-3 gap-3">
                <?php $growth = $kpis['last_month'] > 0 ? (($kpis['this_month'] - $kpis['last_month']) / $kpis['last_month']) * 100 : 0; ?>
                <div class="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-lg shadow-sm p-3 hover:border-blue-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-calendar-day text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-blue-700"><?php echo number_format($kpis['this_month']); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-blue-800">This Month</h3>
                        <p class="text-xs text-blue-600">Applications</p>
                    </div>
                </div>
                <div class="group bg-gradient-to-br from-slate-50 to-slate-100 border-2 border-slate-200 rounded-lg shadow-sm p-3 hover:border-slate-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-slate-500 to-slate-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-history text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-slate-700"><?php echo number_format($kpis['last_month']); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-slate-800">Last Month</h3>
                        <p class="text-xs text-slate-600">Applications</p>
                    </div>
                </div>
                <div class="group bg-gradient-to-br from-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-50 to-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-100 border-2 border-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-200 rounded-lg shadow-sm p-3 hover:border-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-500 to-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-<?php echo $growth >= 0 ? 'trending-up' : 'trending-down'; ?> text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-700"><?php echo $growth >= 0 ? '+' : ''; ?><?php echo number_format($growth, 1); ?>%</div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-800">Growth</h3>
                        <p class="text-xs text-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-600">vs Last Month</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Commission Summary -->
        <div class="mb-6">
            <h2 class="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <div class="w-8 h-8 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-lg flex items-center justify-center">
                    <i class="fas fa-coins text-white text-sm"></i>
                </div>
                Commission Summary
            </h2>
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
                <a href="../admin/payouts.php" class="group bg-gradient-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-200 rounded-lg shadow-sm p-3 hover:border-emerald-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-piggy-bank text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-emerald-700">₹<?php echo number_format($kpis['total_paid'] ?? 0); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-emerald-800">Total Earned</h3>
                        <p class="text-xs text-emerald-600">Lifetime commission</p>
                    </div>
                </a>
                
                <a href="../admin/payouts.php?month=current" class="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-lg shadow-sm p-3 hover:border-blue-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-calendar-week text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-blue-700">₹<?php echo number_format($kpis['paid_this_month'] ?? 0); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-blue-800">This Month</h3>
                        <p class="text-xs text-blue-600">Current earnings</p>
                    </div>
                </a>
                
                <a href="../admin/payouts.php?status=pending" class="group bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-200 rounded-lg shadow-sm p-3 hover:border-amber-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-clock text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-amber-700">
                            <?php
                            $pending_amount = 0;
                            if ($is_admin) {
                                $sql = "SELECT SUM(commission_amount + bonus_amount) as amt FROM payouts WHERE status = 'pending' AND lead_id IN (SELECT id FROM leads WHERE status IN ('activated','disbursed'))";
                                $stmt = $conn->prepare($sql);
                            } else {
                                $sql = "SELECT SUM(commission_amount + bonus_amount) as amt FROM payouts WHERE status = 'pending' AND lead_id IN (SELECT id FROM leads WHERE channel_code = ? AND status IN ('activated','disbursed'))";
                                $stmt = $conn->prepare($sql);
                                $stmt->bind_param('s', $user['channel_code']);
                            }
                            $stmt->execute();
                            $stmt->bind_result($pending_amount);
                            $stmt->fetch();
                            $stmt->close();
                            echo '₹' . number_format((float)$pending_amount);
                            ?>
                            </div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-amber-800">Pending</h3>
                        <p class="text-xs text-amber-600">Awaiting approval</p>
                    </div>
                </a>
                
                <div class="group bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-200 rounded-lg shadow-sm p-3 hover:border-purple-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-chart-line text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-purple-700">₹<?php echo number_format(($kpis['total_paid'] ?? 0) + ($pending_amount ?? 0)); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-purple-800">Total Value</h3>
                        <p class="text-xs text-purple-600">Paid + Pending</p>
                    </div>
                </div>
            </div>
        </div>


        <!-- Quick Actions -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <a href="../forms/apply_select.php" class="bg-white rounded-lg shadow-sm border p-6 hover:shadow-md transition-shadow">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                        <i class="fas fa-plus text-blue-600"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold text-slate-900">New Application</h3>
                        <p class="text-sm text-slate-600">Create new lead</p>
                    </div>
                </div>
            </a>
            <a href="../admin/payouts.php" class="bg-white rounded-lg shadow-sm border p-6 hover:shadow-md transition-shadow">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                        <i class="fas fa-money-bill-wave text-purple-600"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold text-slate-900">View Payouts</h3>
                        <p class="text-sm text-slate-600">Track earnings</p>
                    </div>
                </div>
            </a>
            <a href="../leads/leads_updated.php" class="bg-white rounded-lg shadow-sm border p-6 hover:shadow-md transition-shadow">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                        <i class="fas fa-list text-green-600"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold text-slate-900">Manage Leads</h3>
                        <p class="text-sm text-slate-600">View all leads</p>
                    </div>
                </div>
            </a>
        </div>
</div>

    <!-- Bottom Navigation Bar for Mobile -->
    <?php include '../includes/footer.php'; ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
