<?php
require_once __DIR__ . '/../includes/auth.php';

echo "<h2>Debug Profile Management Access</h2>";
echo "<pre>";
echo "Session data:\n";
print_r($_SESSION);

if (isset($_SESSION['user_id'])) {
    $user = getCurrentUser();
    echo "\nUser data:\n";
    print_r($user);
    
    echo "\nAdmin checks:\n";
    echo "is_admin field: " . ($user['is_admin'] ?? 'not set') . "\n";
    echo "role session: " . ($_SESSION['role'] ?? 'not set') . "\n";
    echo "Admin check 1: " . (isset($user['is_admin']) && $user['is_admin'] ? 'true' : 'false') . "\n";
    echo "Admin check 2: " . (($_SESSION['role'] ?? '') === 'admin' ? 'true' : 'false') . "\n";
} else {
    echo "No user session found\n";
}
echo "</pre>";

echo '<a href="profile_management.php">Try Profile Management</a>';
?>