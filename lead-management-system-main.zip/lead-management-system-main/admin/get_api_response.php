<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    exit(json_encode(['error' => 'Unauthorized']));
}

// Check if user is admin
$user = getCurrentUser();
if (!$user || (!isset($user['is_admin']) || !$user['is_admin']) && ($_SESSION['role'] ?? '') !== 'admin') {
    http_response_code(403);
    exit(json_encode(['error' => 'Admin access required']));
}

$userId = $_GET['user_id'] ?? null;
if (!$userId) {
    http_response_code(400);
    exit(json_encode(['error' => 'User ID required']));
}

$database = new Database();
$conn = $database->getConnection();

$stmt = $conn->prepare("SELECT api_response, manual_fix_notes FROM users WHERE id = ?");
$stmt->bind_param('i', $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    http_response_code(404);
    exit(json_encode(['error' => 'User not found']));
}

header('Content-Type: application/json');
echo json_encode([
    'api_response' => (isset($user['api_response']) && $user['api_response']) ? json_decode($user['api_response'], true) : null,
    'manual_fix_notes' => $user['manual_fix_notes'] ?? null
]);
?>