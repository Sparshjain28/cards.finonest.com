<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/role_manager.php';
require_once __DIR__ . '/../config/database_updated.php';

requireLogin();
if (!isAdmin()) {
    http_response_code(403);
    exit();
}

$roleId = (int)$_GET['role_id'];

$database = new Database();
$conn = $database->getConnection();
$roleManager = new RoleManager($conn);

$permissions = $roleManager->getRolePermissions($roleId);

header('Content-Type: application/json');
echo json_encode($permissions);
?>