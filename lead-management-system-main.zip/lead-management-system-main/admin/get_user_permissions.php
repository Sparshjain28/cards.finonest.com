<?php
require_once '../includes/auth.php';
require_once '../includes/role_manager.php';
require_once '../config/database_updated.php';

requireLogin();
if (!isAdmin()) {
    http_response_code(403);
    exit();
}

$userId = (int)($_GET['user_id'] ?? 0);
if (!$userId) {
    http_response_code(400);
    exit();
}

$database = new Database();
$conn = $database->getConnection();
$roleManager = new RoleManager($conn);

// Get user's permissions (both from role and individual)
$permissions = $roleManager->getUserPermissions($userId);
$individualPermissions = $roleManager->getUserSpecificPermissions($userId);

// Combine permissions
$allPermissions = [];
foreach ($permissions as $perm) {
    $allPermissions[] = $perm['name'];
}

// Add individual permissions
foreach ($individualPermissions as $perm) {
    if ($perm['granted']) {
        $allPermissions[] = $perm['name'];
    }
}

header('Content-Type: application/json');
echo json_encode(array_unique($allPermissions));
?>