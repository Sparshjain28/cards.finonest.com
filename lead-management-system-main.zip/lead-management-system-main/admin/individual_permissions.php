<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/role_manager.php';
require_once __DIR__ . '/../config/database_updated.php';

requireLogin();
if (!isAdmin()) {
    header('Location: ../adviser/dashboard.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();
$roleManager = new RoleManager($conn);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_manager_permissions'])) {
        $userId = (int)$_POST['user_id'];
        $permissions = $_POST['permissions'] ?? [];
        
        // Clear existing user permissions
        $conn->query("DELETE FROM user_permissions WHERE user_id = $userId");
        
        // Add new permissions
        foreach ($permissions as $permissionName) {
            $roleManager->setUserPermission($userId, $permissionName, true);
        }
        
        header('Location: individual_permissions.php?success=updated');
        exit();
    }
}

// Get managers only
$managersResult = $conn->query("
    SELECT u.id, u.name, u.email 
    FROM users u 
    JOIN roles r ON u.role_id = r.id 
    WHERE r.name = 'manager'
    ORDER BY u.name
");
$managers = [];
while ($row = $managersResult->fetch_assoc()) {
    $managers[] = $row;
}

$permissions = $roleManager->getAllPermissions();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Individual Manager Permissions - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    
    <div class="w-full max-w-6xl mx-auto px-4 py-8">
        <div class="mb-8">
            <div class="bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-500 p-8 rounded-2xl shadow-2xl">
                <div class="flex items-center gap-6">
                    <div class="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                        <i class="fas fa-user-cog text-white text-2xl"></i>
                    </div>
                    <div>
                        <h1 class="text-3xl font-bold text-white mb-1">Individual Manager Permissions</h1>
                        <p class="text-white/80 text-lg">Customize permissions for each manager individually</p>
                    </div>
                </div>
            </div>
        </div>

        <?php if (isset($_GET['success'])): ?>
        <div class="mb-6 bg-emerald-50 border border-emerald-200 text-emerald-800 px-6 py-4 rounded-xl">
            <i class="fas fa-check-circle mr-2"></i>Manager permissions updated successfully!
        </div>
        <?php endif; ?>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="bg-gradient-to-r from-indigo-50 to-purple-50 px-6 py-5 border-b">
                <h2 class="text-xl font-bold text-slate-800">Configure Manager Permissions</h2>
            </div>
            
            <div class="p-6">
                <form method="POST" id="permissionsForm">
                    <input type="hidden" name="update_manager_permissions" value="1">
                    
                    <div class="mb-6">
                        <label class="block text-sm font-bold text-slate-600 mb-2">Select Manager</label>
                        <select name="user_id" id="managerSelect" required class="w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:border-indigo-500">
                            <option value="">Choose a manager...</option>
                            <?php foreach ($managers as $manager): ?>
                            <option value="<?php echo $manager['id']; ?>">
                                <?php echo htmlspecialchars($manager['name'] . ' (' . $manager['email'] . ')'); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div id="permissionsContainer" class="hidden">
                        <h3 class="text-lg font-bold text-slate-800 mb-4">Customize Permissions</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <?php foreach ($permissions as $category => $perms): ?>
                            <div class="bg-slate-50 p-4 rounded-xl">
                                <h4 class="font-bold text-slate-700 mb-3 flex items-center gap-2">
                                    <i class="fas fa-folder text-indigo-500"></i>
                                    <?php echo ucfirst($category); ?>
                                </h4>
                                <div class="space-y-2">
                                    <?php foreach ($perms as $perm): ?>
                                    <label class="flex items-center gap-3 p-2 hover:bg-white rounded-lg cursor-pointer">
                                        <input type="checkbox" name="permissions[]" value="<?php echo $perm['name']; ?>" 
                                               class="w-4 h-4 text-indigo-600 border-2 border-slate-300 rounded focus:ring-indigo-500">
                                        <div>
                                            <span class="font-medium text-slate-700"><?php echo htmlspecialchars($perm['display_name']); ?></span>
                                            <p class="text-xs text-slate-500"><?php echo htmlspecialchars($perm['name']); ?></p>
                                        </div>
                                    </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="mt-6">
                            <button type="submit" class="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-4 rounded-xl hover:from-indigo-700 hover:to-purple-700 font-bold transition-all shadow-lg">
                                <i class="fas fa-save mr-2"></i>Save Manager Permissions
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    document.getElementById('managerSelect').addEventListener('change', function() {
        const managerId = this.value;
        const container = document.getElementById('permissionsContainer');
        
        if (!managerId) {
            container.classList.add('hidden');
            return;
        }
        
        // Load current permissions
        fetch(`get_user_permissions.php?user_id=${managerId}`)
            .then(response => response.json())
            .then(permissions => {
                // Uncheck all first
                document.querySelectorAll('input[name="permissions[]"]').forEach(cb => cb.checked = false);
                
                // Check current permissions
                permissions.forEach(perm => {
                    const checkbox = document.querySelector(`input[value="${perm}"]`);
                    if (checkbox) checkbox.checked = true;
                });
                
                container.classList.remove('hidden');
            })
            .catch(error => {
                console.error('Error loading permissions:', error);
                container.classList.remove('hidden');
            });
    });
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>