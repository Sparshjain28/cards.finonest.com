<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/role_manager.php';
require_once __DIR__ . '/../config/database_updated.php';

requireLogin();
if (!isAdmin()) {
    header('Location: ../adviser/dashboard.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();
$roleManager = new RoleManager($conn);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['assign_manager'])) {
        $managerId = !empty($_POST['manager_id']) ? (int)$_POST['manager_id'] : null;
        
        if (isset($_POST['select_all']) && $_POST['select_all'] === '1') {
            $stmt = $conn->prepare("UPDATE users SET assigned_manager_id = ?");
            $stmt->bind_param('i', $managerId);
        } else {
            $userId = (int)$_POST['user_id'];
            $stmt = $conn->prepare("UPDATE users SET assigned_manager_id = ? WHERE id = ?");
            $stmt->bind_param('ii', $managerId, $userId);
        }
        
        if ($stmt->execute()) {
            header('Location: manager_assignments.php?success=assigned');
        } else {
            header('Location: manager_assignments.php?error=assignment_failed');
        }
        exit();
    }
}

// Get all users with their current manager assignments
$usersResult = $conn->query("
    SELECT u.id, u.name, u.email, r.display_name as role_name,
           m.name as manager_name, m.id as manager_id
    FROM users u 
    LEFT JOIN roles r ON u.role_id = r.id 
    LEFT JOIN users m ON u.assigned_manager_id = m.id
    ORDER BY u.name
");
$users = [];
while ($row = $usersResult->fetch_assoc()) {
    $users[] = $row;
}

// Get all managers (users with manager role)
$managersResult = $conn->query("
    SELECT u.id, u.name, u.email 
    FROM users u 
    JOIN roles r ON u.role_id = r.id 
    WHERE r.name = 'manager'
    ORDER BY u.name
");
$managers = [];
while ($row = $managersResult->fetch_assoc()) {
    $managers[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Assignments - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/css/tom-select.bootstrap5.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/js/tom-select.complete.min.js"></script>
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    
    <div class="w-full max-w-7xl mx-auto px-4 py-8">
        <!-- Hero Banner -->
        <div class="mb-8">
            <div class="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-500 p-8 shadow-2xl">
                <div class="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full -mr-48 -mt-48 blur-3xl"></div>
                <div class="relative z-10 flex items-center gap-6">
                    <div class="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-lg">
                        <i class="fas fa-users-cog text-white text-2xl"></i>
                    </div>
                    <div>
                        <h1 class="text-3xl font-bold text-white mb-1">Manager Assignments</h1>
                        <p class="text-white/80 text-lg">Assign users to managers for hierarchical access control</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Notifications -->
        <?php if (isset($_GET['success'])): ?>
        <div class="mb-6 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 text-emerald-800 px-6 py-4 rounded-xl flex items-center shadow-sm">
            <i class="fas fa-check-circle text-emerald-600 text-lg mr-4"></i>
            <span><strong>Success!</strong> Manager assignment updated successfully.</span>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['error'])): ?>
        <div class="mb-6 bg-gradient-to-r from-red-50 to-pink-50 border border-red-200 text-red-800 px-6 py-4 rounded-xl flex items-center shadow-sm">
            <i class="fas fa-exclamation-circle text-red-600 text-lg mr-4"></i>
            <span><strong>Error!</strong> Failed to update assignment. Please try again.</span>
        </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 xl:grid-cols-3 gap-8">
            <!-- Assignment Form -->
            <div class="xl:col-span-1">
                <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
                    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 px-6 py-5 border-b border-slate-100">
                        <h2 class="text-xl font-bold text-slate-800 flex items-center gap-3">
                            <i class="fas fa-user-plus text-blue-600"></i>
                            Assign Manager
                        </h2>
                    </div>
                    
                    <div class="p-6">
                        <form method="POST">
                            <input type="hidden" name="assign_manager" value="1">
                            
                            <div class="mb-4">
                                <label class="block text-sm font-bold text-slate-600 mb-2">
                                    <i class="fas fa-user mr-1 text-blue-500"></i> Select User
                                </label>
                                <select name="user_id" id="user-select">
                                    <option value="">Choose a user...</option>
                                    <option value="all">✓ Select All Users</option>
                                    <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user['id']; ?>">
                                        <?php echo htmlspecialchars($user['name'] . ' (' . $user['email'] . ')'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="hidden" name="select_all" id="select-all-input" value="0">
                            </div>
                            
                            <div class="mb-6">
                                <label class="block text-sm font-bold text-slate-600 mb-2">
                                    <i class="fas fa-user-tie mr-1 text-indigo-500"></i> Assign Manager
                                </label>
                                <select name="manager_id" id="manager-select">
                                    <option value="">No Manager (Remove Assignment)</option>
                                    <?php foreach ($managers as $manager): ?>
                                    <option value="<?php echo $manager['id']; ?>">
                                        <?php echo htmlspecialchars($manager['name'] . ' (' . $manager['email'] . ')'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <button type="submit" class="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-indigo-700 font-bold transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2">
                                <i class="fas fa-save"></i> Update Assignment
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Users List -->
            <div class="xl:col-span-2">
                <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
                    <div class="bg-gradient-to-r from-purple-50 to-pink-50 px-6 py-5 border-b border-slate-100">
                        <h2 class="text-xl font-bold text-slate-800 flex items-center gap-3">
                            <i class="fas fa-users text-purple-600"></i>
                            Current Assignments
                        </h2>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-slate-50">
                                <tr>
                                    <th class="px-6 py-4 text-left text-xs font-bold text-slate-600 uppercase tracking-wider">User</th>
                                    <th class="px-6 py-4 text-left text-xs font-bold text-slate-600 uppercase tracking-wider">Role</th>
                                    <th class="px-6 py-4 text-left text-xs font-bold text-slate-600 uppercase tracking-wider">Assigned Manager</th>
                                    <th class="px-6 py-4 text-left text-xs font-bold text-slate-600 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-200">
                                <?php foreach ($users as $user): ?>
                                <tr class="hover:bg-slate-50 transition-colors">
                                    <td class="px-6 py-4">
                                        <div class="flex items-center gap-3">
                                            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 flex items-center justify-center text-slate-600 font-bold text-sm">
                                                <?= strtoupper(substr($user['name'], 0, 2)) ?>
                                            </div>
                                            <div>
                                                <div class="font-semibold text-slate-800"><?php echo htmlspecialchars($user['name']); ?></div>
                                                <div class="text-sm text-slate-500"><?php echo htmlspecialchars($user['email']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <?php 
                                        $roleColor = 'bg-gray-100 text-gray-700';
                                        $roleName = strtolower($user['role_name'] ?? '');
                                        if (strpos($roleName, 'admin') !== false) $roleColor = 'bg-red-100 text-red-700';
                                        elseif (strpos($roleName, 'manager') !== false) $roleColor = 'bg-orange-100 text-orange-700';
                                        elseif (strpos($roleName, 'adviser') !== false) $roleColor = 'bg-emerald-100 text-emerald-700';
                                        ?>
                                        <span class="px-3 py-1 text-xs font-bold rounded-full <?php echo $roleColor; ?>">
                                            <?php echo htmlspecialchars($user['role_name'] ?? 'No Role'); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4">
                                        <?php if ($user['manager_name']): ?>
                                            <div class="flex items-center gap-2">
                                                <i class="fas fa-user-tie text-indigo-500"></i>
                                                <span class="font-medium text-slate-700"><?php echo htmlspecialchars($user['manager_name']); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-slate-400 italic">No manager assigned</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4">
                                        <button onclick="editAssignment(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['name']); ?>', <?php echo $user['manager_id'] ?? 'null'; ?>)" 
                                                class="text-blue-600 hover:text-blue-800 font-medium text-sm flex items-center gap-1">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>

    <script>
    const userSelect = new TomSelect("#user-select", {
        create: false,
        sortField: { field: "text", direction: "asc" },
        onChange: function(value) {
            document.getElementById('select-all-input').value = value === 'all' ? '1' : '0';
        }
    });
    
    const managerSelect = new TomSelect("#manager-select", {
        create: false,
        sortField: { field: "text", direction: "asc" }
    });

    function editAssignment(userId, userName, currentManagerId) {
        userSelect.setValue(userId);
        managerSelect.setValue(currentManagerId || '');
        document.querySelector('form').scrollIntoView({ behavior: 'smooth' });
    }
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>