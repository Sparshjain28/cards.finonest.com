<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

requireLogin();

$database = new Database();
$conn = $database->getConnection();
$user = getCurrentUser();

// Handle notice creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_notice'])) {
    $title = $_POST['title'];
    $message = $_POST['message'];
    $type = $_POST['type'];
    $visibility = $_POST['visibility'];
    $expires_at = !empty($_POST['expires_at']) ? $_POST['expires_at'] : null;
    
    // Add visibility column if it doesn't exist
    $check_column = $conn->query("SHOW COLUMNS FROM notices LIKE 'visibility'");
    if ($check_column->num_rows == 0) {
        $conn->query("ALTER TABLE notices ADD COLUMN visibility ENUM('all', 'channel_partner', 'network_program', 'advisor', 'full') DEFAULT 'all' AFTER type");
    }
    
    // Add is_active column if it doesn't exist
    $check_active = $conn->query("SHOW COLUMNS FROM notices LIKE 'is_active'");
    if ($check_active->num_rows == 0) {
        $conn->query("ALTER TABLE notices ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER visibility");
    }
    
    $stmt = $conn->prepare("INSERT INTO notices (title, message, type, visibility, is_active, created_by, expires_at) VALUES (?, ?, ?, ?, 1, ?, ?)");
    $stmt->bind_param('ssssii', $title, $message, $type, $visibility, $user['id'], $expires_at);
    $stmt->execute();
    $stmt->close();
    
    header("Location: notices.php?created=1");
    exit;
}

// Handle notice deletion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    // First delete related records in user_notice_reads
    $stmt = $conn->prepare("DELETE FROM user_notice_reads WHERE notice_id = ?");
    $stmt->bind_param('i', $_GET['delete']);
    $stmt->execute();
    $stmt->close();
    
    // Then delete the notice
    $stmt = $conn->prepare("DELETE FROM notices WHERE id = ?");
    $stmt->bind_param('i', $_GET['delete']);
    $stmt->execute();
    $stmt->close();
    
    header("Location: notices.php?deleted=1");
    exit;
}

// Get all notices
$notices_query = "SELECT n.*, u.name as created_by_name FROM notices n JOIN users u ON n.created_by = u.id ORDER BY n.created_at DESC";
$notices = $conn->query($notices_query)->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Notices</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include __DIR__ . '/../includes/header.php'; ?>

    <main class="w-full mx-auto py-6 px-4">
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-slate-900">Manage Important Notices</h1>
        </div>

        <!-- Create Notice Form -->
        <div class="bg-white rounded-lg shadow border p-6 mb-6">
            <h2 class="text-lg font-semibold mb-4">Create New Notice</h2>
            <form method="POST">
                <input type="hidden" name="create_notice" value="1">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-2">Title</label>
                        <input type="text" name="title" required class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-2">Type</label>
                        <select name="type" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            <option value="info">Info</option>
                            <option value="warning">Warning</option>
                            <option value="success">Success</option>
                            <option value="error">Error</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-2">Visibility</label>
                        <select name="visibility" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            <option value="all">All Users</option>
                            <option value="channel_partner">Channel Partner Only</option>
                            <option value="network_program">Network Program Only</option>
                            <option value="advisor">Advisor Only</option>
                            <option value="full">Full Access Only</option>
                        </select>
                    </div>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-slate-700 mb-2">Message</label>
                    <textarea name="message" rows="3" required class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500"></textarea>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-slate-700 mb-2">Expires At (Optional)</label>
                    <input type="datetime-local" name="expires_at" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
                    <i class="fas fa-plus mr-2"></i>Create Notice
                </button>
            </form>
        </div>

        <!-- Notices List -->
        <div class="bg-white rounded-lg shadow border">
            <div class="px-6 py-4 border-b">
                <h2 class="text-lg font-semibold">Active Notices</h2>
            </div>
            <div class="divide-y">
                <?php foreach ($notices as $notice): ?>
                    <div class="p-6">
                        <div class="flex justify-between items-start">
                            <div class="flex-1">
                                <div class="flex items-center gap-2 mb-2">
                                    <span class="px-2 py-1 text-xs rounded-full <?php 
                                        echo $notice['type'] === 'info' ? 'bg-blue-100 text-blue-800' : 
                                            ($notice['type'] === 'warning' ? 'bg-yellow-100 text-yellow-800' : 
                                            ($notice['type'] === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800')); 
                                    ?>">
                                        <?= ucfirst($notice['type']) ?>
                                    </span>
                                    <?php if (isset($notice['visibility'])): ?>
                                    <span class="px-2 py-1 text-xs rounded-full bg-gray-100 text-gray-800">
                                        <?= ucfirst(str_replace('_', ' ', $notice['visibility'])) ?>
                                    </span>
                                    <?php endif; ?>
                                    <span class="text-sm text-slate-500">by <?= htmlspecialchars($notice['created_by_name']) ?></span>
                                </div>
                                <h3 class="font-semibold text-slate-900 mb-2"><?= htmlspecialchars($notice['title']) ?></h3>
                                <p class="text-slate-600 mb-2"><?= htmlspecialchars($notice['message']) ?></p>
                                <div class="text-xs text-slate-500">
                                    Created: <?= date('M d, Y H:i', strtotime($notice['created_at'])) ?>
                                    <?php if ($notice['expires_at']): ?>
                                        | Expires: <?= date('M d, Y H:i', strtotime($notice['expires_at'])) ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <a href="?delete=<?= $notice['id'] ?>" onclick="return confirm('Delete this notice?')" 
                               class="text-red-600 hover:text-red-800 ml-4">
                                <i class="fas fa-trash"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </main>

    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>