<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../includes/notices_component.php';
require_once __DIR__ . '/../includes/notification_helper.php';

// Check if PhpSpreadsheet is available
$hasPhpSpreadsheet = false;
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
    $hasPhpSpreadsheet = class_exists('PhpOffice\\PhpSpreadsheet\\Spreadsheet');
}

requireLogin();

if (!isAdmin() && !isManager() && !hasPermission('view_payouts')) {
    $_SESSION['error_message'] = 'Access Denied: You do not have permission to view payouts.';
    header('Location: ../adviser/dashboard.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();

// Add role manager for filtering
require_once __DIR__ . '/../includes/role_manager.php';
$roleManager = new RoleManager($conn);
$isCurrentUserAdmin = isAdmin();
$isCurrentUserManager = isManager();
$currentUserId = $_SESSION['user_id'];

// Get manager's team if not admin
$managerFilter = '';
if ($isCurrentUserManager && !$isCurrentUserAdmin) {
    $managerFilter = " AND u.assigned_manager_id = $currentUserId";
}

        // Handle notice dismissal
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dismiss_notice'])) {
            $user = getCurrentUser();
            markNoticeAsRead($conn, $user['id'], $_POST['dismiss_notice']);
            exit;
        }

        // Handle CSV/Excel export
        if (isset($_GET['export']) && $_GET['export'] === 'csv') {
            exportPayoutReport($conn, $_GET);
            exit;
        }

        // Handle Excel export
        if (isset($_GET['export']) && $_GET['export'] === 'excel') {
            exportPayoutReportExcel($conn, $_GET);
            exit;
        }

        // Export function
        function exportPayoutReport($conn, $params = []) {
            global $hasPhpSpreadsheet, $managerFilter;
            
            $filter = $params['filter'] ?? 'all';
            $whereClause = "WHERE u.is_admin = 0 AND (l.status IN ('activated', 'disbursed') OR (l.status = 'approved' AND l.activation_status = 'Active'))" . $managerFilter;
            if ($filter === 'pending') {
                $whereClause .= " AND p.status = 'pending'";
            } elseif ($filter === 'paid') {
                $whereClause .= " AND p.status = 'paid'";
            }
            
            $query = "SELECT DISTINCT
                u.name as advisor_name,
                u.account_number,
                u.bank_name,
                u.ifsc_code,
                u.pan_number,
                p.status as payment_status,
                (p.commission_amount - COALESCE(p.deduction_amount, 0)) as lead_amount,
                l.lead_id,
                l.customer_name,
                pr.name as product_name,
                pr.variant as product_variant,
                COALESCE(pr.payout_source, 'Direct Lead') as payout_source,
                COALESCE(pr.bank_redirect_url, 'N/A') as product_link
            FROM payouts p
            JOIN leads l ON p.lead_id = l.id
            JOIN products pr ON l.product_id = pr.id
            JOIN users u ON l.channel_code = u.channel_code
            $whereClause
            ORDER BY u.name, p.created_at DESC";
            
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            
            if ($hasPhpSpreadsheet) {
                // Create Excel file using fully qualified class names
                $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();
                
                // Set headers
                $headers = ['Advisor Name', 'Account Number', 'Bank Name', 'IFSC Code', 'PAN Number', 'Payment Status', 'Lead Amount', 'Lead ID', 'Customer Name', 'Product Name', 'Variant', 'Payout Source', 'Product Link'];
                $sheet->fromArray($headers, null, 'A1');
                
                // Style headers
                $headerStyle = [
                    'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                    'fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['rgb' => '4F46E5']]
                ];
                $sheet->getStyle('A1:M1')->applyFromArray($headerStyle);
                
                // Add data
                $row = 2;
                foreach ($results as $data) {
                    $sheet->fromArray(array_values($data), null, 'A' . $row);
                    $row++;
                }
                
                // Auto-size columns
                foreach (range('A', 'M') as $col) {
                    $sheet->getColumnDimension($col)->setAutoSize(true);
                }
                
                // Output file
                $filename = 'payout_report_' . $filter . '_' . date('Y-m-d') . '.xlsx';
                
                // Clear any previous output
                if (ob_get_level()) {
                    ob_end_clean();
                }
                
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment; filename="' . $filename . '"');
                header('Cache-Control: max-age=0');
                header('Pragma: public');
                
                $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
                $writer->save('php://output');
                exit;
            } else {
                // Fallback to CSV
                exportPayoutReportExcel($conn, $params);
            }
        }

        // Simple CSV export function
        function exportPayoutReportExcel($conn, $params = []) {
            global $managerFilter;
            $filter = $params['filter'] ?? 'all';
            $whereClause = "WHERE u.is_admin = 0 AND (l.status IN ('activated', 'disbursed') OR (l.status = 'approved' AND l.activation_status = 'Active'))" . $managerFilter;
            if ($filter === 'pending') {
                $whereClause .= " AND p.status = 'pending'";
            } elseif ($filter === 'paid') {
                $whereClause .= " AND p.status = 'paid'";
            }
            
            $query = "SELECT DISTINCT
                u.name as advisor_name,
                u.account_number,
                u.bank_name,
                u.ifsc_code,
                u.pan_number,
                p.status as payment_status,
                (p.commission_amount - COALESCE(p.deduction_amount, 0)) as lead_amount,
                l.lead_id,
                l.customer_name,
                pr.name as product_name,
                pr.variant as product_variant,
                COALESCE(pr.payout_source, 'Direct Lead') as payout_source,
                COALESCE(pr.bank_redirect_url, 'N/A') as product_link
            FROM payouts p
            JOIN leads l ON p.lead_id = l.id
            JOIN products pr ON l.product_id = pr.id
            JOIN users u ON l.channel_code = u.channel_code
            $whereClause
            ORDER BY u.name, p.created_at DESC";
            
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            
            // Clear any previous output
            if (ob_get_level()) {
                ob_end_clean();
            }
            
            $filename = 'payout_report_' . $filter . '_' . date('Y-m-d') . '.csv';
            
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: max-age=0');
            
            $output = fopen('php://output', 'w');
            
            // Add headers
            fputcsv($output, ['Advisor Name', 'Account Number', 'Bank Name', 'IFSC Code', 'PAN Number', 'Payment Status', 'Lead Amount', 'Lead ID', 'Customer Name', 'Product Name', 'Variant', 'Payout Source', 'Product Link']);
            
            // Add data
            foreach ($results as $row) {
                fputcsv($output, array_values($row));
            }
            
            fclose($output);
            exit;
        }

        // Handle payout deduction update
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_payout_deduction'])) {
            $payout_id = (int)$_POST['payout_id'];
            $deduction_amount = (float)$_POST['deduction_amount'];
            $stmt = $conn->prepare("UPDATE payouts SET deduction_amount = ? WHERE id = ?");
            $stmt->bind_param('di', $deduction_amount, $payout_id);
            $stmt->execute();
            $stmt->close();
            header("Location: payouts.php?updated=1");
            exit;
        }

        // Handle payout remark update
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_payout_remark'])) {
            $payout_id = (int)$_POST['payout_id'];
            $payout_remark = $_POST['payout_remark'] ?? '';
            $stmt = $conn->prepare("UPDATE payouts SET payout_remark = ? WHERE id = ?");
            $stmt->bind_param('si', $payout_remark, $payout_id);
            $stmt->execute();
            $stmt->close();
            header("Location: payouts.php?updated=1");
            exit;
        }

        // Handle payout status update
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_payout_status'])) {
            $payout_id = (int)$_POST['payout_id'];
            $status = $_POST['status'];
            
            // Get payout and user details for notification
            $payout_query = "SELECT p.commission_amount, l.lead_id, u.email FROM payouts p JOIN leads l ON p.lead_id = l.id JOIN users u ON l.channel_code = u.channel_code WHERE p.id = ? LIMIT 1";
            $payout_stmt = $conn->prepare($payout_query);
            $payout_stmt->bind_param('i', $payout_id);
            $payout_stmt->execute();
            $payout_data = $payout_stmt->get_result()->fetch_assoc();
            $payout_stmt->close();
            
            $stmt = $conn->prepare("UPDATE payouts SET status = ? WHERE id = ?");
            $stmt->bind_param('si', $status, $payout_id);
            $stmt->execute();
            $stmt->close();
            
            // Send notification if marked as paid
            if ($status === 'paid' && $payout_data) {
                notifyUser('payout_processed', $payout_data['email'], [
                    'amount' => $payout_data['commission_amount'],
                    'payout_id' => $payout_data['lead_id']
                ]);
            }
            
            header("Location: payouts.php?updated=1");
            exit;
        }

        // Get payout summary for non-admin users only
        $user = getCurrentUser();
        $current_user_id = $user['id'] ?? null;

        // Exclude direct bonus amounts for normal advisors. Referral bonuses are handled separately.
        $summary_query = "SELECT 
            SUM(CASE WHEN p.status = 'pending' THEN p.commission_amount ELSE 0 END) as pending,
            SUM(CASE WHEN p.status = 'paid' AND MONTH(p.payout_date) = MONTH(CURDATE()) AND YEAR(p.payout_date) = YEAR(CURDATE()) THEN p.commission_amount ELSE 0 END) as paid_this_month,
            SUM(CASE WHEN p.status = 'paid' THEN p.commission_amount ELSE 0 END) as total_paid,
            COUNT(DISTINCT u.id) as total_users,
            COUNT(p.id) as total_payouts
        FROM payouts p
        JOIN leads l ON p.lead_id = l.id
        JOIN products pr ON l.product_id = pr.id
        JOIN users u ON l.channel_code = u.channel_code
        WHERE u.is_admin = 0" . $managerFilter;;

        $summary_stmt = $conn->prepare($summary_query);
        $summary_stmt->execute();
        $summary = $summary_stmt->get_result()->fetch_assoc();
        $summary_stmt->close();

        // Get referral bonus summary for the current user
        $referral_summary = [
            'total_referred_members' => 0,
            'total_referral_sales' => 0,
            'your_bonus' => 0
        ];

        if ($current_user_id) {
            $referral_query = "SELECT 
                COUNT(DISTINCT ru.referred_user_id) as total_referred_members,
                SUM(CASE WHEN l.status IN ('activated','disbursed') THEN p.commission_amount ELSE 0 END) as total_referral_sales
            FROM referral_users ru
            JOIN users u_referred ON ru.referred_user_id = u_referred.id
            JOIN leads l ON u_referred.channel_code = l.channel_code
            JOIN payouts p ON l.id = p.lead_id
            WHERE ru.referrer_user_id = ? AND l.status IN ('activated','disbursed')";

            $referral_stmt = $conn->prepare($referral_query);
            $referral_stmt->bind_param('i', $current_user_id);
            $referral_stmt->execute();
            $referral_result = $referral_stmt->get_result()->fetch_assoc();
            $referral_stmt->close();

            if ($referral_result) {
                $referral_summary['total_referred_members'] = $referral_result['total_referred_members'] ?? 0;
                $referral_summary['total_referral_sales'] = $referral_result['total_referral_sales'] ?? 0;
            }
        }

        // Get filter parameter
        $filter = $_GET['filter'] ?? 'all';

        // Build WHERE clause based on filter
        $whereClause = "WHERE u.is_admin = 0 AND (l.status IN ('activated', 'disbursed') OR (l.status = 'approved' AND l.activation_status = 'Active'))" . $managerFilter;
        if ($filter === 'pending') {
            $whereClause .= " AND p.status = 'pending'";
        } elseif ($filter === 'paid') {
            $whereClause .= " AND p.status = 'paid'";
        }

        // Get lead-wise payout details - Only for approved + active cards
        $payouts_query = "SELECT DISTINCT
            p.id,
            p.commission_amount,
            p.deduction_amount,
            p.payout_remark,
            p.status,
            p.payout_date,
            p.created_at,
            l.id as lead_db_id,
            l.lead_id,
            l.customer_name,
            l.status as lead_status,
            l.activation_status,
            l.channel_code,
            l.cust_type,
            l.bkyc_status,
            pr.name as product_name,
            pr.variant as product_variant,
            pr.category,
            pr.commission_rate,
            u.name as user_name,
            u.email as user_email,
            u.user_type,
            u.bank_name,
            u.account_number,
            u.ifsc_code,
            u.pan_number,
            u.aadhar_number,
            0 as team_earning
        FROM payouts p
        JOIN leads l ON p.lead_id = l.id
        JOIN products pr ON l.product_id = pr.id
        JOIN users u ON l.channel_code = u.channel_code
        $whereClause
        ORDER BY p.created_at DESC";

        $payouts_stmt = $conn->prepare($payouts_query);
        $payouts_stmt->execute();
        $payouts = $payouts_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $payouts_stmt->close();
        
        // Apply HDFC payout logic for display
        foreach ($payouts as &$payout) {
            if ($payout['category'] === 'Credit Card' && stripos($payout['product_name'], 'HDFC') !== false) {
                // Rule 1: ETB customer gets ₹1000 payout
                if (!empty($payout['cust_type']) && $payout['cust_type'] === 'ETB') {
                    $payout['commission_amount'] = 1000;
                }
                
                // Rule 2: BKYC completed gets ₹320 deduction
                if (!empty($payout['bkyc_status']) && $payout['bkyc_status'] === 'COMPLETED') {
                    $payout['deduction_amount'] = 320;
                }
            }
        }

        $user_referral_bonuses = [];
        $admin_show_bonus_header = false;

        function getStatusBadge($status) {
            $badges = [
                'pending' => 'bg-yellow-100 text-yellow-800',
                'paid' => 'bg-green-100 text-green-800',
                'cancelled' => 'bg-red-100 text-red-800'
            ];
            return $badges[$status] ?? 'bg-gray-100 text-gray-800';
        }

        function isLeadComplete($lead) {
            $status = $lead['lead_status'] ?? '';
            $activation_status = $lead['activation_status'] ?? '';
            return in_array($status, ['activated', 'disbursed']) || ($status === 'approved' && $activation_status === 'Active');
        }

        function getLeadDisplayStatus($lead) {
            if (isLeadComplete($lead)) {
                return 'Complete';
            }
            return ucwords(str_replace('_', ' ', $lead['lead_status'] ?? ''));
        }

        function getLeadStatusBadge($lead) {
            if (isLeadComplete($lead)) {
                return 'bg-blue-100 text-blue-800';
            }
            $status_colors = [
                'generated' => 'bg-blue-100 text-blue-800',
                'yet_to_start' => 'bg-gray-100 text-gray-800',
                'in_process' => 'bg-yellow-100 text-yellow-800',
                'approved' => 'bg-green-100 text-green-800',
                'declined' => 'bg-red-100 text-red-800',
                'activated' => 'bg-purple-100 text-purple-800',
                'disbursed' => 'bg-indigo-100 text-indigo-800'
            ];
            return $status_colors[$lead['lead_status'] ?? ''] ?? 'bg-gray-100 text-gray-800';
        }
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Payouts & Commission Tracking</title>
            <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        </head>
        <body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
            <!-- Loading Spinner -->
            <div id="loadingSpinner" class="fixed inset-0 bg-white bg-opacity-75 flex items-center justify-center z-50">
                <div class="flex flex-col items-center">
                    <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                    <p class="mt-3 text-sm text-gray-600">Loading payouts...</p>
                </div>
            </div>
            
            <?php include __DIR__ . '/../includes/header.php'; ?>

            <main class="w-full mx-auto py-6">
                <?php 
                $user = getCurrentUser();
                $notices = getActiveNotices($conn, $user['id']);
                echo renderNotices($notices);
                ?>
                
                <!-- Header with Filters and Actions -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
                    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div>
                            <h1 class="text-2xl font-bold text-slate-800">User Payouts</h1>
                            <p class="text-sm text-gray-500 mt-1">Manage and track all user payouts and commissions</p>
                        </div>
                        
                        <div class="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
                            <!-- Search Box -->
                            <div class="relative flex-1 md:w-64">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-search text-gray-400"></i>
                                </div>
                                <input type="text" id="searchInput" placeholder="Search payouts..." 
                                    class="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                                    onkeyup="filterTable()">
                            </div>
                            
                            <!-- Filter Dropdown -->
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-filter text-gray-400 text-sm"></i>
                                </div>
                                <select id="statusFilter" onchange="filterPayouts()" 
                                    class="appearance-none pl-10 pr-8 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm bg-white">
                                    <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>All Records</option>
                                    <option value="pending" <?= $filter === 'pending' ? 'selected' : '' ?>>Pending Only</option>
                                    <option value="paid" <?= $filter === 'paid' ? 'selected' : '' ?>>Paid Only</option>
                                </select>
                                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                                    <i class="fas fa-chevron-down text-xs"></i>
                                </div>
                            </div>
                            
                            <!-- Action Buttons -->
                            <div class="flex items-center gap-2">
                                <!-- Referral Payouts Button -->
                                <button onclick="window.location.href='referral_payouts.php'" 
                                    class="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-all duration-200 text-sm font-medium shadow-sm hover:shadow-md">
                                    <i class="fas fa-users"></i>
                                    <span class="hidden sm:inline">Referral Payouts</span>
                                    <span class="sm:hidden">Referrals</span>
                                </button>
                                
                                <!-- Export Dropdown -->
                                <div class="relative group">
                                    <button class="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-3 py-2 rounded-lg flex items-center gap-2 transition-colors text-sm font-medium">
                                        <i class="fas fa-download"></i>
                                        <span class="hidden sm:inline">Export</span>
                                        <i class="fas fa-chevron-down text-xs ml-1"></i>
                                    </button>
                                    <div class="absolute right-0 mt-1 w-36 bg-white rounded-md shadow-lg border border-gray-200 z-10 hidden group-hover:block">
                                        <div class="py-1">
                                            <a href="#" onclick="downloadReport('csv')" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                <i class="fas fa-file-csv text-green-600 mr-2"></i>Export as CSV
                                            </a>
                                            <a href="#" onclick="downloadReport('excel')" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                                <i class="fas fa-file-excel text-blue-600 mr-2"></i>Export as Excel
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Active Filters (can be added dynamically) -->
                    <div id="activeFilters" class="flex flex-wrap gap-2 mt-3">
                        <?php if ($filter && $filter !== 'all'): ?>
                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            <?= ucfirst($filter) ?> Only
                            <button onclick="clearFilter()" class="ml-1.5 text-blue-500 hover:text-blue-700">
                                <i class="fas fa-times"></i>
                            </button>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Payout Summary Cards -->
                <div class="mb-8">
                    <!-- Mobile Carousel for Stats -->
                    <div class="md:hidden overflow-x-auto pb-4 -mx-2 px-2">
                        <div class="flex space-x-4 w-max min-w-full">
                            <!-- Pending Payouts -->
                            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 w-40 flex-shrink-0">
                                <div class="flex items-center justify-between mb-2">
                                    <div class="p-2 rounded-lg bg-yellow-50 text-yellow-600">
                                        <i class="fas fa-hourglass-half text-lg"></i>
                                    </div>
                                    <span class="text-xs font-medium text-yellow-600 bg-yellow-50 px-2 py-1 rounded-full">Pending</span>
                                </div>
                                <p class="text-xs text-gray-500 mb-1">Pending Payouts</p>
                                <p class="text-xl font-bold text-gray-900">₹<?= number_format($summary['pending'] ?? 0) ?></p>
                            </div>

                            <!-- Paid This Month -->
                            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 w-40 flex-shrink-0">
                                <div class="flex items-center justify-between mb-2">
                                    <div class="p-2 rounded-lg bg-blue-50 text-blue-600">
                                        <i class="fas fa-calendar-check text-lg"></i>
                                    </div>
                                    <span class="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full">This Month</span>
                                </div>
                                <p class="text-xs text-gray-500 mb-1">Paid This Month</p>
                                <p class="text-xl font-bold text-gray-900">₹<?= number_format($summary['paid_this_month'] ?? 0) ?></p>
                            </div>

                            <!-- Total Paid -->
                            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 w-40 flex-shrink-0">
                                <div class="flex items-center justify-between mb-2">
                                    <div class="p-2 rounded-lg bg-green-50 text-green-600">
                                        <i class="fas fa-wallet text-lg"></i>
                                    </div>
                                    <span class="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">Total</span>
                                </div>
                                <p class="text-xs text-gray-500 mb-1">Total Paid</p>
                                <p class="text-xl font-bold text-gray-900">₹<?= number_format($summary['total_paid'] ?? 0) ?></p>
                            </div>

                            <!-- Total Users -->
                            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 w-40 flex-shrink-0">
                                <div class="flex items-center justify-between mb-2">
                                    <div class="p-2 rounded-lg bg-purple-50 text-purple-600">
                                        <i class="fas fa-users text-lg"></i>
                                    </div>
                                    <span class="text-xs font-medium text-purple-600 bg-purple-50 px-2 py-1 rounded-full">Users</span>
                                </div>
                                <p class="text-xs text-gray-500 mb-1">Total Users</p>
                                <p class="text-xl font-bold text-gray-900"><?= number_format($summary['total_users'] ?? 0) ?></p>
                            </div>

                            <!-- Team Payouts -->
                            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 w-40 flex-shrink-0">
                                <div class="flex items-center justify-between mb-2">
                                    <div class="p-2 rounded-lg bg-indigo-50 text-indigo-600">
                                        <i class="fas fa-network-wired text-lg"></i>
                                    </div>
                                    <span class="text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-1 rounded-full">Team</span>
                                </div>
                                <p class="text-xs text-gray-500 mb-1">Team Payouts</p>
                                <p class="text-xl font-bold text-gray-900">₹<?= number_format(($summary['pending'] ?? 0) + ($summary['total_paid'] ?? 0)) ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Desktop Grid (Hidden on mobile) -->
                    <div class="hidden md:grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                        <!-- Pending Payouts -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 hover:shadow-md transition-shadow duration-200">
                            <div class="flex items-center justify-between mb-3">
                                <div class="p-2 rounded-lg bg-yellow-50 text-yellow-600">
                                    <i class="fas fa-hourglass-half text-xl"></i>
                                </div>
                                <span class="text-xs font-medium text-yellow-600 bg-yellow-50 px-2 py-1 rounded-full">Pending</span>
                            </div>
                            <p class="text-sm text-gray-500 mb-1">Pending Payouts</p>
                            <p class="text-2xl font-bold text-gray-900">₹<?= number_format($summary['pending'] ?? 0) ?></p>
                        </div>

                        <!-- Paid This Month -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 hover:shadow-md transition-shadow duration-200">
                            <div class="flex items-center justify-between mb-3">
                                <div class="p-2 rounded-lg bg-blue-50 text-blue-600">
                                    <i class="fas fa-calendar-check text-xl"></i>
                                </div>
                                <span class="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full">This Month</span>
                            </div>
                            <p class="text-sm text-gray-500 mb-1">Paid This Month</p>
                            <p class="text-2xl font-bold text-gray-900">₹<?= number_format($summary['paid_this_month'] ?? 0) ?></p>
                        </div>

                        <!-- Total Paid -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 hover:shadow-md transition-shadow duration-200">
                            <div class="flex items-center justify-between mb-3">
                                <div class="p-2 rounded-lg bg-green-50 text-green-600">
                                    <i class="fas fa-wallet text-xl"></i>
                                </div>
                                <span class="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">Total</span>
                            </div>
                            <p class="text-sm text-gray-500 mb-1">Total Paid</p>
                            <p class="text-2xl font-bold text-gray-900">₹<?= number_format($summary['total_paid'] ?? 0) ?></p>
                        </div>

                        <!-- Total Users -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 hover:shadow-md transition-shadow duration-200">
                            <div class="flex items-center justify-between mb-3">
                                <div class="p-2 rounded-lg bg-purple-50 text-purple-600">
                                    <i class="fas fa-users text-xl"></i>
                                </div>
                                <span class="text-xs font-medium text-purple-600 bg-purple-50 px-2 py-1 rounded-full">Users</span>
                            </div>
                            <p class="text-sm text-gray-500 mb-1">Total Users</p>
                            <p class="text-2xl font-bold text-gray-900"><?= number_format($summary['total_users'] ?? 0) ?></p>
                        </div>

                        <!-- Team Payouts -->
                        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 hover:shadow-md transition-shadow duration-200">
                            <div class="flex items-center justify-between mb-3">
                                <div class="p-2 rounded-lg bg-indigo-50 text-indigo-600">
                                    <i class="fas fa-network-wired text-xl"></i>
                                </div>
                                <span class="text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-1 rounded-full">Team</span>
                            </div>
                            <p class="text-sm text-gray-500 mb-1">Team Payouts</p>
                            <p class="text-2xl font-bold text-gray-900">₹<?= number_format(($summary['pending'] ?? 0) + ($summary['total_paid'] ?? 0)) ?></p>
                        </div>
                    </div>
                </div>

                <!-- Payouts Table (Hidden on small screens) -->
                <div class="bg-white rounded-lg shadow border hidden md:block">
                    <div class="overflow-x-auto">
                        <table class="min-w-full">
                            <thead class="bg-slate-50">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">User</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Banking Info</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Lead ID</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Customer</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Product & Variant</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Lead Status</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Commission</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Team Earning</th>
                                    <?php if ($admin_show_bonus_header): ?>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Bonus</th>
                                    <?php endif; ?>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Deduction</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Net Payout</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Remark</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Payout Status</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Payout Date</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-slate-200">
                                <?php foreach ($payouts as $payout): ?>
                                    <tr class="hover:bg-slate-50 payout-row">
                                        <td class="px-4 py-3">
                                            <div class="text-sm text-slate-900 font-medium"><?= htmlspecialchars($payout['user_name']) ?></div>
                                            <div class="text-xs text-slate-500"><?= htmlspecialchars($payout['user_email']) ?></div>
                                        </td>
                                        <td class="px-4 py-3">
                                            <div class="text-xs text-slate-600">
                                                <div><strong>Bank:</strong> <?= htmlspecialchars($payout['bank_name'] ?? 'N/A') ?></div>
                                                <div><strong>A/C:</strong> <?= htmlspecialchars($payout['account_number'] ?? 'N/A') ?></div>
                                                <div><strong>IFSC:</strong> <?= htmlspecialchars($payout['ifsc_code'] ?? 'N/A') ?></div>
                                                <div><strong>PAN:</strong> <?= htmlspecialchars($payout['pan_number'] ?? 'N/A') ?></div>
                                                <div><strong>Aadhar:</strong> <?= htmlspecialchars($payout['aadhar_number'] ?? 'N/A') ?></div>
                                            </div>
                                        </td>
                                        <td class="px-4 py-3 text-sm text-slate-900"><?= htmlspecialchars($payout['lead_id']) ?></td>
                                        <td class="px-4 py-3 text-sm text-slate-900"><?= htmlspecialchars($payout['customer_name']) ?></td>
                                        <td class="px-4 py-3">
                                            <div class="flex items-center">
                                                <i class="fas fa-<?php echo $payout['category'] === 'Credit Card' ? 'credit-card' : 'money-bill-wave'; ?> text-blue-600 mr-2"></i>
                                                <div>
                                                    <span class="text-sm text-slate-900"><?= htmlspecialchars($payout['product_name']) ?></span>
                                                    <?php if (!empty($payout['product_variant'])): ?>
                                                        <div class="text-xs text-slate-500"><?= htmlspecialchars($payout['product_variant']) ?></div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-4 py-3">
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full <?= getLeadStatusBadge($payout) ?>">
                                                <?php if (isLeadComplete($payout)): ?>
                                                    <i class="fas fa-check-double mr-1"></i>
                                                <?php endif; ?>
                                                <?= getLeadDisplayStatus($payout) ?>
                                            </span>
                                        </td>
                                        <td class="px-4 py-3 text-sm text-slate-900">₹<?= number_format($payout['commission_amount']) ?></td>
                                        <td class="px-4 py-3 text-sm text-indigo-600">₹<?= number_format($payout['team_earning'] ?? 0, 2) ?></td>
                                        <?php if ($admin_show_bonus_header): ?>
                                        <td class="px-4 py-3 text-sm text-green-600">₹<?= number_format($payout['bonus_amount'] ?? 0) ?></td>
                                        <?php endif; ?>
                                        <td class="px-4 py-3 text-sm text-red-600">
                                            <form method="POST" class="inline-flex items-center gap-2">
                                                <input type="hidden" name="update_payout_deduction" value="1">
                                                <input type="hidden" name="payout_id" value="<?php echo $payout['id']; ?>">
                                                <input type="number" name="deduction_amount" value="<?php echo $payout['deduction_amount'] ?? 0; ?>" step="0.01" class="w-20 px-2 py-1 text-xs border rounded" placeholder="0.00">
                                                <button type="submit" class="text-xs bg-red-500 text-white px-2 py-1 rounded">Save</button>
                                            </form>
                                        </td>
                                        <td class="px-4 py-3 text-sm font-bold text-slate-900">₹<?= number_format($payout['commission_amount'] - ($payout['deduction_amount'] ?? 0)) ?></td>
                                        <td class="px-4 py-3 text-sm text-slate-600">
                                            <form method="POST" class="inline-flex items-center gap-2">
                                                <input type="hidden" name="update_payout_remark" value="1">
                                                <input type="hidden" name="payout_id" value="<?php echo $payout['id']; ?>">
                                                <input type="text" name="payout_remark" value="<?php echo htmlspecialchars($payout['payout_remark'] ?? ''); ?>" class="w-32 px-2 py-1 text-xs border rounded" placeholder="Remark">
                                                <button type="submit" class="text-xs bg-blue-500 text-white px-2 py-1 rounded">Save</button>
                                            </form>
                                        </td>
                                        <td class="px-4 py-3">
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full <?= getStatusBadge($payout['status']) ?>">
                                                <?php if ($payout['status'] === 'paid'): ?>
                                                    <i class="fas fa-check-circle mr-1"></i>
                                                <?php elseif ($payout['status'] === 'pending'): ?>
                                                    <i class="fas fa-clock mr-1"></i>
                                                <?php endif; ?>
                                                <?= ucfirst($payout['status']) ?>
                                            </span>
                                        </td>
                                        <td class="px-4 py-3">
                                            <div class="flex gap-2">
                                                <?php if ($payout['status'] === 'pending'): ?>
                                                    <form method="POST" class="inline">
                                                        <input type="hidden" name="update_payout_status" value="1">
                                                        <input type="hidden" name="payout_id" value="<?php echo $payout['id']; ?>">
                                                        <input type="hidden" name="status" value="paid">
                                                        <button type="submit" class="bg-green-500 hover:bg-green-600 text-white px-2 py-1 rounded text-xs">
                                                            <i class="fas fa-check mr-1"></i>Mark Paid
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                <form method="POST" class="inline">
                                                    <input type="hidden" name="update_payout_status" value="1">
                                                    <input type="hidden" name="payout_id" value="<?php echo $payout['id']; ?>">
                                                    <select name="status" class="px-2 py-1 text-xs border rounded" onchange="this.form.submit()">
                                                        <option value="pending" <?= $payout['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                                                        <option value="paid" <?= $payout['status'] === 'paid' ? 'selected' : '' ?>>Paid</option>
                                                        <option value="cancelled" <?= $payout['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                                    </select>
                                                </form>
                                            </div>
                                        </td>
                                        <td class="px-4 py-3 text-sm text-slate-500">
                                            <?php echo $payout['payout_date'] ? date('M d, Y', strtotime($payout['payout_date'])) : '-'; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Payouts Mobile Card View (Hidden on larger screens) -->
                <div class="md:hidden space-y-3 px-3 py-2">
                    <?php foreach ($payouts as $payout): 
                        $statusClass = getStatusBadge($payout['status']);
                        $statusIcon = $payout['status'] === 'paid' ? 'fa-check-circle' : 'fa-clock';
                        $categoryIcon = $payout['category'] === 'Credit Card' ? 'fa-credit-card' : 'fa-money-bill-wave';
                        $netPayout = $payout['commission_amount'] - ($payout['deduction_amount'] ?? 0);
                    ?>
                        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden transition-all duration-200 hover:shadow-md">
                            <!-- Card Header -->
                            <div class="p-4 border-b border-gray-100 bg-white">
                                <div class="flex justify-between items-start">
                                    <div class="flex-1 min-w-0">
                                        <h3 class="text-base font-semibold text-gray-900 truncate">
                                            <?= htmlspecialchars($payout['customer_name']) ?>
                                        </h3>
                                        <p class="text-xs text-gray-500 mt-0.5">
                                            <i class="fas <?= $categoryIcon ?> text-blue-500 mr-1"></i>
                                            <?= htmlspecialchars($payout['product_name']) ?>
                                            <?php if (!empty($payout['product_variant'])): ?>
                                                <span class="text-gray-400"> • <?= htmlspecialchars($payout['product_variant']) ?></span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?= $statusClass ?> ml-2">
                                        <i class="fas <?= $statusIcon ?> mr-1"></i>
                                        <?= ucfirst($payout['status']) ?>
                                    </span>
                                </div>
                                <div class="mt-2 flex items-center text-xs text-gray-500">
                                    <span class="inline-flex items-center">
                                        <i class="fas fa-hashtag text-gray-400 mr-1"></i>
                                        <?= htmlspecialchars($payout['lead_id']) ?>
                                    </span>
                                    <span class="mx-2 text-gray-300">•</span>
                                    <span class="inline-flex items-center">
                                        <i class="fas fa-user-tie text-gray-400 mr-1"></i>
                                        <?= htmlspecialchars($payout['user_name']) ?>
                                    </span>
                                </div>
                            </div>
                            
                            <!-- Card Body -->
                            <div class="p-4">
                                <div class="grid grid-cols-2 gap-4 text-sm">
                                    <div class="bg-gray-50 p-2 rounded-lg">
                                        <p class="text-xs text-gray-500 mb-1">Commission</p>
                                        <p class="font-medium text-gray-900">₹<?= number_format($payout['commission_amount']) ?></p>
                                    </div>
                                    <?php if (($payout['bonus_amount'] ?? 0) > 0): ?>
                                    <div class="bg-green-50 p-2 rounded-lg">
                                        <p class="text-xs text-green-600 mb-1">Bonus</p>
                                        <p class="font-medium text-green-700">+ ₹<?= number_format($payout['bonus_amount']) ?></p>
                                    </div>
                                    <?php endif; ?>
                                    <?php if (($payout['deduction_amount'] ?? 0) > 0): ?>
                                    <div class="bg-red-50 p-2 rounded-lg">
                                        <p class="text-xs text-red-600 mb-1">Deduction</p>
                                        <p class="font-medium text-red-700">- ₹<?= number_format($payout['deduction_amount']) ?></p>
                                    </div>
                                    <?php endif; ?>
                                    <div class="bg-blue-50 p-2 rounded-lg">
                                        <p class="text-xs text-blue-600 mb-1">Net Payout</p>
                                        <p class="font-bold text-blue-700 text-base">₹<?= number_format($netPayout) ?></p>
                                    </div>
                                </div>
                                
                                <!-- Bank Info (Collapsible) -->
                                <div class="mt-3">
                                    <button onclick="this.nextElementSibling.classList.toggle('hidden')" class="w-full text-left text-sm font-medium text-indigo-600 hover:text-indigo-500 flex items-center justify-between">
                                        <span>Bank Details</span>
                                        <i class="fas fa-chevron-down text-xs transition-transform duration-200"></i>
                                    </button>
                                    <div class="mt-2 p-3 bg-gray-50 rounded-lg text-xs text-gray-600 hidden">
                                        <div class="space-y-1">
                                            <p><span class="font-medium">Bank:</span> <?= htmlspecialchars($payout['bank_name'] ?? 'N/A') ?></p>
                                            <p><span class="font-medium">A/C:</span> <?= htmlspecialchars($payout['account_number'] ?? 'N/A') ?></p>
                                            <p><span class="font-medium">IFSC:</span> <?= htmlspecialchars($payout['ifsc_code'] ?? 'N/A') ?></p>
                                            <?php if (!empty($payout['payout_remark'])): ?>
                                            <div class="mt-2 pt-2 border-t border-gray-200">
                                                <p class="font-medium text-gray-700">Remarks:</p>
                                                <p class="text-gray-600"><?= htmlspecialchars($payout['payout_remark']) ?></p>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Card Footer -->
                            <div class="px-4 py-3 bg-gray-50 border-t border-gray-100 flex justify-between items-center">
                                <div class="text-xs text-gray-500">
                                    <i class="far fa-calendar-alt mr-1"></i>
                                    <?= $payout['payout_date'] ? date('M d, Y', strtotime($payout['payout_date'])) : 'Pending' ?>
                                </div>
                                <div class="flex space-x-2">
                                    <?php if ($payout['status'] === 'pending'): ?>
                                        <form method="POST" class="inline" onsubmit="return confirm('Mark this payout as paid?')">
                                            <input type="hidden" name="payout_id" value="<?= $payout['id'] ?>">
                                            <input type="hidden" name="status" value="paid">
                                            <button type="submit" name="update_payout_status" class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                                                <i class="fas fa-check-circle mr-1"></i> Mark Paid
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

        </main>

        <script>
        // Enhanced filter functionality
        function filterPayouts() {
            showLoading();
            const filter = document.getElementById('statusFilter').value;
            const url = new URL(window.location);
            
            if (filter === 'all') {
                url.searchParams.delete('filter');
            } else {
                url.searchParams.set('filter', filter);
            }
            
            window.location.href = url.toString();
        }

        // Clear all active filters
        function clearFilter() {
            showLoading();
            const url = new URL(window.location);
            url.searchParams.delete('filter');
            window.location.href = url.toString();
        }

        // Download report with current filters
        function downloadReport(format) {
            showLoading('Preparing download...');
            const filter = document.getElementById('statusFilter').value;
            const search = document.getElementById('searchInput').value;
            const url = new URL(window.location);
            
            url.searchParams.set('export', format);
            
            if (filter && filter !== 'all') {
                url.searchParams.set('filter', filter);
            }
            
            if (search) {
                url.searchParams.set('search', search);
            }
            
            window.location.href = url.toString();
            setTimeout(hideLoading, 3000); // Hide after 3 seconds for downloads
            return false;
        }

        // Show loading spinner
        function showLoading(message = 'Loading payouts...') {
            const spinner = document.getElementById('loadingSpinner');
            const text = spinner.querySelector('p');
            text.textContent = message;
            spinner.classList.remove('hidden');
        }

        // Hide loading spinner
        function hideLoading() {
            document.getElementById('loadingSpinner').classList.add('hidden');
        }

        // Client-side table filtering
        function filterTable() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toLowerCase();
            const rows = document.querySelectorAll('.payout-row');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        }

        // Handle keyboard shortcuts for better UX
        document.addEventListener('keydown', function(e) {
            // Focus search on Ctrl+F or Cmd+F
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                document.getElementById('searchInput').focus();
            }
            
            // Clear search on Escape
            if (e.key === 'Escape') {
                const searchInput = document.getElementById('searchInput');
                if (searchInput.value) {
                    searchInput.value = '';
                    filterTable();
                }
            }
        });

        // Hide loading spinner when page loads
        document.addEventListener('DOMContentLoaded', function() {
            hideLoading();
            
            // Add loading to all links
            document.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', function(e) {
                    if (!this.href.includes('#') && !this.href.includes('javascript:')) {
                        showLoading('Loading...');
                    }
                });
            });
            
            // Add loading to all buttons with navigation
            document.querySelectorAll('button[onclick*="location"]').forEach(btn => {
                btn.addEventListener('click', function() {
                    showLoading('Loading...');
                });
            });
        });

        // Show loading on form submissions
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function() {
                showLoading('Processing...');
            });
        });
        
        // Show loading on page unload (back/forward navigation)
        window.addEventListener('beforeunload', function() {
            showLoading('Loading...');
        });
        
        // Show loading on popstate (browser back/forward)
        window.addEventListener('popstate', function() {
            showLoading('Loading...');
        });

        // Initialize any tooltips or other UI elements
        // document.addEventListener('DOMContentLoaded', function() {
        //     // Initialize tooltips if needed
        //     if (typeof tippy === 'function') {
        //         tippy('[data-tippy-content]');
        //     }
        // });
        </script>

        <!-- Add this style for better mobile experience -->
        <style>
        /* Loading spinner animation */
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .animate-spin {
            animation: spin 1s linear infinite;
        }
        
        /* Custom scrollbar for filter chips */
        #activeFilters {
            scrollbar-width: thin;
            scrollbar-color: #cbd5e1 #f1f5f9;
        }

        #activeFilters::-webkit-scrollbar {
            height: 4px;
        }

        #activeFilters::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 2px;
        }

        #activeFilters::-webkit-scrollbar-thumb {
            background-color: #cbd5e1;
            border-radius: 2px;
        }

        /* Better focus states for better accessibility */
        [tabindex]:focus-visible, 
        button:focus-visible, 
        select:focus-visible,
        input:focus-visible {
            outline: 2px solid #3b82f6;
            outline-offset: 2px;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.3);
        }

        /* Smooth transitions for dropdowns */
        [role="menu"] {
            transition: opacity 0.1s ease-in-out, transform 0.1s ease-in-out;
        }
        </style>

        <?php include __DIR__ . '/../includes/footer.php'; ?>
            <script src="/assets/js/loading.js"></script>
</body>
        </html>
