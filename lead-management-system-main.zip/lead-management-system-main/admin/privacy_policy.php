<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

requireLogin();
$user = getCurrentUser();
if (empty($user['is_admin'])) {
    header('Location: /login.php');
    exit;
}

$database = new Database();
$conn = $database->getConnection();

$message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_privacy'])) {
    $new_privacy = $_POST['privacy_policy'];
    
    // Check if privacy policy setting exists
    $check_stmt = $conn->prepare("SELECT id FROM settings WHERE setting_key = 'privacy_policy'");
    $check_stmt->execute();
    $exists = $check_stmt->get_result()->num_rows > 0;
    $check_stmt->close();
    
    if ($exists) {
        $stmt = $conn->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'privacy_policy'");
        $stmt->bind_param('s', $new_privacy);
    } else {
        $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('privacy_policy', ?)");
        $stmt->bind_param('s', $new_privacy);
    }
    
    if ($stmt->execute()) {
        $message = '<div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">Privacy policy updated successfully.</div>';
    } else {
        $message = '<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">Failed to update privacy policy.</div>';
    }
    $stmt->close();
}

// Fetch current privacy policy
$stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = 'privacy_policy'");
$stmt->execute();
$result = $stmt->get_result();
$privacy = $result->fetch_assoc();
$stmt->close();

$current_privacy = $privacy['setting_value'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Privacy Policy</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
</head>
<body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include __DIR__ . '/../includes/header.php'; ?>

    <main class="w-full mx-auto py-8">
        <div class="max-w-2xl mx-auto bg-white rounded-lg shadow p-8">
            <h2 class="text-2xl font-bold mb-6">Manage Privacy Policy</h2>
            
            <?php echo $message; ?>

            <form method="POST" action="">
                <div class="mb-4">
                    <label for="privacy_policy" class="block text-sm font-medium text-slate-700 mb-2">Privacy Policy Text</label>
                    <textarea id="privacy_policy" name="privacy_policy" rows="10" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($current_privacy); ?></textarea>
                </div>
                <div class="flex justify-end">
                    <button type="submit" name="update_privacy" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Update Privacy Policy</button>
                </div>
            </form>
        </div>
    </main>

    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>