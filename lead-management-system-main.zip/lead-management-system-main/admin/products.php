<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/role_manager.php';
require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../includes/timezone_helper.php';
require_once __DIR__ . '/../includes/image_orientation_fix.php';
requireLogin();
if (!isAdmin() && !hasPermission('products.view')) { 
    header('Location: ../adviser/dashboard.php'); 
    exit(); 
}

// Ensure timezone is set
ensureTimezone();

$database = new Database();
$conn = $database->getConnection();

// Helper function to save Base64 Image with orientation fix (guarded to avoid redeclare)
if (!function_exists('saveBase64Image')) {
    function saveBase64Image($base64String, $prefix) {
        return saveBase64ImageWithOrientation($base64String, $prefix);
    }
}

// Helper for Base64 updates (kept separate for clarity)
if (!function_exists('saveBase64ImageUpdate')) {
    function saveBase64ImageUpdate($base64String, $prefix) {
        return saveBase64Image($base64String, $prefix);
    }
}

// Serve AJAX HTML for product change history (returns HTML fragment)
if (isset($_GET['history_html']) && isset($_GET['product_id'])) {
    date_default_timezone_set('Asia/Kolkata');
    $product_id = intval($_GET['product_id']);
    // fetch product current snapshot
    $pstmt = $conn->prepare("SELECT * FROM products WHERE id = ? LIMIT 1");
    $pstmt->bind_param('i', $product_id);
    $pstmt->execute();
    $pres = $pstmt->get_result();
    $product = $pres ? $pres->fetch_assoc() : null;
    $pstmt->close();

    // fetch recent timeline rows (limit 10)
    $tl_stmt = $conn->prepare("SELECT date_from, date_to, link_used, payout_source, payout, utm_template_url, terms_content, changed_fields, old_values, new_values, created_at FROM product_timeline WHERE product_id = ? ORDER BY created_at DESC LIMIT 10");
    $tl_stmt->bind_param('i', $product_id);
    $tl_stmt->execute();
    $tl_res = $tl_stmt->get_result();
    $timeline_rows = [];
    while ($r = $tl_res->fetch_assoc()) $timeline_rows[] = $r;
    $tl_stmt->close();

    // Build HTML fragment
    ob_start();
    echo '<div class="overflow-x-auto">';
    echo '<table class="w-full text-xs">';
    echo '<thead class="bg-gray-100"><tr><th class="px-2 py-1 text-left">Link Used</th><th class="px-2 py-1 text-left">Payout Source</th><th class="px-2 py-1 text-left">Payout</th><th class="px-2 py-1 text-left">Changes</th><th class="px-2 py-1 text-left">Changed On</th></tr></thead><tbody>';
    // current snapshot row
    echo '<tr class="bg-blue-50">';
    echo '<td class="px-2 py-1">'.($product['bank_redirect_url']? '<a href="'.htmlspecialchars($product['bank_redirect_url']).'" target="_blank" class="text-blue-600 hover:underline">'.(strlen($product['bank_redirect_url'])>40?htmlspecialchars(substr($product['bank_redirect_url'],0,40)).'...':htmlspecialchars($product['bank_redirect_url'])).'</a>' : '-') .'</td>';
    echo '<td class="px-2 py-1">'.htmlspecialchars($product['payout_source'] ?? '-') .'</td>';
    echo '<td class="px-2 py-1">'.(is_null($product['commission_rate'])?'-':($product['category']==='Personal Loan' ? number_format($product['commission_rate'],2). '%' : '₹'.number_format($product['commission_rate'],2))) .'</td>';
    echo '<td class="px-2 py-1 text-gray-500">-</td>';
    echo '<td class="px-2 py-1 font-semibold text-blue-600">Current</td>';
    echo '</tr>';

    foreach ($timeline_rows as $tr) {
        echo '<tr class="border-t">';
        echo '<td class="px-2 py-1">'.($tr['link_used']? '<a href="'.htmlspecialchars($tr['link_used']).'" target="_blank" class="text-blue-600 hover:underline">'.(strlen($tr['link_used'])>40?htmlspecialchars(substr($tr['link_used'],0,40)).'...':htmlspecialchars($tr['link_used'])).'</a>' : '-') .'</td>';
        echo '<td class="px-2 py-1">'.htmlspecialchars($tr['payout_source'] ?? '-') .'</td>';
        echo '<td class="px-2 py-1">'.(is_null($tr['payout'])?'-':'₹'.number_format($tr['payout'],2)).'</td>';
        // Use tracked changes from database
        $changesText = 'Multiple fields';
        if (!empty($tr['changed_fields'])) {
            $fields = explode(',', $tr['changed_fields']);
            $displayFields = [];
            foreach ($fields as $field) {
                switch ($field) {
                    case 'commission_rate': $displayFields[] = 'Commission'; break;
                    case 'bank_redirect_url': $displayFields[] = 'Link'; break;
                    case 'payout_source': $displayFields[] = 'Payout Source'; break;
                    case 'utm_template_url': $displayFields[] = 'UTM URL'; break;
                    default: $displayFields[] = ucfirst(str_replace('_', ' ', $field));
                }
            }
            $changesText = implode(', ', $displayFields);
        }
        echo '<td class="px-2 py-1 text-xs text-gray-600">'.htmlspecialchars($changesText).'</td>';
        
        $changeDate = $tr['created_at'] ? date('M j, Y g:i A', strtotime($tr['created_at'])) : '-';
        echo '<td class="px-2 py-1">'.htmlspecialchars($changeDate).'</td>';
        echo '</tr>';
    }

    echo '</tbody></table>';
    echo '</div>';
    $html = ob_get_clean();
    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    exit;
}

// Serve AJAX for lead status history
if (isset($_GET['history']) && isset($_GET['lead_id'])) {
    header('Content-Type: application/json');
    $lead_id = (int)$_GET['lead_id'];
    $stmt = $conn->prepare("SELECT old_status, new_status, changed_by, notes, created_at FROM lead_status_history WHERE lead_id = ? ORDER BY created_at DESC");
    $stmt->bind_param('i', $lead_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    echo json_encode($rows);
    exit;
}

// Handle product add logic for admin
error_log("DEBUG: products.php - Request method: " . $_SERVER['REQUEST_METHOD']);
error_log("DEBUG: products.php - POST data: " . print_r($_POST, true));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_variant_image'])) {
        if (!hasPermission('products.edit')) {
            http_response_code(403);
            exit();
        }
        $productId = (int)$_POST['product_id'];
        $stmt = $conn->prepare("UPDATE products SET variant_image = NULL WHERE id = ?");
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $stmt->close();
        echo 'success';
        exit;
    }
    
    if (isset($_POST['delete_card_image'])) {
        if (!hasPermission('products.edit')) {
            http_response_code(403);
            exit();
        }
        $productId = (int)$_POST['product_id'];
        $stmt = $conn->prepare("UPDATE products SET card_image = NULL WHERE id = ?");
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $stmt->close();
        echo 'success';
        exit;
    }
    
    if (isset($_POST['add_product'])) {
        if (!hasPermission('products.create')) {
            header('Location: products.php?error=no_permission');
            exit();
        }
        error_log("DEBUG: Adding product - Name: " . ($_POST['name'] ?? 'not set'));
        error_log("DEBUG: Adding product - Category: " . ($_POST['category'] ?? 'not set'));
        
        $name = trim($_POST['name']);
        $category = $_POST['category'];
    $variant = isset($_POST['variant']) ? trim($_POST['variant']) : '';
    if ($variant === '+new' && isset($_POST['variant_new'])) {
        $variant = trim($_POST['variant_new']);
    }
    $commission = floatval($_POST['commission']);
        $status = $_POST['status'];
        $bankRedirectUrl = trim($_POST['bank_redirect_url']);
        $utmTemplateUrl = isset($_POST['utm_template_url']) ? trim($_POST['utm_template_url']) : '';
        $payoutSource = isset($_POST['payout_source']) ? trim($_POST['payout_source']) : '';
        $productHighlights = trim($_POST['product_highlights']);
        $pinCodes = trim($_POST['pin_codes'] ?? '');
        
        // Handle card image upload (Base64 priority, then File)
        $cardImage = null;
        if (!empty($_POST['card_image_base64'])) {
            $cardImage = saveBase64Image($_POST['card_image_base64'], 'card');
        } elseif (isset($_FILES['card_image']) && $_FILES['card_image']['error'] === UPLOAD_ERR_OK) {
            $ext = pathinfo($_FILES['card_image']['name'], PATHINFO_EXTENSION);
            $filename = 'card_' . time() . '_' . rand(1000,9999) . '.' . $ext;
            $dest = __DIR__ . '/../assets/cards/' . $filename;
            if (!is_dir(__DIR__ . '/../assets/cards')) { mkdir(__DIR__ . '/../assets/cards', 0777, true); }
            if (processUploadedImage($_FILES['card_image']['tmp_name'], $dest)) {
                $cardImage = 'assets/cards/' . $filename;
            }
        }
        $productHighlights = trim($_POST['product_highlights']);
        
        // (saveBase64Image helper moved to file scope)

        // Handle variant image upload (Base64 priority, then File)
        $variantImage = null;
        if (!empty($_POST['variant_image_base64'])) {
            $variantImage = saveBase64Image($_POST['variant_image_base64'], 'variant');
        } elseif (isset($_FILES['variant_image']) && $_FILES['variant_image']['error'] === UPLOAD_ERR_OK) {
            $ext = pathinfo($_FILES['variant_image']['name'], PATHINFO_EXTENSION);
            $filename = 'variant_' . time() . '_' . rand(1000,9999) . '.' . $ext;
            $dest = __DIR__ . '/../assets/cards/' . $filename;
            if (!is_dir(__DIR__ . '/../assets/cards')) { mkdir(__DIR__ . '/../assets/cards', 0777, true); }
            if (processUploadedImage($_FILES['variant_image']['tmp_name'], $dest)) {
                $variantImage = 'assets/cards/' . $filename;
            }
        }
    $terms_content = trim($_POST['terms_content'] ?? '');
    $stmt = $conn->prepare("INSERT INTO products (name, category, variant, commission_rate, status, bank_redirect_url, utm_template_url, card_image, variant_image, product_highlights, payout_source, terms_content, pin_codes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('sssssssssssss', $name, $category, $variant, $commission, $status, $bankRedirectUrl, $utmTemplateUrl, $cardImage, $variantImage, $productHighlights, $payoutSource, $terms_content, $pinCodes);
        try {
            if (!$stmt->execute()) {
                // Non-exceptional failure (older mysqli modes)
                error_log("Product Add Error: " . $stmt->error);
                header('Location: products.php?error=add_failed');
                exit();
            }
        } catch (mysqli_sql_exception $e) {
            // Likely a collation/charset conversion error when parameter contains non-latin characters
            error_log("Product Add Exception: " . $e->getMessage());
            // Recommend running migration to convert tables to utf8mb4
            header('Location: products.php?error=charset_conversion');
            exit();
        } finally {
            $stmt->close();
        }
        header('Location: products.php');
        exit();
    }
    
    if (isset($_POST['edit_product'])) {
        if (!hasPermission('products.edit')) {
            header('Location: products.php?error=no_permission');
            exit();
        }
        $productId = (int)$_POST['product_id'];
        $name = trim($_POST['name']);
        $category = $_POST['category'];
        $variant = trim($_POST['variant']);
        $commission = floatval($_POST['commission']);
        $status = $_POST['status'];
        $bankRedirectUrl = trim($_POST['bank_redirect_url']);
        $utmTemplateUrl = isset($_POST['utm_template_url']) ? trim($_POST['utm_template_url']) : '';
        $payoutSource = isset($_POST['payout_source']) ? trim($_POST['payout_source']) : '';
        $productHighlights = trim($_POST['product_highlights'] ?? '');
        $termsContent = trim($_POST['terms_content'] ?? '');
        $pinCodes = trim($_POST['pin_codes'] ?? '');

        // Fetch current images so we can keep them if no new upload is provided
        $curStmt = $conn->prepare("SELECT card_image, variant_image FROM products WHERE id = ? LIMIT 1");
        $curStmt->bind_param('i', $productId);
        $curStmt->execute();
        $curRes = $curStmt->get_result();
        $curRow = $curRes ? $curRes->fetch_assoc() : null;
        $curStmt->close();

        $cardImage = $curRow['card_image'] ?? null;
        $variantImage = $curRow['variant_image'] ?? null;

        // Handle card image (Base64 priority, then file)
        if (!empty($_POST['card_image_base64'])) {
            $saved = saveBase64ImageUpdate($_POST['card_image_base64'], 'card');
            if ($saved) $cardImage = $saved;
            else error_log("Card base64 save failed for product {$productId}");
        } elseif (isset($_FILES['card_image']) && $_FILES['card_image']['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($_FILES['card_image']['error'] === UPLOAD_ERR_OK) {
                $ext = pathinfo($_FILES['card_image']['name'], PATHINFO_EXTENSION);
                $filename = 'card_' . time() . '_' . rand(1000,9999) . '.' . $ext;
                $dest = __DIR__ . '/../assets/cards/' . $filename;
                if (!is_dir(__DIR__ . '/../assets/cards')) { mkdir(__DIR__ . '/../assets/cards', 0777, true); }
                if (processUploadedImage($_FILES['card_image']['tmp_name'], $dest)) {
                    $cardImage = 'assets/cards/' . $filename;
                } else {
                    error_log("Failed to move uploaded card image for product {$productId}: " . print_r($_FILES['card_image'], true));
                    header('Location: products.php?error=upload_failed_edit');
                    exit();
                }
            } else {
                error_log("Card upload error ({$_FILES['card_image']['error']}) for product {$productId}");
                header('Location: products.php?error=upload_failed_edit');
                exit();
            }
        }

        // Handle variant image (Base64 priority, then file)
        if (!empty($_POST['variant_image_base64'])) {
            $saved = saveBase64ImageUpdate($_POST['variant_image_base64'], 'variant');
            if ($saved) $variantImage = $saved;
            else error_log("Variant base64 save failed for product {$productId}");
        } elseif (isset($_FILES['variant_image']) && $_FILES['variant_image']['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($_FILES['variant_image']['error'] === UPLOAD_ERR_OK) {
                $ext = pathinfo($_FILES['variant_image']['name'], PATHINFO_EXTENSION);
                $filename = 'variant_' . time() . '_' . rand(1000,9999) . '.' . $ext;
                $dest = __DIR__ . '/../assets/cards/' . $filename;
                if (!is_dir(__DIR__ . '/../assets/cards')) { mkdir(__DIR__ . '/../assets/cards', 0777, true); }
                if (processUploadedImage($_FILES['variant_image']['tmp_name'], $dest)) {
                    $variantImage = 'assets/cards/' . $filename;
                } else {
                    error_log("Failed to move uploaded variant image for product {$productId}: " . print_r($_FILES['variant_image'], true));
                    header('Location: products.php?error=upload_failed_edit');
                    exit();
                }
            } else {
                error_log("Variant upload error ({$_FILES['variant_image']['error']}) for product {$productId}");
                header('Location: products.php?error=upload_failed_edit');
                exit();
            }
        }

        // Prepare update including images
        $stmt = $conn->prepare("UPDATE products SET name=?, category=?, variant=?, commission_rate=?, status=?, bank_redirect_url=?, utm_template_url=?, product_highlights=?, payout_source=?, terms_content=?, pin_codes=?, card_image=?, variant_image=? WHERE id=?");
        $stmt->bind_param('sssssssssssssi', $name, $category, $variant, $commission, $status, $bankRedirectUrl, $utmTemplateUrl, $productHighlights, $payoutSource, $termsContent, $pinCodes, $cardImage, $variantImage, $productId);

        try {
            if (!$stmt->execute()) {
                error_log("Product Update Error: " . $stmt->error);
                header('Location: products.php?error=update_failed');
                exit();
            }
        } catch (mysqli_sql_exception $e) {
            error_log("Product Update Exception: " . $e->getMessage());
            header('Location: products.php?error=charset_conversion');
            exit();
        } finally {
            $stmt->close();
        }
        header('Location: products.php');
        exit();
    }
    
    if (isset($_POST['delete_product'])) {
        if (!hasPermission('products.delete')) {
            header('Location: products.php?error=no_permission');
            exit();
        }
        $productId = (int)$_POST['product_id'];
        
        // Check if product has associated leads
        $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM leads WHERE product_id = ?");
        $checkStmt->bind_param('i', $productId);
        $checkStmt->execute();
        $result = $checkStmt->get_result();
        $row = $result->fetch_assoc();
        $leadCount = $row['count'];
        $checkStmt->close();
        
        if ($leadCount > 0) {
            header("Location: products.php?error=has_leads&count={$leadCount}&product_id={$productId}");
            exit();
        }
        
        // Delete the product
        $deleteStmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $deleteStmt->bind_param('i', $productId);
        
        if ($deleteStmt->execute()) {
            $deleteStmt->close();
            header('Location: products.php?deleted=1');
            exit();
        } else {
            error_log("Product Delete Error: " . $deleteStmt->error);
            $deleteStmt->close();
            header('Location: products.php?error=delete_failed');
            exit();
        }
    }
}

// Fetch all products
$products = [];
$res = $conn->query("SELECT * FROM products ORDER BY commission_rate DESC");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $products[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <style>

    </style>
</head>
<body class="min-h-screen bg-gray-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include __DIR__ . '/../includes/header.php'; ?>
    
    <div class="p-4 sm:p-6 max-w-7xl mx-auto">
        <!-- Alerts -->
        <?php if (isset($_GET['error']) && $_GET['error'] === 'has_leads'): ?>
        <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-r">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-exclamation-circle h-5 w-5 text-red-500"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-red-700">
                        <strong>Cannot Delete Product:</strong> This product has <?php echo intval($_GET['count'] ?? 0); ?> associated lead<?php echo intval($_GET['count'] ?? 0) > 1 ? 's' : ''; ?>. 
                        <a href="../leads/leads_updated.php?product_id=<?php echo intval($_GET['product_id'] ?? 0); ?>" class="font-medium text-red-700 underline hover:text-red-600">View leads</a> and remove them first.
                    </p>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php if (isset($_GET['error']) && $_GET['error'] === 'charset_conversion'): ?>
        <div class="bg-yellow-50 border-l-4 border-yellow-500 p-4 mb-6 rounded-r">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-exclamation-triangle h-5 w-5 text-yellow-500"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-yellow-700">
                        <strong>Database charset issue:</strong> The database appears to use a latin1 collation which can fail for non-latin characters. Please run the migration <code>migrations/20260107_convert_to_utf8mb4.sql</code> to convert affected tables to <code>utf8mb4</code> (backup first).
                    </p>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (isset($_GET['error']) && $_GET['error'] === 'upload_failed_edit'): ?>
        <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-r">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-exclamation-circle h-5 w-5 text-red-500"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-red-700">
                        <strong>Image upload failed:</strong> There was a problem saving the uploaded image. Check server logs for details and try again.
                    </p>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (isset($_GET['error']) && $_GET['error'] === 'update_failed'): ?>
        <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-r">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-exclamation-circle h-5 w-5 text-red-500"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-red-700">
                        <strong>Update failed:</strong> The product could not be updated. Please check input values and try again.
                    </p>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['deleted'])): ?>
        <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6 rounded-r">
            <div class="flex">
                <div class="flex-shrink-0">
                    <i class="fas fa-check-circle h-5 w-5 text-green-500"></i>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-green-700">
                        <strong>Success!</strong> Product has been deleted successfully.
                    </p>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Header with Actions -->
        <div class="mb-8">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Product Management</h1>
                    <p class="mt-1 text-sm text-gray-500">Manage your products, commissions, and settings</p>
                </div>
                <div class="flex flex-col sm:flex-row gap-3">
                    <button onclick="toggleFilters()" class="btn-secondary flex items-center justify-center gap-2">
                        <i class="fas fa-filter"></i>
                        <span>Filter</span>
                    </button>
                    <button onclick="filterProducts()" class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 flex items-center justify-center gap-2">
                        <i class="fas fa-search"></i>
                        <span>Apply Filter</span>
                    </button>
                    <button onclick="toggleAddForm()" class="btn-primary flex items-center justify-center gap-2 <?php echo !hasPermission('products.create') ? 'opacity-50 cursor-not-allowed' : ''; ?>" <?php echo !hasPermission('products.create') ? 'disabled' : ''; ?>>
                        <i class="fas fa-plus"></i>
                        <span>Add Product</span>
                    </button>
                </div>
            </div>
            
            <!-- Search and Filters -->
            <div class="mt-6">
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <i class="fas fa-search text-gray-400"></i>
                    </div>
                    <input type="text" id="searchInput" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500" placeholder="Search products...">
                </div>
            </div>
        </div>

        <!-- Filter Panel -->
        <div id="filterPanel" class="hidden bg-white rounded-lg shadow-sm border p-4 mb-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Category</label>
                    <select id="filterCategory" class="w-full px-3 py-2 border border-slate-300 rounded-md text-sm">
                        <option value="">All Categories</option>
                        <option value="Credit Card">Credit Card</option>
                        <option value="Personal Loan">Personal Loan</option>
                        <option value="Car Loan">Car Loan</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Status</label>
                    <select id="filterStatus" class="w-full px-3 py-2 border border-slate-300 rounded-md text-sm">
                        <option value="" selected>All Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Search</label>
                    <input type="text" id="filterSearch" placeholder="ID, name, variant, commission, payout source..." class="w-full px-3 py-2 border border-slate-300 rounded-md text-sm">
                </div>
                <div class="flex items-end">
                    <button onclick="clearFilters()" class="w-full bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 text-sm">
                        <i class="fas fa-times mr-1"></i>Clear
                    </button>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
            <div class="card bg-white rounded-xl p-5 shadow-sm hover:shadow transition-shadow">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-500">Total Products</p>
                        <p class="mt-1 text-2xl font-bold text-gray-900"><?php echo count($products); ?></p>
                        <p class="mt-1 text-xs text-gray-500">
                            <span class="text-green-600">
                                <i class="fas fa-arrow-up"></i> 12%
                            </span> from last month
                        </p>
                    </div>
                    <div class="p-3 rounded-lg bg-blue-50 text-blue-600">
                        <i class="fas fa-boxes text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="card bg-white rounded-xl p-5 shadow-sm hover:shadow transition-shadow">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-500">Active Products</p>
                        <p class="mt-1 text-2xl font-bold text-gray-900"><?php echo count(array_filter($products, fn($p) => $p['status'] === 'active')); ?></p>
                        <p class="mt-1 text-xs text-gray-500">
                            <span class="text-green-600">
                                <i class="fas fa-arrow-up"></i> 5%
                            </span> from last month
                        </p>
                    </div>
                    <div class="p-3 rounded-lg bg-green-50 text-green-600">
                        <i class="fas fa-check-circle text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="card bg-white rounded-xl p-5 shadow-sm hover:shadow transition-shadow">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-500">Inactive Products</p>
                        <p class="mt-1 text-2xl font-bold text-gray-900"><?php echo count(array_filter($products, fn($p) => $p['status'] !== 'active')); ?></p>
                        <p class="mt-1 text-xs text-gray-500">
                            <span class="text-red-600">
                                <i class="fas fa-arrow-down"></i> 2%
                            </span> from last month
                        </p>
                    </div>
                    <div class="p-3 rounded-lg bg-amber-50 text-amber-600">
                        <i class="fas fa-pause-circle text-xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="card bg-white rounded-xl p-5 shadow-sm hover:shadow transition-shadow">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-500">Avg. Commission</p>
                        <p class="mt-1 text-2xl font-bold text-gray-900">₹<?php echo $products ? number_format(array_sum(array_column($products, 'commission_rate')) / count($products), 0) : 0; ?></p>
                        <p class="mt-1 text-xs text-gray-500">
                            <span class="text-green-600">
                                <i class="fas fa-arrow-up"></i> 8%
                            </span> from last month
                        </p>
                    </div>
                    <div class="p-3 rounded-lg bg-purple-50 text-purple-600">
                        <i class="fas fa-money-bill-wave text-xl"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Product Form -->
        <div id="addProductForm" class="hidden bg-white rounded-xl shadow-sm p-6 mb-8">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-bold text-gray-900">Add New Product</h2>
                <button type="button" onclick="toggleAddForm()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="add_product" value="1">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Bank Name</label>
                        <select name="variant" id="variant_select" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                            <option value="">-- Select Bank --</option>
                            <option value="+new">+ Add New Bank</option>
                        </select>
                        <input type="text" name="variant_new" id="variant_new" placeholder="Enter new bank name" class="w-full px-3 py-2 border border-slate-300 rounded-md mt-2 hidden">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Product Name *</label>
                        <input type="text" name="name" required class="w-full px-3 py-2 border border-slate-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Category</label>
                        <select name="category" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                            <option value="Credit Card">💳 Credit Card</option>
                            <option value="Personal Loan">💰 Personal Loan</option>
                            <option value="Car Loan">🚗 Car Loan</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Commission</label>
                        <input type="number" name="commission" step="0.01" min="0" required class="w-full px-3 py-2 border border-slate-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Bank Redirect URL *</label>
                        <input type="url" name="bank_redirect_url" required class="w-full px-3 py-2 border border-slate-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Payout Source</label>
                        <input type="text" name="payout_source" maxlength="100" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Status</label>
                        <select name="status" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                            <option value="active">✅ Active</option>
                            <option value="inactive">❌ Inactive</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Variant Image</label>
                        <input type="file" name="variant_image" id="add_variant_image_input" accept="image/*" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                        <div id="add_variant_preview" class="mt-2 hidden">
                            <img id="add_variant_img" src="" alt="Variant Preview" class="w-20 h-20 object-cover rounded border">
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Card Image</label>
                        <input type="file" name="card_image" id="add_card_image_input" accept="image/*" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                        <div id="add_card_preview" class="mt-2 hidden">
                            <img id="add_card_img" src="" alt="Card Preview" class="w-20 h-20 object-cover rounded border">
                        </div>
                    </div>
                </div>
                <div class="mt-4 grid grid-cols-1 md:col-span-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Serviceable Pin Codes (Bulk paste supported)</label>
                        <textarea name="pin_codes" id="pin_codes_input" rows="3" class="w-full px-3 py-2 border border-slate-300 rounded-md resize-vertical" placeholder="Paste bulk pincodes separated by comma, space, or new line&#10;e.g. 110001, 110002, 110003&#10;or: 110001 110002 110003&#10;or: 110001&#10;110002&#10;110003&#10;or type ALL for all pincodes" oninput="formatPinCodes(this)"></textarea>
                        <div class="text-xs text-gray-500 mt-1">Auto-formats 6-digit pincodes. Supports bulk paste.</div>
                    </div>
                </div>
                <div class="mt-4">
                    <label class="block text-sm font-medium text-slate-700 mb-1">Product Highlights</label>
                    <textarea name="product_highlights" rows="3" class="w-full px-3 py-2 border border-slate-300 rounded-md"></textarea>
                </div>
                <div class="mt-4">
                    <label class="block text-sm font-medium text-slate-700 mb-1">Terms & Conditions</label>
                    <textarea name="terms_content" rows="4" class="w-full px-3 py-2 border border-slate-300 rounded-md" placeholder="Enter terms and conditions"></textarea>
                </div>
                <div class="flex justify-end gap-3 mt-6">
                    <button type="button" onclick="toggleAddForm()" class="px-4 py-2 border border-slate-300 rounded-md hover:bg-slate-50">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                        Add Product
                    </button>
                </div>
            </form>
        </div>

        <!-- Edit Product Form -->
        <div id="editProductForm" class="hidden bg-white rounded-xl shadow-sm p-6 mb-8">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-bold text-gray-900">Edit Product</h2>
                <button type="button" onclick="toggleEditForm()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="edit_product" value="1">
                <input type="hidden" name="product_id" id="edit_product_id">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Variant Name</label>
                        <input type="text" name="variant" id="edit_variant" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Product Name *</label>
                        <input type="text" name="name" id="edit_name" required class="w-full px-3 py-2 border border-slate-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Category</label>
                        <select name="category" id="edit_category" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                            <option value="Credit Card">💳 Credit Card</option>
                            <option value="Personal Loan">💰 Personal Loan</option>
                            <option value="Car Loan">🚗 Car Loan</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Commission</label>
                        <input type="number" name="commission" id="edit_commission" step="0.01" min="0" required class="w-full px-3 py-2 border border-slate-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Bank Redirect URL *</label>
                        <input type="url" name="bank_redirect_url" id="edit_bank_redirect_url" required class="w-full px-3 py-2 border border-slate-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Status</label>
                        <select name="status" id="edit_status" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                            <option value="active">✅ Active</option>
                            <option value="inactive">❌ Inactive</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Payout Source</label>
                        <input type="text" name="payout_source" id="edit_payout_source" maxlength="100" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-slate-700 mb-1">Serviceable Pin Codes (Comma separated or "ALL")</label>
                        <textarea name="pin_codes" id="edit_pin_codes" rows="2" class="w-full px-3 py-2 border border-slate-300 rounded-md" placeholder="Paste bulk pincodes separated by comma, space, or new line&#10;e.g. 110001, 110002 or ALL" oninput="formatPinCodes(this)"></textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Variant Image</label>
                        <input type="file" name="variant_image" id="edit_variant_image_input" accept="image/*" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                        <div id="edit_variant_preview" class="mt-2 hidden">
                            <img id="edit_variant_img" src="" alt="Variant Preview" class="w-20 h-20 object-cover rounded border">
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Card Image</label>
                        <input type="file" name="card_image" id="edit_card_image_input" accept="image/*" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                        <div id="edit_card_preview" class="mt-2 hidden">
                            <img id="edit_card_img" src="" alt="Card Preview" class="w-20 h-20 object-cover rounded border">
                        </div>
                    </div>
                </div>
                <div class="mt-4">
                    <label class="block text-sm font-medium text-slate-700 mb-1">Product Highlights</label>
                    <textarea name="product_highlights" id="edit_product_highlights" rows="3" class="w-full px-3 py-2 border border-slate-300 rounded-md"></textarea>
                </div>
                <div class="mt-4">
                    <label class="block text-sm font-medium text-slate-700 mb-1">Terms & Conditions</label>
                    <textarea name="terms_content" id="edit_terms_content" rows="4" class="w-full px-3 py-2 border border-slate-300 rounded-md" placeholder="Enter terms and conditions"></textarea>
                </div>
                <div class="flex justify-end gap-3 mt-6">
                    <button type="button" onclick="toggleEditForm()" class="px-4 py-2 border border-slate-300 rounded-md hover:bg-slate-50">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                        Save Changes
                    </button>
                </div>
            </form>
        </div>
        <div class="bg-white rounded-xl shadow-sm overflow-hidden">
            <div class="table-container overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                <div class="flex items-center">
                                    <span>Product</span>
                                    <button class="ml-1 text-gray-400 hover:text-gray-500">
                                        <i class="fas fa-sort"></i>
                                    </button>
                                </div>
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Card Image
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                <div class="flex items-center">
                                    <span>Category</span>
                                    <button class="ml-1 text-gray-400 hover:text-gray-500">
                                        <i class="fas fa-sort"></i>
                                    </button>
                                </div>
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                <div class="flex items-center">
                                    <span>Commission</span>
                                    <button class="ml-1 text-gray-400 hover:text-gray-500">
                                        <i class="fas fa-sort"></i>
                                    </button>
                                </div>
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Status
                            </th>
                            <th scope="col" class="relative px-6 py-3">
                                <span class="sr-only">Actions</span>
                            </th>
                        </tr>
                    </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($products as $index => $product): 
                            $statusColor = $product['status'] === 'active' ? 'green' : 'red';
                            $statusIcon = $product['status'] === 'active' ? 'check-circle' : 'times-circle';
                            $categoryIcon = '';
                            $categoryColor = '';
                            
                            switch($product['category']) {
                                case 'Credit Card':
                                    $categoryIcon = 'credit-card';
                                    $categoryColor = 'blue';
                                    break;
                                case 'Personal Loan':
                                    $categoryIcon = 'hand-holding-usd';
                                    $categoryColor = 'green';
                                    break;
                                case 'Car Loan':
                                    $categoryIcon = 'car';
                                    $categoryColor = 'purple';
                                    break;
                                default:
                                    $categoryIcon = 'box';
                                    $categoryColor = 'gray';
                            }
                        ?>
                    <tr class="hover:bg-gray-50 transition-colors">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="flex-shrink-0 h-10 w-10 rounded-full overflow-hidden bg-<?php echo $categoryColor; ?>-100 flex items-center justify-center text-<?php echo $categoryColor; ?>-600">
                                    <?php if (!empty($product['variant_image'])): ?>
                                        <img src="../<?php echo htmlspecialchars($product['variant_image']); ?>" alt="<?php echo htmlspecialchars($product['variant']); ?>" class="w-full h-full object-cover">
                                    <?php else: ?>
                                        <i class="fas fa-<?php echo $categoryIcon; ?> text-sm"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($product['name']); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo htmlspecialchars($product['variant'] ?? 'No variant'); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center justify-center">
                                <?php if (!empty($product['card_image'])): ?>
                                    <img src="../<?php echo htmlspecialchars($product['card_image']); ?>" alt="Card Image" class="w-16 h-10 object-cover rounded border">
                                <?php else: ?>
                                    <div class="w-16 h-10 bg-gray-100 rounded border flex items-center justify-center">
                                        <i class="fas fa-credit-card text-gray-400 text-xs"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($product['category']); ?></div>
                            <div class="text-xs text-gray-500">ID: <?php echo $product['id']; ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">
                                <?php 
                                if ($product['category'] === 'Personal Loan' || $product['category'] === 'Car Loan') {
                                    echo number_format($product['commission_rate'], 2) . '%';
                                } else {
                                    echo '₹' . number_format($product['commission_rate'], 2);
                                } ?>
                            </div>
                            <div class="text-xs text-gray-500">per approval</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-<?php echo $statusColor; ?>-100 text-<?php echo $statusColor; ?>-800">
                                <i class="fas fa-<?php echo $statusIcon; ?> mr-1"></i>
                                <?php echo ucfirst($product['status']); ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <div class="flex items-center justify-end space-x-2">
                                <button onclick="document.getElementById('editProductModal').showModal(); showEditFormModal(<?php echo $product['id']; ?>)" class="text-blue-600 hover:text-blue-900 transition-colors p-1.5 rounded-full hover:bg-blue-50 <?php echo !hasPermission('products.edit') ? 'opacity-50 cursor-not-allowed' : ''; ?>" <?php echo !hasPermission('products.edit') ? 'disabled' : ''; ?>>
                                    <i class="fas fa-edit w-5 h-5"></i>
                                </button>
                                <button onclick="toggleHistory(<?php echo $product['id']; ?>)" class="text-green-600 hover:text-green-900 transition-colors p-1.5 rounded-full hover:bg-green-50">
                                    <i class="fas fa-history w-5 h-5"></i>
                                </button>
                                <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this product?');" class="inline">
                                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                    <button type="submit" name="delete_product" class="text-red-600 hover:text-red-900 transition-colors p-1.5 rounded-full hover:bg-red-50 <?php echo !hasPermission('products.delete') ? 'opacity-50 cursor-not-allowed' : ''; ?>" <?php echo !hasPermission('products.delete') ? 'disabled' : ''; ?>>
                                        <i class="fas fa-trash w-5 h-5"></i>
                                    </button>
                                </form>
                                <button class="text-gray-400 hover:text-gray-600 transition-colors p-1.5 rounded-full hover:bg-gray-100">
                                    <i class="fas fa-ellipsis-v w-5 h-5"></i>
                                </button>
                            </div>
                        </td>
                        </tr>
                        <tr id="history-row-<?php echo $product['id']; ?>" class="hidden">
                            <td colspan="6" class="px-4 py-0">
                                <div class="bg-gray-50 border-l-4 border-blue-500 p-4 mb-2">
                                    <div id="history-content-<?php echo $product['id']; ?>" class="text-sm">
                                        <div class="text-center text-gray-500 py-4">Loading history...</div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>

                        <?php if (empty($products)): ?>
                        <tr>
                            <td colspan="6" class="px-6 py-12 text-center">
                                <div class="flex flex-col items-center justify-center">
                                    <div class="bg-gray-100 p-4 rounded-full mb-4">
                                        <i class="fas fa-box-open text-3xl text-gray-400"></i>
                                    </div>
                                    <h3 class="text-lg font-medium text-gray-900 mb-1">No products found</h3>
                                    <p class="text-gray-500 mb-4 max-w-md">Get started by adding your first product to the system.</p>
                                    <button onclick="document.getElementById('addProductModal').showModal()" class="btn-primary inline-flex items-center px-4 py-2">
                                        <i class="fas fa-plus mr-2"></i>
                                        Add Product
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>
<!-- Add Product Modal -->
<dialog id="addProductModal" class="fixed inset-0 z-50 w-full h-full m-0 p-0 bg-black bg-opacity-50 overflow-y-auto">
    <div class="min-h-screen flex items-center justify-center p-2 sm:p-4">
        <div class="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
            <div class="bg-blue-600 text-white px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between sticky top-0 z-10">
                <h2 class="text-lg sm:text-xl font-bold">Add New Product</h2>
                <button type="button" onclick="document.getElementById('addProductModal').close()" class="p-2 -mr-2 text-white hover:bg-blue-700 rounded-full transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            <form method="POST" enctype="multipart/form-data" class="flex-1 overflow-y-auto p-4 sm:p-6">
                <input type="hidden" name="add_product" value="1">
                <div class="space-y-3 sm:space-y-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Variant Name <span class="text-xs text-gray-400">(e.g. HDFC Bank)</span></label>
                    <input type="text" name="variant" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base" placeholder="Enter variant name">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Variant Image <span class="text-xs text-gray-400">(Bank/Lender Logo)</span></label>
                    <input type="file" name="variant_image" id="add_variant_image_input" accept="image/*" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Product Name *</label>
                    <input type="text" name="name" required class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base" placeholder="Enter product name">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Category</label>
                    <select name="category" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base bg-white">
                        <option value="Credit Card">💳 Credit Card</option>
                        <option value="Personal Loan">💰 Personal Loan</option>
                        <option value="Car Loan">🚗 Car Loan</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Bank Redirect URL *</label>
                    <input type="url" name="bank_redirect_url" required class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base" placeholder="https://bank.example.com/apply">
                    <small class="text-xs text-gray-500">You can use <b>{lead_id}</b> in the URL.</small>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">UTM Template URL</label>
                    <input type="url" name="utm_template_url" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base" placeholder="https://example.com?utm_id={unique_id}">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Payout Source</label>
                    <input type="text" name="payout_source" maxlength="100" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Product Highlights <span class="text-xs text-gray-400">(Max 3 rows)</span></label>
                    <textarea name="product_highlights" rows="3" maxlength="500" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md resize-vertical text-sm sm:text-base" oninput="this.value=this.value.split('\n').slice(0,3).join('\n')"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Terms & Conditions</label>
                    <textarea name="terms_content" rows="4" maxlength="5000" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md resize-vertical text-sm sm:text-base" placeholder="Enter terms and conditions"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Card Image</label>
                    <input type="file" name="card_image" id="add_card_image_input" accept="image/*" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Commission <span id="add_commission_unit">Amount</span></label>
                    <div class="relative">
                        <span id="add_commission_symbol" class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 font-bold">₹</span>
                        <input type="number" name="commission" id="add_commission" step="0.01" min="0" required class="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-md" placeholder="500">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Status</label>
                    <select name="status" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                        <option value="active">✅ Active</option>
                        <option value="inactive">❌ Inactive</option>
                    </select>
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-slate-700 mb-1">Serviceable Pin Codes (Comma separated or "ALL")</label>
                    <textarea name="pin_codes" id="add_pin_codes_modal" rows="2" class="w-full px-3 py-2 border border-slate-300 rounded-md" placeholder="Paste bulk pincodes separated by comma, space, or new line&#10;e.g. 110001, 110002 or ALL" oninput="formatPinCodes(this)"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Product Highlights</label>
                    <textarea name="product_highlights" rows="3" maxlength="500" class="w-full px-3 py-2 border border-slate-300 rounded-md resize-vertical" placeholder="Enter product highlights (one per line)"></textarea>
                </div>
            </div>
            <div class="flex flex-col sm:flex-row justify-end gap-3 pt-4 sticky bottom-0 bg-white pb-2 sm:pb-0">
                <button type="button" onclick="document.getElementById('addProductModal').close()" class="px-4 py-3 sm:py-2 border border-slate-300 rounded-md text-slate-700 hover:bg-slate-50 text-sm sm:text-base">
                    Cancel
                </button>
                <button type="submit" class="px-4 py-3 sm:py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm sm:text-base">
                    Add Product
                </button>
            </div>
        </form>
    </div>
</dialog>

<!-- Edit Product Modal -->
<dialog id="editProductModal" class="fixed inset-0 z-50 w-full h-full m-0 p-0 bg-black bg-opacity-50 overflow-y-auto">
    <div class="min-h-screen flex items-center justify-center p-2 sm:p-4">
        <div class="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
            <div class="bg-blue-600 text-white px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between sticky top-0 z-10">
                <h2 class="text-lg sm:text-xl font-bold">Edit Product</h2>
                <button type="button" onclick="document.getElementById('editProductModal').close()" class="p-2 -mr-2 text-white hover:bg-blue-700 rounded-full transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            <form method="POST" id="editProductForm" enctype="multipart/form-data" class="flex-1 overflow-y-auto p-4 sm:p-6">
                <input type="hidden" name="edit_product" value="1">
                <input type="hidden" name="product_id" id="edit_product_id">
                <div class="space-y-3 sm:space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Variant Name</label>
                        <input type="text" name="variant" id="edit_variant" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Variant Image <span class="text-xs text-gray-400">(Bank/Lender Logo)</span></label>
                        <input type="file" name="variant_image" id="edit_variant_image_modal_input" accept="image/*" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                        <small class="text-xs text-gray-500">Leave blank to keep current image.</small>
                        <div id="edit_variant_current" class="mt-2 hidden">
                            <div class="flex items-center gap-2">
                                <img id="edit_variant_current_img" src="" alt="Current Variant" class="w-16 h-16 object-cover rounded border">
                                <button type="button" onclick="deleteVariantImage()" class="px-2 py-1 bg-red-500 text-white text-xs rounded hover:bg-red-600">
                                    Delete
                                </button>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="button" onclick="applyImageToAllSameLender()" class="px-3 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700">
                                Apply to all cards with same lender
                            </button>
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Product Name *</label>
                        <input type="text" name="name" id="edit_name" required class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Category</label>
                        <select name="category" id="edit_category" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base bg-white">
                            <option value="Credit Card">💳 Credit Card</option>
                            <option value="Personal Loan">💰 Personal Loan</option>
                            <option value="Car Loan">🚗 Car Loan</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Bank Redirect URL *</label>
                        <input type="url" name="bank_redirect_url" id="edit_bank_redirect_url" required class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">UTM Template URL</label>
                        <input type="url" name="utm_template_url" id="edit_utm_template_url" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Payout Source</label>
                        <input type="text" name="payout_source" id="edit_payout_source" maxlength="100" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-slate-700 mb-1">Serviceable Pin Codes (Comma separated or "ALL")</label>
                        <textarea name="pin_codes" id="edit_pin_codes_modal" rows="2" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base" placeholder="Paste bulk pincodes separated by comma, space, or new line&#10;e.g. 110001, 110002 or ALL" oninput="formatPinCodes(this)"></textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Product Highlights</label>
                        <textarea name="product_highlights" id="edit_product_highlights" rows="3" maxlength="500" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md resize-vertical text-sm sm:text-base"></textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Terms & Conditions</label>
                        <textarea name="terms_content" id="edit_terms_content" rows="4" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md resize-vertical text-sm sm:text-base"></textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Card Image</label>
                        <input type="file" name="card_image" id="edit_card_image_modal_input" accept="image/*" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                        <small class="text-xs text-gray-500">Leave blank to keep current image.</small>
                        <div id="edit_card_current" class="mt-2 hidden">
                            <div class="flex items-center gap-2">
                                <img id="edit_card_current_img" src="" alt="Current Card" class="w-16 h-16 object-cover rounded border">
                                <button type="button" onclick="deleteCardImage()" class="px-2 py-1 bg-red-500 text-white text-xs rounded hover:bg-red-600">
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Commission <span id="edit_commission_unit">Amount</span></label>
                        <div class="relative">
                            <span id="edit_commission_symbol" class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 font-bold">₹</span>
                            <input type="number" name="commission" id="edit_commission" step="0.01" min="0" required class="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-md">
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Status</label>
                        <select name="status" id="edit_status" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                            <option value="active">✅ Active</option>
                            <option value="inactive">❌ Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row justify-end gap-3 pt-4 sticky bottom-0 bg-white pb-2 sm:pb-0">
                    <button type="button" onclick="document.getElementById('editProductModal').close()" class="px-4 py-3 sm:py-2 border border-slate-300 rounded-md text-slate-700 hover:bg-slate-50 text-sm sm:text-base">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-3 sm:py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm sm:text-base">
                        Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</dialog>





<script>
// Products data for JS (for edit modal)
const productsData = <?php echo json_encode($products); ?>;
console.log('Products data loaded:', productsData.length, 'products');

function toggleFilters() {
    const panel = document.getElementById('filterPanel');
    panel.classList.toggle('hidden');
}

function clearFilters() {
    document.getElementById('filterCategory').value = '';
    document.getElementById('filterStatus').value = '';
    document.getElementById('filterSearch').value = '';
    filterProducts();
}

function filterProducts() {
    const category = document.getElementById('filterCategory')?.value || '';
    const status = document.getElementById('filterStatus')?.value || '';
    const search = (document.getElementById('filterSearch')?.value || document.getElementById('searchInput')?.value || '').toLowerCase();
    
    if (!category && !status && !search) {
        const rows = document.querySelectorAll('tbody tr');
        rows.forEach(row => {
            if (row.id && row.id.includes('history-row')) return;
            row.style.display = '';
        });
        return;
    }
    
    const rows = document.querySelectorAll('tbody tr');
    let visibleCount = 0;
    
    rows.forEach((row) => {
        if (row.id && row.id.includes('history-row')) return;
        
        const cells = row.cells;
        if (!cells || cells.length < 3) {
            row.style.display = 'none';
            return;
        }
        
        const productName = cells[0]?.textContent?.toLowerCase() || '';
        const categoryText = cells[1]?.textContent?.toLowerCase() || '';
        const commissionText = cells[2]?.textContent?.toLowerCase() || '';
        const statusText = cells[3]?.textContent?.toLowerCase() || '';
        
        let show = true;
        
        if (category && !categoryText.includes(category.toLowerCase())) show = false;
        if (status && !statusText.includes(status.toLowerCase())) show = false;
        if (search) {
            const searchable = [productName, categoryText, commissionText, statusText].join(' ');
            if (!searchable.includes(search)) show = false;
        }
        
        row.style.display = show ? '' : 'none';
        if (show) visibleCount++;
    });
}

function updateCommissionField(category, prefixId) {
    if (category === 'Personal Loan' || category === 'Car Loan') {
        document.getElementById(prefixId + '_commission_symbol').textContent = '%';
        document.getElementById(prefixId + '_commission').placeholder = '2.5';
        document.getElementById(prefixId + '_commission_unit').textContent = 'Percentage';
    } else {
        document.getElementById(prefixId + '_commission_symbol').textContent = '₹';
        document.getElementById(prefixId + '_commission').placeholder = '500';
        document.getElementById(prefixId + '_commission_unit').textContent = 'Amount';
    }
}

function applyImageToAllSameLender() {
    const currentProductId = document.getElementById('edit_product_id').value;
    const currentProduct = productsData.find(p => p.id == currentProductId);
    
    if (!currentProduct || !currentProduct.variant) {
        alert('No variant name found for this product.');
        return;
    }
    
    const sameLenderProducts = productsData.filter(p => p.variant === currentProduct.variant && p.id != currentProductId);
    
    if (sameLenderProducts.length === 0) {
        alert('No other products found with the same lender name.');
        return;
    }
    
    if (!confirm(`Apply this lender image to ${sameLenderProducts.length} other product(s) with lender "${currentProduct.variant}"?`)) {
        return;
    }
    
    const formData = new FormData();
    formData.append('apply_lender_image', '1');
    formData.append('source_product_id', currentProductId);
    formData.append('lender_name', currentProduct.variant);
    
    fetch('products.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(() => {
        alert('Lender image applied to all matching products successfully!');
        location.reload();
    })
    .catch(error => {
        alert('Error applying lender image: ' + error.message);
    });
}

function toggleAddForm() {
    const form = document.getElementById('addProductForm');
    form.classList.toggle('hidden');
    
    if (!form.classList.contains('hidden')) {
        form.scrollIntoView({ behavior: 'smooth' });
    }
}

function toggleEditForm() {
    const form = document.getElementById('editProductForm');
    form.classList.toggle('hidden');
    
    if (!form.classList.contains('hidden')) {
        form.scrollIntoView({ behavior: 'smooth' });
    }
}

function showEditForm(productId) {
    const product = productsData.find(p => p.id == productId);
    if (!product) {
        console.error('Product not found:', productId);
        return;
    }
    
    console.log('Editing product:', product);
    
    // Set form values for inline form
    document.getElementById('edit_product_id').value = product.id;
    document.getElementById('edit_name').value = product.name;
    document.getElementById('edit_category').value = product.category;
    document.getElementById('edit_variant').value = product.variant || '';
    document.getElementById('edit_commission').value = product.commission_rate;
    document.getElementById('edit_status').value = product.status;
    document.getElementById('edit_bank_redirect_url').value = product.bank_redirect_url;
    document.getElementById('edit_payout_source').value = product.payout_source || '';
    document.getElementById('edit_product_highlights').value = product.product_highlights || '';
    document.getElementById('edit_terms_content').value = product.terms_content || '';
    document.getElementById('edit_utm_template_url').value = product.utm_template_url || '';
    document.getElementById('edit_pin_codes').value = product.pin_codes || '';
    
    // Show existing images with delete buttons
    if (product.variant_image) {
        document.getElementById('edit_variant_current_img').src = '../' + product.variant_image;
        document.getElementById('edit_variant_current').classList.remove('hidden');
    } else {
        document.getElementById('edit_variant_current').classList.add('hidden');
    }
    
    if (product.card_image) {
        document.getElementById('edit_card_current_img').src = '../' + product.card_image;
        document.getElementById('edit_card_current').classList.remove('hidden');
    } else {
        document.getElementById('edit_card_current').classList.add('hidden');
    }
}

function showEditFormModal(productId) {
    const product = productsData.find(p => p.id == productId);
    if (!product) {
        console.error('Product not found:', productId);
        return;
    }
    
    // Set form values for modal form using correct modal IDs
    document.querySelector('#editProductModal input[name="product_id"]').value = product.id;
    document.querySelector('#editProductModal input[name="name"]').value = product.name;
    document.querySelector('#editProductModal select[name="category"]').value = product.category;
    document.querySelector('#editProductModal input[name="variant"]').value = product.variant || '';
    document.querySelector('#editProductModal input[name="commission"]').value = product.commission_rate;
    document.querySelector('#editProductModal select[name="status"]').value = product.status;
    document.querySelector('#editProductModal input[name="bank_redirect_url"]').value = product.bank_redirect_url;
    document.querySelector('#editProductModal input[name="payout_source"]').value = product.payout_source || '';
    document.querySelector('#editProductModal textarea[name="product_highlights"]').value = product.product_highlights || '';
    document.querySelector('#editProductModal textarea[name="terms_content"]').value = product.terms_content || '';
    document.querySelector('#editProductModal input[name="utm_template_url"]').value = product.utm_template_url || '';
    document.querySelector('#editProductModal textarea[name="pin_codes"]').value = product.pin_codes || '';
    
    // Update commission field based on category
    updateCommissionField(product.category, 'edit');
    
    // Show existing images with delete buttons
    if (product.variant_image) {
        document.getElementById('edit_variant_current_img').src = '../' + product.variant_image;
        document.getElementById('edit_variant_current').classList.remove('hidden');
    } else {
        document.getElementById('edit_variant_current').classList.add('hidden');
    }
    
    if (product.card_image) {
        document.getElementById('edit_card_current_img').src = '../' + product.card_image;
        document.getElementById('edit_card_current').classList.remove('hidden');
    } else {
        document.getElementById('edit_card_current').classList.add('hidden');
    }
}

// Image preview logic handled by ImageEditor initEditor function
document.addEventListener('DOMContentLoaded', function() {
    
    // Test if search input exists
    const searchInput = document.getElementById('searchInput');
    
    // Add filter event listeners
    document.getElementById('filterCategory').addEventListener('change', filterProducts);
    document.getElementById('filterStatus').addEventListener('change', filterProducts);
    document.getElementById('filterSearch').addEventListener('input', filterProducts);
    
    // Add category change listeners for commission field updates
    const addCategorySelect = document.querySelector('select[name="category"]');
    if (addCategorySelect) {
        addCategorySelect.addEventListener('change', function() {
            updateCommissionField(this.value, 'add');
        });
        // Initialize on page load
        updateCommissionField(addCategorySelect.value, 'add');
    }
    
    const editCategorySelect = document.getElementById('edit_category');
    if (editCategorySelect) {
        editCategorySelect.addEventListener('change', function() {
            updateCommissionField(this.value, 'edit');
        });
    }
    
    // Add main search input listener
    document.getElementById('searchInput').addEventListener('input', function(e) {
        filterProducts();
    });
    
    // Populate variant dropdown with existing variants
    function populateVariantDropdown() {
        const variantSelect = document.getElementById('variant_select');
        if (!variantSelect) return;
        
        const variants = [...new Set(productsData.map(p => p.variant).filter(v => v && v.trim() !== ''))];
        
        while (variantSelect.options.length > 2) {
            variantSelect.remove(2);
        }
        
        variants.forEach(variant => {
            const option = document.createElement('option');
            option.value = variant;
            option.textContent = variant;
            variantSelect.appendChild(option);
        });
    }
    
    // Handle variant selection change
    document.getElementById('variant_select')?.addEventListener('change', function() {
        const newVariantInput = document.getElementById('variant_new');
        if (this.value === '+new') {
            newVariantInput.classList.remove('hidden');
            newVariantInput.required = true;
        } else {
            newVariantInput.classList.add('hidden');
            newVariantInput.required = false;
            newVariantInput.value = '';
        }
    });
    
    // Initialize variant dropdown
    populateVariantDropdown();
    
    // Also populate when add form is opened
    const originalToggleAddForm = window.toggleAddForm;
    window.toggleAddForm = function() {
        if (originalToggleAddForm) originalToggleAddForm();
        setTimeout(() => populateVariantDropdown(), 100);
    };
    
    // Add file input change listeners for image preview
    const addVariantInput = document.getElementById('add_variant_image_input');
    const addCardInput = document.getElementById('add_card_image_input');
    const editVariantInput = document.getElementById('edit_variant_image_input');
    const editCardInput = document.getElementById('edit_card_image_input');
    
    if (addVariantInput) {
        addVariantInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('add_variant_img').src = e.target.result;
                    document.getElementById('add_variant_preview').classList.remove('hidden');
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    if (addCardInput) {
        addCardInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('add_card_img').src = e.target.result;
                    document.getElementById('add_card_preview').classList.remove('hidden');
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    if (editVariantInput) {
        editVariantInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('edit_variant_img').src = e.target.result;
                    document.getElementById('edit_variant_preview').classList.remove('hidden');
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    if (editCardInput) {
        editCardInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('edit_card_img').src = e.target.result;
                    document.getElementById('edit_card_preview').classList.remove('hidden');
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    // Auto-format pin codes function
    window.formatPinCodes = function(textarea) {
        let value = textarea.value;
        
        // Don't format if it's ALL (case insensitive)
        if (value.trim().toUpperCase() === 'ALL') {
            return;
        }
        
        // Split by comma, space, or new line
        let pincodes = value.split(/[\s,\n]+/).filter(p => p.trim() !== '');
        
        // Format each pincode (ensure 6 digits)
        let formattedPincodes = pincodes.map(pin => {
            pin = pin.trim();
            // Remove any non-digit characters
            pin = pin.replace(/\D/g, '');
            // Limit to 6 digits if user keeps typing
            if (pin.length > 6) {
                pin = pin.substring(0, 6);
            }
            return pin;
        }).filter(pin => pin.length === 6); // Only keep valid 6-digit pincodes
        
        // Remove duplicates
        formattedPincodes = [...new Set(formattedPincodes)];
        
        // Join with comma and space
        if (formattedPincodes.length > 0) {
            // Only update if the value actually changed to avoid cursor jumping
            let newValue = formattedPincodes.join(', ');
            if (textarea.value !== newValue && !newValue.startsWith(textarea.value)) {
                 textarea.value = newValue;
            }
        }
    };
    
    // Delete image functions
    window.deleteVariantImage = function() {
        if (confirm('Delete variant image?')) {
            const productId = document.getElementById('edit_product_id').value;
            const formData = new FormData();
            formData.append('delete_variant_image', '1');
            formData.append('product_id', productId);
            
            fetch('products.php', {
                method: 'POST',
                body: formData
            }).then(() => {
                document.getElementById('edit_variant_current').classList.add('hidden');
                alert('Variant image deleted');
            });
        }
    };
    
    window.deleteCardImage = function() {
        if (confirm('Delete card image?')) {
            const productId = document.getElementById('edit_product_id').value;
            const formData = new FormData();
            formData.append('delete_card_image', '1');
            formData.append('product_id', productId);
            
            fetch('products.php', {
                method: 'POST',
                body: formData
            }).then(() => {
                document.getElementById('edit_card_current').classList.add('hidden');
                alert('Card image deleted');
            });
        }
    };
});
</script>
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>



<script>
function toggleHistory(productId) {
    const historyRow = document.getElementById('history-row-' + productId);
    const content = document.getElementById('history-content-' + productId);
    
    if (historyRow.classList.contains('hidden')) {
        historyRow.classList.remove('hidden');
        
        fetch('products.php?history_html=1&product_id=' + encodeURIComponent(productId))
            .then(res => {
                if (!res.ok) throw new Error('Server error');
                return res.text();
            })
            .then(html => {
                content.innerHTML = html;
            })
            .catch(err => {
                content.innerHTML = '<div class="text-red-600 p-4">Failed to load history: ' + err.message + '</div>';
            });
    } else {
        historyRow.classList.add('hidden');
    }
}
</script>
