<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../includes/timezone_helper.php';
requireLogin();
if (!isAdmin()) { header('Location: ../adviser/dashboard.php'); exit(); }

ensureTimezone();

$database = new Database();
$conn = $database->getConnection();

// Handle product add
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $name = trim($_POST['name']);
    $category = $_POST['category'];
    $variant = isset($_POST['variant']) ? trim($_POST['variant']) : '';
    $commission = floatval($_POST['commission']);
    $status = $_POST['status'];
    $bankRedirectUrl = trim($_POST['bank_redirect_url']);
    $utmTemplateUrl = trim($_POST['utm_template_url']);
    $payoutSource = trim($_POST['payout_source']);
    $productHighlights = trim($_POST['product_highlights']);
    $terms_content = trim($_POST['terms_content'] ?? '');
    
    $stmt = $conn->prepare("INSERT INTO products (name, category, variant, commission_rate, status, bank_redirect_url, utm_template_url, product_highlights, payout_source, terms_content) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('ssssssssss', $name, $category, $variant, $commission, $status, $bankRedirectUrl, $utmTemplateUrl, $productHighlights, $payoutSource, $terms_content);
    $stmt->execute();
    $stmt->close();
    header('Location: products.php');
    exit();
}

// Handle product delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product'])) {
    $id = intval($_POST['product_id']);
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
    header('Location: products.php?deleted=1');
    exit();
}

// Fetch all products
$products = [];
$res = $conn->query("SELECT * FROM products ORDER BY commission_rate DESC");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $products[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="min-h-screen bg-gray-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="p-4 sm:p-6 max-w-7xl mx-auto">
        <!-- Header -->
        <div class="mb-8">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Product Management</h1>
                    <p class="mt-1 text-sm text-gray-500">Manage your products, commissions, and settings</p>
                </div>
                <button onclick="document.getElementById('addProductModal').showModal()" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                    <i class="fas fa-plus mr-2"></i>Add Product
                </button>
            </div>
        </div>

        <!-- Products Table -->
        <div class="bg-white rounded-xl shadow-sm overflow-hidden">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Commission</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php foreach ($products as $product): ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($product['name']); ?></div>
                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($product['variant'] ?? 'No variant'); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($product['category']); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">
                                <?php 
                                if ($product['category'] === 'Personal Loan') {
                                    echo number_format($product['commission_rate'], 2) . '%';
                                } else {
                                    echo '₹' . number_format($product['commission_rate'], 2);
                                } ?>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $product['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                <?php echo ucfirst($product['status']); ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <form method="POST" onsubmit="return confirm('Delete this product?');" class="inline">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                <button type="submit" name="delete_product" class="text-red-600 hover:text-red-900">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Product Modal -->
    <dialog id="addProductModal" class="rounded-lg p-6 max-w-md w-full">
        <h2 class="text-xl font-bold mb-4">Add New Product</h2>
        <form method="POST">
            <input type="hidden" name="add_product" value="1">
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Product Name *</label>
                    <input type="text" name="name" required class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Category</label>
                    <select name="category" class="w-full px-3 py-2 border rounded-md">
                        <option value="Credit Card">Credit Card</option>
                        <option value="Personal Loan">Personal Loan</option>
                        <option value="Car Loan">Car Loan</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Variant</label>
                    <input type="text" name="variant" class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Commission</label>
                    <input type="number" name="commission" step="0.01" class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Bank URL</label>
                    <input type="url" name="bank_redirect_url" class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">UTM URL</label>
                    <input type="url" name="utm_template_url" class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Payout Source</label>
                    <input type="text" name="payout_source" class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Status</label>
                    <select name="status" class="w-full px-3 py-2 border rounded-md">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
            </div>
            <div class="flex justify-end gap-3 mt-6">
                <button type="button" onclick="document.getElementById('addProductModal').close()" class="px-4 py-2 border rounded-md">Cancel</button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md">Add Product</button>
            </div>
        </form>
    </dialog>
    <script src="/assets/js/loading.js"></script>
</body>
</html>