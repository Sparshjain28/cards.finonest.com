<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

$database = new Database();
$conn = $database->getConnection();

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_product'])) {
        $name = trim($_POST['name']);
        $category = $_POST['category'];
        $variant = trim($_POST['variant'] ?? '');
        $commission = floatval($_POST['commission']);
        $status = $_POST['status'];
        $bankRedirectUrl = trim($_POST['bank_redirect_url']);
        $utmTemplateUrl = trim($_POST['utm_template_url'] ?? '');
        $payoutSource = trim($_POST['payout_source'] ?? '');
        $productHighlights = trim($_POST['product_highlights'] ?? '');
        $pinCodes = trim($_POST['pin_codes'] ?? '');
        $terms_content = trim($_POST['terms_content'] ?? '');
        
        $stmt = $conn->prepare("INSERT INTO products (name, category, variant, commission_rate, status, bank_redirect_url, utm_template_url, product_highlights, payout_source, terms_content, pin_codes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('sssssssssss', $name, $category, $variant, $commission, $status, $bankRedirectUrl, $utmTemplateUrl, $productHighlights, $payoutSource, $terms_content, $pinCodes);
        $stmt->execute();
        $stmt->close();
        header('Location: products_complete.php');
        exit();
    }
    
    if (isset($_POST['edit_product'])) {
        $id = intval($_POST['product_id']);
        $name = trim($_POST['name']);
        $category = $_POST['category'];
        $variant = trim($_POST['variant'] ?? '');
        $commission = floatval($_POST['commission']);
        $status = $_POST['status'];
        $bankRedirectUrl = trim($_POST['bank_redirect_url']);
        $utmTemplateUrl = trim($_POST['utm_template_url'] ?? '');
        $payoutSource = trim($_POST['payout_source'] ?? '');
        $productHighlights = trim($_POST['product_highlights'] ?? '');
        $pinCodes = trim($_POST['pin_codes'] ?? '');
        $terms_content = trim($_POST['terms_content'] ?? '');
        
        $stmt = $conn->prepare("UPDATE products SET name=?, category=?, variant=?, commission_rate=?, status=?, bank_redirect_url=?, utm_template_url=?, product_highlights=?, payout_source=?, terms_content=?, pin_codes=? WHERE id=?");
        $stmt->bind_param('sssssssssssi', $name, $category, $variant, $commission, $status, $bankRedirectUrl, $utmTemplateUrl, $productHighlights, $payoutSource, $terms_content, $pinCodes, $id);
        $stmt->execute();
        $stmt->close();
        header('Location: products_complete.php?updated=1');
        exit();
    }
    
    if (isset($_POST['delete_product'])) {
        $id = intval($_POST['product_id']);
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        header('Location: products_complete.php?deleted=1');
        exit();
    }
}

// Fetch products with filters
$whereClause = "WHERE 1=1";
$params = [];
$types = "";

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = '%' . $_GET['search'] . '%';
    $whereClause .= " AND (name LIKE ? OR variant LIKE ? OR category LIKE ?)";
    $params = array_merge($params, [$search, $search, $search]);
    $types .= "sss";
}

if (isset($_GET['category']) && !empty($_GET['category'])) {
    $whereClause .= " AND category = ?";
    $params[] = $_GET['category'];
    $types .= "s";
}

if (isset($_GET['status']) && !empty($_GET['status'])) {
    $whereClause .= " AND status = ?";
    $params[] = $_GET['status'];
    $types .= "s";
}

$sql = "SELECT * FROM products $whereClause ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}
$stmt->close();

$totalProducts = count($products);
$activeProducts = 0;
foreach ($products as $p) {
    if ($p['status'] === 'active') $activeProducts++;
}
$inactiveProducts = $totalProducts - $activeProducts;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .image-editor-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 9999;
            display: none;
            align-items: center;
            justify-content: center;
        }
        .image-editor-modal.active { display: flex; }
        .editor-container {
            background: #1f2937;
            border-radius: 12px;
            width: 90vw;
            max-width: 800px;
            height: 90vh;
            display: flex;
            flex-direction: column;
            color: white;
        }
        .editor-header {
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #374151;
            display: flex;
            justify-content: between;
            align-items: center;
        }
        .editor-body {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            overflow: hidden;
        }
        .editor-canvas-wrapper {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: move;
        }
        .editor-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid #374151;
            background: #111827;
        }
        .editor-controls {
            display: flex;
            gap: 1rem;
            margin-bottom: 1rem;
            flex-wrap: wrap;
        }
        .control-item {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        .control-label {
            font-size: 0.75rem;
            color: #9ca3af;
        }
        .editor-range {
            width: 100px;
        }
        .slider-wrapper {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .mode-toggle {
            display: flex;
            border-radius: 6px;
            overflow: hidden;
        }
        .mode-btn {
            padding: 0.25rem 0.75rem;
            background: #374151;
            color: #9ca3af;
            border: none;
            cursor: pointer;
            font-size: 0.75rem;
        }
        .mode-btn.active {
            background: #3b82f6;
            color: white;
        }
        .editor-btn {
            padding: 0.5rem 1rem;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            font-size: 0.875rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .editor-btn-success {
            background: #10b981;
            color: white;
        }
        .editor-btn-danger {
            background: #ef4444;
            color: white;
        }
        .image-preview-box {
            width: 80px;
            height: 80px;
            border: 2px dashed #d1d5db;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 0.5rem;
        }
        .image-preview-box img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            border-radius: 4px;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="container mx-auto p-4">
        <?php if (isset($_GET['updated'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            Product updated successfully!
        </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['deleted'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            Product deleted successfully!
        </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white p-6 rounded-lg shadow">
                <div class="flex items-center">
                    <i class="fas fa-boxes text-2xl text-blue-600 mr-4"></i>
                    <div>
                        <p class="text-sm text-gray-500">Total Products</p>
                        <p class="text-2xl font-bold"><?php echo $totalProducts; ?></p>
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow">
                <div class="flex items-center">
                    <i class="fas fa-check-circle text-2xl text-green-600 mr-4"></i>
                    <div>
                        <p class="text-sm text-gray-500">Active Products</p>
                        <p class="text-2xl font-bold"><?php echo $activeProducts; ?></p>
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow">
                <div class="flex items-center">
                    <i class="fas fa-times-circle text-2xl text-red-600 mr-4"></i>
                    <div>
                        <p class="text-sm text-gray-500">Inactive Products</p>
                        <p class="text-2xl font-bold"><?php echo $inactiveProducts; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search and Filters -->
        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <input type="text" name="search" id="searchInput" value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>" placeholder="Search products..." class="w-full border border-gray-300 rounded-md px-3 py-2">
                </div>
                <div>
                    <select name="category" id="filterCategory" class="w-full border border-gray-300 rounded-md px-3 py-2">
                        <option value="">All Categories</option>
                        <option value="Credit Card" <?php echo ($_GET['category'] ?? '') === 'Credit Card' ? 'selected' : ''; ?>>Credit Card</option>
                        <option value="Personal Loan" <?php echo ($_GET['category'] ?? '') === 'Personal Loan' ? 'selected' : ''; ?>>Personal Loan</option>
                        <option value="Car Loan" <?php echo ($_GET['category'] ?? '') === 'Car Loan' ? 'selected' : ''; ?>>Car Loan</option>
                    </select>
                </div>
                <div>
                    <select name="status" id="filterStatus" class="w-full border border-gray-300 rounded-md px-3 py-2">
                        <option value="">All Status</option>
                        <option value="active" <?php echo ($_GET['status'] ?? '') === 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo ($_GET['status'] ?? '') === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>
                <div class="flex space-x-2">
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Search</button>
                    <a href="products_complete.php" class="bg-gray-500 text-white px-4 py-2 rounded">Clear</a>
                </div>
            </form>
        </div>

        <!-- Add Product Button -->
        <div class="mb-6">
            <button onclick="document.getElementById('addProductModal').showModal()" class="bg-blue-600 text-white px-4 py-2 rounded">
                <i class="fas fa-plus mr-2"></i> Add New Product
            </button>
        </div>

        <!-- Products Table -->
        <div class="bg-white rounded-xl shadow-sm overflow-hidden">
            <div class="table-container overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Commission</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th scope="col" class="relative px-6 py-3"><span class="sr-only">Actions</span></th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($products as $index => $product): 
                            $statusColor = $product['status'] === 'active' ? 'green' : 'red';
                            $statusIcon = $product['status'] === 'active' ? 'check-circle' : 'times-circle';
                            $categoryIcon = '';
                            $categoryColor = '';
                            
                            switch($product['category']) {
                                case 'Credit Card':
                                    $categoryIcon = 'credit-card';
                                    $categoryColor = 'blue';
                                    break;
                                case 'Personal Loan':
                                    $categoryIcon = 'hand-holding-usd';
                                    $categoryColor = 'green';
                                    break;
                                case 'Car Loan':
                                    $categoryIcon = 'car';
                                    $categoryColor = 'purple';
                                    break;
                                default:
                                    $categoryIcon = 'box';
                                    $categoryColor = 'gray';
                            }
                        ?>
                    <tr class="hover:bg-gray-50 transition-colors">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center">
                                <div class="flex-shrink-0 h-10 w-10 rounded-full bg-<?php echo $categoryColor; ?>-100 flex items-center justify-center text-<?php echo $categoryColor; ?>-600">
                                    <i class="fas fa-<?php echo $categoryIcon; ?> text-sm"></i>
                                </div>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($product['name']); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo htmlspecialchars($product['variant'] ?? 'No variant'); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($product['category']); ?></div>
                            <div class="text-xs text-gray-500">ID: <?php echo $product['id']; ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">
                                <?php 
                                if ($product['category'] === 'Personal Loan' || $product['category'] === 'Car Loan') {
                                    echo number_format($product['commission_rate'], 2) . '%';
                                } else {
                                    echo '₹' . number_format($product['commission_rate'], 2);
                                } ?>
                            </div>
                            <div class="text-xs text-gray-500">per approval</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-<?php echo $statusColor; ?>-100 text-<?php echo $statusColor; ?>-800">
                                <i class="fas fa-<?php echo $statusIcon; ?> mr-1"></i>
                                <?php echo ucfirst($product['status']); ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <div class="flex items-center justify-end space-x-2">
                                <button onclick="showEditForm(<?php echo $product['id']; ?>)" class="text-blue-600 hover:text-blue-900 transition-colors p-1.5 rounded-full hover:bg-blue-50">
                                    <i class="fas fa-edit w-5 h-5"></i>
                                </button>
                                <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this product?');" class="inline">
                                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                    <button type="submit" name="delete_product" class="text-red-600 hover:text-red-900 transition-colors p-1.5 rounded-full hover:bg-red-50">
                                        <i class="fas fa-trash w-5 h-5"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                        </tr>
                        <?php endforeach; ?>

                        <?php if (empty($products)): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-12 text-center">
                                <div class="flex flex-col items-center justify-center">
                                    <div class="bg-gray-100 p-4 rounded-full mb-4">
                                        <i class="fas fa-box-open text-3xl text-gray-400"></i>
                                    </div>
                                    <h3 class="text-lg font-medium text-gray-900 mb-1">No products found</h3>
                                    <p class="text-gray-500 mb-4 max-w-md">Get started by adding your first product to the system.</p>
                                    <button onclick="document.getElementById('addProductModal').showModal()" class="btn-primary inline-flex items-center px-4 py-2">
                                        <i class="fas fa-plus mr-2"></i>
                                        Add Product
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>

<!-- Add Product Modal -->
<dialog id="addProductModal" class="fixed inset-0 z-50 w-full h-full m-0 p-0 bg-black bg-opacity-50 overflow-y-auto">
    <div class="min-h-screen flex items-center justify-center p-2 sm:p-4">
        <div class="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
            <div class="bg-blue-600 text-white px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between sticky top-0 z-10">
                <h2 class="text-lg sm:text-xl font-bold">Add New Product</h2>
                <button type="button" onclick="document.getElementById('addProductModal').close()" class="p-2 -mr-2 text-white hover:bg-blue-700 rounded-full transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            <form method="POST" enctype="multipart/form-data" class="flex-1 overflow-y-auto p-4 sm:p-6">
                <input type="hidden" name="add_product" value="1">
                <div class="space-y-3 sm:space-y-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Variant Name <span class="text-xs text-gray-400">(e.g. HDFC Bank)</span></label>
                    <input type="text" name="variant" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base" placeholder="Enter variant name">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Product Name *</label>
                    <input type="text" name="name" required class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base" placeholder="Enter product name">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Category</label>
                    <select name="category" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base bg-white">
                        <option value="Credit Card">💳 Credit Card</option>
                        <option value="Personal Loan">💰 Personal Loan</option>
                        <option value="Car Loan">🚗 Car Loan</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Bank Redirect URL *</label>
                    <input type="url" name="bank_redirect_url" required class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base" placeholder="https://bank.example.com/apply">
                    <small class="text-xs text-gray-500">You can use <b>{lead_id}</b> in the URL.</small>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">UTM Template URL</label>
                    <input type="url" name="utm_template_url" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base" placeholder="https://example.com?utm_id={unique_id}">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Payout Source</label>
                    <input type="text" name="payout_source" maxlength="100" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Product Highlights <span class="text-xs text-gray-400">(Max 3 rows)</span></label>
                    <textarea name="product_highlights" rows="3" maxlength="500" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md resize-vertical text-sm sm:text-base" oninput="this.value=this.value.split('\n').slice(0,3).join('\n')"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Terms & Conditions</label>
                    <textarea name="terms_content" rows="4" maxlength="5000" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md resize-vertical text-sm sm:text-base" placeholder="Enter terms and conditions"></textarea>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Commission <span id="add_commission_unit">Amount</span></label>
                    <div class="relative">
                        <span id="add_commission_symbol" class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 font-bold">₹</span>
                        <input type="number" name="commission" id="add_commission" step="0.01" min="0" required class="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-md" placeholder="500">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1">Status</label>
                    <select name="status" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                        <option value="active">✅ Active</option>
                        <option value="inactive">❌ Inactive</option>
                    </select>
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-slate-700 mb-1">Serviceable Pin Codes (Comma separated or "ALL")</label>
                    <textarea name="pin_codes" id="add_pin_codes_modal" rows="2" class="w-full px-3 py-2 border border-slate-300 rounded-md" placeholder="Paste bulk pincodes separated by comma, space, or new line&#10;e.g. 110001, 110002 or ALL" oninput="formatPinCodes(this)"></textarea>
                </div>
            </div>
            <div class="flex flex-col sm:flex-row justify-end gap-3 pt-4 sticky bottom-0 bg-white pb-2 sm:pb-0">
                <button type="button" onclick="document.getElementById('addProductModal').close()" class="px-4 py-3 sm:py-2 border border-slate-300 rounded-md text-slate-700 hover:bg-slate-50 text-sm sm:text-base">
                    Cancel
                </button>
                <button type="submit" class="px-4 py-3 sm:py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm sm:text-base">
                    Add Product
                </button>
            </div>
        </form>
    </div>
</dialog>

<!-- Edit Product Modal -->
<dialog id="editProductModal" class="fixed inset-0 z-50 w-full h-full m-0 p-0 bg-black bg-opacity-50 overflow-y-auto">
    <div class="min-h-screen flex items-center justify-center p-2 sm:p-4">
        <div class="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
            <div class="bg-blue-600 text-white px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between sticky top-0 z-10">
                <h2 class="text-lg sm:text-xl font-bold">Edit Product</h2>
                <button type="button" onclick="document.getElementById('editProductModal').close()" class="p-2 -mr-2 text-white hover:bg-blue-700 rounded-full transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            <form method="POST" id="editProductForm" enctype="multipart/form-data" class="flex-1 overflow-y-auto p-4 sm:p-6">
                <input type="hidden" name="edit_product" value="1">
                <input type="hidden" name="product_id" id="edit_product_id">
                <div class="space-y-3 sm:space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Variant Name</label>
                        <input type="text" name="variant" id="edit_variant" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Product Name *</label>
                        <input type="text" name="name" id="edit_name" required class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Category</label>
                        <select name="category" id="edit_category" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base bg-white">
                            <option value="Credit Card">💳 Credit Card</option>
                            <option value="Personal Loan">💰 Personal Loan</option>
                            <option value="Car Loan">🚗 Car Loan</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Bank Redirect URL *</label>
                        <input type="url" name="bank_redirect_url" id="edit_bank_redirect_url" required class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">UTM Template URL</label>
                        <input type="url" name="utm_template_url" id="edit_utm_template_url" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Payout Source</label>
                        <input type="text" name="payout_source" id="edit_payout_source" maxlength="100" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-slate-700 mb-1">Serviceable Pin Codes (Comma separated or "ALL")</label>
                        <textarea name="pin_codes" id="edit_pin_codes_modal" rows="2" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md text-sm sm:text-base" placeholder="Paste bulk pincodes separated by comma, space, or new line&#10;e.g. 110001, 110002 or ALL" oninput="formatPinCodes(this)"></textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Product Highlights</label>
                        <textarea name="product_highlights" id="edit_product_highlights" rows="3" maxlength="500" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md resize-vertical text-sm sm:text-base"></textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Terms & Conditions</label>
                        <textarea name="terms_content" id="edit_terms_content" rows="4" class="w-full px-3 py-2.5 sm:py-2 border border-slate-300 rounded-md resize-vertical text-sm sm:text-base"></textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Commission <span id="edit_commission_unit">Amount</span></label>
                        <div class="relative">
                            <span id="edit_commission_symbol" class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 font-bold">₹</span>
                            <input type="number" name="commission" id="edit_commission" step="0.01" min="0" required class="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-md">
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-1">Status</label>
                        <select name="status" id="edit_status" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                            <option value="active">✅ Active</option>
                            <option value="inactive">❌ Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="flex flex-col sm:flex-row justify-end gap-3 pt-4 sticky bottom-0 bg-white pb-2 sm:pb-0">
                    <button type="button" onclick="document.getElementById('editProductModal').close()" class="px-4 py-3 sm:py-2 border border-slate-300 rounded-md text-slate-700 hover:bg-slate-50 text-sm sm:text-base">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-3 sm:py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm sm:text-base">
                        Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</dialog>

<script>
// Products data for JS (for edit modal)
const productsData = <?php echo json_encode($products); ?>;

function updateCommissionField(category, prefixId) {
    if (category === 'Personal Loan' || category === 'Car Loan') {
        document.getElementById(prefixId + '_commission_symbol').textContent = '%';
        document.getElementById(prefixId + '_commission').placeholder = '2.5';
        document.getElementById(prefixId + '_commission_unit').textContent = 'Percentage';
    } else {
        document.getElementById(prefixId + '_commission_symbol').textContent = '₹';
        document.getElementById(prefixId + '_commission').placeholder = '500';
        document.getElementById(prefixId + '_commission_unit').textContent = 'Amount';
    }
}

function showEditForm(productId) {
    const product = productsData.find(p => p.id == productId);
    if (!product) return;
    
    document.getElementById('edit_product_id').value = product.id;
    document.getElementById('edit_name').value = product.name;
    document.getElementById('edit_category').value = product.category;
    document.getElementById('edit_variant').value = product.variant || '';
    document.getElementById('edit_commission').value = product.commission_rate;
    document.getElementById('edit_status').value = product.status;
    document.getElementById('edit_bank_redirect_url').value = product.bank_redirect_url;
    document.getElementById('edit_utm_template_url').value = product.utm_template_url || '';
    document.getElementById('edit_payout_source').value = product.payout_source || '';
    document.getElementById('edit_product_highlights').value = product.product_highlights || '';
    document.getElementById('edit_terms_content').value = product.terms_content || '';
    document.getElementById('edit_pin_codes_modal').value = product.pin_codes || '';
    
    updateCommissionField(product.category, 'edit');
    document.getElementById('editProductModal').showModal();
}

// Auto-format pin codes function
window.formatPinCodes = function(textarea) {
    let value = textarea.value;
    
    // Don't format if it's ALL (case insensitive)
    if (value.trim().toUpperCase() === 'ALL') {
        return;
    }
    
    // Split by comma, space, or new line
    let pincodes = value.split(/[\s,\n]+/).filter(p => p.trim() !== '');
    
    // Format each pincode (ensure 6 digits)
    let formattedPincodes = pincodes.map(pin => {
        pin = pin.trim();
        // Remove any non-digit characters
        pin = pin.replace(/\D/g, '');
        // Limit to 6 digits if user keeps typing
        if (pin.length > 6) {
            pin = pin.substring(0, 6);
        }
        return pin;
    }).filter(pin => pin.length === 6); // Only keep valid 6-digit pincodes
    
    // Remove duplicates
    formattedPincodes = [...new Set(formattedPincodes)];
    
    // Join with comma and space
    if (formattedPincodes.length > 0) {
        // Only update if the value actually changed to avoid cursor jumping
        let newValue = formattedPincodes.join(', ');
        if (textarea.value !== newValue && !newValue.startsWith(textarea.value)) {
             textarea.value = newValue;
        }
    }
};

document.addEventListener('DOMContentLoaded', function() {
    // Add modal category change
    const addCat = document.querySelector('#addProductModal select[name="category"]');
    if (addCat) {
        addCat.onchange = function() {
            updateCommissionField(this.value, 'add');
        };
        updateCommissionField(addCat.value, 'add');
    }
    
    // Close modals when clicking outside
    document.getElementById('addProductModal').addEventListener('click', function(e) {
        if (e.target === this) this.close();
    });
    
    document.getElementById('editProductModal').addEventListener('click', function(e) {
        if (e.target === this) this.close();
    });
});
</script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>