<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../includes/timezone_helper.php';

$database = new Database();
$conn = $database->getConnection();

// Helper function to save Base64 Image
if (!function_exists('saveBase64Image')) {
    function saveBase64Image($base64String, $prefix) {
        if (empty($base64String)) return null;
        if (strpos($base64String, 'base64,') !== false) {
            $base64String = explode('base64,', $base64String)[1];
        }
        $data = base64_decode($base64String);
        if (!$data) return null;
        
        $filename = $prefix . '_' . time() . '_' . rand(1000,9999) . '.png';
        $dest = __DIR__ . '/../assets/cards/' . $filename;
        if (!is_dir(__DIR__ . '/../assets/cards')) { 
            mkdir(__DIR__ . '/../assets/cards', 0777, true); 
        }
        if (file_put_contents($dest, $data)) {
            return 'assets/cards/' . $filename;
        }
        return null;
    }
}

// Helper function for Base64 update
if (!function_exists('saveBase64ImageUpdate')) {
    function saveBase64ImageUpdate($base64String, $prefix) {
        if (empty($base64String)) return null;
        if (strpos($base64String, 'base64,') !== false) {
            $base64String = explode('base64,', $base64String)[1];
        }
        $data = base64_decode($base64String);
        if (!$data) return null;
        $filename = $prefix . '_' . time() . '_' . rand(1000,9999) . '.png';
        $dest = __DIR__ . '/../assets/cards/' . $filename;
        if (!is_dir(__DIR__ . '/../assets/cards')) { 
            mkdir(__DIR__ . '/../assets/cards', 0777, true); 
        }
        if (file_put_contents($dest, $data)) {
            return 'assets/cards/' . $filename;
        }
        return null;
    }
}

// Handle product add/edit logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_product'])) {
        $name = trim($_POST['name']);
        $category = $_POST['category'];
        $variant = isset($_POST['variant']) ? trim($_POST['variant']) : '';
        if ($variant === '+new' && isset($_POST['variant_new'])) {
            $variant = trim($_POST['variant_new']);
        }
        $commission = floatval($_POST['commission']);
        $status = $_POST['status'];
        $bankRedirectUrl = trim($_POST['bank_redirect_url']);
        $utmTemplateUrl = trim($_POST['utm_template_url'] ?? '');
        $payoutSource = trim($_POST['payout_source'] ?? '');
        $productHighlights = trim($_POST['product_highlights'] ?? '');
        $pinCodes = trim($_POST['pin_codes'] ?? '');
        $terms_content = trim($_POST['terms_content'] ?? '');
        
        // Handle card image
        $cardImage = null;
        if (!empty($_POST['card_image_base64'])) {
            $cardImage = saveBase64Image($_POST['card_image_base64'], 'card');
        } elseif (isset($_FILES['card_image']) && $_FILES['card_image']['error'] === UPLOAD_ERR_OK) {
            $ext = pathinfo($_FILES['card_image']['name'], PATHINFO_EXTENSION);
            $filename = 'card_' . time() . '_' . rand(1000,9999) . '.' . $ext;
            $dest = '../assets/cards/' . $filename;
            if (!is_dir('../assets/cards')) { mkdir('../assets/cards', 0777, true); }
            if (move_uploaded_file($_FILES['card_image']['tmp_name'], $dest)) {
                $cardImage = 'assets/cards/' . $filename;
            }
        }
        
        // Handle variant image
        $variantImage = null;
        if (!empty($_POST['variant_image_base64'])) {
            $variantImage = saveBase64Image($_POST['variant_image_base64'], 'variant');
        } elseif (isset($_FILES['variant_image']) && $_FILES['variant_image']['error'] === UPLOAD_ERR_OK) {
            $ext = pathinfo($_FILES['variant_image']['name'], PATHINFO_EXTENSION);
            $filename = 'variant_' . time() . '_' . rand(1000,9999) . '.' . $ext;
            $dest = '../assets/cards/' . $filename;
            if (!is_dir('../assets/cards')) { mkdir('../assets/cards', 0777, true); }
            if (move_uploaded_file($_FILES['variant_image']['tmp_name'], $dest)) {
                $variantImage = 'assets/cards/' . $filename;
            }
        }
        
        $stmt = $conn->prepare("INSERT INTO products (name, category, variant, commission_rate, status, bank_redirect_url, utm_template_url, card_image, variant_image, product_highlights, payout_source, terms_content, pin_codes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('sssssssssssss', $name, $category, $variant, $commission, $status, $bankRedirectUrl, $utmTemplateUrl, $cardImage, $variantImage, $productHighlights, $payoutSource, $terms_content, $pinCodes);
        $stmt->execute();
        $stmt->close();
        header('Location: products.php');
        exit();
    }
    
    if (isset($_POST['edit_product'])) {
        $id = intval($_POST['product_id']);
        $name = trim($_POST['name']);
        $category = $_POST['category'];
        $variant = isset($_POST['variant']) ? trim($_POST['variant']) : '';
        $commission = floatval($_POST['commission']);
        $status = $_POST['status'];
        $bankRedirectUrl = trim($_POST['bank_redirect_url']);
        $utmTemplateUrl = trim($_POST['utm_template_url'] ?? '');
        $payoutSource = trim($_POST['payout_source'] ?? '');
        $productHighlights = trim($_POST['product_highlights'] ?? '');
        $pinCodes = trim($_POST['pin_codes'] ?? '');
        $terms_content = trim($_POST['terms_content'] ?? '');
        
        // Handle card image
        $cardImage = null;
        if (!empty($_POST['card_image_base64'])) {
            $cardImage = saveBase64ImageUpdate($_POST['card_image_base64'], 'card');
        } elseif (isset($_FILES['card_image']) && $_FILES['card_image']['error'] === UPLOAD_ERR_OK) {
            $ext = pathinfo($_FILES['card_image']['name'], PATHINFO_EXTENSION);
            $filename = 'card_' . time() . '_' . rand(1000,9999) . '.' . $ext;
            $dest = '../assets/cards/' . $filename;
            if (!is_dir('../assets/cards')) { mkdir('../assets/cards', 0777, true); }
            if (move_uploaded_file($_FILES['card_image']['tmp_name'], $dest)) {
                $cardImage = 'assets/cards/' . $filename;
            }
        }
        
        // Handle variant image
        $variantImage = null;
        if (!empty($_POST['variant_image_base64'])) {
            $variantImage = saveBase64ImageUpdate($_POST['variant_image_base64'], 'variant');
        } elseif (isset($_FILES['variant_image']) && $_FILES['variant_image']['error'] === UPLOAD_ERR_OK) {
            $ext = pathinfo($_FILES['variant_image']['name'], PATHINFO_EXTENSION);
            $filename = 'variant_' . time() . '_' . rand(1000,9999) . '.' . $ext;
            $dest = '../assets/cards/' . $filename;
            if (!is_dir('../assets/cards')) { mkdir('../assets/cards', 0777, true); }
            if (move_uploaded_file($_FILES['variant_image']['tmp_name'], $dest)) {
                $variantImage = 'assets/cards/' . $filename;
            }
        }
        
        if ($cardImage && $variantImage) {
            $stmt = $conn->prepare("UPDATE products SET name=?, category=?, variant=?, commission_rate=?, status=?, bank_redirect_url=?, utm_template_url=?, payout_source=?, product_highlights=?, card_image=?, variant_image=?, terms_content=?, pin_codes=? WHERE id=?");
            $stmt->bind_param('sssssssssssssi', $name, $category, $variant, $commission, $status, $bankRedirectUrl, $utmTemplateUrl, $payoutSource, $productHighlights, $cardImage, $variantImage, $terms_content, $pinCodes, $id);
        } elseif ($cardImage) {
            $stmt = $conn->prepare("UPDATE products SET name=?, category=?, variant=?, commission_rate=?, status=?, bank_redirect_url=?, utm_template_url=?, payout_source=?, product_highlights=?, card_image=?, terms_content=?, pin_codes=? WHERE id=?");
            $stmt->bind_param('ssssssssssssi', $name, $category, $variant, $commission, $status, $bankRedirectUrl, $utmTemplateUrl, $payoutSource, $productHighlights, $cardImage, $terms_content, $pinCodes, $id);
        } elseif ($variantImage) {
            $stmt = $conn->prepare("UPDATE products SET name=?, category=?, variant=?, commission_rate=?, status=?, bank_redirect_url=?, utm_template_url=?, payout_source=?, product_highlights=?, variant_image=?, terms_content=?, pin_codes=? WHERE id=?");
            $stmt->bind_param('ssssssssssssi', $name, $category, $variant, $commission, $status, $bankRedirectUrl, $utmTemplateUrl, $payoutSource, $productHighlights, $variantImage, $terms_content, $pinCodes, $id);
        } else {
            $stmt = $conn->prepare("UPDATE products SET name=?, category=?, variant=?, commission_rate=?, status=?, bank_redirect_url=?, utm_template_url=?, payout_source=?, product_highlights=?, terms_content=?, pin_codes=? WHERE id=?");
            $stmt->bind_param('sssssssssssi', $name, $category, $variant, $commission, $status, $bankRedirectUrl, $utmTemplateUrl, $payoutSource, $productHighlights, $terms_content, $pinCodes, $id);
        }
        $stmt->execute();
        $stmt->close();
        header('Location: products.php');
        exit();
    }
}

// Fetch all products
$products = [];
$res = $conn->query("SELECT * FROM products ORDER BY commission_rate DESC");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $products[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
</head>
<body>
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="container mx-auto p-4">
        <h1 class="text-2xl font-bold mb-4">Product Management</h1>
        
        <!-- Products Table -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <table class="min-w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Commission</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php foreach ($products as $product): ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($product['name']); ?></div>
                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($product['variant'] ?? 'No variant'); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <?php echo htmlspecialchars($product['category']); ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <?php 
                            if ($product['category'] === 'Personal Loan' || $product['category'] === 'Car Loan') {
                                echo number_format($product['commission_rate'], 2) . '%';
                            } else {
                                echo '₹' . number_format($product['commission_rate'], 2);
                            } 
                            ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $product['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                <?php echo ucfirst($product['status']); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="/assets/js/loading.js"></script>
</body>
</html>