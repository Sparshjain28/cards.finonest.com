<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

$database = new Database();
$conn = $database->getConnection();

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_product'])) {
        $name = trim($_POST['name']);
        $category = $_POST['category'];
        $variant = trim($_POST['variant'] ?? '');
        $commission = floatval($_POST['commission']);
        $status = $_POST['status'];
        $bankRedirectUrl = trim($_POST['bank_redirect_url']);
        $utmTemplateUrl = trim($_POST['utm_template_url'] ?? '');
        $payoutSource = trim($_POST['payout_source'] ?? '');
        $productHighlights = trim($_POST['product_highlights'] ?? '');
        $pinCodes = trim($_POST['pin_codes'] ?? '');
        $terms_content = trim($_POST['terms_content'] ?? '');
        
        $stmt = $conn->prepare("INSERT INTO products (name, category, variant, commission_rate, status, bank_redirect_url, utm_template_url, product_highlights, payout_source, terms_content, pin_codes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('sssssssssss', $name, $category, $variant, $commission, $status, $bankRedirectUrl, $utmTemplateUrl, $productHighlights, $payoutSource, $terms_content, $pinCodes);
        $stmt->execute();
        $stmt->close();
        header('Location: products_simple.php');
        exit();
    }
    
    if (isset($_POST['edit_product'])) {
        $id = intval($_POST['product_id']);
        $name = trim($_POST['name']);
        $category = $_POST['category'];
        $variant = trim($_POST['variant'] ?? '');
        $commission = floatval($_POST['commission']);
        $status = $_POST['status'];
        $bankRedirectUrl = trim($_POST['bank_redirect_url']);
        $utmTemplateUrl = trim($_POST['utm_template_url'] ?? '');
        $payoutSource = trim($_POST['payout_source'] ?? '');
        $productHighlights = trim($_POST['product_highlights'] ?? '');
        $pinCodes = trim($_POST['pin_codes'] ?? '');
        $terms_content = trim($_POST['terms_content'] ?? '');
        
        $stmt = $conn->prepare("UPDATE products SET name=?, category=?, variant=?, commission_rate=?, status=?, bank_redirect_url=?, utm_template_url=?, product_highlights=?, payout_source=?, terms_content=?, pin_codes=? WHERE id=?");
        $stmt->bind_param('sssssssssssi', $name, $category, $variant, $commission, $status, $bankRedirectUrl, $utmTemplateUrl, $productHighlights, $payoutSource, $terms_content, $pinCodes, $id);
        $stmt->execute();
        $stmt->close();
        header('Location: products_simple.php?updated=1');
        exit();
    }
    
    if (isset($_POST['delete_product'])) {
        $id = intval($_POST['product_id']);
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->close();
        header('Location: products_simple.php?deleted=1');
        exit();
    }
}

// Fetch products with filters
$whereClause = "WHERE 1=1";
$params = [];
$types = "";

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = '%' . $_GET['search'] . '%';
    $whereClause .= " AND (name LIKE ? OR variant LIKE ? OR category LIKE ?)";
    $params = array_merge($params, [$search, $search, $search]);
    $types .= "sss";
}

if (isset($_GET['category']) && !empty($_GET['category'])) {
    $whereClause .= " AND category = ?";
    $params[] = $_GET['category'];
    $types .= "s";
}

if (isset($_GET['status']) && !empty($_GET['status'])) {
    $whereClause .= " AND status = ?";
    $params[] = $_GET['status'];
    $types .= "s";
}

$sql = "SELECT * FROM products $whereClause ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}
$stmt->close();

$totalProducts = count($products);
$activeProducts = 0;
foreach ($products as $p) {
    if ($p['status'] === 'active') $activeProducts++;
}
$inactiveProducts = $totalProducts - $activeProducts;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="container mx-auto p-4">
        <h1 class="text-3xl font-bold mb-6">Product Management</h1>

        <?php if (isset($_GET['updated'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            Product updated successfully!
        </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['deleted'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            Product deleted successfully!
        </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white p-6 rounded-lg shadow">
                <div class="flex items-center">
                    <i class="fas fa-boxes text-2xl text-blue-600 mr-4"></i>
                    <div>
                        <p class="text-sm text-gray-500">Total Products</p>
                        <p class="text-2xl font-bold"><?php echo $totalProducts; ?></p>
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow">
                <div class="flex items-center">
                    <i class="fas fa-check-circle text-2xl text-green-600 mr-4"></i>
                    <div>
                        <p class="text-sm text-gray-500">Active Products</p>
                        <p class="text-2xl font-bold"><?php echo $activeProducts; ?></p>
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow">
                <div class="flex items-center">
                    <i class="fas fa-times-circle text-2xl text-red-600 mr-4"></i>
                    <div>
                        <p class="text-sm text-gray-500">Inactive Products</p>
                        <p class="text-2xl font-bold"><?php echo $inactiveProducts; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search and Filters -->
        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Search</label>
                    <input type="text" name="search" value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>" placeholder="Search products..." class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select name="category" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">All Categories</option>
                        <option value="Credit Card" <?php echo ($_GET['category'] ?? '') === 'Credit Card' ? 'selected' : ''; ?>>Credit Card</option>
                        <option value="Personal Loan" <?php echo ($_GET['category'] ?? '') === 'Personal Loan' ? 'selected' : ''; ?>>Personal Loan</option>
                        <option value="Car Loan" <?php echo ($_GET['category'] ?? '') === 'Car Loan' ? 'selected' : ''; ?>>Car Loan</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <select name="status" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">All Status</option>
                        <option value="active" <?php echo ($_GET['status'] ?? '') === 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo ($_GET['status'] ?? '') === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>
                <div class="flex items-end space-x-2">
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                        <i class="fas fa-search mr-1"></i> Search
                    </button>
                    <a href="products_simple.php" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">
                        <i class="fas fa-times mr-1"></i> Clear
                    </a>
                </div>
            </form>
        </div>

        <!-- Add Product Button -->
        <div class="mb-6">
            <button onclick="document.getElementById('addModal').style.display='flex'" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                <i class="fas fa-plus mr-2"></i> Add New Product
            </button>
        </div>

        <!-- Products Table -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <table class="min-w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Commission</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php foreach ($products as $product): ?>
                    <tr>
                        <td class="px-6 py-4">
                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($product['name']); ?></div>
                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($product['variant'] ?? ''); ?></div>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-900"><?php echo htmlspecialchars($product['category']); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-900">
                            <?php 
                            if ($product['category'] === 'Personal Loan' || $product['category'] === 'Car Loan') {
                                echo number_format($product['commission_rate'], 2) . '%';
                            } else {
                                echo '₹' . number_format($product['commission_rate'], 2);
                            } 
                            ?>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs font-semibold rounded-full <?php echo $product['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                <?php echo ucfirst($product['status']); ?>
                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <button onclick="openEditModal(<?php echo htmlspecialchars(json_encode($product)); ?>)" class="text-blue-600 hover:text-blue-900 mr-3">
                                <i class="fas fa-edit"></i>
                            </button>
                            <form method="POST" class="inline" onsubmit="return confirm('Delete this product?')">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                <button type="submit" name="delete_product" class="text-red-600 hover:text-red-900">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center text-gray-500">
                            <i class="fas fa-box-open text-4xl mb-4"></i>
                            <p>No products found</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div id="addModal" style="display:none;" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold">Add New Product</h3>
                <button onclick="document.getElementById('addModal').style.display='none'" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            
            <form method="POST">
                <input type="hidden" name="add_product" value="1">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Product Name *</label>
                        <input type="text" name="name" required class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Category *</label>
                        <select name="category" required class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">Select Category</option>
                            <option value="Credit Card">Credit Card</option>
                            <option value="Personal Loan">Personal Loan</option>
                            <option value="Car Loan">Car Loan</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Variant/Bank Name</label>
                        <input type="text" name="variant" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Commission Rate *</label>
                        <input type="number" name="commission" step="0.01" required class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                        <select name="status" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Payout Source</label>
                        <input type="text" name="payout_source" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>
                <div class="mt-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Bank Redirect URL *</label>
                    <input type="url" name="bank_redirect_url" required class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div class="mt-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">UTM Template URL</label>
                    <input type="url" name="utm_template_url" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div class="mt-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Product Highlights</label>
                    <textarea name="product_highlights" rows="3" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                </div>
                <div class="mt-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Serviceable Pin Codes</label>
                    <textarea name="pin_codes" rows="2" placeholder="Comma separated pin codes" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                </div>
                <div class="mt-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Terms & Conditions</label>
                    <textarea name="terms_content" rows="4" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                </div>
                <div class="mt-6 flex justify-end space-x-3">
                    <button type="button" onclick="document.getElementById('addModal').style.display='none'" class="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Add Product</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    function closeModal() {
        document.getElementById('addModal').style.display = 'none';
    }
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Product Name *</label>
                        <input type="text" name="name" required class="w-full px-3 py-2 border border-gray-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Category *</label>
                        <select name="category" required class="w-full px-3 py-2 border border-gray-300 rounded-md">
                            <option value="Credit Card">Credit Card</option>
                            <option value="Personal Loan">Personal Loan</option>
                            <option value="Car Loan">Car Loan</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Variant/Bank Name</label>
                        <input type="text" name="variant" class="w-full px-3 py-2 border border-gray-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Commission *</label>
                        <input type="number" name="commission" step="0.01" min="0" required class="w-full px-3 py-2 border border-gray-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Bank Redirect URL *</label>
                        <input type="url" name="bank_redirect_url" required class="w-full px-3 py-2 border border-gray-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                        <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded-md">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">UTM Template URL</label>
                        <input type="url" name="utm_template_url" class="w-full px-3 py-2 border border-gray-300 rounded-md">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Payout Source</label>
                        <input type="text" name="payout_source" class="w-full px-3 py-2 border border-gray-300 rounded-md">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Product Highlights</label>
                        <textarea name="product_highlights" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md"></textarea>
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Terms & Conditions</label>
                        <textarea name="terms_content" rows="4" class="w-full px-3 py-2 border border-gray-300 rounded-md"></textarea>
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Pin Codes</label>
                        <textarea name="pin_codes" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-md" placeholder="110001, 110002, 110003 or ALL"></textarea>
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3 mt-6">
                    <button type="button" onclick="document.getElementById('addModal').style.display='none'" class="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700">Cancel</button>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Add Product</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Close modal when clicking outside
        document.getElementById('addModal').addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>