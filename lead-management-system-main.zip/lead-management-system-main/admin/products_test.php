<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "Starting products.php...<br>";

try {
    echo "1. Including auth...<br>";
    require_once __DIR__ . '/../includes/auth.php';
    echo "Auth included<br>";
    
    echo "2. Including database...<br>";
    require_once __DIR__ . '/../config/database_updated.php';
    echo "Database included<br>";
    
    echo "3. Including timezone helper...<br>";
    require_once __DIR__ . '/../includes/timezone_helper.php';
    echo "Timezone helper included<br>";
    
    echo "4. Checking login...<br>";
    requireLogin();
    echo "Login check passed<br>";
    
    echo "5. Checking admin...<br>";
    if (!isAdmin()) { 
        echo "Not admin, redirecting...<br>";
        header('Location: ../adviser/dashboard.php'); 
        exit(); 
    }
    echo "Admin check passed<br>";
    
    echo "6. Setting timezone...<br>";
    ensureTimezone();
    echo "Timezone set<br>";
    
    echo "7. Creating database connection...<br>";
    $database = new Database();
    $conn = $database->getConnection();
    echo "Database connected<br>";
    
    echo "8. Testing products query...<br>";
    $products = [];
    $res = $conn->query("SELECT * FROM products ORDER BY commission_rate DESC");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $products[] = $row;
        }
        echo "Found " . count($products) . " products<br>";
    } else {
        echo "Query failed: " . $conn->error . "<br>";
    }
    
    echo "All checks passed! Products page should work.<br>";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "<br>";
    echo "File: " . $e->getFile() . "<br>";
    echo "Line: " . $e->getLine() . "<br>";
    echo "Stack trace:<br><pre>" . $e->getTraceAsString() . "</pre>";
}
?>

<h1>Products Page Test</h1>
<p>If you see this, the basic functionality works.</p>