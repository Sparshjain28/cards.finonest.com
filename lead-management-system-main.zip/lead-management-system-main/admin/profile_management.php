<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

// Check if user is admin
if (!isAdmin()) {
    header('Location: ../dashboard.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();

// Handle form submissions
if ($_POST) {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_status') {
        $userEmail = $_POST['user_email'];
        $status = $_POST['status'];
        
        // Add status column to tables if not exists
        $tables = ['aadhaar_verifications', 'pan_verifications', 'bank_verifications', 'kyc_submissions'];
        foreach ($tables as $table) {
            $checkQuery = "SHOW TABLES LIKE '$table'";
            if ($conn->query($checkQuery)->num_rows > 0) {
                // Check if status column exists, if not add it
                $columnCheck = $conn->query("SHOW COLUMNS FROM $table LIKE 'status'");
                if ($columnCheck->num_rows == 0) {
                    $conn->query("ALTER TABLE $table ADD COLUMN status VARCHAR(20) DEFAULT 'pending'");
                }
                
                $emailField = ($table === 'kyc_submissions') ? 'email' : 'user_email';
                $stmt = $conn->prepare("UPDATE $table SET status = ? WHERE $emailField = ?");
                $stmt->bind_param('ss', $status, $userEmail);
                $stmt->execute();
                $stmt->close();
            }
        }
        
        // Also update users table if exists
        $stmt = $conn->prepare("UPDATE users SET account_status = ? WHERE email = ?");
        $stmt->bind_param('ss', $status, $userEmail);
        $stmt->execute();
        $stmt->close();
        
        header('Location: profile_management.php?status_updated=1');
        exit();
    }
    
    if ($action === 'add_note') {
        $userEmail = $_POST['user_email'];
        $note = $_POST['note'];
        
        // Create admin_notes table if not exists
        $conn->query("CREATE TABLE IF NOT EXISTS admin_notes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_email VARCHAR(255),
            note TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        $stmt = $conn->prepare("INSERT INTO admin_notes (user_email, note) VALUES (?, ?)");
        $stmt->bind_param('ss', $userEmail, $note);
        $stmt->execute();
        $stmt->close();
        
        header('Location: profile_management.php?updated=1');
        exit();
    }
    
    if ($action === 'update_kyc') {
        $userEmail = $_POST['user_email'];
        
        // Update Aadhaar if data provided
        if (!empty($_POST['aadhaar_number']) || !empty($_POST['aadhaar_name'])) {
            $stmt = $conn->prepare("UPDATE aadhaar_verifications SET aadhaar_number=?, name=?, dob=?, gender=?, full_address=? WHERE user_email=?");
            $stmt->bind_param('ssssss', $_POST['aadhaar_number'], $_POST['aadhaar_name'], $_POST['aadhaar_dob'], $_POST['aadhaar_gender'], $_POST['aadhaar_address'], $userEmail);
            $stmt->execute();
            $stmt->close();
        }
        
        // Update PAN if data provided
        if (!empty($_POST['kyc_pan']) || !empty($_POST['pan_name'])) {
            $stmt = $conn->prepare("UPDATE pan_verifications SET pan_number=?, full_name=?, dob=?, gender=? WHERE user_email=?");
            $stmt->bind_param('sssss', $_POST['kyc_pan'], $_POST['pan_name'], $_POST['pan_dob'], $_POST['pan_gender'], $userEmail);
            $stmt->execute();
            $stmt->close();
        }
        
        // Update Bank if data provided
        if (!empty($_POST['account_number']) || !empty($_POST['bank_holder_name'])) {
            $stmt = $conn->prepare("UPDATE bank_verifications SET account_holder_name=?, account_number=?, ifsc_code=?, bank_name=? WHERE user_email=?");
            $stmt->bind_param('sssss', $_POST['bank_holder_name'], $_POST['account_number'], $_POST['ifsc_code'], $_POST['bank_name'], $userEmail);
            $stmt->execute();
            $stmt->close();
        }
        
        // Update KYC submissions table
        $stmt = $conn->prepare("UPDATE kyc_submissions SET aadhar=?, pan=?, bank_name=?, account_number=?, ifsc_code=? WHERE email=?");
        $stmt->bind_param('ssssss', $_POST['aadhaar_number'], $_POST['kyc_pan'], $_POST['bank_name'], $_POST['account_number'], $_POST['ifsc_code'], $userEmail);
        $stmt->execute();
        $stmt->close();
        
        header('Location: profile_management.php?kyc_updated=1');
        exit();
    }
}

// Get users with KYC data from actual tables
$search = $_GET['search'] ?? '';

$whereClause = "";
if ($search) {
    $whereClause = " AND (COALESCE(av.name, pv.full_name, bv.account_holder_name, u.name) LIKE '%$search%' OR COALESCE(av.user_email, pv.user_email, bv.user_email, ks.email, u.email) LIKE '%$search%')";
}

// Get users with their verification data from all available sources
$query = "SELECT DISTINCT 
                 COALESCE(av.user_email, pv.user_email, bv.user_email, ks.email, u.email) as email,
                 COALESCE(av.name, pv.full_name, bv.account_holder_name, u.name) as name,
                 COALESCE(av.verified_at, pv.verified_at, bv.verified_at, ks.submitted_at, u.created_at) as verified_at,
                 COALESCE(u.account_status, 'pending') as status,
                 av.aadhaar_number, av.dob, av.gender, av.full_address, av.photo,
                 pv.pan_number, pv.full_name as pan_name, pv.dob as pan_dob, pv.gender as pan_gender,
                 bv.account_number, bv.ifsc_code, bv.account_holder_name, bv.bank_name,
                 ks.aadhar as kyc_aadhar, ks.pan as kyc_pan, ks.selfie_path
          FROM aadhaar_verifications av
          LEFT JOIN pan_verifications pv ON av.user_email = pv.user_email
          LEFT JOIN bank_verifications bv ON av.user_email = bv.user_email
          LEFT JOIN kyc_submissions ks ON av.user_email = ks.email
          LEFT JOIN users u ON av.user_email = u.email
          WHERE 1=1 $whereClause
          UNION
          SELECT DISTINCT 
                 COALESCE(pv.user_email, bv.user_email, ks.email, u.email) as email,
                 COALESCE(pv.full_name, bv.account_holder_name, u.name) as name,
                 COALESCE(pv.verified_at, bv.verified_at, ks.submitted_at, u.created_at) as verified_at,
                 COALESCE(u.account_status, 'pending') as status,
                 NULL as aadhaar_number, NULL as dob, NULL as gender, NULL as full_address, NULL as photo,
                 pv.pan_number, pv.full_name as pan_name, pv.dob as pan_dob, pv.gender as pan_gender,
                 bv.account_number, bv.ifsc_code, bv.account_holder_name, bv.bank_name,
                 ks.aadhar as kyc_aadhar, ks.pan as kyc_pan, ks.selfie_path
          FROM pan_verifications pv
          LEFT JOIN bank_verifications bv ON pv.user_email = bv.user_email
          LEFT JOIN kyc_submissions ks ON pv.user_email = ks.email
          LEFT JOIN users u ON pv.user_email = u.email
          LEFT JOIN aadhaar_verifications av ON pv.user_email = av.user_email
          WHERE av.user_email IS NULL $whereClause
          ORDER BY verified_at DESC";

$result = $conn->query($query);
if (!$result) {
    // Fallback to simpler query if tables don't exist
    $query = "SELECT email, name, created_at as verified_at FROM users WHERE 1=1 $whereClause ORDER BY created_at DESC";
    $result = $conn->query($query);
}
$users = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Management - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>

    <div class="max-w-7xl mx-auto px-4 py-6">
        <!-- Success Messages -->
        <?php if (isset($_GET['status_updated'])): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                Status updated successfully!
            </div>
        <?php endif; ?>
        <?php if (isset($_GET['updated'])): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                Note added successfully!
            </div>
        <?php endif; ?>
        <?php if (isset($_GET['kyc_updated'])): ?>
            <div class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded mb-4">
                KYC data updated successfully!
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="bg-white rounded-xl shadow-sm p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-3xl font-bold text-slate-900">Profile Management</h1>
                    <p class="text-slate-600 mt-1">Manage user KYC status and verification details</p>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="text-right">
                        <div class="text-2xl font-bold text-blue-600"><?= count($users) ?></div>
                        <div class="text-sm text-slate-500">Verified Users</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="bg-white rounded-xl shadow-sm p-6 mb-6">
            <div class="flex flex-wrap gap-4">
                <div class="text-sm text-slate-600">
                    Showing verified users with KYC data
                </div>
                
                <input type="text" placeholder="Search users..." value="<?= htmlspecialchars($search) ?>" 
                       onkeypress="searchOnEnter(event)" class="border border-slate-300 rounded-lg px-4 py-2 w-64 focus:ring-2 focus:ring-blue-500">
            </div>
        </div>

        <!-- Users Grid -->
        <div class="grid gap-6">
            <?php foreach ($users as $user): ?>
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="p-6">
                    <div class="flex items-start justify-between mb-4">
                        <div class="flex items-center space-x-4">
                            <div class="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                                <i class="fas fa-user text-white"></i>
                            </div>
                            <div>
                                <h3 class="text-lg font-semibold text-slate-900"><?= htmlspecialchars($user['name']) ?></h3>
                                <p class="text-slate-600"><?= htmlspecialchars($user['email']) ?></p>
                                <div class="flex items-center space-x-2 mt-1">
                                    <?php 
                                    $status = $user['status'] ?? 'pending';
                                    $statusColors = [
                                        'approved' => 'bg-green-100 text-green-800',
                                        'pending' => 'bg-yellow-100 text-yellow-800',
                                        'under_review' => 'bg-blue-100 text-blue-800',
                                        'rejected' => 'bg-red-100 text-red-800'
                                    ];
                                    $statusColor = $statusColors[$status] ?? 'bg-gray-100 text-gray-800';
                                    ?>
                                    <span class="px-3 py-1 text-xs font-medium rounded-full <?= $statusColor ?>">
                                        <?= ucfirst(str_replace('_', ' ', $status)) ?>
                                    </span>
                                    <span class="text-xs text-slate-500"><?= date('M j, Y', strtotime($user['verified_at'])) ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="flex space-x-2">
                            <button onclick="openStatusModal('<?= htmlspecialchars($user['email']) ?>', '<?= htmlspecialchars($user['status'] ?? 'pending') ?>')" 
                                    class="bg-purple-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-purple-700 transition-colors">
                                <i class="fas fa-edit mr-1"></i>Status
                            </button>
                            <button onclick="openNoteModal('<?= htmlspecialchars($user['email']) ?>')" 
                                    class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition-colors">
                                <i class="fas fa-sticky-note mr-1"></i>Add Note
                            </button>
                            <button onclick="openKYCModal('<?= htmlspecialchars($user['email']) ?>')" 
                                    class="bg-green-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-green-700 transition-colors">
                                <i class="fas fa-id-card mr-1"></i>View Details
                            </button>
                        </div>
                    </div>

                    <!-- KYC Status Cards -->
                    <div class="grid md:grid-cols-3 gap-4">
                        <!-- Aadhaar Card -->
                        <div class="border border-slate-200 rounded-lg p-4 <?= ($user['aadhaar_number'] || $user['kyc_aadhar']) ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200' ?>">
                            <div class="flex items-center justify-between mb-2">
                                <h4 class="font-medium text-slate-900">Aadhaar</h4>
                                <?php if ($user['aadhaar_number'] || $user['kyc_aadhar']): ?>
                                    <i class="fas fa-check-circle text-green-600"></i>
                                <?php else: ?>
                                    <i class="fas fa-times-circle text-red-600"></i>
                                <?php endif; ?>
                            </div>
                            <?php if ($user['aadhaar_number'] || $user['kyc_aadhar']): ?>
                                <p class="text-sm text-slate-600">Number: <?= htmlspecialchars($user['aadhaar_number'] ?: $user['kyc_aadhar']) ?></p>
                                <p class="text-sm text-slate-600">Name: <?= htmlspecialchars($user['name']) ?></p>
                                <?php if ($user['dob']): ?>
                                    <p class="text-sm text-slate-600">DOB: <?= htmlspecialchars($user['dob']) ?></p>
                                <?php endif; ?>
                            <?php else: ?>
                                <p class="text-sm text-red-600">Not verified</p>
                            <?php endif; ?>
                        </div>

                        <!-- PAN Card -->
                        <div class="border border-slate-200 rounded-lg p-4 <?= ($user['pan_number'] || $user['kyc_pan']) ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200' ?>">
                            <div class="flex items-center justify-between mb-2">
                                <h4 class="font-medium text-slate-900">PAN</h4>
                                <?php if ($user['pan_number'] || $user['kyc_pan']): ?>
                                    <i class="fas fa-check-circle text-green-600"></i>
                                <?php else: ?>
                                    <i class="fas fa-times-circle text-red-600"></i>
                                <?php endif; ?>
                            </div>
                            <?php if ($user['pan_number'] || $user['kyc_pan']): ?>
                                <p class="text-sm text-slate-600">Number: <?= htmlspecialchars($user['pan_number'] ?: $user['kyc_pan']) ?></p>
                                <p class="text-sm text-slate-600">Name: <?= htmlspecialchars($user['pan_name']) ?></p>
                            <?php else: ?>
                                <p class="text-sm text-red-600">Not verified</p>
                            <?php endif; ?>
                        </div>

                        <!-- Bank Card -->
                        <div class="border border-slate-200 rounded-lg p-4 <?= $user['account_number'] ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200' ?>">
                            <div class="flex items-center justify-between mb-2">
                                <h4 class="font-medium text-slate-900">Bank</h4>
                                <?php if ($user['account_number']): ?>
                                    <i class="fas fa-check-circle text-green-600"></i>
                                <?php else: ?>
                                    <i class="fas fa-times-circle text-red-600"></i>
                                <?php endif; ?>
                            </div>
                            <?php if ($user['account_number']): ?>
                                <p class="text-sm text-slate-600">Account: <?= htmlspecialchars($user['account_number']) ?></p>
                                <p class="text-sm text-slate-600">IFSC: <?= htmlspecialchars($user['ifsc_code']) ?></p>
                                <p class="text-sm text-slate-600">Bank: <?= htmlspecialchars($user['bank_name']) ?></p>
                            <?php else: ?>
                                <p class="text-sm text-red-600">Not verified</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Address Info -->
                    <?php if ($user['full_address']): ?>
                    <div class="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <h5 class="font-medium text-blue-800 mb-1">Address:</h5>
                        <p class="text-sm text-blue-700"><?= htmlspecialchars($user['full_address']) ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Status Modal -->
    <div id="statusModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-xl max-w-md w-full p-6">
                <h3 class="text-xl font-bold mb-4">Update KYC Status</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="user_email" id="statusUserEmail">
                    
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">Status</label>
                        <select name="status" id="statusSelect" class="w-full border border-slate-300 rounded-lg px-3 py-2" required>
                            <option value="pending">Pending</option>
                            <option value="under_review">Under Review</option>
                            <option value="approved">Approved</option>
                            <option value="rejected">Rejected</option>
                        </select>
                    </div>
                    
                    <div class="flex justify-end space-x-2">
                        <button type="button" onclick="closeStatusModal()" 
                                class="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
                        <button type="submit" class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700">
                            Update Status
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Note Modal -->
    <div id="noteModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-xl max-w-md w-full p-6">
                <h3 class="text-xl font-bold mb-4">Add Admin Note</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="add_note">
                    <input type="hidden" name="user_email" id="noteUserEmail">
                    
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">Note</label>
                        <textarea name="note" rows="4" class="w-full border border-slate-300 rounded-lg px-3 py-2" 
                                  placeholder="Add your note here..." required></textarea>
                    </div>
                    
                    <div class="flex justify-end space-x-2">
                        <button type="button" onclick="closeNoteModal()" 
                                class="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
                        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                            Add Note
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- KYC Edit Modal -->
    <div id="kycModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-xl max-w-4xl w-full p-6 max-h-screen overflow-y-auto">
                <h3 class="text-xl font-bold mb-4">KYC Details</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="update_kyc">
                    <input type="hidden" name="user_email" id="kycUserEmail">
                    
                    <div class="grid md:grid-cols-3 gap-6">
                        <!-- Aadhaar Section -->
                        <div class="border border-slate-200 rounded-lg p-4">
                            <h4 class="font-semibold mb-3 text-green-700">Aadhaar Details</h4>
                            <div class="space-y-3">
                                <div>
                                    <label class="block text-sm font-medium mb-1">Aadhaar Number</label>
                                    <input type="text" name="aadhaar_number" id="modal_aadhaar" class="w-full border border-slate-300 rounded px-3 py-2 text-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">Name</label>
                                    <input type="text" name="aadhaar_name" id="modal_name" class="w-full border border-slate-300 rounded px-3 py-2 text-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">Date of Birth</label>
                                    <input type="date" name="aadhaar_dob" id="modal_dob" class="w-full border border-slate-300 rounded px-3 py-2 text-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">Gender</label>
                                    <select name="aadhaar_gender" id="modal_gender" class="w-full border border-slate-300 rounded px-3 py-2 text-sm">
                                        <option value="">Select</option>
                                        <option value="M">Male</option>
                                        <option value="F">Female</option>
                                        <option value="O">Other</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">Address</label>
                                    <textarea name="aadhaar_address" id="modal_address" rows="2" class="w-full border border-slate-300 rounded px-3 py-2 text-sm"></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- PAN Section -->
                        <div class="border border-slate-200 rounded-lg p-4">
                            <h4 class="font-semibold mb-3 text-blue-700">PAN Details</h4>
                            <div class="space-y-3">
                                <div>
                                    <label class="block text-sm font-medium mb-1">PAN Number</label>
                                    <input type="text" name="kyc_pan" id="modal_pan" class="w-full border border-slate-300 rounded px-3 py-2 text-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">Full Name</label>
                                    <input type="text" name="pan_name" id="modal_pan_name" class="w-full border border-slate-300 rounded px-3 py-2 text-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">Date of Birth</label>
                                    <input type="date" name="pan_dob" id="modal_pan_dob" class="w-full border border-slate-300 rounded px-3 py-2 text-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">Gender</label>
                                    <select name="pan_gender" id="modal_pan_gender" class="w-full border border-slate-300 rounded px-3 py-2 text-sm">
                                        <option value="">Select</option>
                                        <option value="M">Male</option>
                                        <option value="F">Female</option>
                                        <option value="O">Other</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Bank Section -->
                        <div class="border border-slate-200 rounded-lg p-4">
                            <h4 class="font-semibold mb-3 text-purple-700">Bank Details</h4>
                            <div class="space-y-3">
                                <div>
                                    <label class="block text-sm font-medium mb-1">Account Holder Name</label>
                                    <input type="text" name="bank_holder_name" id="modal_bank_holder" class="w-full border border-slate-300 rounded px-3 py-2 text-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">Account Number</label>
                                    <input type="text" name="account_number" id="modal_account" class="w-full border border-slate-300 rounded px-3 py-2 text-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">IFSC Code</label>
                                    <input type="text" name="ifsc_code" id="modal_ifsc" class="w-full border border-slate-300 rounded px-3 py-2 text-sm">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">Bank Name</label>
                                    <input type="text" name="bank_name" id="modal_bank_name" class="w-full border border-slate-300 rounded px-3 py-2 text-sm">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-2 mt-6">
                        <button type="button" onclick="closeKYCModal()" 
                                class="px-4 py-2 text-slate-600 hover:text-slate-800">Close</button>
                        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                            Update All KYC Data
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function openStatusModal(userEmail, currentStatus) {
            document.getElementById('statusUserEmail').value = userEmail;
            document.getElementById('statusSelect').value = currentStatus;
            document.getElementById('statusModal').classList.remove('hidden');
        }

        function closeStatusModal() {
            document.getElementById('statusModal').classList.add('hidden');
        }

        function searchOnEnter(event) {
            if (event.key === 'Enter') {
                const value = event.target.value;
                const url = new URL(window.location);
                if (value.trim()) {
                    url.searchParams.set('search', value.trim());
                } else {
                    url.searchParams.delete('search');
                }
                window.location = url;
            }
        }

        function searchUsers(value) {
            clearTimeout(window.searchTimeout);
            window.searchTimeout = setTimeout(() => {
                const url = new URL(window.location);
                if (value.trim()) {
                    url.searchParams.set('search', value.trim());
                } else {
                    url.searchParams.delete('search');
                }
                window.location = url;
            }, 1000);
        }

        function openNoteModal(userEmail) {
            document.getElementById('noteUserEmail').value = userEmail;
            document.getElementById('noteModal').classList.remove('hidden');
        }

        function closeNoteModal() {
            document.getElementById('noteModal').classList.add('hidden');
        }

        function openKYCModal(userEmail) {
            document.getElementById('kycUserEmail').value = userEmail;
            
            // Find user data and populate modal
            const users = <?= json_encode($users) ?>;
            const user = users.find(u => u.email === userEmail);
            
            if (user) {
                document.getElementById('modal_aadhaar').value = user.aadhaar_number || user.kyc_aadhar || '';
                document.getElementById('modal_name').value = user.name || '';
                document.getElementById('modal_dob').value = user.dob || '';
                document.getElementById('modal_gender').value = user.gender || '';
                document.getElementById('modal_address').value = user.full_address || '';
                
                document.getElementById('modal_pan').value = user.pan_number || user.kyc_pan || '';
                document.getElementById('modal_pan_name').value = user.pan_name || '';
                document.getElementById('modal_pan_dob').value = user.pan_dob || '';
                document.getElementById('modal_pan_gender').value = user.pan_gender || '';
                
                document.getElementById('modal_bank_holder').value = user.account_holder_name || '';
                document.getElementById('modal_account').value = user.account_number || '';
                document.getElementById('modal_ifsc').value = user.ifsc_code || '';
                document.getElementById('modal_bank_name').value = user.bank_name || '';
            }
            
            document.getElementById('kycModal').classList.remove('hidden');
        }

        function closeKYCModal() {
            document.getElementById('kycModal').classList.add('hidden');
        }
    </script>

    <?php include '../includes/footer.php'; ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>