<?php
// Referral Helper Functions for Multi-Level Referral System

/**
 * Build referral hierarchy when a new user signs up
 * This creates entries in referral_hierarchy for network partners
 * FIXED: Now builds hierarchy regardless of direct referrer's partner type
 */
function buildReferralHierarchy($conn, $new_user_id, $referrer_user_id) {
    // Get referrer's info
    $referrer_query = "SELECT id, partner_type, referral_code FROM users WHERE id = ?";
    $stmt = $conn->prepare($referrer_query);
    $stmt->bind_param("i", $referrer_user_id);
    $stmt->execute();
    $referrer = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (empty($referrer)) {
        return; // Referrer doesn't exist
    }
    
    $referral_code = $referrer['referral_code'] ?? '';
    
    // Insert Level 1 relationship ONLY if referrer is network partner
    // (Channel partners don't need hierarchy entries, they use referral_users only)
    if ($referrer['partner_type'] === 'network_partner') {
        $insert_l1 = "INSERT INTO referral_hierarchy (referrer_user_id, referred_user_id, level, referral_code) 
                       VALUES (?, ?, 1, ?)
                       ON DUPLICATE KEY UPDATE referral_code = ?";
        $stmt = $conn->prepare($insert_l1);
        $stmt->bind_param("iiss", $referrer_user_id, $new_user_id, $referral_code, $referral_code);
        $stmt->execute();
        $stmt->close();
    }
    
    // Find who referred the direct referrer (for Level 2)
    // IMPORTANT: Check referral_users FIRST (most reliable), then hierarchy
    $l2_query = "SELECT DISTINCT referrer_user_id 
                 FROM referral_users 
                 WHERE referred_user_id = ?
                 UNION
                 SELECT DISTINCT referrer_user_id 
                 FROM referral_hierarchy 
                 WHERE referred_user_id = ? AND level = 1";
    $stmt = $conn->prepare($l2_query);
    if (!$stmt) {
        error_log("Failed to prepare L2 query: " . $conn->error);
        return;
    }
    $stmt->bind_param("ii", $referrer_user_id, $referrer_user_id);
    if (!$stmt->execute()) {
        error_log("Failed to execute L2 query: " . $stmt->error);
        $stmt->close();
        return;
    }
    $l2_result = $stmt->get_result();
    $stmt->close();
    
    if ($l2_result->num_rows == 0) {
        // No one referred the direct referrer, so no Level 2 to build
        return;
    }
    
    while ($l2_row = $l2_result->fetch_assoc()) {
        $l2_referrer_id = $l2_row['referrer_user_id'];
        
        // Skip if same as direct referrer (shouldn't happen, but safety check)
        if ($l2_referrer_id == $referrer_user_id) {
            continue;
        }
        
        // Get L2 referrer's info and check if they're network partner
        $l2_info_stmt = $conn->prepare($referrer_query);
        if (!$l2_info_stmt) {
            error_log("Failed to prepare L2 info query: " . $conn->error);
            continue;
        }
        $l2_info_stmt->bind_param("i", $l2_referrer_id);
        if (!$l2_info_stmt->execute()) {
            error_log("Failed to execute L2 info query: " . $l2_info_stmt->error);
            $l2_info_stmt->close();
            continue;
        }
        $l2_referrer = $l2_info_stmt->get_result()->fetch_assoc();
        $l2_info_stmt->close();
        
        // Only create Level 2 relationship if L2 referrer is network partner
        if (!empty($l2_referrer) && $l2_referrer['partner_type'] === 'network_partner') {
            $l2_referral_code = $l2_referrer['referral_code'] ?? '';
            
            // Insert Level 2 relationship
            $insert_l2 = "INSERT INTO referral_hierarchy (referrer_user_id, referred_user_id, level, referral_code) 
                           VALUES (?, ?, 2, ?)
                           ON DUPLICATE KEY UPDATE referral_code = ?";
            $stmt = $conn->prepare($insert_l2);
            if ($stmt) {
                $stmt->bind_param("iiss", $l2_referrer_id, $new_user_id, $l2_referral_code, $l2_referral_code);
                if (!$stmt->execute()) {
                    error_log("Failed to insert Level 2 relationship: " . $stmt->error . " (L2: $l2_referrer_id -> New: $new_user_id)");
                }
                $stmt->close();
            } else {
                error_log("Failed to prepare Level 2 insert: " . $conn->error);
            }
            
            // Find who referred the L2 referrer (for Level 3)
            $l3_query = "SELECT DISTINCT referrer_user_id 
                         FROM (
                             SELECT referrer_user_id FROM referral_users WHERE referred_user_id = ?
                             UNION
                             SELECT referrer_user_id FROM referral_hierarchy WHERE referred_user_id = ? AND level = 1
                         ) as combined";
            $stmt = $conn->prepare($l3_query);
            $stmt->bind_param("ii", $l2_referrer_id, $l2_referrer_id);
            $stmt->execute();
            $l3_result = $stmt->get_result();
            
            while ($l3_row = $l3_result->fetch_assoc()) {
                $l3_referrer_id = $l3_row['referrer_user_id'];
                
                // Get L3 referrer's info and check if they're network partner
                $l3_info_stmt = $conn->prepare($referrer_query);
                $l3_info_stmt->bind_param("i", $l3_referrer_id);
                $l3_info_stmt->execute();
                $l3_referrer = $l3_info_stmt->get_result()->fetch_assoc();
                $l3_info_stmt->close();
                
                // Only create Level 3 relationship if L3 referrer is network partner
                if (!empty($l3_referrer) && $l3_referrer['partner_type'] === 'network_partner') {
                    $l3_referral_code = $l3_referrer['referral_code'] ?? '';
                    
                    // Insert Level 3 relationship
                    $insert_l3 = "INSERT INTO referral_hierarchy (referrer_user_id, referred_user_id, level, referral_code) 
                                  VALUES (?, ?, 3, ?)
                                  ON DUPLICATE KEY UPDATE referral_code = ?";
                    $stmt = $conn->prepare($insert_l3);
                    $stmt->bind_param("iiss", $l3_referrer_id, $new_user_id, $l3_referral_code, $l3_referral_code);
                    $stmt->execute();
                    $stmt->close();
                }
            }
        }
    }
}

/**
 * Calculate and record payout for network partner
 */
function calculateNetworkPartnerPayout($conn, $lead_id, $payout_amount) {
    // Get the lead's channel_code and find the user
    $lead_query = "SELECT channel_code FROM leads WHERE id = ?";
    $stmt = $conn->prepare($lead_query);
    $stmt->bind_param("i", $lead_id);
    $stmt->execute();
    $lead = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (empty($lead)) return;
    
    $user_query = "SELECT id FROM users WHERE channel_code = ?";
    $stmt = $conn->prepare($user_query);
    $stmt->bind_param("s", $lead['channel_code']);
    $stmt->execute();
    $user_result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (empty($user_result)) return;
    
    $source_user_id = $user_result['id'];
    
    // Find all network partners who should earn from this
    $hierarchy_query = "SELECT DISTINCT referrer_user_id, level 
                         FROM referral_hierarchy 
                         WHERE referred_user_id = ?";
    $stmt = $conn->prepare($hierarchy_query);
    $stmt->bind_param("i", $source_user_id);
    $stmt->execute();
    $hierarchy_result = $stmt->get_result();
    
    $percentages = [1 => 0.05, 2 => 0.02, 3 => 0.01]; // 5%, 2%, 1%
    
    while ($row = $hierarchy_result->fetch_assoc()) {
        $referrer_id = $row['referrer_user_id'];
        $level = $row['level'];
        
        // Check if referrer is network partner
        $partner_check = "SELECT partner_type FROM users WHERE id = ?";
        $check_stmt = $conn->prepare($partner_check);
        $check_stmt->bind_param("i", $referrer_id);
        $check_stmt->execute();
        $partner = $check_stmt->get_result()->fetch_assoc();
        $check_stmt->close();
        
        if ($partner && $partner['partner_type'] === 'network_partner') {
            $earning = $payout_amount * $percentages[$level];
            
            // Get product info
            $product_query = "SELECT l.product_id, p.category FROM leads l 
                             JOIN products p ON l.product_id = p.id 
                             WHERE l.id = ?";
            $prod_stmt = $conn->prepare($product_query);
            $prod_stmt->bind_param("i", $lead_id);
            $prod_stmt->execute();
            $prod_result = $prod_stmt->get_result()->fetch_assoc();
            $prod_stmt->close();
            
            // Insert into payout_ledger
            $ledger_insert = "INSERT INTO payout_ledger 
                              (user_id, source_user_id, lead_id, level, earning_type, amount, product_id, product_category, status) 
                              VALUES (?, ?, ?, ?, 'referral_percentage', ?, ?, ?, 'pending')";
            $ledger_stmt = $conn->prepare($ledger_insert);
            $ledger_stmt->bind_param("iiiidss", 
                $referrer_id, 
                $source_user_id, 
                $lead_id, 
                $level, 
                $earning,
                $prod_result['product_id'] ?? null,
                $prod_result['category'] ?? null
            );
            $ledger_stmt->execute();
            $ledger_stmt->close();
        }
    }
}

/**
 * Calculate and record payout for channel partner
 */
function calculateChannelPartnerPayout($conn, $lead_id, $payout_amount) {
    // Get the lead's channel_code and find the user
    $lead_query = "SELECT channel_code, product_id FROM leads WHERE id = ?";
    $stmt = $conn->prepare($lead_query);
    $stmt->bind_param("i", $lead_id);
    $stmt->execute();
    $lead = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (empty($lead)) return;
    
    $user_query = "SELECT id FROM users WHERE channel_code = ?";
    $stmt = $conn->prepare($user_query);
    $stmt->bind_param("s", $lead['channel_code']);
    $stmt->execute();
    $user_result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (empty($user_result)) return;
    
    $source_user_id = $user_result['id'];
    
    // Find channel partners who have this user as L1
    $referrer_query = "SELECT DISTINCT referrer_user_id 
                       FROM referral_users 
                       WHERE referred_user_id = ? AND level = 1";
    $stmt = $conn->prepare($referrer_query);
    $stmt->bind_param("i", $source_user_id);
    $stmt->execute();
    $referrer_result = $stmt->get_result();
    
    while ($row = $referrer_result->fetch_assoc()) {
        $referrer_id = $row['referrer_user_id'];
        
        // Check if referrer is channel partner
        $partner_check = "SELECT partner_type FROM users WHERE id = ?";
        $check_stmt = $conn->prepare($partner_check);
        $check_stmt->bind_param("i", $referrer_id);
        $check_stmt->execute();
        $partner = $check_stmt->get_result()->fetch_assoc();
        $check_stmt->close();
        
        if ($partner && $partner['partner_type'] === 'channel_partner') {
            // Get payout setting for this advisor and product
            $setting_query = "SELECT payout_rate, rate_type FROM payout_settings 
                             WHERE user_id = ? AND advisor_user_id = ? 
                             AND (product_id = ? OR product_id IS NULL)
                             ORDER BY product_id DESC
                             LIMIT 1";
            $setting_stmt = $conn->prepare($setting_query);
            $setting_stmt->bind_param("iii", $referrer_id, $source_user_id, $lead['product_id']);
            $setting_stmt->execute();
            $setting = $setting_stmt->get_result()->fetch_assoc();
            $setting_stmt->close();
            
            if ($setting) {
                $advisor_payout = $setting['payout_rate'];
                $margin = $payout_amount - $advisor_payout;
                
                if ($margin > 0) {
                    // Get product info
                    $product_query = "SELECT category FROM products WHERE id = ?";
                    $prod_stmt = $conn->prepare($product_query);
                    $prod_stmt->bind_param("i", $lead['product_id']);
                    $prod_stmt->execute();
                    $prod_result = $prod_stmt->get_result()->fetch_assoc();
                    $prod_stmt->close();
                    
                    // Insert into payout_ledger
                    $ledger_insert = "INSERT INTO payout_ledger 
                                      (user_id, source_user_id, lead_id, level, earning_type, amount, product_id, product_category, status) 
                                      VALUES (?, ?, ?, 1, 'margin_control', ?, ?, ?, 'pending')";
                    $ledger_stmt = $conn->prepare($ledger_insert);
                    $ledger_stmt->bind_param("iiiiss", 
                        $referrer_id, 
                        $source_user_id, 
                        $lead_id, 
                        $margin,
                        $lead['product_id'],
                        $prod_result['category'] ?? null
                    );
                    $ledger_stmt->execute();
                    $ledger_stmt->close();
                }
            }
        }
    }
}

