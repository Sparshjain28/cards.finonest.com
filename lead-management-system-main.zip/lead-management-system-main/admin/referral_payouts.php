<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../includes/notices_component.php';

requireLogin();

$database = new Database();
$conn = $database->getConnection();

// Handle payout status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_referral_payout'])) {
    $user_id = (int)$_POST['user_id'];
    $amount = (float)$_POST['amount'];
    $status = $_POST['status'];
    
    // Insert or update referral payout
    $stmt = $conn->prepare("INSERT INTO payout_ledger (user_id, earning_type, amount, status) VALUES (?, 'referral_percentage', ?, ?) ON DUPLICATE KEY UPDATE amount = VALUES(amount), status = VALUES(status)");
    $stmt->bind_param('ids', $user_id, $amount, $status);
    $stmt->execute();
    $stmt->close();
    
    $redirect_url = "referral_payouts.php?updated=1";
    if (isset($_POST['current_filter'])) {
        $redirect_url .= "&filter=" . urlencode($_POST['current_filter']);
    }
    header("Location: " . $redirect_url);
    exit;
}

// Handle team payout status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_team_payout'])) {
    $user_id = (int)$_POST['user_id'];
    $amount = (float)$_POST['amount'];
    $status = $_POST['status'];
    
    // Update all pending payout_ledger entries for this channel partner
    $stmt = $conn->prepare("UPDATE payout_ledger SET status = ? WHERE user_id = ? AND status = 'pending'");
    $stmt->bind_param('si', $status, $user_id);
    $stmt->execute();
    $stmt->close();
    
    header("Location: referral_payouts.php?team_updated=1");
    exit;
}

// Get channel partner team leader payouts using payout_ledger
$team_leader_query = "SELECT 
    u.id as leader_id, u.name as team_leader_name, u.channel_code,
    COUNT(DISTINCT team.id) as team_members,
    COUNT(DISTINCT l.id) as total_leads,
    SUM(CASE WHEN l.status IN ('activated','disbursed') THEN p.commission_amount ELSE 0 END) as total_commission,
    COALESCE(ledger_summary.total_earned, 0) as total_earned,
    COALESCE(ledger_summary.downline_paid, 0) as team_member_payout,
    COALESCE(ledger_summary.pending_amount, 0) as pending_amount,
    COALESCE(ledger_summary.paid_amount, 0) as paid_amount,
    CASE 
        WHEN COALESCE(ledger_summary.pending_amount, 0) > 0 THEN 'pending'
        WHEN COALESCE(ledger_summary.paid_amount, 0) > 0 THEN 'paid'
        ELSE 'pending'
    END as payout_status
FROM users u
LEFT JOIN users team ON team.parent_id = u.id
LEFT JOIN leads l ON l.channel_code = team.channel_code
LEFT JOIN payouts p ON l.id = p.lead_id
LEFT JOIN (
    SELECT pl.user_id,
           SUM(pl.amount) as total_earned,
           SUM(CASE WHEN pl.earning_type = 'referral_percentage' THEN pl.amount ELSE 0 END) as downline_paid,
           SUM(CASE WHEN pl.status = 'pending' THEN pl.amount ELSE 0 END) as pending_amount,
           SUM(CASE WHEN pl.status = 'paid' THEN pl.amount ELSE 0 END) as paid_amount
    FROM payout_ledger pl
    GROUP BY pl.user_id
) ledger_summary ON ledger_summary.user_id = u.id
WHERE u.partner_type = 'channel_partner'
GROUP BY u.id, u.name, u.channel_code

ORDER BY team_leader_name, total_commission DESC";

$team_leader_stmt = $conn->prepare($team_leader_query);
$team_leader_stmt->execute();
$team_leader_data = $team_leader_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$team_leader_stmt->close();

// Get referral payouts data with proper 3-level hierarchy calculation
$referral_query = "SELECT 
    u.id, u.name, u.email, u.partner_type,
    COUNT(DISTINCT ru.referred_user_id) as total_referrals,
    COUNT(DISTINCT l.id) as total_leads,
    SUM(CASE WHEN l.status IN ('activated','disbursed') THEN p.commission_amount ELSE 0 END) as total_commission,
    (
        -- Level 1: Direct referrals (5%)
        COALESCE((SELECT SUM(p1.commission_amount * 0.05)
                  FROM referral_users ru1
                  JOIN users u1 ON ru1.referred_user_id = u1.id
                  JOIN leads l1 ON u1.channel_code = l1.channel_code
                  JOIN payouts p1 ON l1.id = p1.lead_id
                  WHERE ru1.referrer_user_id = u.id AND l1.status IN ('activated','disbursed')), 0) +
        -- Level 2: Referrals of Level 1 (2%)
        COALESCE((SELECT SUM(p2.commission_amount * 0.02)
                  FROM referral_users ru1
                  JOIN referral_users ru2 ON ru1.referred_user_id = ru2.referrer_user_id
                  JOIN users u2 ON ru2.referred_user_id = u2.id
                  JOIN leads l2 ON u2.channel_code = l2.channel_code
                  JOIN payouts p2 ON l2.id = p2.lead_id
                  WHERE ru1.referrer_user_id = u.id AND l2.status IN ('activated','disbursed')), 0) +
        -- Level 3: Referrals of Level 2 (1%)
        COALESCE((SELECT SUM(p3.commission_amount * 0.01)
                  FROM referral_users ru1
                  JOIN referral_users ru2 ON ru1.referred_user_id = ru2.referrer_user_id
                  JOIN referral_users ru3 ON ru2.referred_user_id = ru3.referrer_user_id
                  JOIN users u3 ON ru3.referred_user_id = u3.id
                  JOIN leads l3 ON u3.channel_code = l3.channel_code
                  JOIN payouts p3 ON l3.id = p3.lead_id
                  WHERE ru1.referrer_user_id = u.id AND l3.status IN ('activated','disbursed')), 0)
    ) as referral_earning,
    COALESCE(pl.amount, 0) as payout_amount,
    COALESCE(pl.status, 'pending') as payout_status,
    (SELECT u4.name FROM referral_users ru4 
     JOIN users u4 ON ru4.referred_user_id = u4.id 
     WHERE ru4.referrer_user_id = u.id 
     ORDER BY ru4.id ASC LIMIT 1) as first_team_member
FROM users u
LEFT JOIN referral_users ru ON u.id = ru.referrer_user_id
LEFT JOIN users u2 ON ru.referred_user_id = u2.id
LEFT JOIN leads l ON u2.channel_code = l.channel_code
LEFT JOIN payouts p ON l.id = p.lead_id
LEFT JOIN payout_ledger pl ON (u.id = pl.user_id AND pl.earning_type = 'referral_percentage')
WHERE u.is_admin = 0 AND u.partner_type = 'network_partner'
GROUP BY u.id, u.name, u.email, u.partner_type, pl.amount, pl.status
HAVING total_referrals > 0
ORDER BY referral_earning DESC";

$referral_stmt = $conn->prepare($referral_query);
$referral_stmt->execute();
$referral_data = $referral_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$referral_stmt->close();

// Calculate summary
$total_referral_earnings = 0;
$total_pending = 0;
$total_paid = 0;
foreach ($referral_data as $row) {
    $total_referral_earnings += $row['referral_earning'];
    if ($row['payout_status'] === 'pending') {
        $total_pending += $row['referral_earning'];
    } elseif ($row['payout_status'] === 'paid') {
        $total_paid += $row['payout_amount'];
    }
}

// Calculate team leader summary
$total_team_payouts = 0;
$total_team_commission = 0;
$total_leader_margin = 0;
foreach ($team_leader_data as $row) {
    $total_team_payouts += $row['team_member_payout'];
    $total_team_commission += $row['total_commission'];
    $total_leader_margin += ($row['total_earned'] - $row['team_member_payout']);
}

function getStatusBadge($status) {
    $badges = [
        'pending' => 'bg-yellow-100 text-yellow-800',
        'paid' => 'bg-green-100 text-green-800',
        'cancelled' => 'bg-red-100 text-red-800'
    ];
    return $badges[$status] ?? 'bg-gray-100 text-gray-800';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Referral Payouts Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include __DIR__ . '/../includes/header.php'; ?>

    <main class="w-full mx-auto py-6">
        <?php 
        $user = getCurrentUser();
        $notices = getActiveNotices($conn, $user['id']);
        echo renderNotices($notices);
        ?>
        
        <div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
                <h1 class="text-2xl font-bold text-slate-900">Referral Payouts</h1>
                <p class="text-slate-600">Manage team referral commissions and payouts</p>
            </div>
            <button onclick="window.location.href='payouts.php'" class="bg-slate-600 hover:bg-slate-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors">
                <i class="fas fa-arrow-left"></i>
                Back to Payouts
            </button>
        </div>

        <!-- Summary Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-sm border p-5 flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-slate-500">Total Referral Earnings</p>
                    <p class="text-2xl font-bold text-slate-900">₹<?= number_format($total_referral_earnings, 2) ?></p>
                </div>
                <i class="fas fa-users text-3xl text-purple-500 opacity-75"></i>
            </div>
            <div class="bg-white rounded-lg shadow-sm border p-5 flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-slate-500">Pending Payouts</p>
                    <p class="text-2xl font-bold text-slate-900">₹<?= number_format($total_pending, 2) ?></p>
                </div>
                <i class="fas fa-hourglass-half text-3xl text-yellow-500 opacity-75"></i>
            </div>
            <div class="bg-white rounded-lg shadow-sm border p-5 flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-slate-500">Paid Payouts</p>
                    <p class="text-2xl font-bold text-slate-900">₹<?= number_format($total_paid, 2) ?></p>
                </div>
                <i class="fas fa-check-circle text-3xl text-green-500 opacity-75"></i>
            </div>
            <div class="bg-white rounded-lg shadow-sm border p-5 flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-slate-500">Active Referrers</p>
                    <p class="text-2xl font-bold text-slate-900"><?= count($referral_data) ?></p>
                </div>
                <i class="fas fa-network-wired text-3xl text-blue-500 opacity-75"></i>
            </div>
        </div>

        <!-- Team Leader Payouts Table -->
        <div class="bg-white rounded-lg shadow border mb-8">
            <div class="p-6 border-b border-slate-200">
                <h2 class="text-lg font-semibold text-slate-900">Team Leader Payouts (Channel Partners)</h2>
                <p class="text-sm text-slate-600 mt-1">Payouts for team members under channel partners with custom rates</p>
            </div>
            
            <?php if (empty($team_leader_data)): ?>
                <div class="text-center py-12">
                    <i class="fas fa-users text-4xl text-slate-300 mb-4"></i>
                    <p class="text-slate-600">No team leader payout data available yet.</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-slate-50">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Team Leader</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Channel Code</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                                    Leader Margin
                                    <i class="fas fa-info-circle ml-1 text-blue-500 cursor-help" title="Leader Margin = Total Earned - Team Member Payout (from payout_ledger)"></i>
                                </th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Payout Status</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-slate-200">
                            <?php foreach ($team_leader_data as $row): ?>
                                <tr class="hover:bg-slate-50">
                                    <td class="px-4 py-3">
                                        <div class="font-medium text-purple-900"><?= htmlspecialchars($row['team_leader_name']) ?></div>
                                        <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-800">Channel Partner</span>
                                    </td>
                                    <td class="px-4 py-3 text-sm text-slate-900"><?= htmlspecialchars($row['channel_code'] ?? 'N/A') ?></td>
                                    <td class="px-4 py-3 text-sm font-medium text-blue-600">₹<?= number_format($row['total_earned'] - $row['team_member_payout'], 2) ?></td>
                                    <td class="px-4 py-3">
                                        <div class="text-xs space-y-1">
                                            <div class="text-slate-600">Pending: ₹<?= number_format($row['pending_amount'], 0) ?></div>
                                            <div class="text-green-600">Paid: ₹<?= number_format($row['paid_amount'], 0) ?></div>
                                        </div>
                                    </td>
                                    <td class="px-4 py-3">
                                        <?php if ($row['total_earned'] > 0): ?>
                                            <form method="POST" class="inline-flex items-center gap-1">
                                                <input type="hidden" name="update_team_payout" value="1">
                                                <input type="hidden" name="user_id" value="<?= $row['leader_id'] ?>">
                                                <input type="hidden" name="amount" value="<?= $row['pending_amount'] ?>">
                                                <select name="status" class="px-1 py-0.5 text-xs border rounded" onchange="this.form.submit()">
                                                    <option value="pending" <?= $row['payout_status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                                                    <option value="paid" <?= $row['payout_status'] === 'paid' ? 'selected' : '' ?>>Paid</option>
                                                </select>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-xs text-slate-400">No earnings</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Referral Payouts Table -->
        <div class="bg-white rounded-lg shadow border">
            <div class="p-6 border-b border-slate-200">
                <h2 class="text-lg font-semibold text-slate-900">Referral Commission Payouts (Network Partners)</h2>
                <p class="text-sm text-slate-600 mt-1">Manage payouts for network partners and referral commissions</p>
            </div>
            
            <?php if (empty($referral_data)): ?>
                <div class="text-center py-12">
                    <i class="fas fa-users text-4xl text-slate-300 mb-4"></i>
                    <p class="text-slate-600">No referral data available yet.</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-slate-50">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">User</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Partner Type</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Team Levels</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Total Leads</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Commission Generated</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Referral Earning</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Payout Status</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-slate-200">
                            <?php foreach ($referral_data as $row): ?>
                                <tr class="hover:bg-slate-50">
                                    <td class="px-4 py-3">
                                        <div class="font-medium text-slate-900"><?= htmlspecialchars($row['name']) ?></div>
                                        <div class="text-sm text-slate-500"><?= htmlspecialchars($row['email']) ?></div>
                                        <?php if ($row['first_team_member']): ?>
                                            <div class="text-xs text-blue-600 mt-1">
                                                <i class="fas fa-user-plus mr-1"></i>First: <?= htmlspecialchars($row['first_team_member']) ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-3">
                                        <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full <?= $row['partner_type'] === 'network_partner' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800' ?>">
                                            <?= $row['partner_type'] === 'network_partner' ? 'Network' : 'Channel' ?>
                                        </span>
                                    </td>
                                    <td class="px-4 py-3">
                                        <?php
                                        // Get direct referrals (L1) and calculate L2, L3 from hierarchy
                                        $l1_query = "SELECT COUNT(*) as count FROM referral_users WHERE referrer_user_id = ?";
                                        $l1_stmt = $conn->prepare($l1_query);
                                        $l1_stmt->bind_param('i', $row['id']);
                                        $l1_stmt->execute();
                                        $l1_count = $l1_stmt->get_result()->fetch_assoc()['count'];
                                        $l1_stmt->close();
                                        
                                        // Get L2 (referrals of L1 members)
                                        $l2_query = "SELECT COUNT(*) as count FROM referral_users ru1 
                                                     JOIN referral_users ru2 ON ru1.referred_user_id = ru2.referrer_user_id 
                                                     WHERE ru1.referrer_user_id = ?";
                                        $l2_stmt = $conn->prepare($l2_query);
                                        $l2_stmt->bind_param('i', $row['id']);
                                        $l2_stmt->execute();
                                        $l2_count = $l2_stmt->get_result()->fetch_assoc()['count'];
                                        $l2_stmt->close();
                                        
                                        // Get L3 (referrals of L2 members)
                                        $l3_query = "SELECT COUNT(*) as count FROM referral_users ru1 
                                                     JOIN referral_users ru2 ON ru1.referred_user_id = ru2.referrer_user_id
                                                     JOIN referral_users ru3 ON ru2.referred_user_id = ru3.referrer_user_id
                                                     WHERE ru1.referrer_user_id = ?";
                                        $l3_stmt = $conn->prepare($l3_query);
                                        $l3_stmt->bind_param('i', $row['id']);
                                        $l3_stmt->execute();
                                        $l3_count = $l3_stmt->get_result()->fetch_assoc()['count'];
                                        $l3_stmt->close();
                                        
                                        // Calculate earnings for each level
                                        $l1_earning = 0; $l2_earning = 0; $l3_earning = 0;
                                        
                                        // L1 earnings (5%)
                                        $l1_earn_query = "SELECT SUM(p.commission_amount * 0.05) as earning FROM referral_users ru
                                                          JOIN users u ON ru.referred_user_id = u.id
                                                          JOIN leads l ON u.channel_code = l.channel_code
                                                          JOIN payouts p ON l.id = p.lead_id
                                                          WHERE ru.referrer_user_id = ? AND l.status IN ('activated','disbursed')";
                                        $l1_earn_stmt = $conn->prepare($l1_earn_query);
                                        $l1_earn_stmt->bind_param('i', $row['id']);
                                        $l1_earn_stmt->execute();
                                        $l1_earning = $l1_earn_stmt->get_result()->fetch_assoc()['earning'] ?? 0;
                                        $l1_earn_stmt->close();
                                        
                                        // L2 earnings (2%)
                                        $l2_earn_query = "SELECT SUM(p.commission_amount * 0.02) as earning FROM referral_users ru1
                                                          JOIN referral_users ru2 ON ru1.referred_user_id = ru2.referrer_user_id
                                                          JOIN users u ON ru2.referred_user_id = u.id
                                                          JOIN leads l ON u.channel_code = l.channel_code
                                                          JOIN payouts p ON l.id = p.lead_id
                                                          WHERE ru1.referrer_user_id = ? AND l.status IN ('activated','disbursed')";
                                        $l2_earn_stmt = $conn->prepare($l2_earn_query);
                                        $l2_earn_stmt->bind_param('i', $row['id']);
                                        $l2_earn_stmt->execute();
                                        $l2_earning = $l2_earn_stmt->get_result()->fetch_assoc()['earning'] ?? 0;
                                        $l2_earn_stmt->close();
                                        
                                        // L3 earnings (1%)
                                        $l3_earn_query = "SELECT SUM(p.commission_amount * 0.01) as earning FROM referral_users ru1
                                                          JOIN referral_users ru2 ON ru1.referred_user_id = ru2.referrer_user_id
                                                          JOIN referral_users ru3 ON ru2.referred_user_id = ru3.referrer_user_id
                                                          JOIN users u ON ru3.referred_user_id = u.id
                                                          JOIN leads l ON u.channel_code = l.channel_code
                                                          JOIN payouts p ON l.id = p.lead_id
                                                          WHERE ru1.referrer_user_id = ? AND l.status IN ('activated','disbursed')";
                                        $l3_earn_stmt = $conn->prepare($l3_earn_query);
                                        $l3_earn_stmt->bind_param('i', $row['id']);
                                        $l3_earn_stmt->execute();
                                        $l3_earning = $l3_earn_stmt->get_result()->fetch_assoc()['earning'] ?? 0;
                                        $l3_earn_stmt->close();
                                        ?>
                                        <?php
                                        // Get L1 names
                                        $l1_names = [];
                                        $l1_name_query = "SELECT u.name FROM referral_users ru JOIN users u ON ru.referred_user_id = u.id WHERE ru.referrer_user_id = ? LIMIT 2";
                                        $l1_name_stmt = $conn->prepare($l1_name_query);
                                        $l1_name_stmt->bind_param('i', $row['id']);
                                        $l1_name_stmt->execute();
                                        $l1_result = $l1_name_stmt->get_result();
                                        while($name_row = $l1_result->fetch_assoc()) {
                                            $l1_names[] = $name_row['name'];
                                        }
                                        $l1_name_stmt->close();
                                        
                                        // Get L2 names
                                        $l2_names = [];
                                        $l2_name_query = "SELECT DISTINCT u3.name FROM referral_users ru1 
                                                          JOIN referral_users ru2 ON ru1.referred_user_id = ru2.referrer_user_id
                                                          JOIN users u3 ON ru2.referred_user_id = u3.id
                                                          WHERE ru1.referrer_user_id = ? LIMIT 2";
                                        $l2_name_stmt = $conn->prepare($l2_name_query);
                                        $l2_name_stmt->bind_param('i', $row['id']);
                                        $l2_name_stmt->execute();
                                        $l2_result = $l2_name_stmt->get_result();
                                        while($name_row = $l2_result->fetch_assoc()) {
                                            $l2_names[] = $name_row['name'];
                                        }
                                        $l2_name_stmt->close();
                                        
                                        // Get L3 names
                                        $l3_names = [];
                                        $l3_name_query = "SELECT DISTINCT u4.name FROM referral_users ru1 
                                                          JOIN referral_users ru2 ON ru1.referred_user_id = ru2.referrer_user_id
                                                          JOIN referral_users ru3 ON ru2.referred_user_id = ru3.referrer_user_id
                                                          JOIN users u4 ON ru3.referred_user_id = u4.id
                                                          WHERE ru1.referrer_user_id = ? LIMIT 2";
                                        $l3_name_stmt = $conn->prepare($l3_name_query);
                                        $l3_name_stmt->bind_param('i', $row['id']);
                                        $l3_name_stmt->execute();
                                        $l3_result = $l3_name_stmt->get_result();
                                        while($name_row = $l3_result->fetch_assoc()) {
                                            $l3_names[] = $name_row['name'];
                                        }
                                        $l3_name_stmt->close();
                                        ?>
                                        <!-- Team Members Trail -->
                                        <div class="flex items-center space-x-1 text-xs overflow-x-auto">
                                            <?php if (!empty($l1_names)): ?>
                                                <!-- L1 Users -->
                                                <?php foreach($l1_names as $index => $l1_name): ?>
                                                    <div class="flex items-center bg-green-50 rounded px-2 py-1 min-w-max">
                                                        <i class="fas fa-user text-green-600 text-xs mr-1"></i>
                                                        <span class="text-green-800 font-medium"><?= htmlspecialchars(explode(' ', $l1_name)[0]) ?></span>
                                                    </div>
                                                    <?php if ($index < count($l1_names) - 1): ?><span class="text-slate-400">•</span><?php endif; ?>
                                                <?php endforeach; ?>
                                                <?php if ($l1_count > 2): ?><span class="text-xs text-slate-500">+<?= $l1_count - 2 ?></span><?php endif; ?>
                                            <?php endif; ?>
                                            
                                            <?php if (!empty($l2_names)): ?>
                                                <?php if (!empty($l1_names)): ?><i class="fas fa-arrow-right text-slate-400 text-xs"></i><?php endif; ?>
                                                <!-- L2 Users -->
                                                <?php foreach($l2_names as $index => $l2_name): ?>
                                                    <div class="flex items-center bg-orange-50 rounded px-2 py-1 min-w-max">
                                                        <i class="fas fa-user text-orange-600 text-xs mr-1"></i>
                                                        <span class="text-orange-800 font-medium"><?= htmlspecialchars(explode(' ', $l2_name)[0]) ?></span>
                                                    </div>
                                                    <?php if ($index < count($l2_names) - 1): ?><span class="text-slate-400">•</span><?php endif; ?>
                                                <?php endforeach; ?>
                                                <?php if ($l2_count > 2): ?><span class="text-xs text-slate-500">+<?= $l2_count - 2 ?></span><?php endif; ?>
                                            <?php endif; ?>
                                            
                                            <?php if (!empty($l3_names)): ?>
                                                <?php if (!empty($l1_names) || !empty($l2_names)): ?><i class="fas fa-arrow-right text-slate-400 text-xs"></i><?php endif; ?>
                                                <!-- L3 Users -->
                                                <?php foreach($l3_names as $index => $l3_name): ?>
                                                    <div class="flex items-center bg-purple-50 rounded px-2 py-1 min-w-max">
                                                        <i class="fas fa-user text-purple-600 text-xs mr-1"></i>
                                                        <span class="text-purple-800 font-medium"><?= htmlspecialchars(explode(' ', $l3_name)[0]) ?></span>
                                                    </div>
                                                    <?php if ($index < count($l3_names) - 1): ?><span class="text-slate-400">•</span><?php endif; ?>
                                                <?php endforeach; ?>
                                                <?php if ($l3_count > 2): ?><span class="text-xs text-slate-500">+<?= $l3_count - 2 ?></span><?php endif; ?>
                                            <?php endif; ?>
                                            
                                            <?php if (empty($l1_names) && empty($l2_names) && empty($l3_names)): ?>
                                                <span class="text-xs text-slate-400">No team members</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="text-xs text-slate-500 mt-1">
                                            L1: <?= $l1_count ?> ₹<?= number_format($l1_earning, 0) ?> | L2: <?= $l2_count ?> ₹<?= number_format($l2_earning, 0) ?> | L3: <?= $l3_count ?> ₹<?= number_format($l3_earning, 0) ?>
                                        </div>
                                    </td>
                                    <td class="px-4 py-3 text-sm text-slate-900"><?= $row['total_leads'] ?></td>
                                    <td class="px-4 py-3 text-sm font-medium text-slate-900">₹<?= number_format($row['total_commission'], 2) ?></td>
                                    <td class="px-4 py-3 text-sm font-medium text-green-600">
                                        <?php if ($row['partner_type'] === 'network_partner'): ?>
                                            <span class="text-slate-400">-</span>
                                        <?php else: ?>
                                            ₹<?= number_format($row['referral_earning'], 2) ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-3">
                                        <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full <?= getStatusBadge($row['payout_status']) ?>">
                                            <?= ucfirst($row['payout_status']) ?>
                                        </span>
                                    </td>
                                    <td class="px-4 py-3">
                                        <?php if ($row['referral_earning'] > 0): ?>
                                            <form method="POST" class="inline-flex items-center gap-2">
                                                <input type="hidden" name="update_referral_payout" value="1">
                                                <input type="hidden" name="user_id" value="<?= $row['id'] ?>">
                                                <input type="hidden" name="amount" value="<?= $row['referral_earning'] ?>">
                                                <input type="hidden" name="current_filter" value="<?= $_GET['filter'] ?? '' ?>">
                                                <select name="status" class="px-2 py-1 text-xs border rounded" onchange="this.form.submit()">
                                                    <option value="pending" <?= $row['payout_status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                                                    <option value="paid" <?= $row['payout_status'] === 'paid' ? 'selected' : '' ?>>Paid</option>
                                                    <option value="cancelled" <?= $row['payout_status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                                </select>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-xs text-slate-400">No earnings</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Payout Programs Info -->
        <div class="mt-8 bg-white rounded-lg shadow-sm border p-6">
            <h3 class="text-lg font-semibold text-slate-900 mb-4">Payout Programs</h3>
            <div class="grid md:grid-cols-3 gap-6">
                <div class="bg-blue-50 p-4 rounded-lg">
                    <h4 class="font-medium text-blue-900 mb-2">Network Partners</h4>
                    <p class="text-sm text-blue-700 mb-3">Fixed percentage-based referral income</p>
                    <ul class="text-sm text-blue-600 space-y-1">
                        <li>• Level 1: 5% of team commission</li>
                        <li>• Level 2: 2% of team commission</li>
                        <li>• Level 3: 1% of team commission</li>
                    </ul>
                </div>
                <div class="bg-purple-50 p-4 rounded-lg">
                    <h4 class="font-medium text-purple-900 mb-2">Channel Partners</h4>
                    <p class="text-sm text-purple-700 mb-3">Custom payout control system</p>
                    <ul class="text-sm text-purple-600 space-y-1">
                        <li>• Set custom rates for advisors</li>
                        <li>• Cards: Multiples of ₹100</li>
                        <li>• Loans: Multiples of 0.1%</li>
                        <li>• Keep margin difference as profit</li>
                    </ul>
                </div>
                <div class="bg-green-50 p-4 rounded-lg">
                    <h4 class="font-medium text-green-900 mb-2">Team Leader Summary</h4>
                    <p class="text-sm text-green-700 mb-3">Channel partner team performance</p>
                    <ul class="text-sm text-green-600 space-y-1">
                        <li>• Total Payouts: ₹<?= number_format($total_team_payouts, 0) ?></li>
                        <li>• Total Commission: ₹<?= number_format($total_team_commission, 0) ?></li>
                        <li>• Leader Margin: ₹<?= number_format($total_team_commission - $total_team_payouts, 0) ?></li>
                    </ul>
                </div>
            </div>
        </div>

    </main>

    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>