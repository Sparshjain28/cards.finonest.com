<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

requireLogin();

$user = getCurrentUser();
$database = new Database();
$conn = $database->getConnection();

// Get referral statistics
$stats_query = "SELECT 
    COUNT(DISTINCT rl.id) as total_links,
    COUNT(DISTINCT ru.id) as total_referrals,
    SUM(rl.clicks) as total_clicks,
    SUM(rl.signups) as total_signups,
    SUM(ru.total_commission_earned) as total_commission
FROM referral_links rl 
LEFT JOIN referral_users ru ON rl.referral_code = ru.referral_code";

$stats_stmt = $conn->prepare($stats_query);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();
$stats_stmt->close();

// Get referral users data
$referrals_query = "SELECT 
    ru.*,
    referrer.name as referrer_name,
    referred.name as referred_name,
    referred.email as referred_email,
    referred.phone as referred_phone
FROM referral_users ru
JOIN users referrer ON ru.referrer_user_id = referrer.id
JOIN users referred ON ru.referred_user_id = referred.id
ORDER BY ru.signup_date DESC";

$referrals_stmt = $conn->prepare($referrals_query);
$referrals_stmt->execute();
$referrals = $referrals_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$referrals_stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Referral Management - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    
    <main class="max-w-7xl mx-auto px-4 py-8">
        <h1 class="text-2xl font-bold mb-6">Referral Program Management</h1>
        
        <!-- Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <i class="fas fa-link text-blue-600 text-2xl mr-3"></i>
                    <div>
                        <p class="text-sm text-gray-600">Total Links</p>
                        <p class="text-2xl font-bold"><?= $stats['total_links'] ?></p>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <i class="fas fa-users text-green-600 text-2xl mr-3"></i>
                    <div>
                        <p class="text-sm text-gray-600">Total Referrals</p>
                        <p class="text-2xl font-bold"><?= $stats['total_referrals'] ?></p>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <i class="fas fa-mouse-pointer text-purple-600 text-2xl mr-3"></i>
                    <div>
                        <p class="text-sm text-gray-600">Total Clicks</p>
                        <p class="text-2xl font-bold"><?= $stats['total_clicks'] ?></p>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <i class="fas fa-user-plus text-orange-600 text-2xl mr-3"></i>
                    <div>
                        <p class="text-sm text-gray-600">Total Signups</p>
                        <p class="text-2xl font-bold"><?= $stats['total_signups'] ?></p>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <i class="fas fa-dollar-sign text-yellow-600 text-2xl mr-3"></i>
                    <div>
                        <p class="text-sm text-gray-600">Commission Paid</p>
                        <p class="text-2xl font-bold">₹<?= number_format($stats['total_commission'] ?? 0) ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Referral Users Table -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="px-6 py-4 border-b">
                <h2 class="text-lg font-semibold">Referral Users</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Referrer</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Referred User</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phone</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Signup Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Commission</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($referrals as $referral): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                <?= htmlspecialchars($referral['referrer_name']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= htmlspecialchars($referral['referred_name']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= htmlspecialchars($referral['referred_email']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= htmlspecialchars($referral['referred_phone']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?= date('M d, Y', strtotime($referral['signup_date'])) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                ₹<?= number_format($referral['total_commission_earned']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                    <?= $referral['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800' ?>">
                                    <?= ucfirst($referral['status']) ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
    <script src="/assets/js/loading.js"></script>
</body>
</html>