<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/role_manager.php';
require_once __DIR__ . '/../config/database_updated.php';

requireLogin();
if (!isAdmin()) {
    header('Location: ../adviser/dashboard.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();
$roleManager = new RoleManager($conn);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['assign_role'])) {
        $userId = (int)$_POST['user_id'];
        $roleId = (int)$_POST['role_id'];
        
        // Sync is_admin flag with role: 1 = admin, others = not admin
        $isAdmin = ($roleId == 1) ? 1 : 0;
        
        if ($roleManager->assignRole($userId, $roleId)) {
            // Update is_admin flag to match role
            $conn->query("UPDATE users SET is_admin = $isAdmin WHERE id = $userId");
            header('Location: role_management.php?success=role_assigned');
        } else {
            header('Location: role_management.php?error=assignment_failed');
        }
        exit();
    }
    
    if (isset($_POST['update_individual_permissions'])) {
        $userId = (int)$_POST['user_id'];
        $permissions = $_POST['individual_permissions'] ?? [];
        
        // Clear existing user permissions
        $conn->query("DELETE FROM user_permissions WHERE user_id = $userId");
        
        // Add new permissions
        foreach ($permissions as $permissionName) {
            $roleManager->setUserPermission($userId, $permissionName, true);
        }
        
        header('Location: role_management.php?success=individual_updated');
        exit();
    }
}

// Get all data
$roles = $roleManager->getAllRoles();
$permissions = $roleManager->getAllPermissions();

// Get users
$usersResult = $conn->query("SELECT u.id, u.name, u.email, r.display_name as role_name 
                            FROM users u 
                            LEFT JOIN roles r ON u.role_id = r.id 
                            ORDER BY u.name");
$users = [];
while ($row = $usersResult->fetch_assoc()) {
    $users[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Role Management - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/css/tom-select.bootstrap5.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/js/tom-select.complete.min.js"></script>
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    
    <div class="flex">
        <!-- Left Panel -->
        <div class="w-64 bg-white shadow-lg min-h-screen">
            <div class="p-6">
                <h2 class="text-xl font-bold text-slate-800 mb-6">Role Management</h2>
                <nav class="space-y-2">
                    <a href="#assign-roles" onclick="showTab('assign-roles')" class="tab-link flex items-center gap-3 px-4 py-3 rounded-lg text-blue-600 bg-blue-50 font-medium">
                        <i class="fas fa-user-plus"></i> Assign Roles
                    </a>
                    <a href="#user-permissions" onclick="showTab('user-permissions')" class="tab-link flex items-center gap-3 px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-50 font-medium">
                        <i class="fas fa-user-cog"></i> User Permissions
                    </a>
                    <a href="manager_assignments.php" class="flex items-center gap-3 px-4 py-3 rounded-lg text-slate-600 hover:bg-slate-50 font-medium">
                        <i class="fas fa-users-cog"></i> Manager Assignments
                    </a>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="flex-1 p-6">
            <!-- Notifications -->
            <?php if (isset($_GET['success'])): ?>
            <div class="mb-6 bg-emerald-50 border border-emerald-200 text-emerald-800 px-6 py-4 rounded-xl">
                <i class="fas fa-check-circle mr-2"></i>
                <?php if ($_GET['success'] === 'role_assigned'): ?>
                    User role assigned successfully!
                <?php elseif ($_GET['success'] === 'individual_updated'): ?>
                    User permissions updated successfully!
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Assign Roles Tab -->
            <div id="assign-roles" class="tab-content">
                <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
                    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 px-6 py-5 border-b">
                        <h3 class="text-xl font-bold text-slate-800">Assign User Roles</h3>
                        <p class="text-sm text-slate-500">Choose user and assign their role</p>
                    </div>
                    
                    <div class="p-6">
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <!-- Assignment Form -->
                            <div>
                                <form method="POST" class="space-y-4">
                                    <input type="hidden" name="assign_role" value="1">
                                    <div>
                                        <label class="block text-sm font-bold text-slate-600 mb-2">
                                            <i class="fas fa-user mr-1 text-blue-500"></i> Select User
                                        </label>
                                        <select name="user_id" id="user-select" required>
                                            <option value="">Choose a user...</option>
                                            <?php foreach ($users as $user): ?>
                                            <option value="<?php echo $user['id']; ?>">
                                                <?php echo htmlspecialchars($user['name'] . ' (' . $user['email'] . ')'); ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-bold text-slate-600 mb-2">
                                            <i class="fas fa-crown mr-1 text-amber-500"></i> Select Role
                                        </label>
                                        <select name="role_id" required>
                                            <option value="">Choose a role...</option>
                                            <?php foreach ($roles as $role): ?>
                                            <option value="<?php echo $role['id']; ?>">
                                                <?php echo htmlspecialchars($role['display_name']); ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <button type="submit" class="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-indigo-700 font-bold transition-all">
                                        <i class="fas fa-user-plus mr-2"></i> Assign Role
                                    </button>
                                </form>
                            </div>

                            <!-- Users List -->
                            <div>
                                <h4 class="text-lg font-bold text-slate-800 mb-4">Current Assignments</h4>
                                <div class="border border-slate-200 rounded-xl overflow-hidden max-h-96 overflow-y-auto">
                                    <?php foreach ($users as $user): ?>
                                    <div class="flex items-center justify-between px-4 py-3 border-b border-slate-100 last:border-0">
                                        <div class="flex items-center gap-3">
                                            <div class="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-bold text-xs">
                                                <?= strtoupper(substr($user['name'], 0, 2)) ?>
                                            </div>
                                            <div>
                                                <div class="font-medium text-slate-800"><?php echo htmlspecialchars($user['name']); ?></div>
                                                <div class="text-xs text-slate-500"><?php echo htmlspecialchars($user['email']); ?></div>
                                            </div>
                                        </div>
                                        <span class="px-2 py-1 text-xs font-bold rounded-full bg-blue-100 text-blue-700">
                                            <?php echo htmlspecialchars($user['role_name'] ?? 'No Role'); ?>
                                        </span>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- User Permissions Tab -->
            <div id="user-permissions" class="tab-content hidden">
                <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
                    <div class="bg-gradient-to-r from-purple-50 to-pink-50 px-6 py-5 border-b">
                        <h3 class="text-xl font-bold text-slate-800">Configure User Permissions</h3>
                        <p class="text-sm text-slate-500">Customize permissions for specific users</p>
                    </div>
                    
                    <div class="p-6">
                        <form method="POST" id="permissionsForm">
                            <input type="hidden" name="update_individual_permissions" value="1">
                            
                            <div class="mb-6">
                                <label class="block text-sm font-bold text-slate-600 mb-2">
                                    <i class="fas fa-user-cog mr-1 text-purple-500"></i> Select User to Configure
                                </label>
                                <select name="user_id" id="userPermissionSelect" required class="w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:border-purple-500">
                                    <option value="">Choose a user...</option>
                                    <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user['id']; ?>">
                                        <?php echo htmlspecialchars($user['name'] . ' - ' . ($user['role_name'] ?? 'No Role')); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div id="permissionsContainer" class="hidden">
                                <h4 class="text-lg font-bold text-slate-800 mb-4">Customize Permissions</h4>
                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-96 overflow-y-auto">
                                    <?php foreach ($permissions as $category => $perms): ?>
                                    <div class="bg-slate-50 p-4 rounded-xl">
                                        <h5 class="font-bold text-slate-700 mb-3"><?php echo ucfirst($category); ?></h5>
                                        <div class="space-y-2">
                                            <?php foreach ($perms as $perm): ?>
                                            <label class="flex items-center gap-3 p-2 hover:bg-white rounded-lg cursor-pointer">
                                                <input type="checkbox" name="individual_permissions[]" value="<?php echo $perm['name']; ?>" class="w-4 h-4 text-purple-600">
                                                <div>
                                                    <span class="font-medium text-slate-700"><?php echo htmlspecialchars($perm['display_name']); ?></span>
                                                    <p class="text-xs text-slate-500"><?php echo htmlspecialchars($perm['name']); ?></p>
                                                </div>
                                            </label>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                
                                <div class="mt-6">
                                    <button type="submit" class="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-4 rounded-xl hover:from-purple-700 hover:to-pink-700 font-bold transition-all">
                                        <i class="fas fa-save mr-2"></i>Save User Permissions
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    // Tab functionality
    function showTab(tabId) {
        // Hide all tabs
        document.querySelectorAll('.tab-content').forEach(tab => tab.classList.add('hidden'));
        // Remove active class from all links
        document.querySelectorAll('.tab-link').forEach(link => {
            link.classList.remove('text-blue-600', 'bg-blue-50');
            link.classList.add('text-slate-600');
        });
        
        // Show selected tab
        document.getElementById(tabId).classList.remove('hidden');
        // Add active class to clicked link
        event.target.closest('.tab-link').classList.add('text-blue-600', 'bg-blue-50');
        event.target.closest('.tab-link').classList.remove('text-slate-600');
    }

    // Initialize Tom Select
    new TomSelect("#user-select", {
        create: false,
        sortField: { field: "text", direction: "asc" }
    });
    
    new TomSelect("#userPermissionSelect", {
        create: false,
        sortField: { field: "text", direction: "asc" }
    });

    // User permission configuration
    document.getElementById('userPermissionSelect').addEventListener('change', function() {
        const userId = this.value;
        const container = document.getElementById('permissionsContainer');
        
        if (!userId) {
            container.classList.add('hidden');
            return;
        }
        
        // Load current permissions
        fetch(`get_user_permissions.php?user_id=${userId}`)
            .then(response => response.json())
            .then(permissions => {
                // Uncheck all first
                document.querySelectorAll('input[name="individual_permissions[]"]').forEach(cb => cb.checked = false);
                
                // Check current permissions
                permissions.forEach(perm => {
                    const checkbox = document.querySelector(`input[name="individual_permissions[]"][value="${perm}"]`);
                    if (checkbox) checkbox.checked = true;
                });
                
                container.classList.remove('hidden');
            })
            .catch(error => {
                console.error('Error loading permissions:', error);
                container.classList.remove('hidden');
            });
    });
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>