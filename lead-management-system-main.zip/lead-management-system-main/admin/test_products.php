<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "Starting test...<br>";

try {
    echo "1. Testing auth include...<br>";
    require_once __DIR__ . '/../includes/auth.php';
    echo "Auth included successfully<br>";
    
    echo "2. Testing database include...<br>";
    require_once __DIR__ . '/../config/database_updated.php';
    echo "Database included successfully<br>";
    
    echo "3. Testing timezone helper...<br>";
    require_once __DIR__ . '/../includes/timezone_helper.php';
    echo "Timezone helper included successfully<br>";
    
    echo "4. Testing login requirement...<br>";
    // Comment out for testing: requireLogin();
    echo "Login check skipped for testing<br>";
    
    echo "5. Testing admin check...<br>";
    // Comment out for testing: if (!isAdmin()) { header('Location: ../adviser/dashboard.php'); exit(); }
    echo "Admin check skipped for testing<br>";
    
    echo "6. Testing timezone function...<br>";
    ensureTimezone();
    echo "Timezone set successfully<br>";
    
    echo "7. Testing database connection...<br>";
    $database = new Database();
    $conn = $database->getConnection();
    if ($conn) {
        echo "Database connected successfully<br>";
    } else {
        echo "Database connection failed<br>";
    }
    
    echo "8. Testing products query...<br>";
    $res = $conn->query("SELECT COUNT(*) as count FROM products");
    if ($res) {
        $row = $res->fetch_assoc();
        echo "Products table accessible, count: " . $row['count'] . "<br>";
    } else {
        echo "Products query failed: " . $conn->error . "<br>";
    }
    
    echo "All tests passed!<br>";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "<br>";
    echo "File: " . $e->getFile() . "<br>";
    echo "Line: " . $e->getLine() . "<br>";
}
?>