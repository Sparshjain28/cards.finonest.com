<?php
session_start();
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/timestamp_validator.php';

// Check if user is admin
if (!isLoggedIn() || !hasRole('admin')) {
    header('Location: ../login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get timestamp validation stats
$stats = getTimestampValidationStats($db);

// Get recent timestamp issues from log
$log_file = '../logs/timestamp_validation.log';
$recent_issues = [];
if (file_exists($log_file)) {
    $lines = array_slice(file($log_file), -20); // Last 20 entries
    $recent_issues = array_reverse($lines);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Timestamp Validation - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
</head>
<body class="bg-gray-100">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="container mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-md p-6">
            <h1 class="text-2xl font-bold mb-6">Timestamp Validation Monitor</h1>
            
            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <div class="bg-blue-50 p-4 rounded-lg">
                    <h3 class="text-sm font-medium text-blue-600">Total Leads (7 days)</h3>
                    <p class="text-2xl font-bold text-blue-900"><?= $stats['total_leads'] ?? 0 ?></p>
                </div>
                <div class="bg-red-50 p-4 rounded-lg">
                    <h3 class="text-sm font-medium text-red-600">Future Timestamps</h3>
                    <p class="text-2xl font-bold text-red-900"><?= $stats['future_timestamps'] ?? 0 ?></p>
                </div>
                <div class="bg-yellow-50 p-4 rounded-lg">
                    <h3 class="text-sm font-medium text-yellow-600">Old Timestamps</h3>
                    <p class="text-2xl font-bold text-yellow-900"><?= $stats['old_timestamps'] ?? 0 ?></p>
                </div>
                <div class="bg-purple-50 p-4 rounded-lg">
                    <h3 class="text-sm font-medium text-purple-600">Off-Hours Leads</h3>
                    <p class="text-2xl font-bold text-purple-900"><?= $stats['off_hours'] ?? 0 ?></p>
                </div>
            </div>
            
            <!-- Recent Issues -->
            <div class="mb-6">
                <h2 class="text-xl font-semibold mb-4">Recent Timestamp Issues</h2>
                <?php if (empty($recent_issues)): ?>
                    <p class="text-green-600">No timestamp issues found!</p>
                <?php else: ?>
                    <div class="bg-gray-50 rounded-lg p-4 max-h-96 overflow-y-auto">
                        <?php foreach ($recent_issues as $issue): ?>
                            <div class="text-sm font-mono mb-2 p-2 bg-white rounded border-l-4 border-red-400">
                                <?= htmlspecialchars(trim($issue)) ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Test Timestamp Validation -->
            <div class="border-t pt-6">
                <h2 class="text-xl font-semibold mb-4">Test Timestamp Validation</h2>
                <form method="POST" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium mb-2">Test Timestamp:</label>
                        <input type="datetime-local" name="test_timestamp" class="border rounded px-3 py-2 w-full" required>
                    </div>
                    <button type="submit" name="test_validation" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                        Test Validation
                    </button>
                </form>
                
                <?php if (isset($_POST['test_validation'])): ?>
                    <?php
                    $test_timestamp = $_POST['test_timestamp'];
                    $validation = validateLeadTimestamp($test_timestamp);
                    ?>
                    <div class="mt-4 p-4 bg-gray-50 rounded">
                        <h3 class="font-semibold mb-2">Validation Result:</h3>
                        <div class="space-y-2 text-sm">
                            <p><strong>Valid:</strong> <span class="<?= $validation['is_valid'] ? 'text-green-600' : 'text-red-600' ?>"><?= $validation['is_valid'] ? 'Yes' : 'No' ?></span></p>
                            <p><strong>Time Difference:</strong> <?= $validation['time_difference'] ?> seconds</p>
                            <p><strong>Lead Time:</strong> <?= $validation['lead_timestamp'] ?></p>
                            <p><strong>Header Time:</strong> <?= $validation['header_timestamp'] ?></p>
                            <?php if ($validation['needs_correction']): ?>
                                <p><strong>Corrected Time:</strong> <?= $validation['corrected_timestamp'] ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="mt-6">
                <a href="dashboard.php" class="text-blue-500 hover:underline">← Back to Dashboard</a>
            </div>
        </div>
    </div>
    <script src="/assets/js/loading.js"></script>
</body>
</html>