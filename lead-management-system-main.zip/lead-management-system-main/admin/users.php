<?php
require_once '../includes/auth.php';
require_once '../config/database_updated.php';
requireLogin();

if (!isAdmin()) {
    header('Location: ../adviser/dashboard.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Approve-only logic: if only id and approved are set, update just approval status
    $id = $_POST['id'] ?? 0;
    if (isset($_POST['approved']) && count($_POST) === 2 && $id > 0) {
        $query = "UPDATE users SET approved = 1 WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            header('Location: users.php?success=1');
            exit();
        } else {
            $error = 'Failed to approve user: ' . $stmt->error;
        }
    } else {
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $channel_code = $_POST['channel_code'] ?? '';
        $is_admin = isset($_POST['is_admin']) ? 1 : 0;
        $user_type = $_POST['user_type'] ?? '';
        $approved = isset($_POST['approved']) ? 1 : 0;
        $role_id = $_POST['role_id'] ?? null;
        
        // Sync is_admin flag with role_id: 1 = admin, others = not admin
        if ($role_id) {
            $is_admin = ($role_id == 1) ? 1 : 0;
        }

        // Check for duplicate email/phone
        $dupQuery = "SELECT id FROM users WHERE (email = ? OR phone = ?)" . ($id > 0 ? " AND id != ?" : "");
        $dupStmt = $conn->prepare($dupQuery);
        if ($id > 0) {
            $dupStmt->bind_param("ssi", $email, $phone, $id);
        } else {
            $dupStmt->bind_param("ss", $email, $phone);
        }
        $dupStmt->execute();
        $dupResult = $dupStmt->get_result();
        if ($dupResult && $dupResult->num_rows > 0) {
            $error = 'Email or phone already exists.';
        } elseif (empty($name) || empty($email) || empty($channel_code)) {
            $error = 'Please fill in all required fields';
        } else {
            if ($id > 0) {
                // Update existing user
                // Generate channel code if user doesn't have one and is being made admin
                if (empty($channel_code) && $is_admin == 1) {
                    $channel_code = 'CH' . strtoupper(bin2hex(random_bytes(4)));
                }
                
                if (isset($_POST['new_password']) && !empty($_POST['new_password'])) {
                    // Admin can change password without old password
                    $hashed_new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                    $query = "UPDATE users SET name = ?, email = ?, phone = ?, channel_code = ?, is_admin = ?, user_type = ?, approved = ?, password = ?, role_id = ? WHERE id = ?";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param("ssssssissi", $name, $email, $phone, $channel_code, $is_admin, $user_type, $approved, $hashed_new_password, $role_id, $id);
                } else {
                    $query = "UPDATE users SET name = ?, email = ?, phone = ?, channel_code = ?, is_admin = ?, user_type = ?, approved = ?, role_id = ? WHERE id = ?";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param("ssssssiii", $name, $email, $phone, $channel_code, $is_admin, $user_type, $approved, $role_id, $id);
                }
            } else {
                // Create new user
                $password = $_POST['password'] ?? '';
                if (empty($password)) {
                    $error = 'Please provide a password for the new user';
                } else {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $query = "INSERT INTO users (name, email, password, phone, channel_code, is_admin, user_type, approved, role_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param("sssssssii", $name, $email, $hashed_password, $phone, $channel_code, $is_admin, $user_type, $approved, $role_id);
                }
            }
            if (empty($error) && $stmt->execute()) {
                // Handle referrer update for existing users
                if ($id > 0) {
                    $referrer_id = $_POST['referrer_id'] ?? '';
                    // Delete existing referral relationship
                    $conn->query("DELETE FROM referral_users WHERE referred_user_id = $id");
                    // Add new referral relationship if referrer is selected
                    if (!empty($referrer_id)) {
                        // Get referrer details
                        $refQuery = $conn->prepare("SELECT name, channel_code FROM users WHERE id = ?");
                        $refQuery->bind_param("i", $referrer_id);
                        $refQuery->execute();
                        $refResult = $refQuery->get_result();
                        if ($refRow = $refResult->fetch_assoc()) {
                            $refStmt = $conn->prepare("INSERT INTO referral_users (referrer_user_id, referred_user_id, referral_code, referrer_name, status) VALUES (?, ?, ?, ?, 'active')");
                            $refStmt->bind_param("iiss", $referrer_id, $id, $refRow['channel_code'], $refRow['name']);
                            $refStmt->execute();
                            $refStmt->close();
                        }
                        $refQuery->close();
                    }
                }
                header('Location: users.php?success=1');
                exit();
            } else {
                $error = 'Failed to save user: ' . $stmt->error;
            }
        }
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    // Delete KYC related records first (only if tables exist)
    $conn->query("DELETE FROM aadhaar_verifications WHERE user_id = $id");
    $conn->query("DELETE FROM pan_verifications WHERE user_id = $id");
    $conn->query("DELETE FROM bank_verifications WHERE user_id = $id");
    $conn->query("DELETE FROM api_responses WHERE user_email = (SELECT email FROM users WHERE id = $id)");
    
    // Delete other related records
    $conn->query("DELETE FROM user_notice_reads WHERE user_id = $id");
    $conn->query("DELETE FROM referral_links WHERE user_id = $id");
    $conn->query("DELETE FROM referral_users WHERE referrer_user_id = $id OR referred_user_id = $id");
    $conn->query("DELETE FROM payouts WHERE lead_id IN (SELECT id FROM leads WHERE channel_code = (SELECT channel_code FROM users WHERE id = $id))");
    $conn->query("DELETE FROM leads WHERE channel_code = (SELECT channel_code FROM users WHERE id = $id)");
    
    // Now delete the user
    $query = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        header('Location: users.php?success=3');
        exit();
    } else {
        $error = 'Failed to delete user: ' . $stmt->error;
    }
}

// Get user to edit
$user = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $query = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
}

// Get all users with referral team information
$query = "
    SELECT u.*, 
           COUNT(DISTINCT ru.referred_user_id) as team_count,
           GROUP_CONCAT(DISTINCT referred.name SEPARATOR ', ') as team_names,
           referrer.name as referred_by_name
    FROM users u
    LEFT JOIN referral_users ru ON u.id = ru.referrer_user_id
    LEFT JOIN users referred ON ru.referred_user_id = referred.id
    LEFT JOIN referral_users ru2 ON u.id = ru2.referred_user_id
    LEFT JOIN users referrer ON ru2.referrer_user_id = referrer.id
    GROUP BY u.id
    ORDER BY u.name ASC
";
$result = $conn->query($query);
$users = $result->fetch_all(MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    <div class="w-full max-w-7xl mx-auto px-4 py-8">
        <div class="flex items-center justify-between mb-6">
            <h1 class="text-2xl font-bold text-slate-900">Manage Users</h1>
            <a href="users.php?new=1" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center">
                <i class="fas fa-plus mr-2"></i>Add New User
            </a>
        </div>
        <main>
            <?php if (isset($_GET['success'])): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    <?php if ($_GET['success'] == 1): ?>
                        User saved successfully!
                    <?php elseif ($_GET['success'] == 3): ?>
                        User deleted successfully!
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['new'])): ?>
                <div class="bg-white rounded-lg shadow-sm border p-6 mb-6">
                    <h2 class="text-xl font-semibold text-slate-900 mb-4">Add New User</h2>
                    <form method="POST">
                        <input type="hidden" name="id" value="0">
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-1">User Type</label>
                                <select name="user_type" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                                    <option value="dsa">DSA</option>
                                    <option value="dst">DST</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-1">Approved</label>
                                <input type="checkbox" name="approved">
                                <p class="text-xs text-slate-500 mt-1">Note: DSA users can login without admin approval. Approval is optional for DSA.</p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-1">Name *</label>
                                <input type="text" name="name" required class="w-full px-3 py-2 border border-slate-300 rounded-md">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-1">Email *</label>
                                <input type="email" name="email" required class="w-full px-3 py-2 border border-slate-300 rounded-md">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-1">Phone</label>
                                <input type="text" name="phone" class="w-full px-3 py-2 border border-slate-300 rounded-md">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-1">Channel Code *</label>
                                <input type="text" name="channel_code" required class="w-full px-3 py-2 border border-slate-300 rounded-md">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-1">Password *</label>
                                <input type="password" name="password" required class="w-full px-3 py-2 border border-slate-300 rounded-md">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-1">Is Admin</label>
                                <input type="checkbox" name="is_admin">
                            </div>
                            <div class="flex justify-end">
                                <a href="users.php" class="px-4 py-2 text-slate-600 hover:text-slate-800 mr-2">Cancel</a>
                                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Save User</button>
                            </div>
                        </div>
                    </form>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['edit'])): ?>
            <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                <div class="bg-white rounded-lg shadow-xl border w-full max-w-4xl max-h-[90vh] overflow-y-auto">
                    <div class="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center">
                        <h2 class="text-xl font-bold text-slate-900">Edit User</h2>
                        <button onclick="window.location.href='users.php'" class="text-slate-400 hover:text-slate-600 text-2xl">&times;</button>
                    </div>
                    <div class="p-6">
                        <form method="POST" class="space-y-6">
                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($user['id'] ?? 0); ?>">
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-2">Name *</label>
                                    <input type="text" name="name" required class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-2">Email *</label>
                                    <input type="email" name="email" required class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-2">Phone</label>
                                    <input type="text" name="phone" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-2">Channel Code *</label>
                                    <input type="text" name="channel_code" required class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value="<?php echo htmlspecialchars($user['channel_code'] ?? ''); ?>">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-2">User Type</label>
                                    <select name="user_type" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                        <option value="dsa" <?php echo (isset($user['user_type']) && $user['user_type'] == 'dsa') ? 'selected' : ''; ?>>DSA</option>
                                        <option value="dst" <?php echo (isset($user['user_type']) && $user['user_type'] == 'dst') ? 'selected' : ''; ?>>DST</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-2">Role</label>
                                    <select name="role_id" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                        <?php
                                        // Get available roles
                                        $rolesQuery = $conn->query("SELECT id, name, display_name FROM roles ORDER BY id");
                                        while ($role = $rolesQuery->fetch_assoc()) {
                                            $selected = (isset($user['role_id']) && $user['role_id'] == $role['id']) ? 'selected' : '';
                                            echo "<option value='{$role['id']}' $selected>{$role['display_name']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-2">Referred By</label>
                                    <div class="space-y-2">
                                        <select name="referrer_id" id="referrer_id" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                            <option value="">None</option>
                                            <?php
                                            $currentReferrer = null;
                                            $referrerQuery = $conn->query("SELECT ru.referrer_user_id, u.name FROM referral_users ru JOIN users u ON ru.referrer_user_id = u.id WHERE ru.referred_user_id = {$user['id']}");
                                            if ($referrerQuery && $referrerRow = $referrerQuery->fetch_assoc()) {
                                                $currentReferrer = $referrerRow['referrer_user_id'];
                                            }
                                            $usersQuery = $conn->query("SELECT id, name, channel_code FROM users WHERE id != {$user['id']} ORDER BY name");
                                            while ($u = $usersQuery->fetch_assoc()) {
                                                $selected = ($currentReferrer == $u['id']) ? 'selected' : '';
                                                echo "<option value='{$u['id']}' data-channel='{$u['channel_code']}' $selected>{$u['name']} ({$u['channel_code']})</option>";
                                            }
                                            ?>
                                        </select>
                                        <div class="flex gap-2">
                                            <input type="text" id="channel_code_lookup" placeholder="Or enter channel code" class="flex-1 px-3 py-2 border border-slate-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                            <button type="button" onclick="findByChannelCode()" class="px-4 py-2 bg-slate-600 text-white rounded-md text-sm hover:bg-slate-700">Find</button>
                                        </div>
                                        <p id="channel_lookup_msg" class="text-xs text-slate-500"></p>
                                    </div>
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-2">Partner Program</label>
                                    <select name="referral_program" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                        <option value="" <?php echo empty($user['referral_program']) ? 'selected' : ''; ?>>Not Selected</option>
                                        <option value="network" <?php echo (isset($user['referral_program']) && $user['referral_program'] == 'network') ? 'selected' : ''; ?>>Network Partner (3 Levels: L1-5%, L2-2%, L3-1%)</option>
                                        <option value="channel" <?php echo (isset($user['referral_program']) && $user['referral_program'] == 'channel') ? 'selected' : ''; ?>>Channel Partner (1 Level: Direct referrals only)</option>
                                    </select>
                                    <p class="text-xs text-slate-500 mt-1">This is a permanent choice and cannot be changed later.</p>
                                </div>

                                <div class="space-y-4">
                                    <div class="flex items-center space-x-3">
                                        <input type="checkbox" name="approved" id="approved" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300 rounded" <?php echo (isset($user['approved']) && $user['approved'] == 1) ? 'checked' : ''; ?>>
                                        <label for="approved" class="text-sm font-medium text-slate-700">Approved</label>
                                    </div>
                                    <div class="flex items-center space-x-3">
                                        <input type="checkbox" name="is_admin" id="is_admin" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-slate-300 rounded" <?php echo (isset($user['is_admin']) && $user['is_admin'] == 1) ? 'checked' : ''; ?>>
                                        <label for="is_admin" class="text-sm font-medium text-slate-700">Is Admin (Legacy)</label>
                                        <small class="text-slate-500">Use Role field instead</small>
                                    </div>
                                </div>
                            </div>
                            
                            <?php if (isset($user['user_type']) && strtolower($user['user_type']) === 'dsa'): ?>
                                <div class="bg-blue-50 border border-blue-200 rounded-md p-3">
                                    <p class="text-sm text-blue-800">DSA users can login without admin approval. You may still mark them approved if desired.</p>
                                </div>
                            <?php endif; ?>
                            
                            <div class="border-t pt-6">
                                <button type="button" onclick="document.getElementById('pwFields').classList.toggle('hidden')" class="text-blue-600 hover:text-blue-800 font-medium">Change Password (optional)</button>
                                <div id="pwFields" class="hidden mt-4 space-y-4">
                                    <div>
                                        <label class="block text-sm font-medium text-slate-700 mb-2">Current Password</label>
                                        <input type="password" name="old_password" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Leave blank if admin">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-slate-700 mb-2">New Password</label>
                                        <input type="password" name="new_password" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Enter new password">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="flex justify-end space-x-3 pt-6 border-t">
                                <button type="button" onclick="window.location.href='users.php'" class="px-4 py-2 border border-slate-300 rounded-md text-slate-700 hover:bg-slate-50">Cancel</button>
                                <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 font-medium">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="bg-white rounded-lg shadow-sm border overflow-hidden" style="width:100%">
                <table class="w-full border border-slate-300 rounded-lg shadow-md" style="border-collapse:collapse;">
                    <thead class="bg-blue-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-bold text-blue-700 uppercase border-b border-slate-300">Name</th>
                            <th class="px-4 py-3 text-left text-xs font-bold text-blue-700 uppercase border-b border-slate-300">Referred By</th>
                            <th class="px-4 py-3 text-left text-xs font-bold text-blue-700 uppercase border-b border-slate-300">Email</th>
                            <th class="px-4 py-3 text-left text-xs font-bold text-blue-700 uppercase border-b border-slate-300">Phone</th>
                            <th class="px-4 py-3 text-left text-xs font-bold text-blue-700 uppercase border-b border-slate-300">Channel Code</th>
                            <th class="px-4 py-3 text-left text-xs font-bold text-blue-700 uppercase border-b border-slate-300">User Type</th>
                            <th class="px-4 py-3 text-left text-xs font-bold text-blue-700 uppercase border-b border-slate-300">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200">
                        <?php foreach ($users as $user): ?>
                            <tr class="hover:bg-blue-100">
                                <td class="px-4 py-3 text-sm text-slate-900 border-b border-slate-200">
                                    <div class="font-medium"><?php echo htmlspecialchars($user['name'] ?? ''); ?></div>
                                </td>
                                <td class="px-4 py-3 text-sm text-slate-900 border-b border-slate-200">
                                    <div><?php echo htmlspecialchars($user['referred_by_name'] ?? '-'); ?></div>
                                </td>
                                <td class="px-4 py-3 text-sm text-slate-900 border-b border-slate-200"><?php echo htmlspecialchars($user['email'] ?? ''); ?></td>
                                <td class="px-4 py-3 text-sm text-slate-900 border-b border-slate-200"><?php echo htmlspecialchars($user['phone'] ?? ''); ?></td>
                                <td class="px-4 py-3 text-sm text-slate-900 border-b border-slate-200"><?php echo htmlspecialchars($user['channel_code'] ?? ''); ?></td>
                                <td class="px-4 py-3 text-sm text-slate-900 border-b border-slate-200"><?php echo htmlspecialchars(strtoupper($user['user_type'] ?? '')); ?></td>
                                <td class="px-4 py-3 border-b border-slate-200">
                                    <div class="flex space-x-2">
                                        <a href="users.php?edit=<?php echo $user['id']; ?>" class="bg-blue-500 text-white px-2 py-1 rounded text-xs hover:bg-blue-600">Edit</a>
                                        <?php if ($user['is_admin'] != 1): ?>
                                            <a href="users.php?delete=<?php echo $user['id']; ?>" class="bg-red-500 text-white px-2 py-1 rounded text-xs hover:bg-red-600" onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                                        <?php else: ?>
                                            <span class="bg-gray-400 text-white px-2 py-1 rounded text-xs cursor-not-allowed" title="Cannot delete admin users">Delete</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <?php include '../includes/footer.php'; ?>
    <script src="/assets/js/loading.js"></script>
    <script>
    function findByChannelCode() {
        const channelCode = document.getElementById('channel_code_lookup').value.trim().toUpperCase();
        const referrerSelect = document.getElementById('referrer_id');
        const msg = document.getElementById('channel_lookup_msg');
        
        if (!channelCode) {
            msg.textContent = 'Please enter a channel code';
            msg.className = 'text-xs text-red-500';
            return;
        }
        
        const options = referrerSelect.options;
        for (let i = 0; i < options.length; i++) {
            const optionChannel = (options[i].dataset.channel || '').trim().toUpperCase();
            if (optionChannel === channelCode) {
                referrerSelect.value = options[i].value;
                msg.textContent = 'Found: ' + options[i].text;
                msg.className = 'text-xs text-green-600';
                return;
            }
        }
        
        msg.textContent = 'No user found with channel code: ' + channelCode;
        msg.className = 'text-xs text-red-500';
    }
    </script>
</body>
</html>
