<?php
session_start();
require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit;
}

$user_id = $_SESSION['user_id'];

$database = new Database();
$conn = $database->getConnection();

try {
    if ($_POST['action'] === 'load_data') {
        $user_ids = json_decode($_POST['user_ids'], true) ?: [];
        $categories = json_decode($_POST['categories'], true) ?: [];
        
        if (empty($user_ids)) {
            echo json_encode(['success' => true, 'data' => []]);
            exit;
        }
        
        if (empty($categories)) {
            $categories = ['Credit Card', 'Personal Loan', 'Car Loan'];
        }
        
        $data = [];
        $placeholders_users = str_repeat('?,', count($user_ids) - 1) . '?';
        $placeholders_cats = str_repeat('?,', count($categories) - 1) . '?';
        
        $query = "SELECT p.id, p.name, p.variant, p.category, p.commission_rate, 
                       ps.payout_rate, u.name as user_name, u.id as user_id
                 FROM products p
                 CROSS JOIN users u
                 LEFT JOIN payout_settings ps ON p.id = ps.product_id AND ps.advisor_user_id = u.id AND ps.user_id = ?
                 WHERE p.status = 'active' AND u.id IN ($placeholders_users) AND p.category IN ($placeholders_cats)
                 ORDER BY u.name, p.category, p.name";
        
        $stmt = $conn->prepare($query);
        if ($stmt) {
            $params = array_merge([$user_id], $user_ids, $categories);
            $types = 'i' . str_repeat('i', count($user_ids)) . str_repeat('s', count($categories));
            $stmt->bind_param($types, ...$params);
            $stmt->execute();
            $result = $stmt->get_result();
            
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            $stmt->close();
        }
        
        echo json_encode(['success' => true, 'data' => $data]);
        exit;
    }
    
    if ($_POST['action'] === 'save_payout') {
        $advisor_id = (int)$_POST['advisor_id'];
        $product_id = (int)$_POST['product_id'];
        $payout_rate = (float)$_POST['payout_rate'];
        
        $query = "INSERT INTO payout_settings (user_id, advisor_user_id, product_id, payout_rate, rate_type) 
                 VALUES (?, ?, ?, ?, 'custom') 
                 ON DUPLICATE KEY UPDATE payout_rate = VALUES(payout_rate)";
        $stmt = $conn->prepare($query);
        
        if ($stmt) {
            $stmt->bind_param("iiid", $user_id, $advisor_id, $product_id, $payout_rate);
            $success = $stmt->execute();
            $stmt->close();
            echo json_encode(['success' => $success]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Database error']);
        }
        exit;
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>