<?php
// Cleanup script to remove old product links (older than 1 minute)
require_once __DIR__ . '/../config/database_updated.php';

try {
    $database = new Database();
    $conn = $database->getConnection();
    
    // Delete links older than 1 minute
    $cleanup_query = "DELETE FROM advisor_products WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 MINUTE)";
    $result = $conn->query($cleanup_query);
    
    if ($result) {
        $deleted_count = $conn->affected_rows;
        error_log("Cleanup: Deleted $deleted_count old product links");
    }
    
} catch (Exception $e) {
    error_log("Cleanup error: " . $e->getMessage());
}
?>