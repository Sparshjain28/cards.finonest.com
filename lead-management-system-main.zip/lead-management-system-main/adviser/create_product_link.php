<?php
// Start output buffering to prevent any stray output
ob_start();

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

requireLogin();

// Clean the buffer before sending JSON
ob_end_clean();

header('Content-Type: application/json');

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get product ID from POST data
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;

if ($product_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
    exit;
}

try {
    // Get current user
    $user = getCurrentUser();
    
    // Database connection
    $database = new Database();
    $conn = $database->getConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    // Check if product exists and is active
    $product_check = $conn->prepare("SELECT id, name, variant, category FROM products WHERE id = ? AND status = 'active'");
    $product_check->bind_param("i", $product_id);
    $product_check->execute();
    $product_result = $product_check->get_result();
    
    if ($product_result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Product not found or not active']);
        exit;
    }
    
    $product = $product_result->fetch_assoc();
    $product_check->close();
    
    // Clean up old links (older than 30 days) for this user and product
    $cleanup_query = "DELETE FROM advisor_products WHERE advisor_id = ? AND product_id = ? AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)";
    $cleanup_stmt = $conn->prepare($cleanup_query);
    $cleanup_stmt->bind_param("ii", $user['id'], $product_id);
    $cleanup_stmt->execute();
    $cleanup_stmt->close();
    
    // Generate unique tracking code
    $tracking_code = 'AP' . strtoupper(uniqid());
    
    // Insert the advisor product
    $insert_query = "INSERT INTO advisor_products (advisor_id, product_id, tracking_code, custom_name) 
                    VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($insert_query);
    $custom_name = NULL; // No custom name field
    $stmt->bind_param("iiss", $user['id'], $product_id, $tracking_code, $custom_name);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to create product link');
    }
    
    $advisor_product_id = $conn->insert_id;
    $stmt->close();
    
    // Generate share link
    $app_page = '';
    $category = strtolower($product['category']);
    if (strpos($category, 'credit') !== false) {
        $app_page = 'apply_card';
    } elseif (strpos($category, 'personal') !== false) {
        $app_page = 'apply_personal';
    } elseif (strpos($category, 'car') !== false) {
        $app_page = 'apply_car';
    } else {
        $app_page = 'apply';
    }
    
    $share_link = "https://" . $_SERVER['HTTP_HOST'] . "/forms/apply_form.php?product_id=" . $product_id . "&product_name=" . urlencode($product['name']) . "&ref=" . $user['channel_code'] . "&product=" . $tracking_code;
    
    // Prepare response data
    $response_data = [
        'id' => $advisor_product_id,
        'product_id' => $product_id,
        'tracking_code' => $tracking_code,
        'product_name' => $product['name'],
        'product_variant' => $product['variant'],
        'category' => $product['category'],
        'share_link' => $share_link,
        'created_date' => date('d M Y')
    ];
    
    echo json_encode([
        'success' => true, 
        'message' => 'Product link created successfully!',
        'product_link' => $response_data
    ]);
    
} catch (Exception $e) {
    $error_message = $e->getMessage();
    $error_trace = $e->getTraceAsString();
    error_log("Create product link error: " . $error_message);
    error_log("Stack trace: " . $error_trace);
    
    // Return more detailed error message in development
    echo json_encode([
        'success' => false, 
        'message' => 'Error: ' . $error_message,
        'debug' => [
            'error' => $error_message,
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ]
    ]);
}
?>
