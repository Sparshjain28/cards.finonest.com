<?php
require_once __DIR__ . '/../includes/auth.php';
    require_once __DIR__ . '/../config/database_updated.php';
    require_once __DIR__ . '/../includes/notices_component.php';
    require_once __DIR__ . '/../includes/margin_helper.php';

    requireLogin();


    $user = getCurrentUser();
    $database = new Database();
    $conn = $database->getConnection();

    // Check account status
    if ($user['account_status'] === 'rejected') {
        $error = 'Your account has been rejected due to KYC verification failure. Please contact support.';
    } elseif ($user['account_status'] === 'pending' && $user['aadhaar_verified'] && $user['pan_verified'] && $user['bank_verified']) {
        $warning = 'Your KYC verification is under review. You will be notified once approved.';
    }

    // Handle notice dismissal
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dismiss_notice'])) {
        markNoticeAsRead($conn, $user['id'], $_POST['dismiss_notice']);
        exit;
    }

    // Handle referral link creation
    if (isset($_GET['create_referral'])) {
        if (empty($user['referral_code'])) {
            // Generate referral code if missing
            $referral_code = 'REF' . strtoupper(bin2hex(random_bytes(3)));
            $update_user = $conn->prepare("UPDATE users SET referral_code = ? WHERE id = ?");
            $update_user->bind_param("si", $referral_code, $user['id']);
            $update_user->execute();
            $update_user->close();
            $user['referral_code'] = $referral_code;
        }
        
        // Default referral URL for general signup
        $referral_url = "https://cards.finonest.com/signup.php?ref=" . urlencode($user['referral_code']) . "&referrer=" . urlencode($user['name']);
        
        // If we have a product ID in the URL, generate a product-specific referral link
        if (isset($_GET['product_id']) && !empty($_GET['product_id'])) {
            $product_id = intval($_GET['product_id']);
            // Get product details
            $product_query = $conn->prepare("SELECT category FROM products WHERE id = ?");
            $product_query->bind_param("i", $product_id);
            $product_query->execute();
            $product_result = $product_query->get_result();
            
            if ($product_result && $product_result->num_rows > 0) {
                $product = $product_result->fetch_assoc();
                $category = strtolower($product['category']);
                
                // Determine the application page based on product category
                if (strpos($category, 'credit') !== false) {
                    $app_page = 'apply_card';
                } elseif (strpos($category, 'personal') !== false) {
                    $app_page = 'apply_personal';
                } elseif (strpos($category, 'car') !== false) {
                    $app_page = 'apply_car';
                } else {
                    $app_page = 'apply';
                }
                
                $referral_url = "https://cards.finonest.com/forms/" . $app_page . ".php?ref=" . urlencode($user['referral_code']) . "&referrer=" . urlencode($user['name']);
            }
        }
        
        $insert_link = $conn->prepare("INSERT INTO referral_links (user_id, referral_code, referral_url, product_id) VALUES (?, ?, ?, ?)");
        $product_id = isset($product_id) ? $product_id : null;
        $insert_link->bind_param("issi", $user['id'], $user['referral_code'], $referral_url, $product_id);
        if (!$insert_link->execute()) {
            error_log("Error inserting referral link in adviser/dashboard.php: " . $insert_link->error);
            // Optionally, set an error message for the user
            // $_SESSION['error_message'] = "Failed to create referral link.";
        }
        $insert_link->close();
        header('Location: dashboard.php');
        exit();
    }

    // Check if referral link exists
    $referral_link_data = null;
    $get_link = $conn->prepare("SELECT referral_url, clicks, signups FROM referral_links WHERE user_id = ?");
    $get_link->bind_param("i", $user['id']);
    $get_link->execute();
    $result = $get_link->get_result();
    if ($result->num_rows > 0) {
        $referral_link_data = $result->fetch_assoc();
    }
    $get_link->close();

    
    // Get advisor's products
    $advisor_products_query = "SELECT ap.*, p.name as product_name, p.variant as product_variant, p.category 
                             FROM advisor_products ap 
                             JOIN products p ON ap.product_id = p.id 
                             WHERE ap.advisor_id = ? 
                             ORDER BY ap.created_at DESC";
    $stmt = $conn->prepare($advisor_products_query);
    $stmt->bind_param("i", $user['id']);
    $stmt->execute();
    $advisor_products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();


    // Get KPIs for dashboard (admin sees all, adviser sees own only)
    function getKPIs($conn, $user) {
        // Adviser: only own leads
        $where = 'WHERE channel_code = ?';
        $params = [$user['channel_code']];
        $types = 's';
        $query = "SELECT 
            COUNT(*) as total_leads,
            SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
            SUM(CASE WHEN status = 'declined' THEN 1 ELSE 0 END) as rejected,
            SUM(CASE WHEN status IN ('generated', 'yet_to_start', 'in_process') THEN 1 ELSE 0 END) as work_in_progress,
            SUM(CASE WHEN MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE()) THEN 1 ELSE 0 END) as this_month,
            SUM(CASE WHEN MONTH(created_at) = MONTH(CURDATE()) - 1 AND YEAR(created_at) = YEAR(CURDATE()) THEN 1 ELSE 0 END) as last_month
            FROM leads $where";
        $stmt = $conn->prepare($query);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $kpis = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        // Bonus/Commission summary (only activated/disbursed)
        $bonus_query = "SELECT 
            SUM(CASE WHEN status = 'pending' AND lead_id IN (SELECT id FROM leads WHERE channel_code = ? AND status IN ('activated','disbursed')) THEN commission_amount + bonus_amount ELSE 0 END) as pending_bonus,
            SUM(CASE WHEN status = 'paid' AND lead_id IN (SELECT id FROM leads WHERE channel_code = ? AND status IN ('activated','disbursed')) AND MONTH(payout_date) = MONTH(CURDATE()) THEN commission_amount + bonus_amount ELSE 0 END) as paid_this_month,
            SUM(CASE WHEN status = 'paid' AND lead_id IN (SELECT id FROM leads WHERE channel_code = ? AND status IN ('activated','disbursed')) THEN commission_amount + bonus_amount ELSE 0 END) as total_paid
            FROM payouts";
        $bonus_stmt = $conn->prepare($bonus_query);
        $bonus_stmt->bind_param('sss', $user['channel_code'], $user['channel_code'], $user['channel_code']);
        $bonus_stmt->execute();
        $bonus_data = $bonus_stmt->get_result()->fetch_assoc();
        $bonus_stmt->close();
        return array_merge($kpis, $bonus_data);
    }

    $kpis = getKPIs($conn, $user);

    // Get product counts by category (adviser: only own leads)

    // Show available products by category (not leads)
    $product_counts = ['Credit Card' => 0, 'Personal Loan' => 0, 'Car Loan' => 0];
    $prod_query = "SELECT category, COUNT(*) as cnt FROM products WHERE status = 'active' GROUP BY category";
    $prod_res = $conn->query($prod_query);
    if ($prod_res) {
        while ($row = $prod_res->fetch_assoc()) {
            if (isset($product_counts[$row['category']])) {
                $product_counts[$row['category']] = (int)$row['cnt'];
            }
        }
    }

    // Recent leads (adviser: only own)
    $recent_query = "SELECT l.lead_id, l.customer_name, l.mobile, l.status, p.name as product_name, 
                    l.created_at,
                    DATE_FORMAT(CONVERT_TZ(l.created_at, '+00:00', '+05:30'), '%d %b %Y at %h:%i %p') as formatted_date,
                    TIMESTAMPDIFF(HOUR, CONVERT_TZ(l.created_at, '+00:00', '+05:30'), NOW()) as hours_ago,
                    TIMESTAMPDIFF(DAY, CONVERT_TZ(l.created_at, '+00:00', '+05:30'), NOW()) as days_ago
                    FROM leads l 
                    JOIN products p ON l.product_id = p.id 
                    WHERE l.channel_code = ?
                    ORDER BY l.created_at DESC LIMIT 5";
    $recent_stmt = $conn->prepare($recent_query);
    $recent_stmt->bind_param('s', $user['channel_code']);
    $recent_stmt->execute();
    $recent_leads = $recent_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $recent_stmt->close();

    if (isset($_GET['logout'])) {
        logout();
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Partner Dashboard - Fino Cards</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link href="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/css/tom-select.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/js/tom-select.complete.min.js"></script>
        <link rel="stylesheet" href="/assets/css/loading.css">
        <style>
         /* Tom Select Tailwind Tweaks */
         .ts-control { border-radius: 0.375rem; border-color: #d1d5db; padding: 0.5rem 0.75rem; }
         .ts-wrapper.focus .ts-control { border-color: #3b82f6; box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.5); }
         .ts-dropdown { border-radius: 0.375rem; border-color: #d1d5db; z-index: 50; }
        </style>
        <style>
        /* Hide scrollbar for horizontal scroll sections */
        .hide-scrollbar {
            scrollbar-width: none; /* Firefox */
            -ms-overflow-style: none; /* IE 10+ */
        }
        .hide-scrollbar::-webkit-scrollbar {
            display: none; /* Chrome, Safari, Opera */
        }
        /* Mobile: keep horizontal scroll, Desktop: use grid */
        @media (min-width: 1024px) {
            .mobile-scroll-desktop-grid {
                display: grid !important;
                overflow-x: visible !important;
            }
        }
        </style>
    </head>
    <body class="min-h-screen bg-slate-50">
        <div id="loader" class="loader"><div class="spinner"></div></div>
        <?php include '../includes/header.php'; ?>

        <div class="w-full px-2 py-2 sm:px-4 sm:py-4 lg:max-w-7xl lg:mx-auto">
            <?php 
            $notices = getActiveNotices($conn, $user['id']);
            echo renderNotices($notices);
            
            // Show verification success message
            if (isset($_SESSION['verification_success'])) {
                echo '<div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">';
                echo htmlspecialchars($_SESSION['verification_success']);
                echo '</div>';
                unset($_SESSION['verification_success']);
            }
            
            // Show account status messages
            if (isset($error)) {
                echo '<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">' . htmlspecialchars($error) . '</div>';
            }
            if (isset($warning)) {
                echo '<div class="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-4">' . htmlspecialchars($warning) . '</div>';
            }
            ?>
            
            <!-- Banner Section -->
            <div class="mb-4">
                <div class="bg-blue-50 border-l-4 border-blue-400 rounded-lg p-3 flex items-center gap-2">
                    <span class="text-2xl">👋</span>
                    <span class="text-blue-800 text-sm font-medium lg:font-bold">Partner Dashboard <span class="hidden lg:inline">&mdash; Sell Credit Cards & Loans Digitally and Earn Attractive Payouts!</span></span>
                </div>
            </div>

            <!-- Products Section -->
            <div class="mb-6">
                <h2 class="text-lg font-semibold text-slate-900 mb-2 lg:mb-4 lg:flex lg:items-center lg:gap-2">
                    <div class="hidden lg:flex w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg items-center justify-center">
                        <i class="fas fa-briefcase text-white text-sm"></i>
                    </div>
                    <span class="lg:hidden">Products</span>
                    <span class="hidden lg:inline">Product Portfolio</span>
                </h2>
                <div class="grid grid-cols-2 lg:grid-cols-5 gap-3">
                    <a href="../forms/apply_card.php" class="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-lg shadow-sm p-3 hover:border-blue-400 hover:shadow-md transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                <i class="fas fa-credit-card text-white text-xs"></i>
                            </div>
                            <div class="text-right">
                                <div class="text-xl font-bold text-blue-700"><?php echo $product_counts['Credit Card']; ?></div>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-xs font-semibold text-blue-800">Credit Cards</h3>
                            <p class="text-xs text-blue-600">Premium cards</p>
                        </div>
                    </a>
                    
                    <a href="../forms/apply_personal.php" class="group bg-gradient-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-200 rounded-lg shadow-sm p-3 hover:border-emerald-400 hover:shadow-md transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <div class="w-9 h-9 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                <i class="fas fa-coins text-white text-xs"></i>
                            </div>
                            <div class="text-right">
                                <div class="text-xl font-bold text-emerald-700"><?php echo $product_counts['Personal Loan']; ?></div>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-xs font-semibold text-emerald-800">Personal Loans</h3>
                            <p class="text-xs text-emerald-600">Quick loans</p>
                        </div>
                    </a>
                    
                    <a href="../forms/apply_car.php" class="group bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-200 rounded-lg shadow-sm p-3 hover:border-orange-400 hover:shadow-md transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <div class="w-9 h-9 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                <i class="fas fa-car-side text-white text-xs"></i>
                            </div>
                            <div class="text-right">
                                <div class="text-xl font-bold text-orange-700"><?php echo $product_counts['Car Loan']; ?></div>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-xs font-semibold text-orange-800">Car Loans</h3>
                            <p class="text-xs text-orange-600">Auto financing</p>
                        </div>
                    </a>

                    <!-- Offline Personal Loan -->
                    <a href="../forms/offline_pl_form.php" class="group bg-gradient-to-br from-indigo-50 to-indigo-100 border-2 border-indigo-200 rounded-lg shadow-sm p-3 hover:border-indigo-400 hover:shadow-md transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <div class="w-9 h-9 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                <i class="fas fa-money-bill-wave text-white text-xs"></i>
                            </div>
                            <div class="text-right">
                                <div class="text-xl font-bold text-indigo-700"><?php echo $product_counts['Offline Personal Loan'] ?? 0; ?></div>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-xs font-semibold text-indigo-800">Offline Personal Loan</h3>
                            <p class="text-xs text-indigo-600">Direct processing</p>
                        </div>
                    </a>

                    <!-- Business Loan -->
                    <a href="../forms/business_loan_form.php" class="group bg-gradient-to-br from-teal-50 to-teal-100 border-2 border-teal-200 rounded-lg shadow-sm p-3 hover:border-teal-400 hover:shadow-md transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <div class="w-9 h-9 bg-gradient-to-br from-teal-500 to-teal-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                <i class="fas fa-briefcase text-white text-xs"></i>
                            </div>
                            <div class="text-right">
                                <div class="text-xl font-bold text-teal-700"><?php echo $product_counts['Business Loan'] ?? 0; ?></div>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-xs font-semibold text-teal-800">Business Loan</h3>
                            <p class="text-xs text-teal-600">Business growth</p>
                        </div>
                    </a>
                </div>
            </div>




        <!-- Application Links for Customers 
            <div class="mb-8">
                <h2 class="text-lg font-semibold text-slate-900 mb-3">Application Links for Customers</h2>
                <div class="bg-blue-100 rounded-xl p-4 flex flex-col items-center gap-3">
                    <?php
                    // Build tracking parameters from user session
                    $params = [];
                    if (!empty($user['channel_code'])) $params['Channel'] = $user['channel_code'];
                    if (!empty($user['dsa_code'])) $params['DSACode'] = $user['dsa_code'];
                    if (!empty($user['sm_code'])) $params['SMCode'] = $user['sm_code'];
                    if (!empty($user['lg_code'])) $params['LGCode'] = $user['lg_code'];
                    if (!empty($user['lc_code'])) $params['LCCode'] = $user['lc_code'];
                    if (!empty($user['lc2_code'])) $params['LC2'] = $user['lc2_code'];
                    $query = http_build_query($params);
                    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . "/apply.html";
                    $app_link = $base_url . ($query ? (strpos($base_url, '?') === false ? '?' : '&') . $query : '');
                    ?>
                    <a href="<?php echo htmlspecialchars('apply.html' . ($query ? '?' . $query : '')); ?>" class="w-full bg-blue-600 text-white rounded-lg py-2 flex items-center justify-center font-medium hover:bg-blue-700 mb-2">
                        <i class="fas fa-link mr-2"></i> Generate Application Link
                    </a>
                    <a href="../leads/leads_updated.php" class="w-full bg-white border border-blue-300 rounded-lg py-2 flex items-center justify-center text-blue-600 font-medium hover:bg-blue-50 mb-2">
                        <i class="fas fa-search mr-2"></i> Track Customer Application
                    </a>
                    <div class="flex w-full gap-2">
                        
                        <a href="sms:?body=Apply%20for%20your%20card%20now%20at%20<?php echo urlencode($app_link); ?>" class="flex-1 bg-blue-500 text-white rounded-lg py-2 flex items-center justify-center font-medium hover:bg-blue-600">
                            <i class="fas fa-sms mr-2"></i> SMS
                        </a>
                        <a href="mailto:?subject=Apply%20for%20your%20card&body=Apply%20for%20your%20card%20now%20at%20<?php echo urlencode($app_link); ?>" class="flex-1 bg-gray-500 text-white rounded-lg py-2 flex items-center justify-center font-medium hover:bg-gray-600">
                            <i class="fas fa-envelope mr-2"></i> Email
                        </a>
                    </div>
                </div>
        </div>-->
            <!-- Key Performance Indicators -->
            <div class="mb-4 lg:mb-6">
                <h2 class="text-base font-semibold text-slate-900 mb-2 lg:text-lg lg:mb-4 lg:flex lg:items-center lg:gap-2">
                    <div class="hidden lg:flex w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg items-center justify-center">
                        <i class="fas fa-chart-line text-white text-sm"></i>
                    </div>
                    Key Performance Indicators
                </h2>
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    <a href="../leads/leads_updated.php" class="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-lg shadow-sm p-3 hover:border-blue-400 hover:shadow-md transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                <i class="fas fa-users text-white text-xs"></i>
                            </div>
                            <div class="text-right">
                                <div class="text-xl font-bold text-blue-700"><?php echo number_format($kpis['total_leads'] ?? 0); ?></div>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-xs font-semibold text-blue-800">Total Leads</h3>
                            <p class="text-xs text-blue-600">All applications</p>
                        </div>
                    </a>
                    
                    <a href="../leads/leads_updated.php?status=approved" class="group bg-gradient-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-200 rounded-lg shadow-sm p-3 hover:border-emerald-400 hover:shadow-md transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <div class="w-9 h-9 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                <i class="fas fa-check-circle text-white text-xs"></i>
                            </div>
                            <div class="text-right">
                                <div class="text-xl font-bold text-emerald-700"><?php echo number_format($kpis['approved'] ?? 0); ?></div>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-xs font-semibold text-emerald-800">Approved</h3>
                            <p class="text-xs text-emerald-600">Successfully processed</p>
                        </div>
                    </a>
                    
                    <a href="../leads/leads_updated.php?status=declined" class="group bg-gradient-to-br from-red-50 to-red-100 border-2 border-red-200 rounded-lg shadow-sm p-3 hover:border-red-400 hover:shadow-md transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <div class="w-9 h-9 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                <i class="fas fa-times-circle text-white text-xs"></i>
                            </div>
                            <div class="text-right">
                                <div class="text-xl font-bold text-red-700"><?php echo number_format($kpis['rejected'] ?? 0); ?></div>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-xs font-semibold text-red-800">Rejected</h3>
                            <p class="text-xs text-red-600">Applications declined</p>
                        </div>
                    </a>
                    
                    <a href="../leads/leads_updated.php?status=in_process" class="group bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-200 rounded-lg shadow-sm p-3 hover:border-amber-400 hover:shadow-md transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <div class="w-9 h-9 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                <i class="fas fa-spinner text-white text-xs"></i>
                            </div>
                            <div class="text-right">
                                <div class="text-xl font-bold text-amber-700"><?php echo number_format($kpis['work_in_progress'] ?? 0); ?></div>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-xs font-semibold text-amber-800">In Progress</h3>
                            <p class="text-xs text-amber-600">Under processing</p>
                        </div>
                    </a>
                </div>
            </div>

            <!-- Monthly Performance -->
            <div class="mb-8 lg:mb-6">
                <h2 class="text-base font-semibold text-slate-900 mb-2 lg:text-lg lg:mb-4 lg:flex lg:items-center lg:gap-2">
                    <div class="hidden lg:flex w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg items-center justify-center">
                        <i class="fas fa-calendar-check text-white text-sm"></i>
                    </div>
                    Monthly Performance
                </h2>
                <div class="grid grid-cols-2 lg:grid-cols-3 gap-3">
                    <?php $growth = $kpis['last_month'] > 0 ? (($kpis['this_month'] - $kpis['last_month']) / $kpis['last_month']) * 100 : 0; ?>
                    <div class="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-lg shadow-sm p-3 hover:border-blue-400 hover:shadow-md transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                <i class="fas fa-calendar-day text-white text-xs"></i>
                            </div>
                            <div class="text-right">
                                <div class="text-xl font-bold text-blue-700"><?php echo number_format($kpis['this_month'] ?? 0); ?></div>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-xs font-semibold text-blue-800">This Month</h3>
                            <p class="text-xs text-blue-600">Applications</p>
                        </div>
                    </div>
                    <div class="group bg-gradient-to-br from-slate-50 to-slate-100 border-2 border-slate-200 rounded-lg shadow-sm p-3 hover:border-slate-400 hover:shadow-md transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <div class="w-9 h-9 bg-gradient-to-br from-slate-500 to-slate-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                <i class="fas fa-history text-white text-xs"></i>
                            </div>
                            <div class="text-right">
                                <div class="text-xl font-bold text-slate-700"><?php echo number_format($kpis['last_month'] ?? 0); ?></div>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-xs font-semibold text-slate-800">Last Month</h3>
                            <p class="text-xs text-slate-600">Applications</p>
                        </div>
                    </div>
                    <div class="group bg-gradient-to-br from-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-50 to-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-100 border-2 border-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-200 rounded-lg shadow-sm p-3 hover:border-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-400 hover:shadow-md transition-all">
                        <div class="flex items-center justify-between mb-2">
                            <div class="w-9 h-9 bg-gradient-to-br from-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-500 to-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                <i class="fas fa-<?php echo $growth >= 0 ? 'trending-up' : 'trending-down'; ?> text-white text-xs"></i>
                            </div>
                            <div class="text-right">
                                <div class="text-xl font-bold text-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-700"><?php echo $growth >= 0 ? '+' : ''; ?><?php echo number_format($growth ?? 0, 1); ?>%</div>
                            </div>
                        </div>
                        <div>
                            <h3 class="text-xs font-semibold text-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-800">Growth</h3>
                            <p class="text-xs text-<?php echo $growth >= 0 ? 'emerald' : 'red'; ?>-600">vs Last Month</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Refer and Earn Section -->
            <?php
            // Get Refer and Earn stats
            $refer_earn_stats = [
                'team_size' => 0,
                'team_earnings' => 0,
                'pending_earnings' => 0,
                'partner_type' => $user['partner_type'] ?? null
            ];
            
            if (!empty($user['partner_type'])) {
                // Get team size
                $partner_type = $user['partner_type'];
                if ($partner_type === 'network_partner') {
                    // Count from referral_hierarchy and referral_users
                    try {
                        $team_size_query = "SELECT COUNT(DISTINCT referred_user_id) as total 
                                        FROM (
                                            SELECT referred_user_id FROM referral_hierarchy WHERE referrer_user_id = ?
                                            UNION
                                            SELECT referred_user_id FROM referral_users WHERE referrer_user_id = ?
                                        ) as combined";
                        $team_stmt = $conn->prepare($team_size_query);
                        if ($team_stmt) {
                            $team_stmt->bind_param("ii", $user['id'], $user['id']);
                            $team_stmt->execute();
                            $team_result = $team_stmt->get_result()->fetch_assoc();
                            $refer_earn_stats['team_size'] = $team_result['total'] ?? 0;
                            $team_stmt->close();
                        }
                    } catch (Exception $e) {
                        // Fallback to referral_users only
                        $team_size_query = "SELECT COUNT(DISTINCT referred_user_id) as total 
                                        FROM referral_users WHERE referrer_user_id = ?";
                        $team_stmt = $conn->prepare($team_size_query);
                        $team_stmt->bind_param("i", $user['id']);
                        $team_stmt->execute();
                        $team_result = $team_stmt->get_result()->fetch_assoc();
                        $refer_earn_stats['team_size'] = $team_result['total'] ?? 0;
                        $team_stmt->close();
                    }
                } else {
                    // Channel partner: only L1
                    $team_size_query = "SELECT COUNT(DISTINCT referred_user_id) as total 
                                    FROM referral_users WHERE referrer_user_id = ? AND level = 1";
                    $team_stmt = $conn->prepare($team_size_query);
                    $team_stmt->bind_param("i", $user['id']);
                    $team_stmt->execute();
                    $team_result = $team_stmt->get_result()->fetch_assoc();
                    $refer_earn_stats['team_size'] = $team_result['total'] ?? 0;
                    $team_stmt->close();
                }
                
                // Get earnings from payout_ledger (if table exists)
                try {
                    $earnings_query = "SELECT 
                        SUM(CASE WHEN status IN ('pending', 'processing') THEN amount ELSE 0 END) as pending,
                        SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) as paid
                        FROM payout_ledger WHERE user_id = ?";
                    $earnings_stmt = $conn->prepare($earnings_query);
                    if ($earnings_stmt) {
                        $earnings_stmt->bind_param("i", $user['id']);
                        $earnings_stmt->execute();
                        $earnings_result = $earnings_stmt->get_result()->fetch_assoc();
                        $refer_earn_stats['team_earnings'] = $earnings_result['paid'] ?? 0;
                        $refer_earn_stats['pending_earnings'] = $earnings_result['pending'] ?? 0;
                        $earnings_stmt->close();
                    }
                } catch (Exception $e) {
                    // Table might not exist yet
                }
            }
            ?>
            
            <div class="mb-8">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-xl font-semibold text-slate-900">Refer and Earn</h2>
                    <a href="refer_and_earn.php" class="text-blue-600 hover:text-blue-800 font-medium text-sm">
                        View Details <i class="fas fa-arrow-right ml-1"></i>
                    </a>
                </div>
                
                <?php if (empty($user['partner_type'])): ?>
                    <!-- Not Selected Yet -->
                    <div class="bg-gradient-to-r from-orange-50 to-purple-50 rounded-lg shadow-sm border-2 border-orange-200 p-6">
                        <div class="flex items-center justify-between">
                            <div class="flex-1">
                                <h3 class="text-lg font-semibold text-slate-900 mb-2">
                                    <i class="fas fa-gift text-orange-600 mr-2"></i>Start Earning with Your Team!
                                </h3>
                                <p class="text-sm text-slate-700 mb-4">
                                    Choose your partner program and start building your referral network. Earn from your team's success!
                                </p>
                                <a href="refer_and_earn.php" class="inline-flex items-center bg-gradient-to-r from-orange-600 to-purple-600 text-white px-6 py-3 rounded-lg hover:from-orange-700 hover:to-purple-700 font-medium transition-all shadow-lg">
                                    <i class="fas fa-rocket mr-2"></i>Get Started
                                </a>
                            </div>
                            <div class="hidden md:block ml-6">
                                <div class="w-24 h-24 bg-gradient-to-br from-orange-400 to-purple-400 rounded-full flex items-center justify-center">
                                    <i class="fas fa-users text-white text-4xl"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Stats Display -->
                    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
                        <a href="refer_and_earn.php?tab=team" class="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-lg shadow-sm p-3 hover:border-blue-400 hover:shadow-md transition-all" style="text-decoration:none;">
                            <div class="flex items-center justify-between mb-2">
                                <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                    <i class="fas fa-users text-white text-xs"></i>
                                </div>
                                <div class="text-right">
                                    <div class="text-xl font-bold text-blue-700"><?= $refer_earn_stats['team_size'] ?></div>
                                </div>
                            </div>
                            <div>
                                <h3 class="text-xs font-semibold text-blue-800">Team Size</h3>
                                <p class="text-xs text-blue-600">Members</p>
                            </div>
                        </a>
                        
                        <a href="refer_and_earn.php?tab=payouts&subsection=summary" class="group bg-gradient-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-200 rounded-lg shadow-sm p-3 hover:border-emerald-400 hover:shadow-md transition-all" style="text-decoration:none;">
                            <div class="flex items-center justify-between mb-2">
                                <div class="w-9 h-9 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                    <i class="fas fa-wallet text-white text-xs"></i>
                                </div>
                                <div class="text-right">
                                    <div class="text-xl font-bold text-emerald-700">₹<?= number_format($refer_earn_stats['team_earnings'] ?? 0, 0) ?></div>
                                </div>
                            </div>
                            <div>
                                <h3 class="text-xs font-semibold text-emerald-800">Team Earnings</h3>
                                <p class="text-xs text-emerald-600">Total Paid</p>
                            </div>
                        </a>
                        
                        <a href="refer_and_earn.php?tab=payouts&subsection=summary" class="group bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-200 rounded-lg shadow-sm p-3 hover:border-amber-400 hover:shadow-md transition-all" style="text-decoration:none;">
                            <div class="flex items-center justify-between mb-2">
                                <div class="w-9 h-9 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                    <i class="fas fa-hourglass-half text-white text-xs"></i>
                                </div>
                                <div class="text-right">
                                    <div class="text-xl font-bold text-amber-700">₹<?= number_format($refer_earn_stats['pending_earnings'] ?? 0, 0) ?></div>
                                </div>
                            </div>
                            <div>
                                <h3 class="text-xs font-semibold text-amber-800">Pending</h3>
                                <p class="text-xs text-amber-600">Awaiting</p>
                            </div>
                        </a>
                        
                        <a href="refer_and_earn.php?tab=leads" class="group bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-200 rounded-lg shadow-sm p-3 hover:border-purple-400 hover:shadow-md transition-all" style="text-decoration:none;">
                            <div class="flex items-center justify-between mb-2">
                                <div class="w-9 h-9 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                                    <i class="fas fa-tag text-white text-xs"></i>
                                </div>
                                <div class="text-right">
                                    <div class="text-lg font-bold text-purple-700">
                                        <?= ucfirst(str_replace('_', ' ', $refer_earn_stats['partner_type'])) ?>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <h3 class="text-xs font-semibold text-purple-800">Program</h3>
                                <p class="text-xs text-purple-600">Active</p>
                            </div>
                        </a>
                    </div>
                    
                    <!-- Quick Actions -->
                    <div class="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg shadow-sm border p-4">
                        <div class="flex flex-wrap items-center justify-between gap-4">
                            <div class="flex-1 min-w-[200px]">
                                <h4 class="font-semibold text-slate-900 mb-1">Manage Your Team</h4>
                                <p class="text-sm text-slate-600">View team members, leads, and earnings</p>
                            </div>
                            <div class="flex gap-2">
                                <a href="refer_and_earn.php?tab=team" class="px-4 py-2 bg-white border border-blue-300 text-blue-700 rounded-lg hover:bg-blue-50 font-medium text-sm">
                                    <i class="fas fa-users mr-2"></i>My Team
                                </a>
                                <a href="refer_and_earn.php?tab=leads" class="px-4 py-2 bg-white border border-green-300 text-green-700 rounded-lg hover:bg-green-50 font-medium text-sm">
                                    <i class="fas fa-briefcase mr-2"></i>Team Leads
                                </a>
                                <a href="refer_and_earn.php?tab=payouts" class="px-4 py-2 bg-white border border-purple-300 text-purple-700 rounded-lg hover:bg-purple-50 font-medium text-sm">
                                    <i class="fas fa-money-bill-wave mr-2"></i>Payouts
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Product Copy and Link Generation Section -->
            <div class="mb-8">
                <h2 class="text-xl font-semibold text-slate-900 mb-4">Product Links</h2>
                
                <!-- Copy Product Form -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-6 border border-gray-200">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Create Product Link</h3>
                    <form class="space-y-4" id="productLinkForm">
                        <input type="hidden" name="product_id" id="form_product_id" value="">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <!-- 1. Select Product Type (Category) -->
                            <div>
                                <label for="product_category" class="block text-sm font-medium text-gray-700 mb-1">Select Product Type</label>
                                <select id="product_category" class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                    <option value="">-- Select Type --</option>
                                    <?php 
                                    // Fetch unique categories
                                    $cat_query = "SELECT DISTINCT category FROM products WHERE status = 'active' ORDER BY category";
                                    $cat_result = $conn->query($cat_query);
                                    while ($cat = $cat_result->fetch_assoc()): 
                                    ?>
                                        <option value="<?= htmlspecialchars($cat['category']) ?>">
                                            <?= htmlspecialchars($cat['category']) ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>


                            <!-- 2. Select Bank -->
                            <div>
                                <label for="product_variant_select" class="block text-sm font-medium text-gray-700 mb-1">Select Bank</label>
                                <select id="product_variant_select" disabled class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-gray-50">
                                    <option value="">-- Select Bank --</option>
                                </select>
                            </div>

                            <!-- 3. Select Product -->
                            <div>
                                <label for="product_name_select" class="block text-sm font-medium text-gray-700 mb-1">Select Product</label>
                                <select id="product_name_select" name="product_id" required disabled class="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-gray-50">
                                    <option value="">-- Select Product --</option>
                                </select>
                                <input type="hidden" id="product_id" name="product_id" value="">
                            </div>

          
                            <div class="flex items-end">
                                <button type="button" id="generateLinkBtn" 
                                    class="w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    <i class="fas fa-copy mr-2"></i> Generate Link
                                </button>
                            </div>
                        </div>
                    </form>
                    
                    <!-- Success/Error Messages -->
                    <div id="productLinkMessage" class="hidden mt-4 p-3 rounded-md"></div>
                    
                    <script>
                    // Initialize Tom Select
                    var categorySelect, nameSelect, variantSelect;
                    
                    document.addEventListener('DOMContentLoaded', function() {
                        categorySelect = new TomSelect('#product_category', {
                            create: false,
                            sortField: { field: 'text', direction: 'asc' },
                            placeholder: 'Select Product Type...'
                        });

                        variantSelect = new TomSelect('#product_variant_select', {
                            create: false,
                            sortField: { field: 'text', direction: 'asc' },
                            placeholder: 'Select Bank...',
                            valueField: 'variant',
                            labelField: 'display',
                            searchField: 'display',
                            options: []
                        });
                        variantSelect.disable();

                        nameSelect = new TomSelect('#product_name_select', {
                            create: false,
                            sortField: { field: 'text', direction: 'asc' },
                            placeholder: 'Select Product...',
                            valueField: 'id',
                            labelField: 'display',
                            searchField: 'display',
                            options: [],
                            onChange: function(value) {
                                // Update the hidden product_id field when a product is selected
                                if (value) {
                                    document.getElementById('product_id').value = value;
                                    document.getElementById('form_product_id').value = value;
                                } else {
                                    document.getElementById('product_id').value = '';
                                    document.getElementById('form_product_id').value = '';
                                }
                            }
                        });
                        nameSelect.disable();

                        // 1. Category Change -> Fetch Variants (Banks)
                        categorySelect.on('change', function(category) {
                            // Reset Variant and Product
                            variantSelect.clear();
                            variantSelect.clearOptions();
                            variantSelect.disable();
                            
                            nameSelect.clear();
                            nameSelect.clearOptions();
                            nameSelect.disable();
                            
                            if (category) {
                                // Fetch variants (banks) for selected category
                                fetch(`get_variants_by_category.php?category=${encodeURIComponent(category)}`)
                                    .then(response => response.json())
                                    .then(data => {
                                        console.log('Variants received:', data);
                                        
                                        if (data.length === 0) {
                                            console.warn('No variants found for category:', category);
                                            return;
                                        }
                                        
                                        // Add variants to TomSelect
                                        data.forEach(item => {
                                            variantSelect.addOption({
                                                variant: item.variant,
                                                display: item.display
                                            });
                                        });
                                        
                                        variantSelect.enable();
                                    })
                                    .catch(error => {
                                        console.error('Error fetching variants:', error);
                                    });
                            }
                        });

                        // 2. Variant Change -> Fetch Products
                        variantSelect.on('change', function(variant) {
                            const category = categorySelect.getValue();
                            
                            // Reset product select
                            nameSelect.clear();
                            nameSelect.clearOptions();
                            nameSelect.disable();
                            
                            if (variant && category) {
                                // Fetch products for selected category and variant
                                fetch(`get_products_by_variant.php?category=${encodeURIComponent(category)}&variant=${encodeURIComponent(variant)}`)
                                    .then(response => response.json())
                                    .then(data => {
                                        console.log('Products received:', data);
                                        
                                        if (data.length === 0) {
                                            console.warn('No products found for:', category, variant);
                                            return;
                                        }
                                        
                                        // Add products to TomSelect
                                        data.forEach(item => {
                                            nameSelect.addOption({
                                                id: item.id,
                                                display: item.display
                                            });
                                        });
                                        
                                        nameSelect.enable();
                                        
                                        // If only one product, auto-select
                                        if (data.length === 1) {
                                            nameSelect.setValue(data[0].id);
                                        }
                                    })
                                    .catch(error => {
                                        console.error('Error fetching products:', error);
                                    });
                            }
                        });

                        // Handle form submission via AJAX
                        document.getElementById('generateLinkBtn').addEventListener('click', function() {
                            const productId = document.getElementById('form_product_id').value;
                            const messageDiv = document.getElementById('productLinkMessage');
                            
                            if (!productId) {
                                showMessage('Please select a product variant first.', 'error');
                                return;
                            }
                            
                            // Disable button and show loading
                            const originalText = this.innerHTML;
                            this.disabled = true;
                            this.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Generating...';
                            
                            // Send AJAX request
                            fetch('/adviser/create_product_link.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded',
                                },
                                body: 'product_id=' + productId
                            })
                            .then(response => {
                                console.log('Response status:', response.status);
                                console.log('Response headers:', response.headers);
                                return response.text().then(text => {
                                    console.log('Raw response:', text);
                                    try {
                                        return JSON.parse(text);
                                    } catch (e) {
                                        console.error('JSON parse error:', e);
                                        throw new Error('Invalid JSON response: ' + text.substring(0, 200));
                                    }
                                });
                            })
                            .then(data => {
                                console.log('Parsed data:', data);
                                if (data.success) {
                                    // Auto-copy the link to clipboard
                                    navigator.clipboard.writeText(data.product_link.share_link).then(function() {
                                        showMessage('Product link created and copied to clipboard!', 'success');
                                    }).catch(function(err) {
                                        showMessage('Product link created successfully! Link: ' + data.product_link.share_link, 'success');
                                    });
                                    
                                    // Reset form
                                    categorySelect.clear();
                                    nameSelect.clear();
                                    nameSelect.clearOptions();
                                    nameSelect.disable();
                                    variantSelect.clear();
                                    variantSelect.clearOptions();
                                    variantSelect.disable();
                                    document.getElementById('form_product_id').value = '';
                                    
                                } else {
                                    console.error('Server returned error:', data.message);
                                    showMessage(data.message || 'Failed to create product link.', 'error');
                                }
                            })
                            .catch(error => {
                                console.error('Error creating product link:', error);
                                showMessage('Error: ' + error.message, 'error');
                            })
                            .finally(() => {
                                // Re-enable button
                                this.disabled = false;
                                this.innerHTML = originalText;
                            });
                        });
                        
                        function showMessage(message, type) {
                            const messageDiv = document.getElementById('productLinkMessage');
                            messageDiv.textContent = message;
                            messageDiv.className = 'mt-4 p-3 rounded-md';
                            
                            if (type === 'success') {
                                messageDiv.classList.add('bg-green-50', 'border', 'border-green-200', 'text-green-700');
                            } else {
                                messageDiv.classList.add('bg-red-50', 'border', 'border-red-200', 'text-red-700');
                            }
                            
                            messageDiv.classList.remove('hidden');
                            
                            // Hide message after 5 seconds
                            setTimeout(() => {
                                messageDiv.classList.add('hidden');
                            }, 5000);
                        }
                        
                        function addProductLinkToList(productLink) {
                            let container = document.getElementById('product-links-container');
                            
                            // If container doesn't exist, we're in the empty state - need to create the structure
                            if (!container) {
                                // Find the parent section (the yellow info box or the product links section)
                                const parentSection = document.querySelector('.mb-8 h2.text-xl.font-semibold.text-slate-900').parentElement;
                                
                                // Find the empty state message and replace it
                                const emptyState = parentSection.querySelector('.bg-yellow-50');
                                if (emptyState) {
                                    emptyState.remove();
                                }
                                
                                // Create the new product links section
                                const newSection = document.createElement('div');
                                newSection.className = 'bg-white rounded-lg shadow-sm border border-gray-200 p-4';
                                newSection.innerHTML = `
                                    <div class="flex justify-between items-center mb-3">
                                        <h3 class="text-sm font-medium text-gray-900">Your Product Links</h3>
                                        <span class="text-xs text-gray-500">1 links</span>
                                    </div>
                                    <div class="space-y-2" id="product-links-container"></div>
                                `;
                                parentSection.appendChild(newSection);
                                
                                // Get the newly created container
                                container = document.getElementById('product-links-container');
                            }
                            
                            // Create new product link element
                            const linkElement = document.createElement('div');
                            linkElement.className = 'flex items-center justify-between p-2 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors';
                            linkElement.id = 'product-' + productLink.id;
                            linkElement.innerHTML = `
                                <div class="flex-1 min-w-0 mr-2">
                                    <div class="text-xs font-medium text-gray-900 truncate">
                                        ${productLink.product_name}
                                        ${productLink.product_variant ? ' - ' + productLink.product_variant : ''}
                                    </div>
                                    <div class="text-xs text-gray-500">
                                        ${productLink.category} • ${productLink.created_date}
                                    </div>
                                </div>
                                <div class="flex items-center space-x-1">
                                    <button onclick="copyToClipboard('link-${productLink.id}', this)" 
                                        class="inline-flex items-center px-2 py-1 text-xs border border-gray-300 rounded text-gray-700 bg-white hover:bg-gray-50">
                                        <i class="far fa-copy"></i>
                                    </button>
                                    <a href="${productLink.share_link}" target="_blank" 
                                        class="inline-flex items-center px-2 py-1 text-xs border border-transparent rounded text-white bg-blue-600 hover:bg-blue-700">
                                        <i class="fas fa-external-link-alt"></i>
                                    </a>
                                    <button onclick="deleteProductLink(${productLink.id})" 
                                        class="inline-flex items-center px-2 py-1 text-xs border border-transparent rounded text-white bg-red-600 hover:bg-red-700">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </div>
                                <input type="hidden" id="link-${productLink.id}" value="${productLink.share_link}">
                            `;
                            
                            // Add to container
                            container.appendChild(linkElement);
                            
                            // Auto-remove after 1 minute
                            setTimeout(function() {
                                if (document.getElementById('product-' + productLink.id)) {
                                    deleteProductLinkFromUI(productLink.id);
                                }
                            }, 60000); // 60 seconds
                            
                            // Update count
                            const countElement = container.parentElement.querySelector('.text-xs.text-gray-500');
                            if (countElement) {
                                const currentCount = container.children.length;
                                countElement.textContent = currentCount + ' link' + (currentCount !== 1 ? 's' : '');
                            }
                        }
                    });
                    </script>
                </div>
            </div>

            <!-- Referral Link Section - For Sharing -->
            <div class="mb-8">
                <h2 class="text-xl font-semibold text-slate-900 mb-4">Your Referral Link</h2>
                <div class="bg-white rounded-lg shadow-sm border p-6">
                    <?php if (!$referral_link_data): ?>
                        <div class="text-center">
                            <i class="fas fa-link text-4xl text-blue-600 mb-3"></i>
                            <h3 class="font-semibold text-slate-900 mb-2">Create Your Referral Link</h3>
                            <p class="text-sm text-slate-600 mb-4">Generate a unique link to share with others and start building your team</p>
                            <button onclick="createReferralLink()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-medium">
                                <i class="fas fa-link mr-2"></i>Create Referral Link
                            </button>
                        </div>
                    <?php else: ?>
                        <div class="flex items-center justify-between mb-4">
                            <div>
                                <h3 class="font-semibold text-slate-900">Share This Link to Refer Others</h3>
                                <p class="text-sm text-slate-600">Copy and share this link with friends to build your team</p>
                            </div>
                            <i class="fas fa-check-circle text-2xl text-green-600"></i>
                        </div>
                        <div class="space-y-3">
                            <div class="flex gap-2">
                                <input type="text" id="referralLink" value="<?= htmlspecialchars($referral_link_data['referral_url']) ?>" class="flex-1 px-3 py-2 border rounded-lg bg-gray-50 text-sm" readonly>
                                <button onclick="copyReferralLink(this)" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm font-medium">
                                    <i class="fas fa-copy mr-1"></i>Copy
                                </button>
                            
                            </div>
                            <div class="flex justify-between text-xs text-slate-600 bg-slate-50 p-2 rounded">
                                <span><i class="fas fa-mouse-pointer mr-1"></i>Clicks: <strong><?= $referral_link_data['clicks'] ?? 0 ?></strong></span>
                                <span><i class="fas fa-user-plus mr-1"></i>Signups: <strong><?= $referral_link_data['signups'] ?? 0 ?></strong></span>
                            </div>
                            <div class="bg-blue-50 border-l-4 border-blue-400 p-3 rounded">
                                <p class="text-sm text-blue-800">
                                    <i class="fas fa-info-circle mr-2"></i>
                                    <strong>Tip:</strong> Share this link via WhatsApp, SMS, or email. When someone signs up using your link, they'll join your team!
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Payout Summary in one row -->
    <div class="mb-8">
        <h2 class="text-xl font-semibold text-slate-900 mb-4">Payout Summary</h2>
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-2">
            <!-- Total Earned (clickable) -->
            <a href="payouts.php" class="group bg-gradient-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-200 rounded-lg shadow-sm p-2 hover:border-emerald-400 hover:shadow-md transition-all" style="text-decoration:none;">
                <div class="flex items-center justify-between mb-1">
                    <div class="w-7 h-7 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <i class="fas fa-piggy-bank text-white text-xs"></i>
                    </div>
                    <div class="text-right">
                        <div class="text-lg font-bold text-emerald-700">₹<?php echo number_format($kpis['total_paid'] ?? 0); ?></div>
                    </div>
                </div>
                <div>
                    <h3 class="text-xs font-semibold text-emerald-800">Total Earned</h3>
                    <p class="text-xs text-emerald-600">Lifetime commission</p>
                </div>
            </a>
            
            <!-- This Month (clickable) -->
            <a href="payouts.php?month=this" class="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-lg shadow-sm p-2 hover:border-blue-400 hover:shadow-md transition-all" style="text-decoration:none;">
                <div class="flex items-center justify-between mb-1">
                    <div class="w-7 h-7 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <i class="fas fa-calendar-week text-white text-xs"></i>
                    </div>
                    <div class="text-right">
                        <div class="text-lg font-bold text-blue-700">₹<?php echo number_format($kpis['paid_this_month'] ?? 0); ?></div>
                    </div>
                </div>
                <div>
                    <h3 class="text-xs font-semibold text-blue-800">This Month</h3>
                    <p class="text-xs text-blue-600">Current earnings</p>
                </div>
            </a>
            
            <!-- Margin Earnings (if exists) -->
            <?php 
            $margin_earnings = 0;
            $pending_margin = 0;
            $total_margin = 0;
            try {
                $margin_earnings = getTotalMarginEarnings($conn, $user['id'], 'paid');
                $pending_margin = getTotalMarginEarnings($conn, $user['id'], 'pending');
                $total_margin = getTotalMarginEarnings($conn, $user['id']);
            } catch (Exception $e) {
                // Tables might not exist yet
            }
            if ($total_margin > 0):
            ?>
            <a href="payouts.php?type=margin" class="group bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-200 rounded-lg shadow-sm p-2 hover:border-purple-400 hover:shadow-md transition-all" style="text-decoration:none;">
                <div class="flex items-center justify-between mb-1">
                    <div class="w-7 h-7 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <i class="fas fa-percentage text-white text-xs"></i>
                    </div>
                    <div class="text-right">
                        <div class="text-lg font-bold text-purple-700">₹<?php echo number_format($total_margin ?? 0); ?></div>
                    </div>
                </div>
                <div>
                    <h3 class="text-xs font-semibold text-purple-800">Margin Earned</h3>
                    <p class="text-xs text-purple-600">Additional income</p>
                </div>
            </a>
            <?php else: ?>
            <div class="group bg-gradient-to-br from-slate-50 to-slate-100 border-2 border-slate-200 rounded-lg shadow-sm p-2 opacity-50">
                <div class="flex items-center justify-between mb-1">
                    <div class="w-7 h-7 bg-gradient-to-br from-slate-400 to-slate-500 rounded-full flex items-center justify-center">
                        <i class="fas fa-percentage text-white text-xs"></i>
                    </div>
                    <div class="text-right">
                        <div class="text-lg font-bold text-slate-700">₹0</div>
                    </div>
                </div>
                <div>
                    <h3 class="text-xs font-semibold text-slate-800">Margin Earned</h3>
                    <p class="text-xs text-slate-600">Additional income</p>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Pending (clickable) -->
            <a href="payouts.php?status=pending" class="group bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-200 rounded-lg shadow-sm p-2 hover:border-amber-400 hover:shadow-md transition-all" style="text-decoration: none;">
                <div class="flex items-center justify-between mb-1">
                    <div class="w-7 h-7 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <i class="fas fa-clock text-white text-xs"></i>
                    </div>
                    <div class="text-right">
                        <div class="text-lg font-bold text-amber-700">₹<?php echo number_format(($kpis['pending_bonus'] ?? 0) + ($pending_margin ?? 0)); ?></div>
                    </div>
                </div>
                <div>
                    <h3 class="text-xs font-semibold text-amber-800">Pending</h3>
                    <p class="text-xs text-amber-600">Awaiting approval</p>
                </div>
            </a>
        </div>
    </div>



            <!-- Quick Actions 
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <a href="../forms/apply.html" class="bg-white rounded-lg shadow-sm border p-6 hover:shadow-md transition-shadow">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-plus text-blue-600"></i>
                        </div>
                        <div>
                            <h3 class="font-semibold text-slate-900">New Application</h3>
                            <p class="text-sm text-slate-600">Create new lead</p>
                        </div>
                    </div>
                </a>
                    <a href="payouts.php" class="bg-white rounded-lg shadow-sm border p-6 hover:shadow-md transition-shadow">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-money-bill-wave text-purple-600"></i>
                        </div>
                        <div>
                            <h3 class="font-semibold text-slate-900">View Payouts</h3>
                            <p class="text-sm text-slate-600">Track earnings</p>
                        </div>
                    </div>
                </a>
                    <a href="../leads/leads_updated.php" class="bg-white rounded-lg shadow-sm border p-6 hover:shadow-md transition-shadow">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-list text-green-600"></i>
                        </div>
                        <div>
                            <h3 class="font-semibold text-slate-900">Manage Leads</h3>
                            <p class="text-sm text-slate-600">View all leads</p>
                        </div>
                    </div>
                </a>
            </div> -->
            </div>
        </div>
    </div>

    <!-- Bottom Navigation Bar for Mobile -->
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    
    <script>
        function deleteProductLinkFromUI(productId) {
            const productElement = document.getElementById('product-' + productId);
            if (productElement) {
                productElement.style.transition = 'opacity 0.3s, transform 0.3s';
                productElement.style.opacity = '0';
                productElement.style.transform = 'translateX(-20px)';
                
                setTimeout(function() {
                    productElement.remove();
                    
                    // Update the links count
                    const container = document.getElementById('product-links-container');
                    if (container) {
                        const linksCount = container.children.length;
                        const countElement = container.parentElement.querySelector('.text-xs.text-gray-500');
                        if (countElement) {
                            countElement.textContent = linksCount + ' link' + (linksCount !== 1 ? 's' : '');
                        }
                        
                        // If no links left, show empty state
                        if (linksCount === 0) {
                            const section = container.parentElement.parentElement;
                            section.innerHTML = `
                                <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                                    <div class="flex">
                                        <div class="flex-shrink-0">
                                            <i class="fas fa-info-circle text-yellow-400 mt-1"></i>
                                        </div>
                                        <div class="ml-3">
                                            <p class="text-sm text-yellow-700">
                                                You haven't created any product links yet. Use the form above to create your first product link.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            `;
                        }
                    }
                }, 300);
            }
        }
        
        function deleteProductLink(productId) {
            if (confirm('Are you sure you want to delete this product link? This action cannot be undone.')) {
                // Create a form to submit the delete request
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'delete_product_link.php';
                
                // Add CSRF token if available
                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
                if (csrfToken) {
                    const csrfInput = document.createElement('input');
                    csrfInput.type = 'hidden';
                    csrfInput.name = 'csrf_token';
                    csrfInput.value = csrfToken;
                    form.appendChild(csrfInput);
                }
                
                // Add product ID to delete
                const productInput = document.createElement('input');
                productInput.type = 'hidden';
                productInput.name = 'product_id';
                productInput.value = productId;
                form.appendChild(productInput);
                
                // Submit the form
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function createReferralLink() {
            window.location.href = '?create_referral=1';
        }

        // Toggle product links visibility
        document.addEventListener('DOMContentLoaded', function() {
            const toggleButton = document.getElementById('toggle-links');
            if (toggleButton) {
                let isExpanded = false;
                const hiddenLinks = document.querySelectorAll('.product-link');
                
                toggleButton.addEventListener('click', function() {
                    isExpanded = !isExpanded;
                    
                    hiddenLinks.forEach(link => {
                        link.classList.toggle('hidden');
                    });
                    
                    if (isExpanded) {
                        toggleButton.innerHTML = `
                            <span class="flex items-center justify-center">
                                <span>Show less</span>
                                <svg class="ml-1 w-4 h-4 transform rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                </svg>
                            </span>
                        `;
                    } else {
                        toggleButton.innerHTML = `
                            <span class="flex items-center justify-center">
                                <span>Show all links (${hiddenLinks.length})</span>
                                <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                </svg>
                            </span>
                        `;
                    }
                });
                
                // Initialize button text with correct count
                toggleButton.innerHTML = `
                    <span class="flex items-center justify-center">
                        <span>Show all links (${hiddenLinks.length})</span>
                        <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </span>
                `;
            }
        });

        function copyToClipboard(elementId, button) {
            // Get the hidden input field
            var copyText = document.getElementById(elementId);
            if (!copyText) {
                console.error('Element not found:', elementId);
                alert('Could not find link to copy');
                return;
            }
            
            // Get the value from the hidden input
            const textToCopy = copyText.value;
            
            // Use modern clipboard API
            navigator.clipboard.writeText(textToCopy).then(function() {
                // Show success message on the button
                const originalHTML = button.innerHTML;
                const originalClasses = button.className;
                
                button.innerHTML = '<i class="fas fa-check"></i>';
                button.className = 'inline-flex items-center px-2 py-1 text-xs border border-transparent rounded text-white bg-green-600 hover:bg-green-700';
                
                // Revert back after 2 seconds
                setTimeout(function() {
                    button.innerHTML = originalHTML;
                    button.className = originalClasses;
                }, 2000);
            }).catch(function(err) {
                console.error('Could not copy text: ', err);
                
                // Fallback for older browsers
                try {
                    // Create a temporary textarea to copy from
                    const tempTextarea = document.createElement('textarea');
                    tempTextarea.value = textToCopy;
                    tempTextarea.style.position = 'fixed';
                    tempTextarea.style.opacity = '0';
                    document.body.appendChild(tempTextarea);
                    tempTextarea.select();
                    document.execCommand('copy');
                    document.body.removeChild(tempTextarea);
                    
                    // Show success
                    const originalHTML = button.innerHTML;
                    button.innerHTML = '<i class="fas fa-check"></i>';
                    setTimeout(function() {
                        button.innerHTML = originalHTML;
                    }, 2000);
                } catch (e) {
                    console.error('Fallback copy failed:', e);
                    alert('Failed to copy link. Please copy manually: ' + textToCopy);
                }
            });
        }

        function deleteProductLink(productId) {
            if (!confirm('Are you sure you want to delete this product link?')) {
                return;
            }

            // Send AJAX request to delete the product link
            fetch('delete_product_link.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'product_id=' + productId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove the product link from the DOM with animation
                    const productElement = document.getElementById('product-' + productId);
                    if (productElement) {
                        productElement.style.transition = 'opacity 0.3s, transform 0.3s';
                        productElement.style.opacity = '0';
                        productElement.style.transform = 'translateX(-20px)';
                        
                        setTimeout(function() {
                            productElement.remove();
                            
                            // Update the links count
                            const container = document.getElementById('product-links-container');
                            const linksCount = container.children.length;
                            const countElement = document.querySelector('.text-xs.text-gray-500');
                            if (countElement) {
                                countElement.textContent = linksCount + ' links';
                            }
                            
                            // If no links left, show the empty state message
                            if (linksCount === 0) {
                                const section = document.querySelector('.bg-white.rounded-lg.shadow-sm.border');
                                section.innerHTML = `
                                    <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                                        <div class="flex">
                                            <div class="flex-shrink-0">
                                                <i class="fas fa-info-circle text-yellow-400 mt-1"></i>
                                            </div>
                                            <div class="ml-3">
                                                <p class="text-sm text-yellow-700">
                                                    You haven't created any product links yet. Use the form above to create your first product link.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                `;
                            }
                        }, 300);
                    }
                } else {
                    alert('Failed to delete product link: ' + (data.message || 'Unknown error'));
                }
            })
            .catch(error => {
                console.error('Error deleting product link:', error);
                alert('Failed to delete product link. Please try again.');
            });
        }

        function copyReferralLink(button) {
            var copyText = document.getElementById('referralLink');
            if (!copyText) return;
            
            copyText.select();
            copyText.setSelectionRange(0, 99999);

            navigator.clipboard.writeText(copyText.value).then(function() {
                const originalText = button.innerHTML;
                button.innerHTML = '<i class="fas fa-check mr-1"></i>Copied!';
                button.classList.add('bg-green-600', 'hover:bg-green-700');
                button.classList.remove('bg-blue-600', 'hover:bg-blue-700');
                
                setTimeout(function() {
                    button.innerHTML = originalText;
                    button.classList.remove('bg-green-600', 'hover:bg-green-700');
                    button.classList.add('bg-blue-600', 'hover:bg-blue-700');
                }, 2000);
            }).catch(function(err) {
                console.error('Could not copy text: ', err);
                try {
                    document.execCommand('copy');
                    button.innerHTML = '<i class="fas fa-check mr-1"></i>Copied!';
                    setTimeout(function() {
                        button.innerHTML = '<i class="fas fa-copy mr-1"></i>Copy';
                    }, 2000);
                } catch (e) {
                    alert('Failed to copy link. Please copy manually.');
                }
            });
        }

        function shareWhatsApp(link) {
            const encodedLink = encodeURIComponent(link);
            const text = encodeURIComponent('Hi! I\'m inviting you to check out this financial product: ');
            window.open(`https://wa.me/?text=${text}${encodedLink}`, '_blank');
        }
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
