<?php
// Start output buffering to prevent any stray output
ob_start();

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

requireLogin();

// Clean the buffer before sending JSON
ob_end_clean();

header('Content-Type: application/json');

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get product ID from POST data
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;

if ($product_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
    exit;
}

try {
    // Get current user
    $user = getCurrentUser();
    
    // Database connection
    $database = new Database();
    $conn = $database->getConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    // Delete the advisor product (ensure it belongs to the current user)
    $stmt = $conn->prepare("DELETE FROM advisor_products WHERE id = ? AND advisor_id = ?");
    $stmt->bind_param("ii", $product_id, $user['id']);
    
    if (!$stmt->execute()) {
        throw new Exception('Failed to delete product link');
    }
    
    // Check if a row was actually deleted
    if ($stmt->affected_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Product link not found or you do not have permission to delete it']);
        exit;
    }
    
    $stmt->close();
    $conn->close();
    
    echo json_encode(['success' => true, 'message' => 'Product link deleted successfully']);
    
} catch (Exception $e) {
    error_log("Delete product link error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred while deleting the product link']);
}
?>
