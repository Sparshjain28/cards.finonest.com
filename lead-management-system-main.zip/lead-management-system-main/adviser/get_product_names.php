<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

if (!isLoggedIn()) {
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

if (!isset($_GET['category'])) {
    echo json_encode([]);
    exit;
}

$category = $_GET['category'];
$database = new Database();
$conn = $database->getConnection();

$stmt = $conn->prepare("SELECT DISTINCT name FROM products WHERE category = ? AND status = 'active' ORDER BY name");
$stmt->bind_param("s", $category);
$stmt->execute();
$result = $stmt->get_result();

$names = [];
while ($row = $result->fetch_assoc()) {
    $names[] = $row;
}

echo json_encode($names);
$stmt->close();
?>
