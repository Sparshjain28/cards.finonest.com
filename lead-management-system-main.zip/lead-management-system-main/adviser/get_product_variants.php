<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

if (!isLoggedIn()) {
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

if (!isset($_GET['name'])) {
    echo json_encode([]);
    exit;
}

$name = $_GET['name'];
$database = new Database();
$conn = $database->getConnection();

$stmt = $conn->prepare("SELECT id, variant, category, commission_rate FROM products WHERE name = ? AND status = 'active' ORDER BY variant");
$stmt->bind_param("s", $name);
$stmt->execute();
$result = $stmt->get_result();

$variants = [];
while ($row = $result->fetch_assoc()) {
    $variants[] = [
        'id' => $row['id'],
        'variant' => $row['variant'] ? $row['variant'] : 'Standard', // Fallback if variant is empty
        'category' => $row['category'],
        'commission' => $row['commission_rate'] // Changed from commission_rate to commission to match JS
    ];
}

echo json_encode($variants);
$stmt->close();
?>
