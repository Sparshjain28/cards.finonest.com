<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

if (!isLoggedIn()) {
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

if (!isset($_GET['category']) || !isset($_GET['variant'])) {
    echo json_encode([]);
    exit;
}

$category = $_GET['category'];
$variant = $_GET['variant'];
$database = new Database();
$conn = $database->getConnection();

$stmt = $conn->prepare("SELECT id, name FROM products WHERE category = ? AND variant = ? AND status = 'active' ORDER BY name");
$stmt->bind_param("ss", $category, $variant);
$stmt->execute();
$result = $stmt->get_result();

$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = [
        'id' => $row['id'],
        'name' => $row['name'],
        'display' => $row['name']
    ];
}

echo json_encode($products);
$stmt->close();
?>