<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../includes/filter_helper.php';
require_once __DIR__ . '/../includes/commission_helper.php';
require_once __DIR__ . '/../includes/margin_helper.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Style\Fill;

requireLogin();

$database = new Database();
$conn = $database->getConnection();

// Get user first
$user = getCurrentUser();

// Export function for advisor
function exportPayoutReport($conn, $channel_code, $filter = 'all') {
    $whereClause = "WHERE l.channel_code = ? AND l.status IN ('activated','disbursed')";
    $params = [$channel_code];
    
    if ($filter === 'pending') {
        $whereClause .= " AND p.status = 'pending'";
    } elseif ($filter === 'paid') {
        $whereClause .= " AND p.status = 'paid'";
    }
    
    $query = "SELECT 
        u.name as advisor_name,
        u.account_number,
        u.bank_name,
        u.ifsc_code,
        u.pan_number,
        p.status as payment_status,
        (p.commission_amount + p.bonus_amount - COALESCE(p.deduction_amount, 0)) as lead_amount,
        l.lead_id,
        l.customer_name,
        pr.name as product_name
    FROM payouts p
    JOIN leads l ON p.lead_id = l.id
    JOIN products pr ON l.product_id = pr.id
    JOIN users u ON l.channel_code = u.channel_code
    $whereClause
    ORDER BY p.created_at DESC";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', ...$params);
    $stmt->execute();
    $results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    // Create Excel file
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    
    // Set headers
    $headers = ['Advisor Name', 'Account Number', 'Bank Name', 'IFSC Code', 'PAN Number', 'Payment Status', 'Lead Amount', 'Lead ID', 'Customer Name', 'Product Name'];
    $sheet->fromArray($headers, null, 'A1');
    
    // Style headers
    $headerStyle = [
        'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
        'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '4F46E5']]
    ];
    $sheet->getStyle('A1:J1')->applyFromArray($headerStyle);
    
    // Add data
    $row = 2;
    foreach ($results as $data) {
        $sheet->fromArray(array_values($data), null, 'A' . $row);
        $row++;
    }
    
    // Auto-size columns
    foreach (range('A', 'J') as $col) {
        $sheet->getColumnDimension($col)->setAutoSize(true);
    }
    
    // Output file
    $filename = 'my_payout_report_' . $filter . '_' . date('Y-m-d') . '.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');
    
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
}

// Handle CSV/Excel export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $filter = $_GET['filter'] ?? 'all';
    exportPayoutReport($conn, $user['channel_code'], $filter);
    exit;
}
$filter = $_GET['filter'] ?? 'all';
$active_tab = $_GET['tab'] ?? 'payouts';
$user_id = $user['id'];
$partner_type = $user['partner_type'];

// Check if user is referred
$is_referred = false;
if (isset($user['id'])) {
    $referral_check = $conn->prepare("SELECT COUNT(*) FROM referral_users WHERE referred_user_id = ?");
    $referral_check->bind_param("i", $user['id']);
    $referral_check->execute();
    $referral_check->bind_result($referral_count);
    $referral_check->fetch();
    $is_referred = ($referral_count > 0);
    $referral_check->close();
}

// Handle payout setting operations for channel partners
if ($partner_type === 'channel_partner') {
    // Save single payout setting (for auto-save)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_single_payout']) && $partner_type === 'channel_partner') {
        $advisor_id = (int)$_POST['advisor_id'];
        $product_id = (int)$_POST['product_id'];
        $rate_type = $_POST['rate_type'];
        $payout_rate = (float)$_POST['payout_rate'];
        
        if ($payout_rate > 0) {
            // Check if setting exists
            $check_stmt = $conn->prepare("SELECT id FROM payout_settings WHERE user_id = ? AND advisor_user_id = ? AND product_id = ?");
            $check_stmt->bind_param("iii", $user_id, $advisor_id, $product_id);
            $check_stmt->execute();
            $existing = $check_stmt->get_result()->fetch_assoc();
            $check_stmt->close();
            
            if ($existing) {
                $update_stmt = $conn->prepare("UPDATE payout_settings SET payout_rate = ?, rate_type = ?, updated_at = NOW() WHERE id = ?");
                $update_stmt->bind_param("dsi", $payout_rate, $rate_type, $existing['id']);
                $update_stmt->execute();
                $update_stmt->close();
            } else {
                $category = null;
                $cat_stmt = $conn->prepare("SELECT category FROM products WHERE id = ?");
                $cat_stmt->bind_param("i", $product_id);
                $cat_stmt->execute();
                $cat_result = $cat_stmt->get_result()->fetch_assoc();
                $category = $cat_result['category'] ?? null;
                $cat_stmt->close();
                
                $insert_stmt = $conn->prepare("INSERT INTO payout_settings (user_id, advisor_user_id, product_id, product_category, payout_rate, rate_type) VALUES (?, ?, ?, ?, ?, ?)");
                $insert_stmt->bind_param("iiisds", $user_id, $advisor_id, $product_id, $category, $payout_rate, $rate_type);
                $insert_stmt->execute();
                $insert_stmt->close();
            }
        }
        echo json_encode(['success' => true]);
        exit;
    }
    
    // Delete setting
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_setting'])) {
        $setting_id = (int)$_POST['setting_id'];
        $delete_stmt = $conn->prepare("DELETE FROM payout_settings WHERE id = ? AND user_id = ?");
        $delete_stmt->bind_param("ii", $setting_id, $user_id);
        $delete_stmt->execute();
        $delete_stmt->close();
        $success_msg = 'Payout setting deleted successfully!';
    }
    
    // Bulk save all payouts
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_all_payouts'])) {
        $payouts = $_POST['payouts'] ?? [];
        $saved_count = 0;
        
        foreach ($payouts as $payout_data) {
            $advisor_id = (int)$payout_data['advisor_id'];
            $product_id = (int)$payout_data['product_id'];
            $rate_type = $payout_data['rate_type'];
            $payout_rate = (float)$payout_data['payout_rate'];
            
            if ($payout_rate > 0) {
                // Check if setting exists
                $check_stmt = $conn->prepare("SELECT id FROM payout_settings WHERE user_id = ? AND advisor_user_id = ? AND product_id = ?");
                $check_stmt->bind_param("iii", $user_id, $advisor_id, $product_id);
                $check_stmt->execute();
                $existing = $check_stmt->get_result()->fetch_assoc();
                $check_stmt->close();
                
                if ($existing) {
                    $update_stmt = $conn->prepare("UPDATE payout_settings SET payout_rate = ?, rate_type = ? WHERE id = ?");
                    $update_stmt->bind_param("dsi", $payout_rate, $rate_type, $existing['id']);
                    $update_stmt->execute();
                    $update_stmt->close();
                } else {
                    $category = null;
                    $cat_stmt = $conn->prepare("SELECT category FROM products WHERE id = ?");
                    $cat_stmt->bind_param("i", $product_id);
                    $cat_stmt->execute();
                    $cat_result = $cat_stmt->get_result()->fetch_assoc();
                    $category = $cat_result['category'] ?? null;
                    $cat_stmt->close();
                    
                    $insert_stmt = $conn->prepare("INSERT INTO payout_settings (user_id, advisor_user_id, product_id, product_category, payout_rate, rate_type) VALUES (?, ?, ?, ?, ?, ?)");
                    $insert_stmt->bind_param("iiisds", $user_id, $advisor_id, $product_id, $category, $payout_rate, $rate_type);
                    $insert_stmt->execute();
                    $insert_stmt->close();
                }
                $saved_count++;
            }
        }
        
        $success_msg = "Successfully saved {$saved_count} payout settings!";
    }
    
    // Save setting
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_payout_setting'])) {
        $advisor_id = (int)$_POST['advisor_id'];
        $product_id = !empty($_POST['product_id']) ? (int)$_POST['product_id'] : null;
        $rate_type = $_POST['rate_type'];
        $payout_rate = (float)$_POST['payout_rate'];
        
        // Validation
        if ($rate_type === 'card_amount' && $payout_rate % 100 !== 0) {
            $error_msg = 'Card payout must be in multiples of ₹100.';
        } elseif ($rate_type === 'loan_percentage' && $payout_rate > 100) {
            $error_msg = 'Loan percentage cannot exceed 100%.';
        } else {
            // Check if setting exists
            $check_stmt = $conn->prepare("SELECT id FROM payout_settings WHERE user_id = ? AND advisor_user_id = ? AND (product_id = ? OR (product_id IS NULL AND ? IS NULL))");
            $check_stmt->bind_param("iiii", $user_id, $advisor_id, $product_id, $product_id);
            $check_stmt->execute();
            $existing = $check_stmt->get_result()->fetch_assoc();
            $check_stmt->close();
            
            if ($existing) {
                $update_stmt = $conn->prepare("UPDATE payout_settings SET payout_rate = ?, rate_type = ?, updated_at = NOW() WHERE id = ?");
                $update_stmt->bind_param("dsi", $payout_rate, $rate_type, $existing['id']);
                $update_stmt->execute();
                $update_stmt->close();
            } else {
                $category = null;
                if ($product_id) {
                    $cat_stmt = $conn->prepare("SELECT category FROM products WHERE id = ?");
                    $cat_stmt->bind_param("i", $product_id);
                    $cat_stmt->execute();
                    $cat_result = $cat_stmt->get_result()->fetch_assoc();
                    $category = $cat_result['category'] ?? null;
                    $cat_stmt->close();
                }
                
                $insert_stmt = $conn->prepare("INSERT INTO payout_settings (user_id, advisor_user_id, product_id, product_category, payout_rate, rate_type) VALUES (?, ?, ?, ?, ?, ?)");
                $insert_stmt->bind_param("iiisds", $user_id, $advisor_id, $product_id, $category, $payout_rate, $rate_type);
                $insert_stmt->execute();
                $insert_stmt->close();
            }
            $success_msg = 'Payout setting saved successfully!';
        }
    }
}

// Build WHERE clause based on filter
$whereClause = "AND l.status IN ('activated','disbursed')";
if ($filter === 'pending') {
    $whereClause .= " AND p.status = 'pending'";
} elseif ($filter === 'paid') {
    $whereClause .= " AND p.status = 'paid'";
}
$summary_query = "SELECT 
    SUM(CASE WHEN p.status = 'pending' AND l.status IN ('activated','disbursed') AND l.channel_code = ? THEN p.commission_amount + p.bonus_amount - COALESCE(p.deduction_amount, 0) ELSE 0 END) as pending,
    SUM(CASE WHEN p.status = 'paid' AND l.status IN ('activated','disbursed') AND l.channel_code = ? AND MONTH(p.payout_date) = MONTH(CURDATE()) AND YEAR(p.payout_date) = YEAR(CURDATE()) THEN p.commission_amount + p.bonus_amount - COALESCE(p.deduction_amount, 0) ELSE 0 END) as paid_this_month,
    SUM(CASE WHEN p.status = 'paid' AND l.status IN ('activated','disbursed') AND l.channel_code = ? AND MONTH(p.payout_date) = MONTH(CURDATE()) - 1 AND YEAR(p.payout_date) = YEAR(CURDATE()) THEN p.commission_amount + p.bonus_amount - COALESCE(p.deduction_amount, 0) ELSE 0 END) as paid_last_month,
    SUM(CASE WHEN p.status = 'paid' AND l.status IN ('activated','disbursed') AND l.channel_code = ? THEN p.commission_amount + p.bonus_amount - COALESCE(p.deduction_amount, 0) ELSE 0 END) as total_paid,
    SUM(CASE WHEN l.status IN ('activated','disbursed') AND l.channel_code = ? THEN p.commission_amount + p.bonus_amount - COALESCE(p.deduction_amount, 0) ELSE 0 END) as total_accrued,
    SUM(CASE WHEN p.status = 'pending' AND l.status IN ('activated','disbursed') AND l.channel_code = ? AND MONTH(p.created_at) = MONTH(CURDATE()) AND YEAR(p.created_at) = YEAR(CURDATE()) THEN p.commission_amount + p.bonus_amount - COALESCE(p.deduction_amount, 0) ELSE 0 END) as accrued_this_month
FROM payouts p
JOIN leads l ON p.lead_id = l.id";

$summary_stmt = $conn->prepare($summary_query);
$summary_stmt->bind_param('ssssss', $user['channel_code'], $user['channel_code'], $user['channel_code'], $user['channel_code'], $user['channel_code'], $user['channel_code']);
$summary_stmt->execute();
$summary = $summary_stmt->get_result()->fetch_assoc();
$summary_stmt->close();

// Get referral earnings summary - both as team leader and as advisor
$referral_query = "SELECT 
    SUM(CASE WHEN pl.status = 'pending' AND pl.earning_type = 'referral_percentage' THEN pl.amount ELSE 0 END) as advisor_pending,
    SUM(CASE WHEN pl.status = 'paid' AND pl.earning_type = 'referral_percentage' THEN pl.amount ELSE 0 END) as advisor_total,
    SUM(CASE WHEN pl.status = 'pending' AND pl.earning_type = 'margin_earning' THEN pl.amount ELSE 0 END) as margin_pending,
    SUM(CASE WHEN pl.status = 'paid' AND pl.earning_type = 'margin_earning' THEN pl.amount ELSE 0 END) as margin_total,
    SUM(CASE WHEN pl.status = 'paid' AND MONTH(pl.created_at) = MONTH(CURDATE()) AND YEAR(pl.created_at) = YEAR(CURDATE()) THEN pl.amount ELSE 0 END) as referral_this_month,
    SUM(pl.amount) as total_referral_earnings
FROM payout_ledger pl
WHERE pl.user_id = ? AND pl.earning_type IN ('referral_percentage', 'margin_earning')";

$referral_stmt = $conn->prepare($referral_query);
$referral_stmt->bind_param('i', $user['id']);
$referral_stmt->execute();
$referral_summary = $referral_stmt->get_result()->fetch_assoc();
$referral_stmt->close();

// Calculate combined totals
$referral_summary['referral_pending'] = ($referral_summary['advisor_pending'] ?? 0) + ($referral_summary['margin_pending'] ?? 0);
$referral_summary['referral_total'] = ($referral_summary['advisor_total'] ?? 0) + ($referral_summary['margin_total'] ?? 0);
$referral_summary['margin_profit'] = $referral_summary['margin_total'] ?? 0;

// Calculate downline payouts for margin display
$downline_paid = 0;
$team_commissions = [];
if ($user['partner_type'] === 'channel_partner') {
    $downline_query = "SELECT SUM(amount) as total FROM payout_ledger WHERE source_user_id = ? AND earning_type = 'referral_percentage'";
    $downline_stmt = $conn->prepare($downline_query);
    $downline_stmt->bind_param("i", $user['id']);
    $downline_stmt->execute();
    $downline_result = $downline_stmt->get_result()->fetch_assoc();
    $downline_paid = $downline_result['total'] ?? 0;
    $downline_stmt->close();
    
    // Get team member commission details with calculated amounts based on set rates
    $team_query = "SELECT u.name, u.id as user_id, u.channel_code,
        COUNT(DISTINCT l.id) as leads_count,
        SUM(CASE WHEN l.status IN ('activated', 'disbursed') THEN 1 ELSE 0 END) as activated_leads
        FROM referral_users ru
        JOIN users u ON ru.referred_user_id = u.id
        LEFT JOIN leads l ON l.channel_code = u.channel_code
        WHERE ru.referrer_user_id = ? AND ru.level = 1
        GROUP BY u.id, u.name, u.channel_code
        ORDER BY activated_leads DESC";
    $team_stmt = $conn->prepare($team_query);
    $team_stmt->bind_param("i", $user['id']);
    $team_stmt->execute();
    $team_members = $team_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $team_stmt->close();
    
    // Calculate commission amounts based on set rates
    foreach ($team_members as &$member) {
        $member['calculated_commission'] = 0;
        $member['pending_commission'] = 0;
        $member['set_rates'] = [];
        
        // Get payout settings for this member
        $settings_query = "SELECT ps.*, p.name as product_name, p.category, p.commission_rate as master_rate
                           FROM payout_settings ps
                           LEFT JOIN products p ON ps.product_id = p.id
                           WHERE ps.user_id = ? AND ps.advisor_user_id = ?";
        $settings_stmt = $conn->prepare($settings_query);
        $settings_stmt->bind_param("ii", $user['id'], $member['user_id']);
        $settings_stmt->execute();
        $member['set_rates'] = $settings_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $settings_stmt->close();
        
        // Calculate commission based on activated leads and set rates
        if (!empty($member['set_rates'])) {
            $commission_query = "SELECT l.id, l.status, p.category, p.commission_rate as master_rate
                                FROM leads l
                                JOIN products p ON l.product_id = p.id
                                WHERE l.channel_code = ? AND l.status IN ('activated', 'disbursed')";
            $comm_stmt = $conn->prepare($commission_query);
            $comm_stmt->bind_param("s", $member['channel_code']);
            $comm_stmt->execute();
            $leads = $comm_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $comm_stmt->close();
            
            foreach ($leads as $lead) {
                foreach ($member['set_rates'] as $rate) {
                    if ($rate['product_category'] === $lead['category'] || !$rate['product_id']) {
                        if ($rate['rate_type'] === 'card_amount') {
                            $member['calculated_commission'] += $rate['payout_rate'];
                        } else {
                            $member['calculated_commission'] += ($lead['master_rate'] * $rate['payout_rate'] / 100);
                        }
                        break;
                    }
                }
            }
        }
    }
    $team_commissions = $team_members;
}

// Get lead-wise payout details with commission logic
$payouts_query = "SELECT 
    p.id,
    p.commission_amount,
    p.bonus_amount,
    p.deduction_amount,
    p.payout_remark,
    p.status,
    p.payout_date,
    p.created_at,
    l.lead_id,
    l.customer_name as customer_name,
    l.status as lead_status,
    l.product_id,
    pr.name as product_name,
    pr.category,
    pr.commission_rate as master_rate,
    'direct' as payout_type
FROM payouts p
JOIN leads l ON p.lead_id = l.id
JOIN products pr ON l.product_id = pr.id
WHERE l.channel_code = ? $whereClause
ORDER BY p.created_at DESC";

$payouts_stmt = $conn->prepare($payouts_query);
$payouts_stmt->bind_param('s', $user['channel_code']);
$payouts_stmt->execute();
$payouts_raw = $payouts_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$payouts_stmt->close();

// Apply commission logic to each payout
$payouts = [];
foreach ($payouts_raw as $payout) {
    $commission_info = getCommissionForUser($conn, $user['id'], $payout['product_id']);
    $payout['calculated_commission'] = $commission_info['amount'];
    $payout['commission_type'] = $commission_info['type'];
    $payout['master_commission'] = $commission_info['master_amount'];
    $payout['is_custom_rate'] = $commission_info['type'] === 'referral';
    $payouts[] = $payout;
}

function getStatusBadge($status) {
    $badges = [
        'pending' => 'bg-yellow-100 text-yellow-800',
        'paid' => 'bg-green-100 text-green-800',
        'cancelled' => 'bg-red-100 text-red-800'
    ];
    return $badges[$status] ?? 'bg-gray-100 text-gray-800';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payouts & Commission Tracking</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-50 flex flex-col">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>

    <main class="w-full max-w-7xl mx-auto px-2 sm:px-4 py-4 sm:py-8">
        
        <?php if (isset($error_msg)): ?>
            <div class="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
                <i class="fas fa-exclamation-triangle mr-2"></i><?= htmlspecialchars($error_msg) ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($success_msg)): ?>
            <div class="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg text-green-700">
                <i class="fas fa-check-circle mr-2"></i><?= htmlspecialchars($success_msg) ?>
            </div>
        <?php endif; ?>
        
        <!-- Tab Navigation (only for referred users) -->
        <?php if ($is_referred): ?>
        <div class="bg-white rounded-lg shadow-sm border mb-6">
            <div class="flex border-b border-slate-200">
                <button onclick="switchTab('payouts')" class="tab-btn flex-1 px-6 py-4 text-center font-medium transition-all <?= $active_tab === 'payouts' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50' ?>">
                    <i class="fas fa-wallet mr-2"></i>My Payouts
                </button>
                <button onclick="switchTab('settings')" class="tab-btn flex-1 px-6 py-4 text-center font-medium transition-all <?= $active_tab === 'settings' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50' ?>">
                    <i class="fas fa-cog mr-2"></i>Team Settings
                </button>
                <button onclick="switchTab('summary')" class="tab-btn flex-1 px-6 py-4 text-center font-medium transition-all <?= $active_tab === 'summary' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50' ?>">
                    <i class="fas fa-chart-bar mr-2"></i>Team Summary
                </button>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Payouts Tab -->
        <div id="tab-payouts" class="tab-content <?= $active_tab !== 'payouts' ? 'hidden' : '' ?>">
        <!-- Payout Summary -->
        <div class="mb-6 sm:mb-8">
            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4 sm:mb-6">
                <h2 class="text-xl sm:text-2xl font-bold text-slate-900">Payout Summary</h2>
                <div class="flex flex-col sm:flex-row gap-3">
                    <!-- Filter Dropdown -->
                    <select id="statusFilter" onchange="filterPayouts()" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>All Records</option>
                        <option value="pending" <?= $filter === 'pending' ? 'selected' : '' ?>>Pending Only</option>
                        <option value="paid" <?= $filter === 'paid' ? 'selected' : '' ?>>Paid Only</option>
                    </select>
                    <!-- Download Report Button -->
                    <button onclick="downloadReport()" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors">
                        <i class="fas fa-download"></i>
                        Download Report
                    </button>
                    <!-- Team Payouts Button (only for referred users) -->
                    <?php if ($is_referred): ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                <!-- Pending Payouts -->
                <div class="bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-lg shadow-lg text-white p-4 sm:p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-yellow-100 text-xs sm:text-sm">Pending Payouts</p>
                            <p class="text-2xl sm:text-3xl font-bold">₹<?php echo number_format($summary['pending'] ?? 0); ?></p>
                            <p class="text-yellow-100 text-xs mt-1">Awaiting payment</p>
                        </div>
                        <i class="fas fa-hourglass-half text-2xl sm:text-4xl text-yellow-200"></i>
                    </div>
                </div>

                <!-- Paid This Month -->
                <div class="bg-gradient-to-r from-green-500 to-green-600 rounded-lg shadow-lg text-white p-4 sm:p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-green-100 text-xs sm:text-sm">Paid This Month</p>
                            <p class="text-2xl sm:text-3xl font-bold">₹<?php echo number_format($summary['paid_this_month'] ?? 0); ?></p>
                            <p class="text-green-100 text-xs mt-1">Current month earnings</p>
                        </div>
                        <i class="fas fa-calendar-check text-2xl sm:text-4xl text-green-200"></i>
                    </div>
                </div>

                <!-- Total Paid -->
                <div class="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg shadow-lg text-white p-4 sm:p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-blue-100 text-xs sm:text-sm">Total Paid Till Now</p>
                            <p class="text-2xl sm:text-3xl font-bold">₹<?php echo number_format($summary['total_paid'] ?? 0); ?></p>
                            <p class="text-blue-100 text-xs mt-1">Lifetime earnings</p>
                        </div>
                        <i class="fas fa-wallet text-2xl sm:text-4xl text-blue-200"></i>
                    </div>
                </div>
                
                <!-- Team Margin Earnings -->
                <?php 
                $margin_earnings = getTotalMarginEarnings($conn, $user['id'], 'paid');
                $pending_margin = getTotalMarginEarnings($conn, $user['id'], 'pending');
                $total_margin = getTotalMarginEarnings($conn, $user['id']);
                // Debug: Always show if user has any margin earnings
                if ($total_margin > 0): 
                ?>
                <div class="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg shadow-lg text-white p-4 sm:p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-purple-100 text-xs sm:text-sm">Team Margin Earned</p>
                            <p class="text-2xl sm:text-3xl font-bold">₹<?php echo number_format($total_margin); ?></p>
                            <p class="text-purple-100 text-xs mt-1">From team leads</p>
                        </div>
                        <i class="fas fa-users text-2xl sm:text-4xl text-purple-200"></i>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Additional Metrics -->
        <div class="mb-6 sm:mb-8">
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
                <div class="bg-white rounded-lg shadow-sm border p-4 sm:p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-slate-600 text-sm">Last Month</p>
                            <p class="text-2xl font-bold text-slate-900">₹<?php echo number_format($summary['paid_last_month'] ?? 0); ?></p>
                        </div>
                        <i class="fas fa-chart-bar text-2xl text-slate-400"></i>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm border p-4 sm:p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-slate-600 text-sm">Accrued This Month</p>
                            <p class="text-2xl font-bold text-purple-600">₹<?php echo number_format($summary['accrued_this_month'] ?? 0); ?></p>
                        </div>
                        <i class="fas fa-plus-circle text-2xl text-purple-400"></i>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm border p-4 sm:p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-slate-600 text-sm">Total Commission</p>
                            <p class="text-2xl font-bold text-indigo-600">₹<?php echo number_format(($summary['total_accrued'] ?? 0) + ($referral_summary['total_referral_earnings'] ?? 0)); ?></p>
                            <p class="text-xs text-slate-500 mt-1">Direct + Referral</p>
                        </div>
                        <i class="fas fa-coins text-2xl text-indigo-400"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Referral Program Earnings -->
        <?php if ($user['partner_type'] === 'channel_partner' || $user['partner_type'] === 'network_partner'): ?>
        <div class="mb-6 sm:mb-8">
            <h3 class="text-lg font-semibold text-slate-900 mb-4"><?= $user['partner_type'] === 'channel_partner' ? 'Channel Partner' : 'Network Partner' ?> Referral Program Earnings</h3>
            
            <?php if ($user['partner_type'] === 'channel_partner'): ?>
            <!-- Margin Trading Overview for Channel Partners -->
            <div class="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 mb-6 border border-blue-200">
                <h4 class="text-lg font-semibold text-slate-900 mb-3">
                    <i class="fas fa-chart-line mr-2 text-blue-600"></i>Margin Trading Overview
                </h4>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div class="bg-white rounded-lg p-4 border border-blue-200">
                        <div class="text-sm text-slate-600 mb-1">Master Payout Received</div>
                        <div class="text-2xl font-bold text-blue-600">₹<?= number_format(($summary['total_paid'] ?? 0) + ($referral_summary['referral_total'] ?? 0), 0) ?></div>
                        <div class="text-xs text-slate-500 mt-1">From Finocards</div>
                    </div>
                    <div class="bg-white rounded-lg p-4 border border-purple-200">
                        <div class="text-sm text-slate-600 mb-1">Paid to Downline</div>
                        <div class="text-2xl font-bold text-purple-600">₹<?= number_format($downline_paid, 0) ?></div>
                        <div class="text-xs text-slate-500 mt-1"><?= count($team_commissions) ?> L1 Advisors</div>
                    </div>
                    <div class="bg-white rounded-lg p-4 border border-green-200">
                        <div class="text-sm text-slate-600 mb-1">Your Margin Profit</div>
                        <div class="text-2xl font-bold text-green-600">₹<?= number_format($referral_summary['margin_profit'] ?? 0, 0) ?></div>
                        <div class="text-xs text-slate-500 mt-1">Margin Earned</div>
                    </div>
                </div>
                <div class="mt-4 p-3 bg-white rounded border-l-4 border-blue-500">
                    <p class="text-sm text-slate-700">
                        <i class="fas fa-info-circle text-blue-500 mr-2"></i>
                        <strong>How it works:</strong> You receive the full payout from Finocards, set rates for your advisors, and keep the margin difference as profit.
                    </p>
                </div>
            </div>
            

            <?php endif; ?>
            
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
                <div class="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg shadow-lg text-white p-4 sm:p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-purple-100 text-xs sm:text-sm">Referral Pending</p>
                            <p class="text-2xl sm:text-3xl font-bold">₹<?php echo number_format($referral_summary['referral_pending'] ?? 0); ?></p>
                            <p class="text-purple-100 text-xs mt-1">Team earnings</p>
                        </div>
                        <i class="fas fa-users text-2xl sm:text-4xl text-purple-200"></i>
                    </div>
                </div>
                <div class="bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-lg shadow-lg text-white p-4 sm:p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-indigo-100 text-xs sm:text-sm">Referral This Month</p>
                            <p class="text-2xl sm:text-3xl font-bold">₹<?php echo number_format($referral_summary['referral_this_month'] ?? 0); ?></p>
                            <p class="text-indigo-100 text-xs mt-1">Current month</p>
                        </div>
                        <i class="fas fa-chart-line text-2xl sm:text-4xl text-indigo-200"></i>
                    </div>
                </div>
                <div class="bg-gradient-to-r from-pink-500 to-pink-600 rounded-lg shadow-lg text-white p-4 sm:p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-pink-100 text-xs sm:text-sm">Total Referral Paid</p>
                            <p class="text-2xl sm:text-3xl font-bold">₹<?php echo number_format($referral_summary['referral_total'] ?? 0); ?></p>
                            <p class="text-pink-100 text-xs mt-1">Team lifetime</p>
                        </div>
                        <i class="fas fa-handshake text-2xl sm:text-4xl text-pink-200"></i>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Referral Payout Report -->
        <?php if ($user['partner_type'] === 'channel_partner' || $user['partner_type'] === 'network_partner'): ?>
        <div class="bg-white rounded-lg shadow-sm border overflow-x-auto mb-6">
            <div class="px-2 sm:px-6 py-2 sm:py-4 border-b border-slate-200">
                <h3 class="text-base sm:text-lg font-semibold text-slate-900">Referral Payout Report</h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-xs sm:text-sm">
                    <thead class="bg-slate-50">
                        <tr>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Source</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Level</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Type</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Product</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Payout Rate</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Amount</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Status</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Date</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200">
                        <?php
                        $referral_payouts_query = "SELECT pl.*, u.name as source_name, p.name as product_name, p.category,
                                                   ps.payout_rate as set_rate, ps.rate_type
                                                   FROM payout_ledger pl
                                                   LEFT JOIN users u ON pl.source_user_id = u.id
                                                   LEFT JOIN products p ON pl.product_id = p.id
                                                   LEFT JOIN payout_settings ps ON ps.user_id = pl.user_id AND ps.advisor_user_id = pl.source_user_id AND (ps.product_id = pl.product_id OR ps.product_id IS NULL)
                                                   WHERE pl.user_id = ? AND pl.earning_type IN ('referral_percentage', 'margin_control', 'margin_earning')
                                                   ORDER BY pl.created_at DESC LIMIT 50";
                        $ref_stmt = $conn->prepare($referral_payouts_query);
                        $ref_stmt->bind_param('i', $user['id']);
                        $ref_stmt->execute();
                        $referral_payouts = $ref_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                        $ref_stmt->close();
                        ?>
                        <?php if (empty($referral_payouts)): ?>
                            <tr>
                                <td colspan="8" class="px-4 py-8 text-center text-slate-500">
                                    No referral payouts yet.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($referral_payouts as $ref_payout): ?>
                                <tr class="hover:bg-slate-50">
                                    <td class="px-2 sm:px-4 py-2 sm:py-3">
                                        <?php if ($ref_payout['source_user_id']): ?>
                                            <span class="text-slate-900"><?= htmlspecialchars($ref_payout['source_name'] ?? 'Team Member') ?></span>
                                        <?php else: ?>
                                            <span class="text-blue-600 font-medium">Self</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 text-slate-600">
                                        <?= $ref_payout['level'] ? 'L' . $ref_payout['level'] : '-' ?>
                                    </td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3">
                                        <?php
                                        $type_labels = [
                                            'referral_percentage' => 'Referral %',
                                            'margin_control' => 'Margin Control',
                                            'margin_earning' => 'Team Margin'
                                        ];
                                        ?>
                                        <span class="text-xs px-2 py-1 rounded-full bg-purple-100 text-purple-700">
                                            <?= $type_labels[$ref_payout['earning_type']] ?? $ref_payout['earning_type'] ?>
                                        </span>
                                    </td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 text-slate-600 text-sm">
                                        <?= htmlspecialchars($ref_payout['product_name'] ?? 'N/A') ?>
                                    </td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 font-medium text-blue-600">
                                        <?php if ($ref_payout['set_rate']): ?>
                                            <?= $ref_payout['rate_type'] === 'card_amount' ? '₹' . number_format($ref_payout['set_rate']) : number_format($ref_payout['set_rate'], 1) . '%' ?>
                                            <div class="text-xs text-slate-500 mt-1">Set by team owner</div>
                                        <?php else: ?>
                                            <span class="text-slate-400">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 font-semibold text-green-600">
                                        ₹<?= number_format($ref_payout['amount'], 2) ?>
                                    </td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3">
                                        <span class="px-2 py-1 text-xs rounded-full <?= getStatusBadge($ref_payout['status']) ?>">
                                            <?= ucfirst($ref_payout['status']) ?>
                                        </span>
                                    </td>
                                    <td class="px-2 sm:px-4 py-2 sm:py-3 text-slate-500 text-sm">
                                        <?= date('M d, Y', strtotime($ref_payout['created_at'])) ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- Lead-wise Payout Report -->
        <div class="bg-white rounded-lg shadow-sm border overflow-x-auto">
            <div class="px-2 sm:px-6 py-2 sm:py-4 border-b border-slate-200">
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                    <h3 class="text-base sm:text-lg font-semibold text-slate-900">Lead-wise Payout Report</h3>
                    <span class="text-sm text-slate-600">Filtered by: <span class="font-medium"><?= ucfirst($filter) ?></span></span>
                </div>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-xs sm:text-sm">
                    <thead class="bg-slate-50">
                        <tr>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Lead ID</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Customer</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Product</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Lead Status</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Commission</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Bonus</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Deduction</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Final Payout</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Remark</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Payout Status</th>
                            <th class="px-2 sm:px-4 py-2 sm:py-3 text-left font-medium text-slate-500 uppercase">Payout Date</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200">
                        <?php foreach ($payouts as $payout): ?>
                            <tr class="hover:bg-slate-50">
                                <td class="px-2 sm:px-4 py-2 sm:py-3 font-medium text-blue-600"><?php echo $payout['lead_id']; ?></td>
                                <td class="px-2 sm:px-4 py-2 sm:py-3 text-slate-900"><?php echo htmlspecialchars($payout['customer_name']); ?></td>
                                <td class="px-2 sm:px-4 py-2 sm:py-3">
                                    <div class="flex items-center">
                                        <i class="fas fa-<?php echo $payout['category'] === 'Credit Card' ? 'credit-card' : 'money-bill-wave'; ?> text-blue-600 mr-2"></i>
                                        <span class="text-slate-900"><?php echo htmlspecialchars($payout['product_name']); ?></span>
                                    </div>
                                </td>
                                <td class="px-2 sm:px-4 py-2 sm:py-3">
                                    <?php
                                    $lead_status_colors = [
                                        'generated' => 'bg-blue-100 text-blue-800',
                                        'yet_to_start' => 'bg-gray-100 text-gray-800',
                                        'in_process' => 'bg-yellow-100 text-yellow-800',
                                        'approved' => 'bg-green-100 text-green-800',
                                        'declined' => 'bg-red-100 text-red-800',
                                        'activated' => 'bg-purple-100 text-purple-800',
                                        'disbursed' => 'bg-indigo-100 text-indigo-800'
                                    ];
                                    $lead_status_class = $lead_status_colors[$payout['lead_status']] ?? 'bg-gray-100 text-gray-800';
                                    ?>
                                    <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full <?php echo $lead_status_class; ?>">
                                        <?php echo ucwords(str_replace('_', ' ', $payout['lead_status'])); ?>
                                    </span>
                                </td>
                                <td class="px-2 sm:px-4 py-2 sm:py-3">
                                    <?php if ($user['partner_type'] === 'channel_partner'): ?>
                                        <!-- Channel Partner View -->
                                        <div class="font-medium text-slate-900">₹<?php echo number_format($payout['master_commission']); ?></div>
                                        <span class="inline-block px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded-full mt-1">Master Payout</span>
                                        <?php if ($payout['is_custom_rate']): ?>
                                            <div class="text-xs text-green-600 mt-1 font-medium">Margin: ₹<?= number_format($payout['master_commission'] - $payout['calculated_commission']) ?></div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <!-- Network Partner / Advisor View -->
                                        <div class="font-medium text-slate-900">₹<?php echo number_format($payout['calculated_commission']); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td class="px-2 sm:px-4 py-2 sm:py-3 font-medium <?php echo $payout['payout_type'] === 'referral' ? 'text-purple-600' : 'text-green-600'; ?>">₹<?php echo number_format($payout['bonus_amount']); ?><?php if($payout['payout_type'] === 'referral') echo ' (Referral)'; ?></td>
                                <td class="px-2 sm:px-4 py-2 sm:py-3 font-medium text-red-600">₹<?php echo number_format($payout['deduction_amount'] ?? 0); ?></td>
                                <td class="px-2 sm:px-4 py-2 sm:py-3 font-bold text-slate-900">₹<?php echo number_format($payout['calculated_commission'] + $payout['bonus_amount'] - ($payout['deduction_amount'] ?? 0)); ?></td>
                                <td class="px-2 sm:px-4 py-2 sm:py-3 text-slate-600"><?php echo htmlspecialchars($payout['payout_remark'] ?? '-'); ?></td>
                                <td class="px-2 sm:px-4 py-2 sm:py-3">
                                    <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full <?php echo getStatusBadge($payout['status']); ?>">
                                        <?php echo ucfirst($payout['status']); ?>
                                    </span>
                                </td>
                                <td class="px-2 sm:px-4 py-2 sm:py-3 text-slate-500">
                                    <?php echo $payout['payout_date'] ? date('M d, Y', strtotime($payout['payout_date'])) : '-'; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Bonus Tracker -->
        <div class="mt-6 sm:mt-8 bg-white rounded-lg shadow-sm border p-4 sm:p-6">
            <h3 class="text-base sm:text-lg font-semibold text-slate-900 mb-2 sm:mb-4">Team Bonus Tracker</h3>
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-2 sm:p-4">
                <div class="flex items-center">
                    <i class="fas fa-users text-blue-600 mr-2 sm:mr-3"></i>
                    <div>
                        <p class="text-xs sm:text-sm font-medium text-blue-900">Team Hierarchy Bonus</p>
                        <p class="text-xs text-blue-700">Earn 5% bonus on your team's sales performance</p>
                    </div>
                </div>
                <div class="mt-2 sm:mt-4 grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-4">
                    <div class="text-center">
                        <p class="text-xl sm:text-2xl font-bold text-blue-600">0</p>
                        <p class="text-xs text-blue-700">Team Members</p>
                    </div>
                    <div class="text-center">
                        <p class="text-xl sm:text-2xl font-bold text-blue-600">₹0</p>
                        <p class="text-xs text-blue-700">Team Sales</p>
                    </div>
                    <div class="text-center">
                        <p class="text-xl sm:text-2xl font-bold text-blue-600">₹0</p>
                        <p class="text-xs text-blue-700">Your Bonus (5%)</p>
                    </div>
                </div>
            </div>
        </div>
        </div>
        
        <?php if ($is_referred): ?>
        <!-- Team Settings Tab -->
        <div id="tab-settings" class="tab-content <?= $active_tab !== 'settings' ? 'hidden' : '' ?>">
            <?php include __DIR__ . '/team_payout_settings.php'; ?>
        </div>
        
        <!-- Team Summary Tab -->
        <div id="tab-summary" class="tab-content <?= $active_tab !== 'summary' ? 'hidden' : '' ?>">
            <?php include __DIR__ . '/team_payout_summary.php'; ?>
        </div>
        <?php endif; ?>
    </main>
    
    <script>
    function switchTab(tab) {
        document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
        document.getElementById('tab-' + tab).classList.remove('hidden');
        
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('bg-blue-50', 'text-blue-600', 'border-b-2', 'border-blue-600');
            btn.classList.add('text-gray-600');
        });
        event.target.closest('button').classList.add('bg-blue-50', 'text-blue-600', 'border-b-2', 'border-blue-600');
        event.target.closest('button').classList.remove('text-gray-600');
        
        const url = new URL(window.location);
        url.searchParams.set('tab', tab);
        window.history.pushState({}, '', url);
    }
    
    function filterPayouts() {
        const filter = document.getElementById('statusFilter').value;
        window.location.href = '<?= preserveFiltersInForm('payouts.php') ?>&filter=' + filter;
    }
    
    function downloadReport() {
        const filter = document.getElementById('statusFilter').value;
        const url = new URL(window.location);
        url.searchParams.set('export', 'csv');
        url.searchParams.set('filter', filter);
        window.open(url.toString(), '_blank');
    }
    </script>
    
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
