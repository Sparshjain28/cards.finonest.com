<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

requireLogin();

$user = getCurrentUser();
$database = new Database();
$conn = $database->getConnection();

if (empty($user['partner_type']) && empty($_SESSION['is_admin'])) {
    header('Location: select_partner_type.php');
    exit();
}

if (empty($user['partner_type']) && !empty($_SESSION['is_admin'])) {
    $user['partner_type'] = 'network_partner';
}

$partner_type = $user['partner_type'];
$active_tab = $_GET['tab'] ?? 'team';

if (isset($_GET['create_referral'])) {
    if (empty($user['referral_code'])) {
        $referral_code = 'REF' . strtoupper(bin2hex(random_bytes(3)));
        $update_user = $conn->prepare("UPDATE users SET referral_code = ? WHERE id = ?");
        $update_user->bind_param("si", $referral_code, $user['id']);
        $update_user->execute();
        $update_user->close();
        $user['referral_code'] = $referral_code;
    }
    
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $base_path = dirname($_SERVER['SCRIPT_NAME']);
    $base_path = str_replace('/adviser', '', $base_path);
    $base_path = rtrim($base_path, '/');
    
    $referral_url = $protocol . "://" . $host . $base_path . "/signup.php?ref=" . urlencode($user['referral_code']) . "&referrer=" . urlencode($user['name']);
    
    $check_link = $conn->prepare("SELECT id FROM referral_links WHERE user_id = ?");
    $check_link->bind_param("i", $user['id']);
    $check_link->execute();
    $link_exists = $check_link->get_result()->num_rows > 0;
    $check_link->close();
    
    if (!$link_exists) {
        $insert_link = $conn->prepare("INSERT INTO referral_links (user_id, referral_code, referral_url) VALUES (?, ?, ?)");
        $insert_link->bind_param("iss", $user['id'], $user['referral_code'], $referral_url);
        $insert_link->execute();
        $insert_link->close();
    } else {
        $update_link = $conn->prepare("UPDATE referral_links SET referral_url = ? WHERE user_id = ?");
        $update_link->bind_param("si", $referral_url, $user['id']);
        $update_link->execute();
        $update_link->close();
    }
    
    header('Location: refer_and_earn.php?tab=team');
    exit();
}

$referral_link_data = null;
$get_link = $conn->prepare("SELECT referral_url, clicks, signups FROM referral_links WHERE user_id = ?");
$get_link->bind_param("i", $user['id']);
$get_link->execute();
$result = $get_link->get_result();
if ($result->num_rows > 0) {
    $referral_link_data = $result->fetch_assoc();
}
$get_link->close();

$partner_info = [
    'network_partner' => [
        'name' => 'Network Partner',
        'description' => '3-Level Passive Model'
    ],
    'channel_partner' => [
        'name' => 'Channel Partner',
        'description' => 'Direct Team Management'
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Refer and Earn - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .tab-content { display: none; }
        .tab-content.active { display: block; }
    </style>
</head>
<body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    
    <div class="w-full max-w-7xl mx-auto px-4 py-4">
        <div class="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-6 mb-6 text-white">
            <h1 class="text-2xl font-bold mb-2">Refer and Earn</h1>
            <p class="text-blue-100">
                <i class="fas fa-tag mr-2"></i>
                <?= htmlspecialchars($partner_info[$partner_type]['name']) ?> - <?= htmlspecialchars($partner_info[$partner_type]['description']) ?>
            </p>
        </div>

        <div class="bg-white rounded-lg shadow-sm mb-6">
            <div class="flex border-b border-slate-200 overflow-x-auto">
                <a href="?tab=team" class="px-6 py-4 font-medium text-slate-700 hover:text-blue-600 border-b-2 <?= $active_tab === 'team' ? 'border-blue-600 text-blue-600' : 'border-transparent' ?>">
                    <i class="fas fa-users mr-2"></i>My Team
                </a>
                <a href="?tab=leads" class="px-6 py-4 font-medium text-slate-700 hover:text-blue-600 border-b-2 <?= $active_tab === 'leads' ? 'border-blue-600 text-blue-600' : 'border-transparent' ?>">
                    <i class="fas fa-briefcase mr-2"></i>My Team Leads
                </a>
                <a href="?tab=payouts" class="px-6 py-4 font-medium text-slate-700 hover:text-blue-600 border-b-2 <?= $active_tab === 'payouts' ? 'border-blue-600 text-blue-600' : 'border-transparent' ?>">
                    <i class="fas fa-money-bill-wave mr-2"></i>My Team Payouts
                </a>
            </div>
        </div>

        <?php if (!$referral_link_data): ?>
        <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
            <h3 class="text-lg font-semibold text-slate-900 mb-4">Your Referral Link</h3>
            <div class="text-center py-4">
                <p class="text-slate-600 mb-4">Create your referral link to start inviting others</p>
                <a href="?create_referral=1" class="inline-flex items-center bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-lg hover:from-blue-700 hover:to-purple-700 font-medium">
                    <i class="fas fa-link mr-2"></i>Create Referral Link
                </a>
            </div>
        </div>
        <?php else: ?>
        <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
            <h3 class="text-lg font-semibold text-slate-900 mb-4">Your Referral Link</h3>
            <div class="flex gap-2 mb-3">
                <input type="text" id="referralLink" value="<?= htmlspecialchars($referral_link_data['referral_url']) ?>" class="flex-1 px-3 py-2 border rounded-lg bg-gray-50 text-sm" readonly>
                <button onclick="copyReferralLink()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm font-medium">
                    <i class="fas fa-copy mr-1"></i>Copy
                </button>
            </div>
            <div class="flex justify-between text-xs text-slate-600 bg-slate-50 p-2 rounded">
                <span>Clicks: <strong><?= $referral_link_data['clicks'] ?? 0 ?></strong></span>
                <span>Signups: <strong><?= $referral_link_data['signups'] ?? 0 ?></strong></span>
            </div>
        </div>
        <?php endif; ?>

        <div id="tab-team" class="tab-content <?= $active_tab === 'team' ? 'active' : '' ?>">
            <?php include 'refer_earn/team.php'; ?>
        </div>

        <div id="tab-leads" class="tab-content <?= $active_tab === 'leads' ? 'active' : '' ?>">
            <?php include 'refer_earn/team_leads.php'; ?>
        </div>

        <div id="tab-payouts" class="tab-content <?= $active_tab === 'payouts' ? 'active' : '' ?>">
            <?php include 'refer_earn/payout_summary.php'; ?>
            <?php include 'refer_earn/team_payouts.php'; ?>
        </div>
    </div>

    <script>
        function copyReferralLink() {
            const link = document.getElementById('referralLink');
            if (link) {
                link.select();
                document.execCommand('copy');
                alert('Link copied!');
            }
        }
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>