<?php
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../config/database_updated.php';

requireLogin();
$user = getCurrentUser();
$database = new Database();
$conn = $database->getConnection();

header('Content-Type: application/json');

if (isset($_GET['advisor_id'])) {
    $advisor_id = (int)$_GET['advisor_id'];
    $user_id = $user['id'];
    
    $query = "SELECT * FROM payout_settings WHERE user_id = ? AND advisor_user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $user_id, $advisor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $settings = [];
    while ($row = $result->fetch_assoc()) {
        $settings[] = $row;
    }
    
    echo json_encode($settings);
    
} elseif (isset($_GET['setting_id'])) {
    $setting_id = (int)$_GET['setting_id'];
    $user_id = $user['id'];
    
    $query = "SELECT * FROM payout_settings WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $setting_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($setting = $result->fetch_assoc()) {
        echo json_encode($setting);
    } else {
        echo json_encode(['error' => 'Setting not found']);
    }
} else {
    echo json_encode(['error' => 'Invalid request']);
}
?>