<?php
session_start();
require_once '../../config/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'] ?? 'user';
$is_admin = $_SESSION['is_admin'] ?? 0;

// Handle form submission to save advisor payout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_payouts'])) {
    $product_id = intval($_POST['product_id']);
    $advisor_payout = floatval($_POST['advisor_payout']);
    $product_category = $_POST['product_category'];
    $rate_type = $product_category === 'Credit Card' ? 'card_amount' : 'loan_percentage';

    // Check if setting already exists
    $check_stmt = $conn->prepare("SELECT id FROM payout_settings WHERE user_id = ? AND product_id = ? AND advisor_user_id = ?");
    $check_stmt->bind_param("iii", $user_id, $product_id, $user_id);
    $check_stmt->execute();
    $existing = $check_stmt->get_result()->fetch_assoc();

    if ($existing) {
        // Update existing
        $update_stmt = $conn->prepare("UPDATE payout_settings SET payout_rate = ?, updated_at = NOW() WHERE id = ?");
        $update_stmt->bind_param("di", $advisor_payout, $existing['id']);
        $update_stmt->execute();
    } else {
        // Insert new - use user_id as advisor_user_id
        $insert_stmt = $conn->prepare("INSERT INTO payout_settings (user_id, advisor_user_id, product_id, product_category, payout_rate, rate_type, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $insert_stmt->bind_param("iiisds", $user_id, $user_id, $product_id, $product_category, $advisor_payout, $rate_type);
        $insert_stmt->execute();
    }

    $success_message = "Payout settings saved successfully!";
}

// Fetch all active products with their categories
$products_query = "SELECT id, name, category, variant, commission_rate FROM products WHERE status = 'active' ORDER BY category, variant, name";
$products_result = $conn->query($products_query);

// Fetch existing payout settings for this user
$settings_query = "SELECT product_id, payout_rate FROM payout_settings WHERE user_id = ? AND advisor_user_id = ?";
$settings_stmt = $conn->prepare($settings_query);
$settings_stmt->bind_param("ii", $user_id, $user_id);
$settings_stmt->execute();
$settings_result = $settings_stmt->get_result();

$payout_settings = [];
while ($row = $settings_result->fetch_assoc()) {
    $payout_settings[$row['product_id']] = $row['payout_rate'];
}

// Function to get default rate for a product category
function getDefaultRate($category) {
    switch ($category) {
        case 'Credit Card':
            return 500; // ₹500
        case 'Personal Loan':
            return 1.00; // 1%
        default:
            return 0;
    }
}

// Group products by category
$grouped_products = [];
while ($product = $products_result->fetch_assoc()) {
    $category = $product['category'];
    if (!isset($grouped_products[$category])) {
        $grouped_products[$category] = [];
    }
    $grouped_products[$category][] = $product;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payout Settings</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .margin-positive {
            color: #16a34a;
        }

        .margin-negative {
            color: #dc2626;
        }
    </style>
</head>

<body class="bg-gray-100">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="container mx-auto px-4 py-6">
        <div class="mb-6">
            <a href="../refer_and_earn.php?tab=payouts" class="text-blue-600 hover:text-blue-800">
                <i class="fas fa-arrow-left mr-2"></i>Back to Payouts
            </a>
        </div>

        <div class="bg-white rounded-lg shadow-lg p-6">
            <h1 class="text-2xl font-bold mb-6">
                <i class="fas fa-cog mr-2 text-blue-600"></i>Payout Settings
            </h1>

            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <h3 class="text-sm font-semibold text-blue-800 mb-2">
                    <i class="fas fa-info-circle mr-1"></i>Default Referral Rates
                </h3>
                <p class="text-sm text-blue-700">
                    For referred users in the channel referral program, default rates are automatically set:
                    <strong>Credit Cards: ₹500</strong> | <strong>Personal Loans: 1%</strong>
                    <br>You can modify these rates below. Advisors will see these rates until you change them.
                </p>
            </div>

            <?php if (isset($success_message)): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    <i class="fas fa-check-circle mr-2"></i><?= htmlspecialchars($success_message) ?>
                </div>
            <?php endif; ?>

            <?php foreach ($grouped_products as $category => $products): ?>
                <div class="mb-8">
                    <h2 class="text-lg font-semibold mb-4 text-gray-700 border-b pb-2">
                        <i
                            class="fas fa-<?= $category === 'Credit Card' ? 'credit-card' : ($category === 'Personal Loan' ? 'money-bill-wave' : 'car') ?> mr-2"></i>
                        <?= htmlspecialchars($category) ?>
                    </h2>

                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse">
                            <thead>
                                <tr class="bg-gray-50">
                                    <th
                                        class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">
                                        Product Type</th>
                                    <th
                                        class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">
                                        Bank</th>
                                    <th
                                        class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">
                                        Product</th>
                                    <th
                                        class="px-4 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">
                                        Your Payout</th>
                                    <th
                                        class="px-4 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">
                                        Advisor Payout</th>
                                    <th
                                        class="px-4 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">
                                        Margin</th>
                                    <th
                                        class="px-4 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">
                                        Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($products as $product):
                                    $your_payout = floatval($product['commission_rate']);
                                    $advisor_payout = isset($payout_settings[$product['id']]) ? floatval($payout_settings[$product['id']]) : getDefaultRate($category);
                                    $margin = $your_payout - $advisor_payout;
                                    $is_loan = ($category !== 'Credit Card');
                                    $symbol = $is_loan ? '%' : '₹';
                                    $is_default = !isset($payout_settings[$product['id']]);
                                    ?>
                                    <tr class="hover:bg-gray-50 border-b">
                                        <form method="POST" class="payout-form">
                                            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                            <input type="hidden" name="product_category"
                                                value="<?= htmlspecialchars($category) ?>">

                                            <td class="px-4 py-3 text-sm text-gray-700"><?= htmlspecialchars($category) ?></td>
                                            <td class="px-4 py-3 text-sm text-gray-700 font-medium">
                                                <?= htmlspecialchars($product['variant'] ?? '-') ?>
                                            </td>
                                            <td class="px-4 py-3 text-sm text-gray-900 font-medium">
                                                <?= htmlspecialchars($product['name']) ?>
                                            </td>
                                            <td class="px-4 py-3 text-center">
                                                <span
                                                    class="text-green-600 font-bold"><?= $symbol ?><?= number_format($your_payout, $is_loan ? 2 : 0) ?></span>
                                            </td>
                                            <td class="px-4 py-3 text-center">
                                                <input type="number" name="advisor_payout" value="<?= $advisor_payout ?>"
                                                    step="<?= $is_loan ? '0.01' : '100' ?>" min="0" max="<?= $your_payout ?>"
                                                    class="w-24 px-2 py-1 border rounded text-center advisor-payout <?= $is_default ? 'bg-yellow-50 border-yellow-300' : '' ?>"
                                                    data-your-payout="<?= $your_payout ?>"
                                                    data-is-loan="<?= $is_loan ? '1' : '0' ?>" onchange="updateMargin(this)"
                                                    <?= $is_default ? 'placeholder="Default: ' . $symbol . number_format($advisor_payout, $is_loan ? 2 : 0) . '"' : '' ?>>
                                                <?php if ($is_default): ?>
                                                    <small class="text-yellow-600 block text-xs mt-1">Default Rate</small>
                                                <?php endif; ?>
                                            </td>
                                            <td class="px-4 py-3 text-center">
                                                <span
                                                    class="margin-display font-bold <?= $margin >= 0 ? 'margin-positive' : 'margin-negative' ?>">
                                                    <?= $symbol ?>         <?= number_format($margin, $is_loan ? 2 : 0) ?>
                                                </span>
                                            </td>
                                            <td class="px-4 py-3 text-center">
                                                <button type="submit" name="save_payouts"
                                                    class="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 transition">
                                                    <i class="fas fa-save mr-1"></i>Save
                                                </button>
                                            </td>
                                        </form>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
        function updateMargin(input) {
            const yourPayout = parseFloat(input.dataset.yourPayout);
            const advisorPayout = parseFloat(input.value) || 0;
            const isLoan = input.dataset.isLoan === '1';
            const margin = yourPayout - advisorPayout;

            const row = input.closest('tr');
            const marginDisplay = row.querySelector('.margin-display');
            const symbol = isLoan ? '%' : '₹';
            const decimals = isLoan ? 2 : 0;

            marginDisplay.textContent = symbol + margin.toFixed(decimals);
            marginDisplay.className = 'margin-display font-bold ' + (margin >= 0 ? 'margin-positive' : 'margin-negative');

            // Validate: advisor payout should not exceed your payout
            if (advisorPayout > yourPayout) {
                input.classList.add('border-red-500');
            } else {
                input.classList.remove('border-red-500');
            }
        }
    </script>
    <script src="/assets/js/loading.js"></script>
</body>

</html>