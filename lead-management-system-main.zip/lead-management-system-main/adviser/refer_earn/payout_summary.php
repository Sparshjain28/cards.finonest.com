<?php
// This file is intentionally minimal - the product payout settings table
// is now displayed in team_payouts.php to avoid duplication
?>