<?php
// My Team Module - Shows team members based on partner type

$user_id = $user['id'];
$partner_type = $user['partner_type'];

// Debug: Force network_partner if not set
if (empty($partner_type)) {
    $conn->query("UPDATE users SET partner_type = 'network_partner' WHERE id = $user_id");
    $partner_type = 'network_partner';
}

// Determine which levels to show
$levels_to_show = [];
if ($partner_type === 'network_partner') {
    $levels_to_show = [1, 2, 3];
} else {
    $levels_to_show = [1];
}

// Debug output
echo "<!-- Debug: User ID: $user_id, Partner Type: $partner_type, Levels: " . implode(',', $levels_to_show) . " -->";

$active_level = isset($_GET['level']) ? (int)$_GET['level'] : 1;
if (!in_array($active_level, $levels_to_show)) {
    $active_level = 1;
}

// Function to get team members by level
function getTeamMembersByLevel($conn, $user_id, $level, $partner_type) {
    if ($partner_type !== 'network_partner' && $level > 1) {
        return [];
    }

    // Temporary recursive function to get team members
    $getTeamRecursive = function($conn, $referrer_ids, $current_level, $target_level) use (&$getTeamRecursive) {
        if ($current_level > $target_level || empty($referrer_ids)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($referrer_ids), '?'));
        $types = str_repeat('i', count($referrer_ids));

        $query = "SELECT ru.referred_user_id, u.id, u.name, u.phone, u.city, u.location, u.created_at, ru.signup_date, ru.status
                  FROM referral_users ru
                  JOIN users u ON ru.referred_user_id = u.id
                  WHERE ru.referrer_user_id IN ($placeholders) AND ru.level = 1";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param($types, ...$referrer_ids);
        $stmt->execute();
        $result = $stmt->get_result();
        $members = [];
        $next_referrer_ids = [];
        
        while ($row = $result->fetch_assoc()) {
            if ($current_level === $target_level) {
                $members[] = $row;
            }
            $next_referrer_ids[] = $row['referred_user_id'];
        }
        $stmt->close();

        if ($current_level < $target_level) {
            return $getTeamRecursive($conn, $next_referrer_ids, $current_level + 1, $target_level);
        }
        
        return $members;
    };

    return $getTeamRecursive($conn, [$user_id], 1, $level);
}

// Function to mask mobile number
function maskMobile($phone) {
    if (empty($phone) || strlen($phone) < 4) return $phone;
    $phone = preg_replace('/[^0-9]/', '', $phone);
    if (strlen($phone) >= 10) {
        return substr($phone, 0, 2) . str_repeat('*', strlen($phone) - 5) . substr($phone, -3);
    }
    return $phone;
}

// Get counts for each level
$level_counts = [];
foreach ($levels_to_show as $lvl) {
    $members = getTeamMembersByLevel($conn, $user_id, $lvl, $partner_type);
    $level_counts[$lvl] = count($members);
}

// Get current level members
$team_members = getTeamMembersByLevel($conn, $user_id, $active_level, $partner_type);
?>

<?php include 'team-hierarchy.php'; ?>

<div class="bg-white rounded-lg shadow-sm p-6">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h2 class="text-xl font-semibold text-slate-900">My Team</h2>
            <p class="text-sm text-slate-600 mt-1">
                <?php if ($partner_type === 'network_partner'): ?>
                    View your 3-level referral network. Earn 5% from Level 1, 2% from Level 2, and 1% from Level 3.
                <?php else: ?>
                    View your direct team members. Set custom payout rates for each advisor.
                <?php endif; ?>
            </p>
        </div>
        <div class="text-sm text-slate-600">
            Total Members: <span class="font-bold text-blue-600"><?= array_sum($level_counts) ?></span>
        </div>
    </div>

    <!-- Hierarchy Explanation -->
    <?php if ($partner_type === 'network_partner' && $active_level > 1): ?>
        <div class="bg-blue-50 border-l-4 border-blue-400 p-4 mb-6 rounded">
            <div class="flex items-start">
                <i class="fas fa-info-circle text-blue-600 mt-1 mr-3"></i>
                <div>
                    <p class="text-sm text-blue-800 font-medium mb-1">Level <?= $active_level ?> Explanation</p>
                    <p class="text-xs text-blue-700">
                        These are users referred by your Level <?= $active_level - 1 ?> team members. 
                        You earn <?= $active_level === 2 ? '2%' : '1%' ?> from their successful applications.
                        <?php if ($active_level === 2): ?>
                            For example: You referred User A (Level 1), User A referred User B (Level 2) - you see User B here.
                        <?php else: ?>
                            For example: User A (L1) referred User B (L2), User B referred User C (L3) - you see User C here.
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Level Tabs -->
    <div class="flex gap-2 mb-6 border-b border-slate-200">
        <?php foreach ($levels_to_show as $lvl): ?>
            <button onclick="loadLevel(<?= $lvl ?>)" 
                    class="px-4 py-2 font-medium text-slate-700 hover:text-blue-600 border-b-2 transition <?= $active_level === $lvl ? 'border-blue-600 text-blue-600' : 'border-transparent' ?>">
                Level <?= $lvl ?>
                <?php if ($partner_type === 'network_partner'): ?>
                    <span class="text-xs text-slate-500 ml-1">
                        (<?= $lvl === 1 ? '5%' : ($lvl === 2 ? '2%' : '1%') ?>)
                    </span>
                <?php endif; ?>
                <span class="ml-2 bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full text-xs">
                    <?= $level_counts[$lvl] ?? 0 ?>
                </span>
            </button>
        <?php endforeach; ?>
    </div>

  

    <!-- Team Members Table -->
    <?php if (empty($team_members)): ?>
        <div class="text-center py-12">
            <i class="fas fa-users text-4xl text-slate-300 mb-4"></i>
            <p class="text-slate-600">No team members at Level <?= $active_level ?> yet.</p>
            <p class="text-sm text-slate-500 mt-2">Share your referral link to start building your team!</p>
            <?php if ($active_level === 1): ?>
                <div class="mt-4">
                    <?php
                    // Check if referral link exists
                    $check_ref_link = $conn->prepare("SELECT id FROM referral_links WHERE user_id = ?");
                    $check_ref_link->bind_param("i", $user_id);
                    $check_ref_link->execute();
                    $has_link = $check_ref_link->get_result()->num_rows > 0;
                    $check_ref_link->close();
                    ?>
                    <?php if (!$has_link): ?>
                        <button onclick="createReferralLink()" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 text-sm font-medium">
                            <i class="fas fa-link mr-2"></i>Create Your Referral Link
                        </button>
                    <?php else: ?>
                        <button onclick="scrollToReferralLink()" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 text-sm font-medium">
                            <i class="fas fa-link mr-2"></i>View Your Referral Link
                        </button>
                    <?php endif; ?>
                    <p class="text-xs text-slate-500 mt-2">Your referral link is displayed at the top of this page</p>
                </div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-slate-50">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Name</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Mobile</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Location</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Join Date</th>
                        <?php if ($partner_type === 'network_partner'): ?>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Earning Rate</th>
                        <?php endif; ?>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200">
                    <?php foreach ($team_members as $member): ?>
                        <tr class="hover:bg-slate-50">
                            <td class="px-4 py-3">
                                <div class="flex items-center">
                                    <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                                        <span class="text-blue-600 font-semibold text-sm">
                                            <?= strtoupper(substr($member['name'], 0, 1)) ?>
                                        </span>
                                    </div>
                                    <span class="font-medium text-slate-900"><?= htmlspecialchars($member['name']) ?></span>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-slate-600">
                                <?= htmlspecialchars(maskMobile($member['phone'] ?? '')) ?>
                            </td>
                            <td class="px-4 py-3 text-slate-600">
                                <?= htmlspecialchars($member['city'] ?? $member['location'] ?? 'N/A') ?>
                            </td>
                            <td class="px-4 py-3 text-slate-600">
                                <?= date('d M Y', strtotime($member['signup_date'] ?? $member['created_at'])) ?>
                            </td>
                            <?php if ($partner_type === 'network_partner'): ?>
                            <td class="px-4 py-3">
                                <span class="px-2 py-1 text-xs rounded-full bg-purple-100 text-purple-700 font-semibold">
                                    <?= $active_level === 1 ? '5%' : ($active_level === 2 ? '2%' : '1%') ?>
                                </span>
                            </td>
                            <?php endif; ?>
                            <td class="px-4 py-3">
                                <span class="px-2 py-1 text-xs rounded-full <?= ($member['status'] ?? 'active') === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-700' ?>">
                                    <?= ucfirst($member['status'] ?? 'Active') ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
function loadLevel(level) {
    window.location.href = '?tab=team&level=' + level;
}
</script>
