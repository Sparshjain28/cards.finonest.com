<?php
// My Team Leads Module - Shows all leads from team members

// Include required files if not already included
if (!function_exists('getCurrentUser')) {
    require_once __DIR__ . '/../../includes/auth.php';
    require_once __DIR__ . '/../../config/database_updated.php';
    
    requireLogin();
    $user = getCurrentUser();
    $database = new Database();
    $conn = $database->getConnection();
}

$user_id = $user['id'];
$partner_type = $user['partner_type'];

// Get filters
$filter_advisor = $_GET['advisor'] ?? '';
$filter_product = $_GET['product'] ?? '';
$filter_status = $_GET['status'] ?? '';

// Build query to get team member IDs
if ($partner_type === 'network_partner') {
    // Get all team members from 3 levels
    // Try referral_hierarchy first, fallback to referral_users
    try {
        $team_query = "SELECT DISTINCT referred_user_id as user_id FROM referral_hierarchy WHERE referrer_user_id = ?
                       UNION
                       SELECT DISTINCT referred_user_id as user_id FROM referral_users WHERE referrer_user_id = ?";
        $team_stmt = $conn->prepare($team_query);
        if ($team_stmt) {
            $team_stmt->bind_param("ii", $user_id, $user_id);
        } else {
            throw new Exception("Prepare failed");
        }
    } catch (Exception $e) {
        // Fallback to referral_users only if referral_hierarchy doesn't exist
        $team_query = "SELECT DISTINCT referred_user_id as user_id FROM referral_users WHERE referrer_user_id = ?";
        $team_stmt = $conn->prepare($team_query);
        $team_stmt->bind_param("i", $user_id);
    }
} else {
    // Channel partner: only direct referrals
    $team_query = "SELECT DISTINCT referred_user_id as user_id FROM referral_users WHERE referrer_user_id = ?";
    $team_stmt = $conn->prepare($team_query);
    $team_stmt->bind_param("i", $user_id);
}

$team_stmt->execute();
$team_result = $team_stmt->get_result();
$team_user_ids = [];
while ($row = $team_result->fetch_assoc()) {
    $team_user_ids[] = $row['user_id'];
}
$team_stmt->close();

// Get channel codes for team members with referrer info
$channel_codes = [];
$team_members = [];
if (!empty($team_user_ids)) {
    $placeholders = str_repeat('?,', count($team_user_ids) - 1) . '?';
    $channel_query = "SELECT u.channel_code, u.id, u.name, r.name as referrer_name 
                     FROM users u 
                     LEFT JOIN users r ON u.parent_id = r.id 
                     WHERE u.id IN ($placeholders)";
    $channel_stmt = $conn->prepare($channel_query);
    $channel_stmt->bind_param(str_repeat('i', count($team_user_ids)), ...$team_user_ids);
    $channel_stmt->execute();
    $channel_result = $channel_stmt->get_result();
    while ($row = $channel_result->fetch_assoc()) {
        $channel_codes[] = $row['channel_code'];
        $team_members[$row['channel_code']] = [
            'name' => $row['name'],
            'referrer_name' => $row['referrer_name'] ?? 'Direct'
        ];
    }
    $channel_stmt->close();
}

// Build leads query
$where_conditions = [];
$params = [];
$types = '';

if (!empty($channel_codes)) {
    $placeholders = str_repeat('?,', count($channel_codes) - 1) . '?';
    $where_conditions[] = "l.channel_code IN ($placeholders)";
    $params = array_merge($params, $channel_codes);
    $types .= str_repeat('s', count($channel_codes));
} else {
    // Fallback: Check direct parent_id relationship
    $direct_query = "SELECT channel_code FROM users WHERE parent_id = ?";
    $direct_stmt = $conn->prepare($direct_query);
    $direct_stmt->bind_param("i", $user_id);
    $direct_stmt->execute();
    $direct_result = $direct_stmt->get_result();
    $direct_codes = [];
    while ($row = $direct_result->fetch_assoc()) {
        $direct_codes[] = $row['channel_code'];
    }
    $direct_stmt->close();
    
    if (!empty($direct_codes)) {
        $placeholders = str_repeat('?,', count($direct_codes) - 1) . '?';
        $where_conditions[] = "l.channel_code IN ($placeholders)";
        $params = array_merge($params, $direct_codes);
        $types .= str_repeat('s', count($direct_codes));
        $channel_codes = $direct_codes;
    } else {
        $where_conditions[] = "1 = 0";
    }
}

if ($filter_advisor) {
    $where_conditions[] = "l.channel_code = ?";
    $params[] = $filter_advisor;
    $types .= 's';
}

if ($filter_status) {
    $where_conditions[] = "l.status = ?";
    $params[] = $filter_status;
    $types .= 's';
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

$leads_query = "SELECT l.*, p.name as product_name, p.category as product_category, p.commission_rate,
                       u.name as advisor_name, u.channel_code,
                       COALESCE(l.commission, p.commission_rate, 0) as display_amount
                FROM leads l
                JOIN products p ON l.product_id = p.id
                JOIN users u ON l.channel_code = u.channel_code
                $where_clause
                ORDER BY l.created_at DESC
                LIMIT 100";

$leads_stmt = $conn->prepare($leads_query);
if (!empty($params)) {
    $leads_stmt->bind_param($types, ...$params);
}
$leads_stmt->execute();
$leads = $leads_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$leads_stmt->close();

// Get unique advisors and products for filters
$advisors = [];
$products = [];
foreach ($leads as $lead) {
    if (!empty($lead['advisor_name']) && isset($team_members[$lead['channel_code']])) {
        $referrer = $team_members[$lead['channel_code']]['referrer_name'];
        $advisors[$lead['channel_code']] = $lead['advisor_name'] . ' (by ' . $referrer . ')';
    }
    if (!empty($lead['product_name'])) {
        $products[$lead['product_name']] = $lead['product_category'];
    }
}
?>

<div class="bg-white rounded-lg shadow-sm p-6">
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-xl font-semibold text-slate-900">My Team Leads</h2>
        <div class="text-sm text-slate-600">
            Total Leads: <span class="font-bold text-blue-600"><?= count($leads) ?></span>
        </div>
    </div>

    <!-- Filters -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Filter by Advisor</label>
            <select id="filterAdvisor" onchange="applyFilters()" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="">All Advisors</option>
                <?php foreach ($advisors as $code => $name): ?>
                    <option value="<?= htmlspecialchars($code) ?>" <?= $filter_advisor === $code ? 'selected' : '' ?>>
                        <?= htmlspecialchars($name) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Filter by Product</label>
            <select id="filterProduct" onchange="applyFilters()" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="">All Products</option>
                <?php foreach ($products as $name => $category): ?>
                    <option value="<?= htmlspecialchars($name) ?>" <?= $filter_product === $name ? 'selected' : '' ?>>
                        <?= htmlspecialchars($name) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Filter by Status</label>
            <select id="filterStatus" onchange="applyFilters()" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="">All Status</option>
                <option value="generated" <?= $filter_status === 'generated' ? 'selected' : '' ?>>Generated</option>
                <option value="yet_to_start" <?= $filter_status === 'yet_to_start' ? 'selected' : '' ?>>Yet to Start</option>
                <option value="in_process" <?= $filter_status === 'in_process' ? 'selected' : '' ?>>In Process</option>
                <option value="approved" <?= $filter_status === 'approved' ? 'selected' : '' ?>>Approved</option>
                <option value="activated" <?= $filter_status === 'activated' ? 'selected' : '' ?>>Activated</option>
                <option value="disbursed" <?= $filter_status === 'disbursed' ? 'selected' : '' ?>>Disbursed</option>
                <option value="declined" <?= $filter_status === 'declined' ? 'selected' : '' ?>>Declined</option>
            </select>
        </div>
    </div>

    <!-- Leads Table -->
    <?php if (empty($leads)): ?>
        <div class="text-center py-12">
            <i class="fas fa-briefcase text-4xl text-slate-300 mb-4"></i>
            <p class="text-slate-600">No leads from your team yet.</p>
        </div>
    <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-slate-50">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Customer Name</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Product</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Amount</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Advisor</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Status</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Date</th>
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200">
                    <?php foreach ($leads as $lead): ?>
                        <tr class="hover:bg-slate-50">
                            <td class="px-4 py-3 font-medium text-slate-900">
                                <?= htmlspecialchars($lead['customer_name'] ?? $lead['name']) ?>
                            </td>
                            <td class="px-4 py-3">
                                <div class="text-sm">
                                    <div class="font-medium text-slate-900"><?= htmlspecialchars($lead['product_name']) ?></div>
                                    <div class="text-xs text-slate-500"><?= htmlspecialchars($lead['product_category']) ?></div>
                                </div>
                            </td>
                            <td class="px-4 py-3 text-slate-600">
                                ₹<?= number_format($lead['display_amount'] ?? 0, 2) ?>
                            </td>
                            <td class="px-4 py-3 text-slate-600">
                                <?= htmlspecialchars($lead['advisor_name'] ?? 'N/A') ?>
                            </td>
                            <td class="px-4 py-3">
                                <?php
                                $status = $lead['status'];
                                $status_colors = [
                                    'generated' => 'bg-blue-100 text-blue-700',
                                    'yet_to_start' => 'bg-yellow-100 text-yellow-700',
                                    'in_process' => 'bg-purple-100 text-purple-700',
                                    'approved' => 'bg-green-100 text-green-700',
                                    'activated' => 'bg-emerald-100 text-emerald-700',
                                    'disbursed' => 'bg-teal-100 text-teal-700',
                                    'declined' => 'bg-red-100 text-red-700'
                                ];
                                $color_class = $status_colors[$status] ?? 'bg-slate-100 text-slate-700';
                                ?>
                                <span class="px-2 py-1 text-xs rounded-full <?= $color_class ?>">
                                    <?= ucfirst(str_replace('_', ' ', $status)) ?>
                                </span>
                            </td>
                            <td class="px-4 py-3 text-slate-600 text-sm">
                                <?= date('d M Y', strtotime($lead['created_at'])) ?>
                            </td>
                            <td class="px-4 py-3">
                                <?php if (in_array($status, ['generated', 'yet_to_start', 'in_process'])): ?>
                                    <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $lead['mobile']) ?>?text=Hi%20<?= urlencode($lead['customer_name']) ?>,%20your%20application%20for%20<?= urlencode($lead['product_name']) ?>%20is%20pending.%20Please%20complete%20the%20required%20steps." 
                                       target="_blank"
                                       class="inline-flex items-center px-3 py-1 bg-green-500 text-white text-xs rounded-lg hover:bg-green-600">
                                        <i class="fab fa-whatsapp mr-1"></i> Nudge
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
function applyFilters() {
    const advisor = document.getElementById('filterAdvisor').value;
    const product = document.getElementById('filterProduct').value;
    const status = document.getElementById('filterStatus').value;
    
    const params = new URLSearchParams();
    params.set('tab', 'leads');
    if (advisor) params.set('advisor', advisor);
    if (product) params.set('product', product);
    if (status) params.set('status', status);
    
    window.location.href = '?' + params.toString();
}
</script>

