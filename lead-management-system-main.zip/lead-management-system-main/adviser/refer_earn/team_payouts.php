<?php
require_once __DIR__ . '/../../includes/auth.php';
requireLogin();
$user = getCurrentUser();

$database = new Database();
$conn = $database->getConnection();

$user_id = $user['id'];
$partner_type = $user['partner_type'];

// Get team members
$team_query = "SELECT DISTINCT u.id, u.name, u.channel_code FROM referral_users ru JOIN users u ON ru.referred_user_id = u.id WHERE ru.referrer_user_id = ? AND ru.level = 1 ORDER BY u.name";
$team_stmt = $conn->prepare($team_query);
$team_stmt->bind_param("i", $user_id);
$team_stmt->execute();
$team_members = $team_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$team_stmt->close();

// Get products
$products_query = "SELECT id, name, category, variant, commission_rate FROM products WHERE status = 'active' ORDER BY category, variant, name";
$products_result = $conn->query($products_query);
$all_products = [];
while ($product = $products_result->fetch_assoc()) {
    $all_products[] = $product;
}

// Handle save product payout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_product_payout'])) {
    $product_id = intval($_POST['product_id']);
    $advisor_payout = floatval($_POST['advisor_payout']);
    $product_category = $_POST['product_category'];
    $advisor_id = intval($_POST['advisor_id']);
    $rate_type = $product_category === 'Credit Card' ? 'card_amount' : 'loan_percentage';

    $check_stmt = $conn->prepare("SELECT id FROM payout_settings WHERE user_id = ? AND product_id = ? AND advisor_user_id = ?");
    $check_stmt->bind_param("iii", $user_id, $product_id, $advisor_id);
    $check_stmt->execute();
    $existing = $check_stmt->get_result()->fetch_assoc();
    $check_stmt->close();

    if ($existing) {
        $update_stmt = $conn->prepare("UPDATE payout_settings SET payout_rate = ?, updated_at = NOW() WHERE id = ?");
        $update_stmt->bind_param("di", $advisor_payout, $existing['id']);
        $update_stmt->execute();
        $update_stmt->close();
    } else {
        $insert_stmt = $conn->prepare("INSERT INTO payout_settings (user_id, advisor_user_id, product_id, product_category, payout_rate, rate_type, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $insert_stmt->bind_param("iiisds", $user_id, $advisor_id, $product_id, $product_category, $advisor_payout, $rate_type);
        $insert_stmt->execute();
        $insert_stmt->close();
    }
    $success = 'Payout settings saved successfully!';
}

// Get selected advisor
$selected_advisor_id = $_POST['advisor_id'] ?? $_GET['advisor_id'] ?? null;
$advisor_payout_settings = [];

if ($selected_advisor_id) {
    $advisor_settings_query = "SELECT product_id, payout_rate FROM payout_settings WHERE user_id = ? AND advisor_user_id = ?";
    $advisor_settings_stmt = $conn->prepare($advisor_settings_query);
    $advisor_settings_stmt->bind_param("ii", $user_id, $selected_advisor_id);
    $advisor_settings_stmt->execute();
    $advisor_settings_result = $advisor_settings_stmt->get_result();
    while ($row = $advisor_settings_result->fetch_assoc()) {
        $advisor_payout_settings[$row['product_id']] = $row['payout_rate'];
    }
    $advisor_settings_stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team Payouts</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="max-w-7xl mx-auto px-4 py-6">
        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h1 class="text-2xl font-bold mb-2">
                <i class="fas fa-users-cog mr-2 text-blue-600"></i>Product Payout Settings by Advisor
            </h1>
            <p class="text-slate-600">Configure individual payout rates for your team members</p>
        </div>

        <?php if (isset($success)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <i class="fas fa-check-circle mr-2"></i><?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <?php if (empty($team_members)): ?>
            <div class="bg-white rounded-lg shadow p-8 text-center">
                <i class="fas fa-info-circle text-4xl text-gray-400 mb-4"></i>
                <h3 class="text-lg font-semibold text-gray-700 mb-2">No Team Members Found</h3>
                <p class="text-gray-500">Add advisors to your team to configure their payout rates.</p>
            </div>
        <?php else: ?>
            <!-- Advisor Selection -->
            <div class="bg-white rounded-lg shadow p-6 mb-6">
                <h3 class="text-lg font-semibold mb-4">
                    <i class="fas fa-user-cog mr-2"></i>Select Advisor
                </h3>
                <form method="POST" class="flex items-center gap-4">
                    <select name="advisor_id" class="border rounded px-3 py-2 min-w-80" required onchange="this.form.submit()">
                        <option value="">Choose an advisor...</option>
                        <?php foreach ($team_members as $member): ?>
                            <option value="<?= $member['id'] ?>" <?= $selected_advisor_id == $member['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($member['name']) ?> (Code: <?= htmlspecialchars($member['channel_code']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>

            <?php if ($selected_advisor_id): ?>
                <?php 
                $selected_advisor = null;
                foreach ($team_members as $member) {
                    if ($member['id'] == $selected_advisor_id) {
                        $selected_advisor = $member;
                        break;
                    }
                }
                ?>
                
                <div class="bg-white rounded-lg shadow p-6">
                    <h3 class="text-lg font-semibold mb-4 text-slate-800 bg-gradient-to-r from-blue-50 to-purple-50 px-4 py-3 rounded-lg border-l-4 border-blue-600">
                        <i class="fas fa-user-circle mr-2 text-blue-600"></i>
                        <?= htmlspecialchars($selected_advisor['name']) ?>
                        <span class="text-sm text-gray-500 ml-2">(Code: <?= htmlspecialchars($selected_advisor['channel_code']) ?>)</span>
                    </h3>

                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse text-sm">
                            <thead>
                                <tr class="bg-slate-100">
                                    <th class="px-3 py-2 text-left font-semibold text-slate-600 uppercase text-xs">Category</th>
                                    <th class="px-3 py-2 text-left font-semibold text-slate-600 uppercase text-xs">Bank</th>
                                    <th class="px-3 py-2 text-left font-semibold text-slate-600 uppercase text-xs">Product</th>
                                    <th class="px-3 py-2 text-center font-semibold text-slate-600 uppercase text-xs">Your Payout</th>
                                    <th class="px-3 py-2 text-center font-semibold text-slate-600 uppercase text-xs">Advisor Payout</th>
                                    <th class="px-3 py-2 text-center font-semibold text-slate-600 uppercase text-xs">Margin</th>
                                    <th class="px-3 py-2 text-center font-semibold text-slate-600 uppercase text-xs">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($all_products as $prod):
                                    $your_payout = floatval($prod['commission_rate']);
                                    $advisor_payout = isset($advisor_payout_settings[$prod['id']]) ? floatval($advisor_payout_settings[$prod['id']]) : 0;
                                    $margin = $your_payout - $advisor_payout;
                                    $is_loan = ($prod['category'] !== 'Credit Card');
                                    $symbol = $is_loan ? '' : '₹';
                                    $suffix = $is_loan ? '%' : '';
                                ?>
                                    <tr class="border-b hover:bg-slate-50">
                                        <form method="POST">
                                            <input type="hidden" name="product_id" value="<?= $prod['id'] ?>">
                                            <input type="hidden" name="product_category" value="<?= htmlspecialchars($prod['category']) ?>">
                                            <input type="hidden" name="advisor_id" value="<?= $selected_advisor_id ?>">

                                            <td class="px-3 py-2 text-slate-700"><?= htmlspecialchars($prod['category']) ?></td>
                                            <td class="px-3 py-2 text-slate-700 font-medium"><?= htmlspecialchars($prod['variant'] ?? '-') ?></td>
                                            <td class="px-3 py-2 text-slate-900 font-medium"><?= htmlspecialchars($prod['name']) ?></td>
                                            <td class="px-3 py-2 text-center">
                                                <span class="text-green-600 font-bold"><?= $symbol ?><?= number_format($your_payout, $is_loan ? 2 : 0) ?><?= $suffix ?></span>
                                            </td>
                                            <td class="px-3 py-2 text-center">
                                                <input type="number" name="advisor_payout" value="<?= $advisor_payout ?>"
                                                       step="<?= $is_loan ? '0.01' : '100' ?>" min="0" max="<?= $your_payout ?>"
                                                       class="w-20 px-2 py-1 border rounded text-center text-sm"
                                                       onchange="updateMargin(this, <?= $your_payout ?>, <?= $is_loan ? 'true' : 'false' ?>)">
                                            </td>
                                            <td class="px-3 py-2 text-center">
                                                <span class="margin-val font-bold <?= $margin >= 0 ? 'text-green-600' : 'text-red-600' ?>">
                                                    <?= $symbol ?><?= number_format($margin, $is_loan ? 2 : 0) ?><?= $suffix ?>
                                                </span>
                                            </td>
                                            <td class="px-3 py-2 text-center">
                                                <button type="submit" name="save_product_payout"
                                                        class="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700">
                                                    <i class="fas fa-save mr-1"></i>SAVE
                                                </button>
                                            </td>
                                        </form>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-lg shadow p-8 text-center">
                    <i class="fas fa-arrow-up text-4xl text-gray-400 mb-4"></i>
                    <p class="text-gray-500">Please select an advisor from the dropdown above to configure their payout settings.</p>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <script>
        function updateMargin(input, yourPayout, isLoan) {
            const advisorPayout = parseFloat(input.value) || 0;
            const margin = yourPayout - advisorPayout;
            const row = input.closest('tr');
            const marginDisplay = row.querySelector('.margin-val');
            const symbol = isLoan ? '' : '₹';
            const suffix = isLoan ? '%' : '';
            const decimals = isLoan ? 2 : 0;

            marginDisplay.textContent = symbol + margin.toFixed(decimals) + suffix;
            marginDisplay.className = 'margin-val font-bold ' + (margin >= 0 ? 'text-green-600' : 'text-red-600');
        }
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>