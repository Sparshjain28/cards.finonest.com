<?php

require_once __DIR__ . '/../../includes/auth.php';

requireLogin();
$user = getCurrentUser();

// Database connection using mysqli
$host = getenv('DB_HOST') ?: 'g0co8w4wgso8ow00sk4k0oks';
$port = getenv('DB_PORT') ?: '3306';
$db_name = getenv('DB_NAME') ?: 'leadmanagement';
$username = getenv('DB_USERNAME') ?: 'leadmanagementadmin';
$password = getenv('DB_PASSWORD') ?: 'sparshjain@28';

$conn = new mysqli($host, $username, $password, $db_name, $port);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

$user_id = $user['id'];
$partner_type = $user['partner_type'];
$active_subsection = $_GET['subsection'] ?? 'settings';

// Get all products
$products_query = "SELECT id, name, category, commission_rate FROM products WHERE status = 'active' ORDER BY category, name";
$products_result = $conn->query($products_query);
$products = [];
while ($row = $products_result->fetch_assoc()) {
    $products[] = $row;
}

// Get team members
$team_query = "SELECT DISTINCT u.id, u.name, u.channel_code FROM referral_users ru JOIN users u ON ru.referred_user_id = u.id WHERE ru.referrer_user_id = ? AND ru.level = 1 ORDER BY u.name";
$team_stmt = $conn->prepare($team_query);
$team_stmt->bind_param("i", $user_id);
$team_stmt->execute();
$team_members = $team_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$team_stmt->close();

// Handle AJAX auto-save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['auto_save']) && $partner_type === 'channel_partner') {
    $advisor_id = (int) $_POST['advisor_id'];
    $product_id = !empty($_POST['product_id']) ? (int) $_POST['product_id'] : null;
    $rate_type = $_POST['rate_type'];
    $payout_rate = (float) $_POST['payout_rate'];

    $check_stmt = $conn->prepare("SELECT id FROM payout_settings WHERE user_id = ? AND advisor_user_id = ? AND (product_id = ? OR (product_id IS NULL AND ? IS NULL))");
    $check_stmt->bind_param("iiii", $user_id, $advisor_id, $product_id, $product_id);
    $check_stmt->execute();
    $existing = $check_stmt->get_result()->fetch_assoc();
    $check_stmt->close();

    if ($existing) {
        $update_stmt = $conn->prepare("UPDATE payout_settings SET payout_rate = ?, rate_type = ?, is_custom_rate = 1, updated_at = NOW() WHERE id = ?");
        $update_stmt->bind_param("dsi", $payout_rate, $rate_type, $existing['id']);
        $update_stmt->execute();
        $update_stmt->close();
    } else {
        $category = null;
        if ($product_id) {
            foreach ($products as $p) {
                if ($p['id'] == $product_id) {
                    $category = $p['category'];
                    break;
                }
            }
        }
        $insert_stmt = $conn->prepare("INSERT INTO payout_settings (user_id, advisor_user_id, product_id, product_category, payout_rate, rate_type, is_custom_rate) VALUES (?, ?, ?, ?, ?, ?, 1)");
        $insert_stmt->bind_param("iiisds", $user_id, $advisor_id, $product_id, $category, $payout_rate, $rate_type);
        $insert_stmt->execute();
        $insert_stmt->close();
    }
    echo json_encode(['success' => true]);
    exit;
}

// Handle edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_setting']) && $partner_type === 'channel_partner') {
    $setting_id = (int) $_POST['setting_id'];
    $rate_type = $_POST['rate_type'];
    $payout_rate = (float) $_POST['payout_rate'];

    $update_stmt = $conn->prepare("UPDATE payout_settings SET payout_rate = ?, rate_type = ?, updated_at = NOW() WHERE id = ? AND user_id = ?");
    $update_stmt->bind_param("dsii", $payout_rate, $rate_type, $setting_id, $user_id);
    $update_stmt->execute();
    $update_stmt->close();
    $success = 'Rate updated successfully!';
}

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_setting']) && $partner_type === 'channel_partner') {
    $setting_id = (int) $_POST['setting_id'];
    $delete_stmt = $conn->prepare("DELETE FROM payout_settings WHERE id = ? AND user_id = ?");
    $delete_stmt->bind_param("ii", $setting_id, $user_id);
    $delete_stmt->execute();
    $delete_stmt->close();
    $success = 'Deleted successfully!';
}

// Handle save product payout (new table format)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_product_payout'])) {
    $product_id = intval($_POST['product_id']);
    $advisor_payout = floatval($_POST['advisor_payout']);
    $product_category = $_POST['product_category'];
    $advisor_id = intval($_POST['advisor_id']); // Get the advisor ID from the form
    $rate_type = $product_category === 'Credit Card' ? 'card_amount' : 'loan_percentage';

    // Check if setting already exists for this advisor
    $check_stmt = $conn->prepare("SELECT id FROM payout_settings WHERE user_id = ? AND product_id = ? AND advisor_user_id = ?");
    $check_stmt->bind_param("iii", $user_id, $product_id, $advisor_id);
    $check_stmt->execute();
    $existing = $check_stmt->get_result()->fetch_assoc();
    $check_stmt->close();

    if ($existing) {
        // Update existing
        $update_stmt = $conn->prepare("UPDATE payout_settings SET payout_rate = ?, updated_at = NOW() WHERE id = ?");
        $update_stmt->bind_param("di", $advisor_payout, $existing['id']);
        $update_stmt->execute();
        $update_stmt->close();
    } else {
        // Insert new - use advisor_id from form
        $insert_stmt = $conn->prepare("INSERT INTO payout_settings (user_id, advisor_user_id, product_id, product_category, payout_rate, rate_type, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $insert_stmt->bind_param("iiisds", $user_id, $advisor_id, $product_id, $product_category, $advisor_payout, $rate_type);
        $insert_stmt->execute();
        $insert_stmt->close();
    }

    $success = 'Payout settings saved successfully!';
}

// Handle save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_payout_setting']) && $partner_type === 'channel_partner') {
    $advisor_id = (int) $_POST['advisor_id'];
    $product_id = !empty($_POST['product_id']) ? (int) $_POST['product_id'] : null;
    $rate_type = $_POST['rate_type'];
    $payout_rate = (float) $_POST['payout_rate'];

    if (empty($error)) {
        $check_stmt = $conn->prepare("SELECT id FROM payout_settings WHERE user_id = ? AND advisor_user_id = ? AND (product_id = ? OR (product_id IS NULL AND ? IS NULL))");
        $check_stmt->bind_param("iiii", $user_id, $advisor_id, $product_id, $product_id);
        $check_stmt->execute();
        $existing = $check_stmt->get_result()->fetch_assoc();
        $check_stmt->close();

        if ($existing) {
            $update_stmt = $conn->prepare("UPDATE payout_settings SET payout_rate = ?, rate_type = ?, is_custom_rate = 1, updated_at = NOW() WHERE id = ?");
            $update_stmt->bind_param("dsi", $payout_rate, $rate_type, $existing['id']);
            $update_stmt->execute();
            $update_stmt->close();
        } else {
            $category = null;
            if ($product_id) {
                foreach ($products as $p) {
                    if ($p['id'] == $product_id) {
                        $category = $p['category'];
                        break;
                    }
                }
            }
            $insert_stmt = $conn->prepare("INSERT INTO payout_settings (user_id, advisor_user_id, product_id, product_category, payout_rate, rate_type, is_custom_rate) VALUES (?, ?, ?, ?, ?, ?, 1)");
            $insert_stmt->bind_param("iiisds", $user_id, $advisor_id, $product_id, $category, $payout_rate, $rate_type);
            $insert_stmt->execute();
            $insert_stmt->close();
        }
        $success = 'Saved successfully!';
    }
}

// Get settings
$payout_settings = [];
if ($partner_type === 'channel_partner') {
    $settings_stmt = $conn->prepare("SELECT ps.*, u.name as advisor_name, p.name as product_name FROM payout_settings ps JOIN users u ON ps.advisor_user_id = u.id LEFT JOIN products p ON ps.product_id = p.id WHERE ps.user_id = ? ORDER BY u.name, p.name");
    $settings_stmt->bind_param("i", $user_id);
    $settings_stmt->execute();
    $payout_settings = $settings_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $settings_stmt->close();
}

// Get ledger
$ledger_stmt = $conn->prepare("SELECT pl.*, u.name as source_name, l.lead_id, l.customer_name, p.name as product_name FROM payout_ledger pl LEFT JOIN users u ON pl.source_user_id = u.id LEFT JOIN leads l ON pl.lead_id = l.id LEFT JOIN products p ON pl.product_id = p.id WHERE pl.user_id = ? ORDER BY pl.created_at DESC LIMIT 100");
$ledger_stmt->bind_param("i", $user_id);
$ledger_stmt->execute();
$ledger_entries = $ledger_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$ledger_stmt->close();

// Calculate totals
$total_earned = $total_pending = $total_paid = $margin_earned = $downline_paid = 0;
foreach ($ledger_entries as $entry) {
    $total_earned += $entry['amount'];
    if ($entry['status'] === 'pending')
        $total_pending += $entry['amount'];
    elseif ($entry['status'] === 'paid')
        $total_paid += $entry['amount'];
    if ($partner_type === 'channel_partner' && in_array($entry['earning_type'], ['margin_control', 'margin_earning'])) {
        $margin_earned += $entry['amount'];
    }
}

if ($partner_type === 'channel_partner') {
    $downline_stmt = $conn->prepare("SELECT SUM(amount) as total FROM payout_ledger WHERE source_user_id = ? AND earning_type = 'referral_percentage'");
    $downline_stmt->bind_param("i", $user_id);
    $downline_stmt->execute();
    $downline_result = $downline_stmt->get_result()->fetch_assoc();
    $downline_paid = $downline_result['total'] ?? 0;
    $downline_stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team Payouts</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body class="bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>

    <div class="max-w-7xl mx-auto px-4 py-6">
        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h1 class="text-2xl font-bold mb-2">Team Payouts</h1>
            <p class="text-slate-600">Partner: <?= ucfirst(str_replace('_', ' ', $partner_type)) ?></p>
        </div>

        <?php if (isset($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-lg shadow mb-6">
            <div class="flex border-b">
                <button onclick="switchTab('settings')"
                    class="flex-1 px-6 py-4 font-medium <?= $active_subsection === 'settings' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600' ?>">
                    <i class="fas fa-cog mr-2"></i>Settings
                </button>
                <button onclick="switchTab('summary')"
                    class="flex-1 px-6 py-4 font-medium <?= $active_subsection === 'summary' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600' ?>">
                    <i class="fas fa-chart-bar mr-2"></i>Summary
                </button>
            </div>
        </div>



        <div id="tab-settings" class="<?= $active_subsection === 'settings' ? '' : 'hidden' ?>">
            <?php if ($partner_type === 'network_partner'): ?>
                <div class="bg-white rounded-lg shadow p-6">
                    <h2 class="text-xl font-bold mb-4">Network Partner Program</h2>
                    <div class="grid grid-cols-3 gap-4">
                        <div class="bg-blue-50 p-6 rounded-lg text-center">
                            <div class="text-3xl font-bold text-blue-600">5%</div>
                            <div class="text-sm text-blue-700 mt-2">Level 1</div>
                        </div>
                        <div class="bg-purple-50 p-6 rounded-lg text-center">
                            <div class="text-3xl font-bold text-purple-600">2%</div>
                            <div class="text-sm text-purple-700 mt-2">Level 2</div>
                        </div>
                        <div class="bg-pink-50 p-6 rounded-lg text-center">
                            <div class="text-3xl font-bold text-pink-600">1%</div>
                            <div class="text-sm text-pink-700 mt-2">Level 3</div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-lg shadow p-6 mb-6">
                    <h2 class="text-xl font-bold mb-4">Margin Overview</h2>
                    <div class="grid grid-cols-3 gap-4">
                        <div class="bg-green-50 p-4 rounded-lg">
                            <div class="text-2xl font-bold text-green-700">₹<?= number_format($total_earned, 0) ?></div>
                            <div class="text-sm text-green-600">Master Payout</div>
                        </div>
                        <div class="bg-purple-50 p-4 rounded-lg">
                            <div class="text-2xl font-bold text-purple-700">₹<?= number_format($downline_paid, 0) ?></div>
                            <div class="text-sm text-purple-600">Paid to Team</div>
                        </div>
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <div class="text-2xl font-bold text-blue-700">
                                ₹<?= number_format($total_earned - $downline_paid, 0) ?></div>
                            <div class="text-sm text-blue-600">Your Margin</div>
                        </div>
                    </div>
                </div>

                <?php if (!empty($team_members)): ?>
                    <div class="bg-white rounded-lg shadow p-6 mb-6">
                        <h2 class="text-lg font-bold mb-4">Set Payout Rates</h2>
                        <form method="POST" class="space-y-4">
                            <div class="grid grid-cols-4 gap-4">
                                <div>
                                    <label class="block text-sm font-medium mb-1">Advisor</label>
                                    <select name="advisor_id" required class="w-full px-3 py-2 border rounded-lg">
                                        <option value="">Select...</option>
                                        <?php foreach ($team_members as $member): ?>
                                            <option value="<?= $member['id'] ?>"><?= htmlspecialchars($member['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">Product</label>
                                    <select name="product_id" class="w-full px-3 py-2 border rounded-lg">
                                        <option value="">All Products</option>
                                        <?php foreach ($products as $product): ?>
                                            <option value="<?= $product['id'] ?>"><?= htmlspecialchars($product['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">Type</label>
                                    <select name="rate_type" required class="w-full px-3 py-2 border rounded-lg">
                                        <option value="card_amount">Card (₹)</option>
                                        <option value="loan_percentage">Loan (%)</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium mb-1">Rate</label>
                                    <input type="number" name="payout_rate" step="0.1" required
                                        class="w-full px-3 py-2 border rounded-lg" onblur="autoSave()">
                                </div>
                            </div>
                            <button type="submit" name="save_payout_setting"
                                class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                                <i class="fas fa-save mr-2"></i>Save
                            </button>
                        </form>
                    </div>


                    <?php
                    // Fetch all products
                    $all_products_query = "SELECT id, name, category, variant, commission_rate FROM products WHERE status = 'active' ORDER BY category, variant, name";
                    $all_products_result = $conn->query($all_products_query);

                    $all_products = [];
                    while ($product = $all_products_result->fetch_assoc()) {
                        $all_products[] = $product;
                    }
                    ?>

                    <div class="bg-white rounded-lg shadow p-6 mb-6">
                        <h2 class="text-xl font-bold mb-4">
                            <i class="fas fa-users mr-2 text-blue-600"></i>Product Payout Settings by Advisor
                        </h2>

                        <?php if (empty($team_members)): ?>
                            <div class="text-center py-8 text-gray-500">
                                <i class="fas fa-info-circle text-4xl mb-3"></i>
                                <p>No team members found. Add advisors to your team to configure their payout rates.</p>
                            </div>
                        <?php else: ?>
                            <!-- Advisor Selection Dropdown -->
                            <div class="mb-6 bg-gray-50 p-4 rounded-lg">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-user-cog mr-1"></i>Select Advisor to Configure:
                                </label>
                                <select id="advisorSelect" class="w-full max-w-md px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" onchange="showAdvisorSettings(this.value)">
                                    <option value="">Choose an advisor...</option>
                                    <?php foreach ($team_members as $member): ?>
                                        <option value="<?= $member['id'] ?>">
                                            <?= htmlspecialchars($member['name']) ?> (Code: <?= htmlspecialchars($member['channel_code']) ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <?php foreach ($team_members as $member):
                                // Fetch payout settings for this specific advisor
                                $advisor_settings_query = "SELECT product_id, payout_rate FROM payout_settings WHERE user_id = ? AND advisor_user_id = ?";
                                $advisor_settings_stmt = $conn->prepare($advisor_settings_query);
                                $advisor_settings_stmt->bind_param("ii", $user_id, $member['id']);
                                $advisor_settings_stmt->execute();
                                $advisor_settings_result = $advisor_settings_stmt->get_result();

                                $advisor_payout_settings = [];
                                while ($row = $advisor_settings_result->fetch_assoc()) {
                                    $advisor_payout_settings[$row['product_id']] = $row['payout_rate'];
                                }
                                $advisor_settings_stmt->close();
                                ?>
                                <div class="mb-8 border-b pb-6 last:border-b-0 advisor-settings" id="advisor-<?= $member['id'] ?>" style="display: none;">
                                    <h3
                                        class="text-lg font-semibold mb-4 text-slate-800 bg-gradient-to-r from-blue-50 to-purple-50 px-4 py-3 rounded-lg border-l-4 border-blue-600">
                                        <i class="fas fa-user-circle mr-2 text-blue-600"></i>
                                        <?= htmlspecialchars($member['name']) ?>
                                        <?php if (!empty($member['channel_code'])): ?>
                                            <span class="text-sm text-gray-500 ml-2">(Code:
                                                <?= htmlspecialchars($member['channel_code']) ?>)</span>
                                        <?php endif; ?>
                                    </h3>

                                    <div class="overflow-x-auto">
                                        <table class="w-full border-collapse text-sm">
                                            <thead>
                                                <tr class="bg-slate-100">
                                                    <th class="px-3 py-2 text-left font-semibold text-slate-600 uppercase text-xs">
                                                        Product Type</th>
                                                    <th class="px-3 py-2 text-left font-semibold text-slate-600 uppercase text-xs">Bank
                                                    </th>
                                                    <th class="px-3 py-2 text-left font-semibold text-slate-600 uppercase text-xs">
                                                        Product</th>
                                                    <th class="px-3 py-2 text-center font-semibold text-slate-600 uppercase text-xs">
                                                        Your Payout</th>
                                                    <th class="px-3 py-2 text-center font-semibold text-slate-600 uppercase text-xs">
                                                        Advisor Payout</th>
                                                    <th class="px-3 py-2 text-center font-semibold text-slate-600 uppercase text-xs">
                                                        Margin</th>
                                                    <th class="px-3 py-2 text-center font-semibold text-slate-600 uppercase text-xs">
                                                        Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($all_products as $prod):
                                                    $your_payout = floatval($prod['commission_rate']);
                                                    $advisor_payout = isset($advisor_payout_settings[$prod['id']]) ? floatval($advisor_payout_settings[$prod['id']]) : 0;
                                                    $margin = $your_payout - $advisor_payout;
                                                    $is_loan = ($prod['category'] !== 'Credit Card');
                                                    $symbol = $is_loan ? '' : '₹';
                                                    $suffix = $is_loan ? '%' : '';
                                                    ?>
                                                    <tr class="border-b hover:bg-slate-50">
                                                        <form method="POST">
                                                            <input type="hidden" name="product_id" value="<?= $prod['id'] ?>">
                                                            <input type="hidden" name="product_category"
                                                                value="<?= htmlspecialchars($prod['category']) ?>">
                                                            <input type="hidden" name="advisor_id" value="<?= $member['id'] ?>">

                                                            <td class="px-3 py-2 text-slate-700"><?= htmlspecialchars($prod['category']) ?>
                                                            </td>
                                                            <td class="px-3 py-2 text-slate-700 font-medium">
                                                                <?= htmlspecialchars($prod['variant'] ?? '-') ?></td>
                                                            <td class="px-3 py-2 text-slate-900 font-medium">
                                                                <?= htmlspecialchars($prod['name']) ?></td>
                                                            <td class="px-3 py-2 text-center">
                                                                <span
                                                                    class="text-green-600 font-bold"><?= $symbol ?><?= number_format($your_payout, $is_loan ? 2 : 0) ?><?= $suffix ?></span>
                                                            </td>
                                                            <td class="px-3 py-2 text-center">
                                                                <input type="number" name="advisor_payout" value="<?= $advisor_payout ?>"
                                                                    step="<?= $is_loan ? '0.01' : '100' ?>" min="0"
                                                                    max="<?= $your_payout ?>"
                                                                    class="w-20 px-2 py-1 border rounded text-center text-sm"
                                                                    onchange="updateMarginDisplay(this, <?= $your_payout ?>, <?= $is_loan ? 'true' : 'false' ?>)">
                                                            </td>
                                                            <td class="px-3 py-2 text-center">
                                                                <span
                                                                    class="margin-val font-bold <?= $margin >= 0 ? 'text-green-600' : 'text-red-600' ?>">
                                                                    <?= $symbol ?>                    <?= number_format($margin, $is_loan ? 2 : 0) ?>                    <?= $suffix ?>
                                                                </span>
                                                            </td>
                                                            <td class="px-3 py-2 text-center">
                                                                <button type="submit" name="save_product_payout"
                                                                    class="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700">
                                                                    SAVE
                                                                </button>
                                                            </td>
                                                        </form>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div id="tab-summary" class="<?= $active_subsection === 'summary' ? '' : 'hidden' ?>">
            <div class="grid grid-cols-4 gap-4 mb-6">
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="text-2xl font-bold">₹<?= number_format($total_earned, 2) ?></div>
                    <div class="text-sm text-slate-600">Total Earned</div>
                </div>
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="text-2xl font-bold text-yellow-600">₹<?= number_format($total_pending, 2) ?></div>
                    <div class="text-sm text-slate-600">Pending</div>
                </div>
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="text-2xl font-bold text-green-600">₹<?= number_format($total_paid, 2) ?></div>
                    <div class="text-sm text-slate-600">Paid</div>
                </div>
                <?php if ($partner_type === 'channel_partner'): ?>
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="text-2xl font-bold text-purple-600">₹<?= number_format($margin_earned, 2) ?></div>
                        <div class="text-sm text-slate-600">Margin Profit</div>
                    </div>
                <?php endif; ?>
            </div>

            <?php if (!empty($ledger_entries)): ?>
                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <div class="px-6 py-4 border-b">
                        <h3 class="font-bold">Payout History</h3>
                    </div>
                    <table class="w-full text-sm">
                        <thead class="bg-slate-50">
                            <tr>
                                <th class="px-4 py-3 text-left">Date</th>
                                <th class="px-4 py-3 text-left">Source</th>
                                <th class="px-4 py-3 text-left">Type</th>
                                <th class="px-4 py-3 text-left">Product</th>
                                <th class="px-4 py-3 text-left">Amount</th>
                                <th class="px-4 py-3 text-left">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ledger_entries as $entry): ?>
                                <tr class="border-t">
                                    <td class="px-4 py-3"><?= date('d M Y', strtotime($entry['created_at'])) ?></td>
                                    <td class="px-4 py-3">
                                        <?= $entry['source_user_id'] ? htmlspecialchars($entry['source_name']) : 'Self' ?>
                                    </td>
                                    <td class="px-4 py-3"><span
                                            class="text-xs px-2 py-1 rounded bg-purple-100 text-purple-700"><?= $entry['earning_type'] ?></span>
                                    </td>
                                    <td class="px-4 py-3"><?= htmlspecialchars($entry['product_name'] ?? 'N/A') ?></td>
                                    <td class="px-4 py-3 font-bold text-green-600">₹<?= number_format($entry['amount'], 2) ?>
                                    </td>
                                    <td class="px-4 py-3"><span
                                            class="text-xs px-2 py-1 rounded <?= $entry['status'] === 'paid' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700' ?>"><?= ucfirst($entry['status']) ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function showAdvisorSettings(advisorId) {
            // Hide all advisor settings
            document.querySelectorAll('.advisor-settings').forEach(el => {
                el.style.display = 'none';
            });
            
            // Show selected advisor settings
            if (advisorId) {
                const selectedAdvisor = document.getElementById('advisor-' + advisorId);
                if (selectedAdvisor) {
                    selectedAdvisor.style.display = 'block';
                }
            }
        }

        function switchTab(tab) {
            document.querySelectorAll('[id^="tab-"]').forEach(el => el.classList.add('hidden'));
            document.getElementById('tab-' + tab).classList.remove('hidden');
            const url = new URL(window.location);
            url.searchParams.set('subsection', tab);
            window.history.pushState({}, '', url);
        }

        function updateMarginDisplay(input, yourPayout, isLoan) {
            const advisorPayout = parseFloat(input.value) || 0;
            const margin = yourPayout - advisorPayout;

            const row = input.closest('tr');
            const marginDisplay = row.querySelector('.margin-val');
            const symbol = isLoan ? '' : '₹';
            const suffix = isLoan ? '%' : '';
            const decimals = isLoan ? 2 : 0;

            marginDisplay.textContent = symbol + margin.toFixed(decimals) + suffix;
            marginDisplay.className = 'margin-val font-bold ' + (margin >= 0 ? 'text-green-600' : 'text-red-600');
        }

        function editRate(settingId, advisorName, productId, rateType, payoutRate) {
            document.getElementById('edit_setting_id').value = settingId;
            document.getElementById('edit_advisor_name').value = advisorName;
            document.getElementById('edit_rate_type').value = rateType;
            document.getElementById('edit_payout_rate').value = payoutRate;
            document.getElementById('editModal').classList.remove('hidden');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.add('hidden');
        }

        function autoSave() {
            const form = document.querySelector('form[method="POST"]');
            const formData = new FormData(form);

            // Check if all required fields are filled
            const advisorId = formData.get('advisor_id');
            const rateType = formData.get('rate_type');
            const payoutRate = formData.get('payout_rate');

            if (!advisorId || !rateType || !payoutRate) {
                return; // Don't save if required fields are empty
            }

            formData.append('auto_save', '1');

            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Show brief success indicator
                        const indicator = document.createElement('div');
                        indicator.className = 'fixed top-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg z-50';
                        indicator.textContent = 'Auto-saved!';
                        document.body.appendChild(indicator);
                        setTimeout(() => indicator.remove(), 2000);

                        // Refresh the settings table
                        setTimeout(() => window.location.reload(), 1000);
                    }
                })
                .catch(error => console.error('Auto-save failed:', error));
        }
    </script>

    <!-- Edit Rate Modal -->
    <div id="editModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg p-6 w-full max-w-md">
                <h3 class="text-lg font-bold mb-4">Edit Payout Rate</h3>
                <form method="POST" id="editForm">
                    <input type="hidden" name="edit_setting" value="1">
                    <input type="hidden" name="setting_id" id="edit_setting_id">

                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-1">Advisor</label>
                        <input type="text" id="edit_advisor_name" class="w-full px-3 py-2 border rounded-lg bg-gray-100"
                            readonly>
                    </div>

                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-1">Rate Type</label>
                        <select name="rate_type" id="edit_rate_type" required
                            class="w-full px-3 py-2 border rounded-lg">
                            <option value="card_amount">Card (₹)</option>
                            <option value="loan_percentage">Loan (%)</option>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-1">Payout Rate</label>
                        <input type="number" name="payout_rate" id="edit_payout_rate" step="0.1" required
                            class="w-full px-3 py-2 border rounded-lg">
                    </div>

                    <div class="flex gap-2">
                        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                            <i class="fas fa-save mr-2"></i>Update
                        </button>
                        <button type="button" onclick="closeEditModal()"
                            class="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600">
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="/assets/js/loading.js"></script>
</body>

</html>