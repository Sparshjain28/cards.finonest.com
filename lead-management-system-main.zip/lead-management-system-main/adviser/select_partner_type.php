<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

requireLogin();

$user = getCurrentUser();
$database = new Database();
$conn = $database->getConnection();

// Check if user already has partner_type selected
if (!empty($user['partner_type'])) {
    header('Location: refer_and_earn.php');
    exit();
}

$error = '';
$success = '';

// Handle partner type selection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['partner_type'])) {
    $partner_type = $_POST['partner_type'];
    
    if (!in_array($partner_type, ['network_partner', 'channel_partner'])) {
        $error = 'Invalid partner type selected.';
    } else {
        $stmt = $conn->prepare("UPDATE users SET partner_type = ? WHERE id = ?");
        $stmt->bind_param("si", $partner_type, $user['id']);
        
        if ($stmt->execute()) {
            // Update session
            $_SESSION['partner_type'] = $partner_type;
            header('Location: refer_and_earn.php');
            exit();
        } else {
            $error = 'Failed to save partner type. Please try again.';
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Choose Your Partner Program - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    
    <div class="w-full max-w-4xl mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-sm border p-6">
            <div class="text-center mb-6">
                <h1 class="text-2xl font-bold text-slate-900 mb-2">Choose Your Partner Program</h1>
                <p class="text-slate-600">This is a <strong class="text-red-600">permanent choice</strong>. You cannot change this later.</p>
            </div>

            <?php if ($error): ?>
                <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="grid md:grid-cols-2 gap-6 mb-6">
                    <!-- Network Partner Option -->
                    <div class="group">
                        <input type="radio" name="partner_type" value="network_partner" id="network_partner" class="hidden" required>
                        <label for="network_partner" class="block cursor-pointer partner-option" data-value="network_partner">
                            <div class="relative overflow-hidden rounded-xl border-2 border-slate-200 bg-gradient-to-br from-blue-50 to-indigo-100 p-6 shadow-sm transition-all duration-300 hover:shadow-lg">
                                <div class="absolute -right-4 -top-4 h-16 w-16 rounded-full bg-blue-500/10"></div>
                                <div class="relative">
                                    <div class="mb-4 flex items-center">
                                        <div class="mr-3 flex h-10 w-10 items-center justify-center rounded-full bg-blue-500 text-white">
                                            <i class="fas fa-network-wired"></i>
                                        </div>
                                        <h3 class="text-xl font-bold text-slate-900">Network Partner</h3>
                                    </div>
                                    <p class="mb-4 text-sm text-slate-600">Build a large chain and earn small % from everyone</p>
                                    <div class="space-y-2 text-sm text-slate-700">
                                        <div class="flex items-center">
                                            <i class="fas fa-check-circle mr-2 text-green-500"></i>
                                            <span><strong>3 Levels:</strong> L1 (5%), L2 (2%), L3 (1%)</span>
                                        </div>
                                        <div class="flex items-center">
                                            <i class="fas fa-check-circle mr-2 text-green-500"></i>
                                            <span>See entire team tree (masked)</span>
                                        </div>
                                        <div class="flex items-center">
                                            <i class="fas fa-check-circle mr-2 text-green-500"></i>
                                            <span>Automatic calculation</span>
                                        </div>
                                        <div class="flex items-center">
                                            <i class="fas fa-check-circle mr-2 text-green-500"></i>
                                            <span>Zero management overhead</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </label>
                    </div>

                    <!-- Channel Partner Option -->
                    <div class="group">
                        <input type="radio" name="partner_type" value="channel_partner" id="channel_partner" class="hidden" required>
                        <label for="channel_partner" class="block cursor-pointer partner-option" data-value="channel_partner">
                            <div class="relative overflow-hidden rounded-xl border-2 border-slate-200 bg-gradient-to-br from-purple-50 to-pink-100 p-6 shadow-sm transition-all duration-300 hover:shadow-lg">
                                <div class="absolute -right-4 -top-4 h-16 w-16 rounded-full bg-purple-500/10"></div>
                                <div class="relative">
                                    <div class="mb-4 flex items-center">
                                        <div class="mr-3 flex h-10 w-10 items-center justify-center rounded-full bg-purple-500 text-white">
                                            <i class="fas fa-crown"></i>
                                        </div>
                                        <h3 class="text-xl font-bold text-slate-900">Channel Partner</h3>
                                    </div>
                                    <p class="mb-4 text-sm text-slate-600">Be a Boss. Manage a direct team and keep high margins</p>
                                    <div class="space-y-2 text-sm text-slate-700">
                                        <div class="flex items-center">
                                            <i class="fas fa-check-circle mr-2 text-green-500"></i>
                                            <span><strong>1 Level Only:</strong> Direct referrals</span>
                                        </div>
                                        <div class="flex items-center">
                                            <i class="fas fa-check-circle mr-2 text-green-500"></i>
                                            <span>Set rates per advisor</span>
                                        </div>
                                        <div class="flex items-center">
                                            <i class="fas fa-check-circle mr-2 text-green-500"></i>
                                            <span>Keep the margin difference</span>
                                        </div>
                                        <div class="flex items-center">
                                            <i class="fas fa-check-circle mr-2 text-green-500"></i>
                                            <span>Active management required</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </label>
                    </div>
                </div>

                <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
                    <p class="text-sm text-yellow-700">
                        <i class="fas fa-exclamation-triangle mr-2"></i>
                        <strong>Important:</strong> This selection is permanent and cannot be changed later.
                    </p>
                </div>

                <div class="text-center">
                    <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        Confirm Selection
                    </button>
                </div>
            </form>
        </div>
    </div>
    <script src="/assets/js/loading.js"></script>
</body>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const partnerOptions = document.querySelectorAll('.partner-option');
    
    partnerOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove selected class from all options
            partnerOptions.forEach(opt => {
                const div = opt.querySelector('div');
                div.classList.remove('border-blue-500', 'border-purple-500', 'shadow-xl');
                div.classList.add('border-slate-200');
            });
            
            // Add selected class to clicked option
            const div = this.querySelector('div');
            const value = this.dataset.value;
            
            if (value === 'network_partner') {
                div.classList.remove('border-slate-200');
                div.classList.add('border-blue-500', 'shadow-xl');
            } else {
                div.classList.remove('border-slate-200');
                div.classList.add('border-purple-500', 'shadow-xl');
            }
            
            // Check the radio button
            document.getElementById(value).checked = true;
        });
    });
});
</script>
</html>

