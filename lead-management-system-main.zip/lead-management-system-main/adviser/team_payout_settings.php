<?php
// Get all products
$products_query = "SELECT id, name, variant, category, commission_rate FROM products WHERE status = 'active' ORDER BY category, variant, name";
$products_result = $conn->query($products_query);
$products = [];
while ($row = $products_result->fetch_assoc()) {
    $products[] = $row;
}

// Get team members (L1 only)
$team_query = "SELECT DISTINCT u.id, u.name, u.channel_code
            FROM referral_users ru
            JOIN users u ON ru.referred_user_id = u.id
            WHERE ru.referrer_user_id = ? AND ru.level = 1
            ORDER BY u.name";
$team_stmt = $conn->prepare($team_query);
$team_stmt->bind_param("i", $user_id);
$team_stmt->execute();
$team_result = $team_stmt->get_result();
$team_members = [];
while ($row = $team_result->fetch_assoc()) {
    $team_members[] = $row;
}
$team_stmt->close();

// Get existing payout settings
$payout_settings = [];
if ($partner_type === 'channel_partner') {
    $settings_query = "SELECT ps.*, u.name as advisor_name, p.name as product_name
                    FROM payout_settings ps
                    JOIN users u ON ps.advisor_user_id = u.id
                    LEFT JOIN products p ON ps.product_id = p.id
                    WHERE ps.user_id = ?
                    ORDER BY u.name, p.name";
    $settings_stmt = $conn->prepare($settings_query);
    $settings_stmt->bind_param("i", $user_id);
    $settings_stmt->execute();
    $settings_result = $settings_stmt->get_result();
    while ($row = $settings_result->fetch_assoc()) {
        $payout_settings[] = $row;
    }
    $settings_stmt->close();
}
?>

<?php if ($partner_type === 'network_partner'): ?>
    <!-- Network Partner View -->
    <div class="bg-white rounded-xl shadow-sm p-8">
        <div class="text-center mb-8">
            <div class="inline-flex items-center px-4 py-2 bg-blue-100 text-blue-800 rounded-full text-sm font-medium mb-4">
                <i class="fas fa-network-wired mr-2"></i>Network Partner Program
            </div>
            <h2 class="text-2xl font-bold text-gray-900 mb-2">Fixed Percentage Structure</h2>
            <p class="text-gray-600">Your earnings are calculated automatically based on team performance</p>
        </div>
        
        <div class="grid md:grid-cols-3 gap-6 mb-8">
            <div class="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6 text-center border border-blue-200">
                <div class="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-user text-white text-xl"></i>
                </div>
                <div class="text-3xl font-bold text-blue-600 mb-2">5%</div>
                <div class="text-sm font-semibold text-blue-800 mb-1">Level 1</div>
                <div class="text-xs text-blue-600">Direct Referrals</div>
            </div>
            <div class="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-6 text-center border border-purple-200">
                <div class="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-users text-white text-xl"></i>
                </div>
                <div class="text-3xl font-bold text-purple-600 mb-2">2%</div>
                <div class="text-sm font-semibold text-purple-800 mb-1">Level 2</div>
                <div class="text-xs text-purple-600">Indirect Referrals</div>
            </div>
            <div class="bg-gradient-to-br from-pink-50 to-pink-100 rounded-xl p-6 text-center border border-pink-200">
                <div class="w-16 h-16 bg-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-sitemap text-white text-xl"></i>
                </div>
                <div class="text-3xl font-bold text-pink-600 mb-2">1%</div>
                <div class="text-sm font-semibold text-pink-800 mb-1">Level 3</div>
                <div class="text-xs text-pink-600">Deep Network</div>
            </div>
        </div>
        
        <div class="bg-gray-50 rounded-xl p-6 border border-gray-200">
            <div class="flex items-center">
                <i class="fas fa-info-circle text-blue-500 text-xl mr-3"></i>
                <div>
                    <h3 class="font-semibold text-gray-900 mb-1">Automatic Calculation</h3>
                    <p class="text-gray-600 text-sm">These rates are fixed and calculated automatically by our system. No manual configuration required.</p>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <!-- Channel Partner View -->
    <?php if (empty($team_members)): ?>
        <div class="bg-white rounded-xl shadow-sm p-12 text-center">
            <div class="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i class="fas fa-users text-gray-400 text-3xl"></i>
            </div>
            <h3 class="text-xl font-semibold text-gray-900 mb-2">No Team Members Yet</h3>
            <p class="text-gray-600 mb-6">Start building your team by sharing your referral link</p>
        </div>
    <?php else: ?>
        <!-- Filters -->
        <div class="bg-white rounded-xl shadow-sm p-4 mb-6">
            <div class="row align-items-end g-3">
                <div class="col-md-4">
                    <label class="form-label text-sm font-medium text-gray-700">Team Members</label>
                    <div class="position-relative">
                        <div id="userMultiSelect" class="form-control d-flex align-items-center justify-content-between" style="cursor: pointer;" onclick="toggleUserDropdown()">
                            <span id="selectedUsersText" class="text-muted">Select Team Members</span>
                            <i class="fas fa-chevron-down"></i>
                        </div>
                        <div id="userDropdown" class="position-absolute bg-white border rounded shadow-lg" style="top: 100%; left: 0; right: 0; z-index: 1000; display: none;">
                            <div class="list-group list-group-flush">
                                <div class="list-group-item border-0 py-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="selectAllUsers" class="form-check-input" onchange="toggleAllUsers()">
                                        <label class="form-check-label fw-bold" for="selectAllUsers">Select All</label>
                                    </div>
                                </div>
                                <?php foreach ($team_members as $member): ?>
                                    <div class="list-group-item list-group-item-action border-0 py-2">
                                        <div class="form-check">
                                            <input type="checkbox" value="<?= $member['id'] ?>" class="form-check-input user-checkbox" id="user_<?= $member['id'] ?>" onchange="updateSelectedUsers()">
                                            <label class="form-check-label" for="user_<?= $member['id'] ?>">
                                                <div class="d-flex align-items-center">
                                                    <div class="flex-grow-1">
                                                        <div class="fw-medium"><?= htmlspecialchars($member['name']) ?></div>
                                                        <small class="text-muted"><?= htmlspecialchars($member['channel_code']) ?></small>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label text-sm font-medium text-gray-700">Product Category</label>
                    <select id="categoryFilter" class="form-select" onchange="applyFilters()">
                        <option value="">All Categories</option>
                        <option value="Credit Card">Credit Card</option>
                        <option value="Personal Loan">Personal Loan</option>
                        <option value="Car Loan">Car Loan</option>
                    </select>
                </div>
                <div class="col-md-5">
                    <div class="d-flex align-items-center gap-3">
                        <button class="btn btn-primary" onclick="bulkUpdate()">
                            <i class="fas fa-edit me-2"></i>Bulk Update
                        </button>
                        <div class="text-sm text-success">
                            <i class="fas fa-check-circle me-1"></i>Auto-save enabled
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 3-Column Spreadsheet -->
        <div class="bg-white rounded-xl shadow-sm">
            <div class="p-4">
                <h3 class="text-lg font-semibold mb-4">Payout Settings</h3>
                
                <div class="overflow-auto">
                    <table class="table table-striped table-bordered" style="width:100%">
                        <thead class="table-dark">
                            <tr>
                                <th style="width: 40%;">Product</th>
                                <th style="width: 30%;">Actual Payout</th>
                                <th style="width: 30%;">Set Payout</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $existing_payouts = [];
                            foreach ($payout_settings as $setting) {
                                $key = $setting['advisor_user_id'] . '_' . $setting['product_id'];
                                $existing_payouts[$key] = $setting['payout_rate'];
                            }
                            
                            foreach ($team_members as $member):
                                foreach ($products as $product): 
                                    $key = $member['id'] . '_' . $product['id'];
                                    $current_rate = $existing_payouts[$key] ?? '';
                            ?>
                                <tr class="payout-row" data-user="<?= $member['id'] ?>" data-category="<?= htmlspecialchars($product['category']) ?>" style="display: none;">
                                    <td>
                                        <div class="text-xs text-blue-600 mb-1"><?= htmlspecialchars($product['variant'] ?? '') ?></div>
                                        <div class="fw-bold"><?= htmlspecialchars($product['name']) ?></div>
                                        <div class="text-xs text-muted"><?= htmlspecialchars($product['category']) ?></div>
                                    </td>
                                    <td class="text-center">
                                        <?php if (in_array($product['category'], ['Personal Loan', 'Car Loan'])): ?>
                                            <span class="badge bg-success"><?= number_format($product['commission_rate'], 2) ?>%</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">₹<?= number_format($product['commission_rate']) ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <input type="number" 
                                               class="form-control text-center" 
                                               data-advisor="<?= $member['id'] ?>" 
                                               data-product="<?= $product['id'] ?>" 
                                               data-max="<?= $product['commission_rate'] ?>"
                                               value="<?= $current_rate ?>" 
                                               placeholder="<?= in_array($product['category'], ['Personal Loan', 'Car Loan']) ? '0.00' : '0' ?>" 
                                               min="0" 
                                               max="<?= $product['commission_rate'] ?>"
                                               step="<?= in_array($product['category'], ['Personal Loan', 'Car Loan']) ? '0.01' : '1' ?>"
                                               onchange="validateAndSave(this)">
                                    </td>
                                </tr>
                            <?php 
                                endforeach;
                            endforeach; 
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<script>
let selectedUsers = [];

function toggleUserDropdown() {
    const dropdown = document.getElementById('userDropdown');
    dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
}

function toggleAllUsers() {
    const selectAll = document.getElementById('selectAllUsers');
    const checkboxes = document.querySelectorAll('.user-checkbox');
    
    checkboxes.forEach(cb => cb.checked = selectAll.checked);
    updateSelectedUsers();
}

function updateSelectedUsers() {
    const checkboxes = document.querySelectorAll('.user-checkbox:checked');
    selectedUsers = Array.from(checkboxes).map(cb => cb.value);
    
    const text = selectedUsers.length === 0 ? 'Select Team Members' : 
                selectedUsers.length === 1 ? '1 member selected' : 
                `${selectedUsers.length} members selected`;
    
    document.getElementById('selectedUsersText').textContent = text;
    document.getElementById('selectAllUsers').checked = selectedUsers.length === document.querySelectorAll('.user-checkbox').length;
    
    applyFilters();
}

function applyFilters() {
    const category = document.getElementById('categoryFilter').value;
    const rows = document.querySelectorAll('.payout-row');
    
    rows.forEach(row => {
        const userMatch = selectedUsers.length === 0 || selectedUsers.includes(row.dataset.user);
        const categoryMatch = !category || row.dataset.category === category;
        
        row.style.display = userMatch && categoryMatch ? '' : 'none';
    });
}

function bulkUpdate() {
    if (selectedUsers.length === 0) {
        alert('Please select at least one team member');
        return;
    }
    
    const rate = prompt('Enter payout rate for selected members:');
    if (!rate || parseFloat(rate) <= 0) return;
    
    const category = document.getElementById('categoryFilter').value;
    const inputs = document.querySelectorAll('.payout-row input[type="number"]');
    
    inputs.forEach(input => {
        const row = input.closest('.payout-row');
        const userMatch = selectedUsers.includes(row.dataset.user);
        const categoryMatch = !category || row.dataset.category === category;
        
        if (userMatch && categoryMatch && row.style.display !== 'none') {
            const maxValue = parseFloat(input.dataset.max);
            if (parseFloat(rate) > maxValue) {
                alert(`Rate ${rate} exceeds maximum allowed ${maxValue} for some products`);
                return;
            }
            input.value = rate;
            autoSave(input);
        }
    });
}

function validateAndSave(input) {
    const maxValue = parseFloat(input.dataset.max);
    const currentValue = parseFloat(input.value);
    
    if (!input.value || currentValue <= 0) return;
    
    if (currentValue > maxValue) {
        input.style.borderColor = '#dc3545';
        alert(`Payout cannot exceed actual payout of ${maxValue}`);
        input.value = maxValue;
        return;
    }
    
    autoSave(input);
}

function autoSave(input) {
    const row = input.closest('.payout-row');
    const category = row.dataset.category;
    const rateType = ['Personal Loan', 'Car Loan'].includes(category) ? 'loan_percentage' : 'card_amount';
    
    const formData = new FormData();
    formData.append('save_single_payout', '1');
    formData.append('advisor_id', input.dataset.advisor);
    formData.append('product_id', input.dataset.product);
    formData.append('rate_type', rateType);
    formData.append('payout_rate', input.value);
    
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    }).then(response => {
        if (response.ok) {
            input.style.borderColor = '#28a745';
            setTimeout(() => input.style.borderColor = '', 1000);
        }
    });
}

// Close dropdown when clicking outside
document.addEventListener('click', function(e) {
    if (!e.target.closest('#userMultiSelect') && !e.target.closest('#userDropdown')) {
        document.getElementById('userDropdown').style.display = 'none';
    }
});
</script>

<style>
.list-group-item-action:hover {
    background-color: #f8f9fa;
}
.form-check-label {
    cursor: pointer;
    width: 100%;
}
#userDropdown {
    max-height: 250px;
    overflow-y: auto;
}
a {
    text-decoration: none !important;
}
a:hover {
    text-decoration: none !important;
}
</style>