<?php
// Get payout ledger entries
$ledger_query = "SELECT pl.*, u.name as source_name, l.lead_id, l.customer_name, p.name as product_name, p.category as product_category
                FROM payout_ledger pl
                LEFT JOIN users u ON pl.source_user_id = u.id
                LEFT JOIN leads l ON pl.lead_id = l.id
                LEFT JOIN products p ON pl.product_id = p.id
                WHERE pl.user_id = ?
                ORDER BY pl.created_at DESC
                LIMIT 100";
$ledger_stmt = $conn->prepare($ledger_query);
$ledger_stmt->bind_param("i", $user_id);
$ledger_stmt->execute();
$ledger_entries = $ledger_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$ledger_stmt->close();

// Calculate totals
$total_earned = 0;
$total_pending = 0;
$total_paid = 0;
$margin_earned = 0;

foreach ($ledger_entries as $entry) {
    $total_earned += $entry['amount'];
    if ($entry['status'] === 'pending') {
        $total_pending += $entry['amount'];
    } elseif ($entry['status'] === 'paid') {
        $total_paid += $entry['amount'];
    }
    
    if ($partner_type === 'channel_partner' && in_array($entry['earning_type'], ['margin_control', 'margin_earning'])) {
        $margin_earned += $entry['amount'];
    }
}

// Calculate downline payouts
$downline_paid = 0;
if ($partner_type === 'channel_partner') {
    $downline_query = "SELECT SUM(amount) as total FROM payout_ledger WHERE source_user_id = ? AND earning_type = 'referral_percentage'";
    $downline_stmt = $conn->prepare($downline_query);
    $downline_stmt->bind_param("i", $user_id);
    $downline_stmt->execute();
    $downline_result = $downline_stmt->get_result()->fetch_assoc();
    $downline_paid = $downline_result['total'] ?? 0;
    $downline_stmt->close();
}
?>

<div class="space-y-8">
    <!-- Summary Cards -->
    <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center">
                    <i class="fas fa-wallet text-white"></i>
                </div>
                <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">Total</span>
            </div>
            <div class="text-2xl font-bold text-gray-900 mb-1">₹<?= number_format($total_earned, 2) ?></div>
            <div class="text-sm text-gray-600">Total Earned</div>
        </div>
        
        <?php if ($partner_type === 'channel_partner'): ?>
        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center">
                    <i class="fas fa-chart-line text-white"></i>
                </div>
                <span class="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">Profit</span>
            </div>
            <div class="text-2xl font-bold text-gray-900 mb-1">₹<?= number_format($total_earned - $downline_paid, 2) ?></div>
            <div class="text-sm text-gray-600">Margin Profit</div>
        </div>
        <?php endif; ?>
        
        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center">
                    <i class="fas fa-hourglass-half text-white"></i>
                </div>
                <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full">Pending</span>
            </div>
            <div class="text-2xl font-bold text-gray-900 mb-1">₹<?= number_format($total_pending, 2) ?></div>
            <div class="text-sm text-gray-600">Pending Amount</div>
        </div>
        
        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center">
                    <i class="fas fa-check-circle text-white"></i>
                </div>
                <span class="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Paid</span>
            </div>
            <div class="text-2xl font-bold text-gray-900 mb-1">₹<?= number_format($total_paid, 2) ?></div>
            <div class="text-sm text-gray-600">Amount Paid</div>
        </div>
    </div>

    <!-- Payout Ledger -->
    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
        <div class="px-8 py-6 border-b border-gray-200">
            <h2 class="text-xl font-bold text-gray-900">
                <i class="fas fa-history text-blue-600 mr-2"></i>Payout History
            </h2>
        </div>
        
        <?php if (empty($ledger_entries)): ?>
            <div class="p-12 text-center">
                <i class="fas fa-chart-bar text-4xl text-gray-300 mb-4"></i>
                <h3 class="text-lg font-semibold text-gray-900 mb-2">No Payout History</h3>
                <p class="text-gray-600">Your payout entries will appear here once you start earning</p>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Date</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Source</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Type</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Product</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Amount</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($ledger_entries as $entry): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 text-sm text-gray-600">
                                    <?= date('d M Y', strtotime($entry['created_at'])) ?>
                                </td>
                                <td class="px-6 py-4">
                                    <?php if ($entry['source_user_id']): ?>
                                        <div class="flex items-center">
                                            <div class="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                                                <i class="fas fa-user text-gray-600 text-sm"></i>
                                            </div>
                                            <span class="text-gray-900"><?= htmlspecialchars($entry['source_name'] ?? 'Team Member') ?></span>
                                        </div>
                                    <?php else: ?>
                                        <div class="flex items-center">
                                            <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                                                <i class="fas fa-user-tie text-blue-600 text-sm"></i>
                                            </div>
                                            <span class="text-blue-600 font-medium">Self</span>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4">
                                    <?php
                                    $type_config = [
                                        'self' => ['label' => 'Self Earned', 'color' => 'bg-blue-100 text-blue-700'],
                                        'referral_percentage' => ['label' => 'Referral %', 'color' => 'bg-purple-100 text-purple-700'],
                                        'margin_control' => ['label' => 'Margin Control', 'color' => 'bg-green-100 text-green-700'],
                                        'margin_earning' => ['label' => 'Team Margin', 'color' => 'bg-orange-100 text-orange-700']
                                    ];
                                    $config = $type_config[$entry['earning_type']] ?? ['label' => $entry['earning_type'], 'color' => 'bg-gray-100 text-gray-700'];
                                    ?>
                                    <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full <?= $config['color'] ?>">
                                        <?= $config['label'] ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600">
                                    <?= htmlspecialchars($entry['product_name'] ?? 'N/A') ?>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="text-lg font-bold text-green-600">₹<?= number_format($entry['amount'], 2) ?></span>
                                </td>
                                <td class="px-6 py-4">
                                    <?php
                                    $status_config = [
                                        'pending' => 'bg-yellow-100 text-yellow-700',
                                        'processing' => 'bg-blue-100 text-blue-700',
                                        'paid' => 'bg-green-100 text-green-700',
                                        'cancelled' => 'bg-red-100 text-red-700'
                                    ];
                                    $status_color = $status_config[$entry['status']] ?? 'bg-gray-100 text-gray-700';
                                    ?>
                                    <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full <?= $status_color ?>">
                                        <?= ucfirst($entry['status']) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
