    <?php
    // My Team Payouts Module - Payout Settings and Payout Summary

    // Include required files if not already included
    if (!function_exists('getCurrentUser')) {
        require_once __DIR__ . '/../../includes/auth.php';
        require_once __DIR__ . '/../../config/database_updated.php';
        
        requireLogin();
        $user = getCurrentUser();
        $database = new Database();
        $conn = $database->getConnection();
    }

    $user_id = $user['id'];
    $partner_type = $user['partner_type'];
    $active_subsection = $_GET['subsection'] ?? 'settings';

    // Get user's master payout rates (from products table or admin settings)
    function getMasterPayoutRate($conn, $product_id, $category) {
        $query = "SELECT commission_rate FROM products WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            return $row['commission_rate'];
        }
        return 0;
    }

    // Get all products
    $products_query = "SELECT id, name, category, commission_rate FROM products WHERE status = 'active' ORDER BY category, name";
    $products_result = $conn->query($products_query);
    $products = [];
    while ($row = $products_result->fetch_assoc()) {
        $products[] = $row;
    }

    // Get team members (L1 only for both types, but channel partner can set rates)
    $team_query = "SELECT DISTINCT u.id, u.name, u.channel_code
                FROM referral_users ru
                JOIN users u ON ru.referred_user_id = u.id
                WHERE ru.referrer_user_id = ? AND ru.level = 1
                ORDER BY u.name";
    $team_stmt = $conn->prepare($team_query);
    $team_stmt->bind_param("i", $user_id);
    $team_stmt->execute();
    $team_result = $team_stmt->get_result();
    $team_members = [];
    while ($row = $team_result->fetch_assoc()) {
        $team_members[] = $row;
    }
    $team_stmt->close();

    // Handle payout setting delete
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_setting']) && $partner_type === 'channel_partner') {
        $setting_id = (int)$_POST['setting_id'];
        
        $delete_query = "DELETE FROM payout_settings WHERE id = ? AND user_id = ?";
        $delete_stmt = $conn->prepare($delete_query);
        $delete_stmt->bind_param("ii", $setting_id, $user_id);
        $delete_stmt->execute();
        $delete_stmt->close();
        
        $success = 'Payout setting deleted successfully!';
    }

    // Handle payout setting save (Channel Partner only)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_payout_setting']) && $partner_type === 'channel_partner') {
        $advisor_id = (int)$_POST['advisor_id'];
        $product_id = !empty($_POST['product_id']) ? (int)$_POST['product_id'] : null;
        $rate_type = $_POST['rate_type'];
        $payout_rate = (float)$_POST['payout_rate'];
        
        // Get master rate for validation
        $master_rate = 0;
        if ($product_id) {
            $master_query = "SELECT commission_rate FROM products WHERE id = ?";
            $master_stmt = $conn->prepare($master_query);
            $master_stmt->bind_param("i", $product_id);
            $master_stmt->execute();
            $master_result = $master_stmt->get_result()->fetch_assoc();
            $master_rate = $master_result['commission_rate'] ?? 0;
            $master_stmt->close();
        }
        
        // Validation
        if ($rate_type === 'card_amount') {
            if ($payout_rate % 100 !== 0) {
                $error = 'Card payout must be in multiples of ₹100.';
            } elseif ($master_rate > 0 && $payout_rate > $master_rate) {
                $error = 'Payout rate cannot exceed master rate of ₹' . number_format($master_rate) . '.';
            }
        } else {
            if (round($payout_rate * 10) / 10 != $payout_rate) {
                $error = 'Loan percentage must be in multiples of 0.1%.';
            } elseif ($payout_rate > 100) {
                $error = 'Loan percentage cannot exceed 100%.';
            }
        }
        
        if (empty($error)) {
            // Check if setting exists
            $check_query = "SELECT id FROM payout_settings WHERE user_id = ? AND advisor_user_id = ? AND (product_id = ? OR (product_id IS NULL AND ? IS NULL))";
            $check_stmt = $conn->prepare($check_query);
            $check_stmt->bind_param("iiii", $user_id, $advisor_id, $product_id, $product_id);
            $check_stmt->execute();
            $existing = $check_stmt->get_result()->fetch_assoc();
            $check_stmt->close();
            
            if ($existing) {
                // Update
                $update_query = "UPDATE payout_settings SET payout_rate = ?, rate_type = ?, is_custom_rate = 1, updated_at = NOW() WHERE id = ?";
                $update_stmt = $conn->prepare($update_query);
                $update_stmt->bind_param("dsi", $payout_rate, $rate_type, $existing['id']);
                $update_stmt->execute();
                $update_stmt->close();
            } else {
                // Insert
                $category = null;
                if ($product_id) {
                    foreach ($products as $p) {
                        if ($p['id'] == $product_id) {
                            $category = $p['category'];
                            break;
                        }
                    }
                }
                
                $insert_query = "INSERT INTO payout_settings (user_id, advisor_user_id, product_id, product_category, payout_rate, rate_type, is_custom_rate) VALUES (?, ?, ?, ?, ?, ?, 1)";
                $insert_stmt = $conn->prepare($insert_query);
                $insert_stmt->bind_param("iiisds", $user_id, $advisor_id, $product_id, $category, $payout_rate, $rate_type);
                $insert_stmt->execute();
                $insert_stmt->close();
            }
            
            $success = 'Payout setting saved successfully!';
        }
    }

    // Get existing payout settings for channel partner
    $payout_settings = [];
    if ($partner_type === 'channel_partner') {
        $settings_query = "SELECT ps.*, u.name as advisor_name, p.name as product_name
                        FROM payout_settings ps
                        JOIN users u ON ps.advisor_user_id = u.id
                        LEFT JOIN products p ON ps.product_id = p.id
                        WHERE ps.user_id = ?
                        ORDER BY u.name, p.name";
        $settings_stmt = $conn->prepare($settings_query);
        $settings_stmt->bind_param("i", $user_id);
        $settings_stmt->execute();
        $settings_result = $settings_stmt->get_result();
        while ($row = $settings_result->fetch_assoc()) {
            $payout_settings[] = $row;
        }
        $settings_stmt->close();
    }

    // Get payout ledger entries
    $ledger_query = "SELECT pl.*, u.name as source_name, l.lead_id, l.customer_name, p.name as product_name, p.category as product_category
                    FROM payout_ledger pl
                    LEFT JOIN users u ON pl.source_user_id = u.id
                    LEFT JOIN leads l ON pl.lead_id = l.id
                    LEFT JOIN products p ON pl.product_id = p.id
                    WHERE pl.user_id = ?
                    ORDER BY pl.created_at DESC
                    LIMIT 100";
    $ledger_stmt = $conn->prepare($ledger_query);
    $ledger_stmt->bind_param("i", $user_id);
    $ledger_stmt->execute();
    $ledger_entries = $ledger_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $ledger_stmt->close();

    // Calculate totals and margin earnings for channel partners
    $total_earned = 0;
    $total_pending = 0;
    $total_paid = 0;
    $margin_earned = 0;
    $downline_paid = 0;

    foreach ($ledger_entries as $entry) {
        $total_earned += $entry['amount'];
        if ($entry['status'] === 'pending') {
            $total_pending += $entry['amount'];
        } elseif ($entry['status'] === 'paid') {
            $total_paid += $entry['amount'];
        }
        
        // Track margin earnings for channel partners
        if ($partner_type === 'channel_partner' && in_array($entry['earning_type'], ['margin_control', 'margin_earning'])) {
            $margin_earned += $entry['amount'];
        }
    }

    // Calculate downline payouts for channel partners
    if ($partner_type === 'channel_partner') {
        $downline_query = "SELECT SUM(amount) as total FROM payout_ledger WHERE source_user_id = ? AND earning_type = 'referral_percentage'";
        $downline_stmt = $conn->prepare($downline_query);
        $downline_stmt->bind_param("i", $user_id);
        $downline_stmt->execute();
        $downline_result = $downline_stmt->get_result()->fetch_assoc();
        $downline_paid = $downline_result['total'] ?? 0;
        $downline_stmt->close();
    }
    ?>

<?php include '../../includes/header.php'; ?>



    <!-- Page Header -->
    <div class="bg-white border-b border-slate-200 py-6 mb-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-2xl font-bold text-slate-900">Team Payouts</h1>
                    <p class="text-slate-600 mt-1">Manage payout settings and track earnings</p>
                </div>
                <div class="text-right">
                    <div class="text-sm text-slate-500">Partner Type</div>
                    <div class="text-lg font-semibold text-slate-900 capitalize"><?= str_replace('_', ' ', $partner_type) ?></div>
                </div>
            </div>
        </div>
    </div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
            <!-- Alert Messages -->
            <?php if (isset($error)): ?>
                <div class="alert alert-error mb-4">
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success mb-4">
                    <i class="fas fa-check-circle mr-2"></i>
                    <?= htmlspecialchars($success) ?>
                </div>
            <?php endif; ?>

            <!-- Navigation Tabs -->
            <div class="card mb-6">
                <div class="flex border-b border-slate-200">
                    <button onclick="switchTab('settings')" 
                            class="tab-button flex-1 px-6 py-4 text-center font-medium transition-all duration-200 <?= $active_subsection === 'settings' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50' ?>">
                        <i class="fas fa-cog mr-2"></i>
                        <span class="hidden sm:inline">Payout Settings</span>
                        <span class="sm:hidden">Settings</span>
                    </button>
                    <button onclick="switchTab('summary')" 
                            class="tab-button flex-1 px-6 py-4 text-center font-medium transition-all duration-200 <?= $active_subsection === 'summary' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50' ?>">
                        <i class="fas fa-chart-bar mr-2"></i>
                        <span class="hidden sm:inline">Payout Summary</span>
                        <span class="sm:hidden">Summary</span>
                    </button>
                </div>
            </div>

            <!-- Settings Tab -->
            <div id="tab-settings" class="tab-content <?= $active_subsection === 'settings' ? '' : 'hidden' ?>">
                <?php if ($partner_type === 'network_partner'): ?>
                    <!-- Network Partner View -->
                    <div class="bg-white rounded-xl shadow-sm p-8">
                        <div class="text-center mb-8">
                            <div class="inline-flex items-center px-4 py-2 bg-blue-100 text-blue-800 rounded-full text-sm font-medium mb-4">
                                <i class="fas fa-network-wired mr-2"></i>
                                Network Partner Program
                            </div>
                            <h2 class="text-2xl font-bold text-gray-900 mb-2">Fixed Percentage Structure</h2>
                            <p class="text-gray-600">Your earnings are calculated automatically based on team performance</p>
                        </div>
                        
                        <div class="grid md:grid-cols-3 gap-6 mb-8">
                            <div class="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6 text-center border border-blue-200 hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
                                <div class="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <i class="fas fa-user text-white text-xl"></i>
                                </div>
                                <div class="text-3xl font-bold text-blue-600 mb-2">5%</div>
                                <div class="text-sm font-semibold text-blue-800 mb-1">Level 1</div>
                                <div class="text-xs text-blue-600">Direct Referrals</div>
                            </div>
                            <div class="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-6 text-center border border-purple-200 hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
                                <div class="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <i class="fas fa-users text-white text-xl"></i>
                                </div>
                                <div class="text-3xl font-bold text-purple-600 mb-2">2%</div>
                                <div class="text-sm font-semibold text-purple-800 mb-1">Level 2</div>
                                <div class="text-xs text-purple-600">Indirect Referrals</div>
                            </div>
                            <div class="bg-gradient-to-br from-pink-50 to-pink-100 rounded-xl p-6 text-center border border-pink-200 hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
                                <div class="w-16 h-16 bg-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <i class="fas fa-sitemap text-white text-xl"></i>
                                </div>
                                <div class="text-3xl font-bold text-pink-600 mb-2">1%</div>
                                <div class="text-sm font-semibold text-pink-800 mb-1">Level 3</div>
                                <div class="text-xs text-pink-600">Deep Network</div>
                            </div>
                        </div>
                        
                        <div class="bg-gray-50 rounded-xl p-6 border border-gray-200">
                            <div class="flex items-center">
                                <i class="fas fa-info-circle text-blue-500 text-xl mr-3"></i>
                                <div>
                                    <h3 class="font-semibold text-gray-900 mb-1">Automatic Calculation</h3>
                                    <p class="text-gray-600 text-sm">These rates are fixed and calculated automatically by our system. No manual configuration required.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Channel Partner View -->
                    <div class="space-y-8">
                        <!-- Margin Overview -->
                        <div class="bg-white rounded-xl shadow-sm p-8">
                            <h2 class="text-xl font-bold text-gray-900 mb-6">
                                <i class="fas fa-chart-line text-blue-600 mr-2"></i>
                                Margin Trading Overview
                            </h2>
                            <div class="grid md:grid-cols-3 gap-6">
                                <div class="bg-gradient-to-br from-green-50 to-emerald-100 rounded-xl p-6 border border-green-200 hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
                                    <div class="flex items-center justify-between mb-4">
                                        <div class="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center">
                                            <i class="fas fa-wallet text-white"></i>
                                        </div>
                                        <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">Total</span>
                                    </div>
                                    <div class="text-2xl font-bold text-green-700 mb-1">₹<?= number_format($total_earned, 0) ?></div>
                                    <div class="text-sm text-green-600">Master Payout Received</div>
                                </div>
                                <div class="bg-gradient-to-br from-purple-50 to-violet-100 rounded-xl p-6 border border-purple-200 hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
                                    <div class="flex items-center justify-between mb-4">
                                        <div class="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center">
                                            <i class="fas fa-arrow-down text-white"></i>
                                        </div>
                                        <span class="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">Paid</span>
                                    </div>
                                    <div class="text-2xl font-bold text-purple-700 mb-1">₹<?= number_format($downline_paid, 0) ?></div>
                                    <div class="text-sm text-purple-600">Paid to Team</div>
                                </div>
                                <div class="bg-gradient-to-br from-blue-50 to-cyan-100 rounded-xl p-6 border border-blue-200 hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
                                    <div class="flex items-center justify-between mb-4">
                                        <div class="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center">
                                            <i class="fas fa-trophy text-white"></i>
                                        </div>
                                        <span class="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Profit</span>
                                    </div>
                                    <div class="text-2xl font-bold text-blue-700 mb-1">₹<?= number_format($total_earned - $downline_paid, 0) ?></div>
                                    <div class="text-sm text-blue-600">Your Margin Profit</div>
                                </div>
                            </div>
                            <div class="mt-6 bg-blue-50 rounded-xl p-4 border border-blue-200">
                                <div class="flex items-start">
                                    <i class="fas fa-lightbulb text-blue-500 text-lg mr-3 mt-1"></i>
                                    <div>
                                        <h4 class="font-semibold text-blue-900 mb-1">How Margin Trading Works</h4>
                                        <p class="text-blue-700 text-sm">You receive the full payout from Finocards, set custom rates for your advisors, and keep the margin difference as profit. The more strategic your rate setting, the higher your margins.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if (empty($team_members)): ?>
                            <!-- Empty State -->
                            <div class="bg-white rounded-xl shadow-sm p-12 text-center">
                                <div class="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                                    <i class="fas fa-users text-gray-400 text-3xl"></i>
                                </div>
                                <h3 class="text-xl font-semibold text-gray-900 mb-2">No Team Members Yet</h3>
                                <p class="text-gray-600 mb-6">Start building your team by sharing your referral link</p>
                                <button class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
                                    <i class="fas fa-share mr-2"></i>Share Referral Link
                                </button>
                            </div>
                        <?php else: ?>
                            <!-- Rate Settings Form -->
                            <div class="bg-white rounded-xl shadow-sm p-8">
                                <h2 class="text-xl font-bold text-gray-900 mb-6">
                                    <i class="fas fa-sliders-h text-blue-600 mr-2"></i>
                                    Rate Manager
                                </h2>
                                <p class="text-gray-600 mb-8">Set custom payout rates for your team members and manage your profit margins</p>
                                
                                <form method="POST" class="space-y-6" id="rateForm">
                                    <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                                        <div>
                                            <label class="block text-sm font-semibold text-gray-700 mb-2">
                                                <i class="fas fa-user text-gray-400 mr-1"></i>Select Advisor
                                            </label>
                                            <select name="advisor_id" id="advisorSelect" required onchange="fetchAdvisorSettings()" 
                                                    class="form-input">
                                                <option value="">Choose advisor...</option>
                                                <?php foreach ($team_members as $member): ?>
                                                    <option value="<?= $member['id'] ?>"><?= htmlspecialchars($member['name']) ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="block text-sm font-semibold text-gray-700 mb-2">
                                                <i class="fas fa-box text-gray-400 mr-1"></i>Product (Optional)
                                            </label>
                                            <select name="product_id" id="productSelect" onchange="loadExistingRate()" 
                                                    class="form-input">
                                                <option value="">All Products</option>
                                                <?php foreach ($products as $product): ?>
                                                    <option value="<?= $product['id'] ?>"><?= htmlspecialchars($product['name']) ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="block text-sm font-semibold text-gray-700 mb-2">
                                                <i class="fas fa-tag text-gray-400 mr-1"></i>Rate Type
                                            </label>
                                            <select name="rate_type" id="rateType" required onchange="updateRateInput()" 
                                                    class="form-input">
                                                <option value="card_amount">Card Amount (₹)</option>
                                                <option value="loan_percentage">Loan Percentage (%)</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="block text-sm font-semibold text-gray-700 mb-2">
                                                <i class="fas fa-rupee-sign text-gray-400 mr-1"></i>Payout Rate
                                            </label>
                                            <input type="number" name="payout_rate" id="payoutRate" step="100" min="0" required 
                                                class="form-input" placeholder="Enter rate">
                                            <small class="text-xs text-gray-500 mt-1 block" id="rateHint">Multiples of ₹100</small>
                                        </div>
                                    </div>
                                    <div class="flex justify-end">
                                        <button type="submit" name="save_payout_setting" class="btn-primary">
                                            <i class="fas fa-save mr-2"></i>Save Setting
                                        </button>
                                    </div>
                                </form>
                            </div>

                            <!-- Existing Settings -->
                            <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                                <div class="px-8 py-6 border-b border-gray-200">
                                    <h2 class="text-xl font-bold text-gray-900">
                                        <i class="fas fa-list text-blue-600 mr-2"></i>
                                        Current Rate Settings
                                    </h2>
                                </div>
                                <?php if (empty($payout_settings)): ?>
                                    <div class="p-12 text-center">
                                        <i class="fas fa-clipboard-list text-4xl text-gray-300 mb-4"></i>
                                        <p class="text-gray-600">No rate settings configured yet</p>
                                    </div>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead class="bg-gray-50">
                                                <tr>
                                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Advisor</th>
                                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Product</th>
                                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Type</th>
                                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Rate</th>
                                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody class="divide-y divide-gray-200">
                                                <?php foreach ($payout_settings as $setting): ?>
                                                    <tr class="hover:bg-gray-50 transition-colors">
                                                        <td class="px-6 py-4">
                                                            <div class="flex items-center">
                                                                <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                                                                    <i class="fas fa-user text-blue-600 text-sm"></i>
                                                                </div>
                                                                <span class="font-medium text-gray-900"><?= htmlspecialchars($setting['advisor_name']) ?></span>
                                                            </div>
                                                        </td>
                                                        <td class="px-6 py-4 text-gray-600">
                                                            <?= $setting['product_name'] ? htmlspecialchars($setting['product_name']) : '<span class="text-gray-400 italic">All Products</span>' ?>
                                                        </td>
                                                        <td class="px-6 py-4">
                                                            <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full <?= $setting['rate_type'] === 'card_amount' ? 'bg-green-100 text-green-700' : 'bg-purple-100 text-purple-700' ?>">
                                                                <?= $setting['rate_type'] === 'card_amount' ? 'Card (₹)' : 'Loan (%)' ?>
                                                            </span>
                                                        </td>
                                                        <td class="px-6 py-4">
                                                            <span class="text-lg font-bold text-blue-600">
                                                                <?= $setting['rate_type'] === 'card_amount' ? '₹' : '' ?><?= number_format($setting['payout_rate'], $setting['rate_type'] === 'card_amount' ? 0 : 1) ?><?= $setting['rate_type'] === 'loan_percentage' ? '%' : '' ?>
                                                            </span>
                                                        </td>
                                                        <td class="px-6 py-4">
                                                            <div class="flex space-x-2">
                                                                <button onclick="editSetting(<?= $setting['id'] ?>)" 
                                                                        class="text-blue-600 hover:text-blue-800 p-2 rounded-lg hover:bg-blue-50 transition-colors">
                                                                    <i class="fas fa-edit"></i>
                                                                </button>
                                                                <button onclick="deleteSetting(<?= $setting['id'] ?>)" 
                                                                        class="text-red-600 hover:text-red-800 p-2 rounded-lg hover:bg-red-50 transition-colors">
                                                                    <i class="fas fa-trash"></i>
                                                                </button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Summary Tab -->
            <div id="tab-summary" class="tab-content <?= $active_subsection === 'summary' ? '' : 'hidden' ?>">
                <div class="space-y-8">
                    <!-- Summary Cards -->
                    <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200 hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
                            <div class="flex items-center justify-between mb-4">
                                <div class="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-wallet text-white"></i>
                                </div>
                                <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">Total</span>
                            </div>
                            <div class="text-2xl font-bold text-gray-900 mb-1">₹<?= number_format($total_earned, 2) ?></div>
                            <div class="text-sm text-gray-600">Total Earned</div>
                        </div>
                        
                        <?php if ($partner_type === 'channel_partner'): ?>
                        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200 hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
                            <div class="flex items-center justify-between mb-4">
                                <div class="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-chart-line text-white"></i>
                                </div>
                                <span class="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">Profit</span>
                            </div>
                            <div class="text-2xl font-bold text-gray-900 mb-1">₹<?= number_format($total_earned - $downline_paid, 2) ?></div>
                            <div class="text-sm text-gray-600">Margin Profit</div>
                        </div>
                        <?php endif; ?>
                        
                        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200 hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
                            <div class="flex items-center justify-between mb-4">
                                <div class="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-hourglass-half text-white"></i>
                                </div>
                                <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full">Pending</span>
                            </div>
                            <div class="text-2xl font-bold text-gray-900 mb-1">₹<?= number_format($total_pending, 2) ?></div>
                            <div class="text-sm text-gray-600">Pending Amount</div>
                        </div>
                        
                        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200 hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
                            <div class="flex items-center justify-between mb-4">
                                <div class="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-check-circle text-white"></i>
                                </div>
                                <span class="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Paid</span>
                            </div>
                            <div class="text-2xl font-bold text-gray-900 mb-1">₹<?= number_format($total_paid, 2) ?></div>
                            <div class="text-sm text-gray-600">Amount Paid</div>
                        </div>
                    </div>

                    <!-- Payout Ledger -->
                    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                        <div class="px-8 py-6 border-b border-gray-200">
                            <h2 class="text-xl font-bold text-gray-900">
                                <i class="fas fa-history text-blue-600 mr-2"></i>
                                Payout History
                            </h2>
                        </div>
                        
                        <?php if (empty($ledger_entries)): ?>
                            <div class="p-12 text-center">
                                <i class="fas fa-chart-bar text-4xl text-gray-300 mb-4"></i>
                                <h3 class="text-lg font-semibold text-gray-900 mb-2">No Payout History</h3>
                                <p class="text-gray-600">Your payout entries will appear here once you start earning</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Date</th>
                                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Source</th>
                                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Type</th>
                                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Product</th>
                                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Amount</th>
                                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-gray-200">
                                        <?php foreach ($ledger_entries as $entry): ?>
                                            <tr class="hover:bg-gray-50 transition-colors">
                                                <td class="px-6 py-4 text-sm text-gray-600">
                                                    <?= date('d M Y', strtotime($entry['created_at'])) ?>
                                                </td>
                                                <td class="px-6 py-4">
                                                    <?php if ($entry['source_user_id']): ?>
                                                        <div class="flex items-center">
                                                            <div class="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                                                                <i class="fas fa-user text-gray-600 text-sm"></i>
                                                            </div>
                                                            <span class="text-gray-900"><?= htmlspecialchars($entry['source_name'] ?? 'Team Member') ?></span>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="flex items-center">
                                                            <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                                                                <i class="fas fa-user-tie text-blue-600 text-sm"></i>
                                                            </div>
                                                            <span class="text-blue-600 font-medium">Self</span>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="px-6 py-4">
                                                    <?php
                                                    $type_config = [
                                                        'self' => ['label' => 'Self Earned', 'color' => 'bg-blue-100 text-blue-700'],
                                                        'referral_percentage' => ['label' => 'Referral %', 'color' => 'bg-purple-100 text-purple-700'],
                                                        'margin_control' => ['label' => 'Margin Control', 'color' => 'bg-green-100 text-green-700'],
                                                        'margin_earning' => ['label' => 'Team Margin', 'color' => 'bg-orange-100 text-orange-700']
                                                    ];
                                                    $config = $type_config[$entry['earning_type']] ?? ['label' => $entry['earning_type'], 'color' => 'bg-gray-100 text-gray-700'];
                                                    ?>
                                                    <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full <?= $config['color'] ?>">
                                                        <?= $config['label'] ?>
                                                    </span>
                                                </td>
                                                <td class="px-6 py-4 text-sm text-gray-600">
                                                    <?= htmlspecialchars($entry['product_name'] ?? 'N/A') ?>
                                                </td>
                                                <td class="px-6 py-4">
                                                    <span class="text-lg font-bold text-green-600">₹<?= number_format($entry['amount'], 2) ?></span>
                                                </td>
                                                <td class="px-6 py-4">
                                                    <?php
                                                    $status_config = [
                                                        'pending' => 'bg-yellow-100 text-yellow-700',
                                                        'processing' => 'bg-blue-100 text-blue-700',
                                                        'paid' => 'bg-green-100 text-green-700',
                                                        'cancelled' => 'bg-red-100 text-red-700'
                                                    ];
                                                    $status_color = $status_config[$entry['status']] ?? 'bg-gray-100 text-gray-700';
                                                    ?>
                                                    <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full <?= $status_color ?>">
                                                        <?= ucfirst($entry['status']) ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <script>
            // Tab switching
            function switchTab(tab) {
                document.querySelectorAll('.tab-content').forEach(content => {
                    content.classList.add('hidden');
                });
                document.getElementById('tab-' + tab).classList.remove('hidden');
                
                document.querySelectorAll('.tab-button').forEach(btn => {
                    btn.classList.remove('bg-blue-50', 'text-blue-600', 'border-b-2', 'border-blue-600');
                    btn.classList.add('text-gray-600');
                });
                event.target.closest('button').classList.add('bg-blue-50', 'text-blue-600', 'border-b-2', 'border-blue-600');
                event.target.closest('button').classList.remove('text-gray-600');
                
                const url = new URL(window.location);
                url.searchParams.set('subsection', tab);
                window.history.pushState({}, '', url);
            }

            // Rate input handling
            function updateRateInput() {
                const rateType = document.getElementById('rateType').value;
                const rateInput = document.getElementById('payoutRate');
                const rateHint = document.getElementById('rateHint');
                
                if (rateType === 'card_amount') {
                    rateInput.step = '100';
                    rateInput.min = '0';
                    rateInput.placeholder = 'Enter amount (₹)';
                    rateHint.textContent = 'Multiples of ₹100';
                } else {
                    rateInput.step = '0.1';
                    rateInput.min = '0';
                    rateInput.max = '100';
                    rateInput.placeholder = 'Enter percentage (%)';
                    rateHint.textContent = 'Multiples of 0.1%';
                }
            }

            let advisorSettings = [];

            function fetchAdvisorSettings() {
                const advisorId = document.getElementById('advisorSelect').value;
                if (!advisorId) {
                    advisorSettings = [];
                    return;
                }
                
                const form = document.getElementById('rateForm');
                form.classList.add('loading');
                
                fetch(`get_advisor_settings.php?advisor_id=${advisorId}`)
                    .then(response => response.json())
                    .then(data => {
                        advisorSettings = data;
                        loadExistingRate();
                    })
                    .catch(error => console.error('Error:', error))
                    .finally(() => {
                        form.classList.remove('loading');
                    });
            }

            function loadExistingRate() {
                const productId = document.getElementById('productSelect').value;
                const rateTypeSelect = document.getElementById('rateType');
                const payoutRateInput = document.getElementById('payoutRate');
                
                const existing = advisorSettings.find(s => 
                    (s.product_id == productId) || (!productId && !s.product_id)
                );
                
                if (existing) {
                    rateTypeSelect.value = existing.rate_type;
                    payoutRateInput.value = existing.payout_rate;
                    updateRateInput();
                } else {
                    payoutRateInput.value = '';
                }
            }

            function editSetting(settingId) {
                fetch(`get_advisor_settings.php?setting_id=${settingId}`)
                    .then(response => response.json())
                    .then(setting => {
                        document.getElementById('advisorSelect').value = setting.advisor_user_id;
                        fetchAdvisorSettings();
                        
                        setTimeout(() => {
                            document.getElementById('productSelect').value = setting.product_id || '';
                            document.getElementById('rateType').value = setting.rate_type;
                            document.getElementById('payoutRate').value = setting.payout_rate;
                            updateRateInput();
                            
                            // Scroll to form
                            document.getElementById('rateForm').scrollIntoView({ behavior: 'smooth' });
                        }, 500);
                    })
                    .catch(error => console.error('Error:', error));
            }

            function deleteSetting(settingId) {
                if (confirm('Are you sure you want to delete this payout setting?')) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.innerHTML = `
                        <input type="hidden" name="delete_setting" value="1">
                        <input type="hidden" name="setting_id" value="${settingId}">
                    `;
                    document.body.appendChild(form);
                    form.submit();
                }
            }

            // Initialize
            updateRateInput();
        </script>

</body>
</html>