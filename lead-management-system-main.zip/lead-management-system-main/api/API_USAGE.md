# API Usage - Channel Code Assignment

## Create Lead with Channel Code

### Endpoint
`POST /api/leads.php`

### Headers
```
X-API-KEY: your_api_key
Content-Type: application/json
```

### Request Body
```json
{
  "name": "John Doe",
  "mobile": "9876543210",
  "email": "john@example.com",
  "product_id": 1,
  "channel_code": "PARTNER_001",
  "tracking_code": "TRK123",
  "ref": "REF456",
  "unique_utm_id": "CHANNEL_UTM_123"
}
```

### Channel Code Priority (Web Users)
1. **User's System Channel Code** - From signup (highest priority)
2. **tracking_code** - Lookup from advisor_products table
3. **ref** - Use as channel code
4. **unique_utm_id** - Extract first part before underscore
5. **Default** - "WEB_DIRECT"

### Channel Code Priority (API Users)
1. **channel_code** - Direct assignment (highest priority)
2. **tracking_code** - Lookup from advisor_products table
3. **ref** - Use as channel code
4. **unique_utm_id** - Extract first part before underscore
5. **Default** - "API_DIRECT"

### Channel Code Format
- 3-20 characters
- Uppercase letters, numbers, underscores only
- Examples: `PARTNER_001`, `WEB_DIRECT`, `MOBILE_APP`

### Response
```json
{
  "success": true,
  "message": "Lead created successfully",
  "data": {
    "lead_id": "ABC123",
    "product_name": "Credit Card",
    "redirect_url": "https://bank.com/apply?lead=ABC123",
    "status": "created"
  }
}
```