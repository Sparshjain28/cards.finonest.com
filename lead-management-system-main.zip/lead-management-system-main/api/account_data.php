<?php
header('Content-Type: application/json');
require_once 'classes/AccountAggregator.php';
require_once 'config/database_updated.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$database = new Database();
$conn = $database->getConnection();
$aa = new AccountAggregator(null, $conn);

if (isset($_GET['id'])) {
    $report = $aa->getReportById($_GET['id']);
    if ($report) {
        $data = json_decode($report['report_data'], true);
        $transformed = $aa->transformData(json_encode($data));
        echo json_encode($transformed);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Report not found']);
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Report ID required']);
}
?>