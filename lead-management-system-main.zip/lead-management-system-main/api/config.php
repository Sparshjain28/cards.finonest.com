<?php
// API Configuration
define('API_VERSION', '1.0');
define('API_RATE_LIMIT', 100); // requests per hour per API key

// CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../includes/auto_migrate.php'; // Auto-run migrations

function validateApiKey($api_key) {
    $database = new Database();
    $conn = $database->getConnection();
    
    $stmt = $conn->prepare("SELECT id, name, rate_limit, is_active, channel_code FROM api_keys WHERE api_key = ? AND is_active = 1");
    $stmt->bind_param("s", $api_key);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    return $result;
}

function checkRateLimit($api_key_id) {
    $database = new Database();
    $conn = $database->getConnection();
    
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM api_requests WHERE api_key_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    $stmt->bind_param("i", $api_key_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    return $result['count'] < API_RATE_LIMIT;
}

function logApiRequest($api_key_id, $endpoint, $method, $ip) {
    $database = new Database();
    $conn = $database->getConnection();
    
    $stmt = $conn->prepare("INSERT INTO api_requests (api_key_id, endpoint, method, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $api_key_id, $endpoint, $method, $ip);
    $stmt->execute();
    $stmt->close();
}

function apiResponse($data, $status = 200, $message = 'Success') {
    http_response_code($status);
    echo json_encode([
        'status' => $status,
        'message' => $message,
        'data' => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    exit;
}

function apiError($message, $status = 400) {
    apiResponse(null, $status, $message);
}
?>