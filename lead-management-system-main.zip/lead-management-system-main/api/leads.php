<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';
require_once __DIR__ . '/../classes/Lead.php';
require_once __DIR__ . '/../db_update.php';
require_once __DIR__ . '/../includes/payout_calculator.php';

// Auto-update database on first API access
checkAndUpdateDatabase();

// Get API key from header
$api_key = $_SERVER['HTTP_X_API_KEY'] ?? null;
if (!$api_key) {
    apiError('API key required', 401);
}

// Validate API key
$api_user = validateApiKey($api_key);
if (!$api_user) {
    apiError('Invalid API key', 401);
}

// Check rate limit
if (!checkRateLimit($api_user['id'])) {
    apiError('Rate limit exceeded', 429);
}

// Log request
logApiRequest($api_user['id'], '/leads', $_SERVER['REQUEST_METHOD'], $_SERVER['REMOTE_ADDR']);

// Handle different HTTP methods
switch ($_SERVER['REQUEST_METHOD']) {
    case 'POST':
        createLead();
        break;
    case 'GET':
        getLeads();
        break;
    default:
        apiError('Method not allowed', 405);
}

function createLead() {
    global $api_user;
    $raw_input = file_get_contents('php://input');
    $input = json_decode($raw_input, true);
    
    if (!$input) {
        apiError('Invalid JSON input');
    }
    
    // Use channel_code from API key - no manual assignment needed
    if (empty($api_user['channel_code'])) {
        apiError('API key missing channel code assignment - contact administrator');
    }
    
    // Validate required fields (channel_code no longer required in input)
    $required = ['name', 'mobile', 'email', 'product_id'];
    foreach ($required as $field) {
        if (empty($input[$field])) {
            apiError("Field '$field' is required");
        }
    }
    
    // Validate data
    if (!preg_match('/^[0-9]{10}$/', $input['mobile'])) {
        apiError('Invalid mobile number format');
    }
    
    if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        apiError('Invalid email format');
    }
    
    // Validate channel_code if provided
    if (!empty($input['channel_code']) && !preg_match('/^[A-Z0-9_]{3,20}$/', $input['channel_code'])) {
        apiError('Invalid channel_code format. Use 3-20 uppercase letters, numbers, or underscores.');
    }
    
    try {
        $database = new Database();
        $conn = $database->getConnection();
        
        if (!$conn) {
            apiError('Database connection failed', 500);
        }
        
        // Check for duplicate for same product (only generated/pending leads)
        $check_stmt = $conn->prepare("SELECT id, lead_id FROM leads WHERE (mobile = ? OR email = ?) AND product_id = ? AND status IN ('generated', 'in_process', 'approved', 'activated', 'disbursed', 'curable') ORDER BY created_at DESC LIMIT 1");
        $check_stmt->bind_param("ssi", $input['mobile'], $input['email'], $input['product_id']);
        $check_stmt->execute();
        $duplicate_result = $check_stmt->get_result();
        if ($duplicate_result->num_rows > 0) {
            $duplicate_lead = $duplicate_result->fetch_assoc();
            $check_stmt->close();
            apiError('Generated application found for this product. Existing Lead ID: ' . $duplicate_lead['lead_id'], 409);
        }
        $check_stmt->close();
        
        // Get product details including bank_redirect_url
        $stmt = $conn->prepare("SELECT id, name, bank_redirect_url, commission_rate FROM products WHERE id = ? AND status = 'active'");
        $stmt->bind_param("i", $input['product_id']);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$product) {
            apiError('Invalid product ID');
        }
        
        // Generate 6-digit alphanumeric lead ID
        $lead_id = generateAlphaNumericLeadId(6);
        
        // Use channel_code from API key
        $channel_code = $api_user['channel_code'];
        
        // Prepare lead data
        $lead_data = [
            'lead_id' => $lead_id,
            'customer_name' => $input['name'],
            'email' => $input['email'],
            'mobile' => $input['mobile'],
            'phone' => $input['mobile'],
            'product_id' => $input['product_id'],
            'channel_code' => $channel_code,
            'unique_utm_id' => $input['unique_utm_id'] ?? null,
            'status' => 'generated'
        ];
        
        // Create lead
        $lead = new Lead($conn);
        $lead_db_id = $lead->create($lead_data);
        
        if ($lead_db_id) {
            // Generate redirect URL with lead ID
            $redirect_url = str_replace(
                ['{lead id}', '{leadId}', '{lead_id}'],
                $lead_id,
                $product['bank_redirect_url']
            );
            
            // Get lead details for payout calculation
            $lead_details_stmt = $conn->prepare("SELECT cust_type, bkyc_status FROM leads WHERE id = ?");
            $lead_details_stmt->bind_param("i", $lead_db_id);
            $lead_details_stmt->execute();
            $lead_details = $lead_details_stmt->get_result()->fetch_assoc();
            $lead_details_stmt->close();
            
            // Calculate payout based on cust_type and bkyc_status
            $payout_calc = calculateLeadPayout(
                $product['commission_rate'],
                $lead_details['cust_type'] ?? null,
                $lead_details['bkyc_status'] ?? null
            );
            
            // Create payout record with deduction
            $payout_stmt = $conn->prepare("INSERT INTO payouts (lead_id, channel_code, commission_amount, deduction_amount, status) VALUES (?, ?, ?, ?, 'pending')");
            $payout_stmt->bind_param("isdd", $lead_db_id, $channel_code, $payout_calc['commission_amount'], $payout_calc['deduction_amount']);
            $payout_stmt->execute();
            $payout_stmt->close();
            
            apiResponse([
                'lead_id' => $lead_id,
                'product_name' => $product['name'],
                'redirect_url' => $redirect_url,
                'status' => 'created'
            ], 201, 'Lead created successfully');
        } else {
            apiError('Failed to create lead', 500);
        }
        
    } catch (Exception $e) {
        apiError('Internal server error: ' . $e->getMessage(), 500);
    }
}

function getLeads() {
    global $api_user;
    
    // Use channel_code from API key
    if (empty($api_user['channel_code'])) {
        apiError('API key missing channel code assignment - contact administrator');
    }
    
    $database = new Database();
    $conn = $database->getConnection();
    
    $limit = min((int)($_GET['limit'] ?? 20), 100);
    $offset = (int)($_GET['offset'] ?? 0);
    $status = $_GET['status'] ?? null;
    
    try {
        $where = "WHERE channel_code = ?";
        $params = [$api_user['channel_code']];
        $types = 's';
        
        if ($status) {
            $where .= " AND status = ?";
            $params[] = $status;
            $types .= 's';
        }
        
        $query = "SELECT lead_id, customer_name, email, mobile, status, channel_code, created_at FROM leads $where ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        $types .= 'ii';
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $leads = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        apiResponse($leads);
        
    } catch (Exception $e) {
        apiError('Internal server error: ' . $e->getMessage(), 500);
    }
}

function resolveChannelCode($input, $conn) {
    // Priority 1: Direct channel_code
    if (!empty($input['channel_code'])) {
        return $input['channel_code'];
    }
    
    // Priority 2: Tracking code lookup
    if (!empty($input['tracking_code'])) {
        $stmt = $conn->prepare("SELECT u.channel_code FROM advisor_products ap JOIN users u ON ap.advisor_id = u.id WHERE ap.tracking_code = ? LIMIT 1");
        $stmt->bind_param("s", $input['tracking_code']);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $stmt->close();
            return $row['channel_code'];
        }
        $stmt->close();
    }
    
    // Priority 3: Ref code
    if (!empty($input['ref'])) {
        return $input['ref'];
    }
    
    // Priority 4: Extract from unique_utm_id
    if (!empty($input['unique_utm_id'])) {
        $parts = explode('_', $input['unique_utm_id']);
        if (count($parts) >= 2) {
            return $parts[0];
        }
    }
    
    // Default
    return 'API_DIRECT';
}

function generateAlphaNumericLeadId($length = 6) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $leadId = '';
    for ($i = 0; $i < $length; $i++) {
        $leadId .= $characters[random_int(0, strlen($characters) - 1)];
    }
    return $leadId;
}
?>
