<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();

$user = getCurrentUser();
if (!isAdmin()) {
    header('Location: ../admin/dashboard.php');
    exit;
}

require_once __DIR__ . '/../config/database_updated.php';
$database = new Database();
$conn = $database->getConnection();

// Handle API key generation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_key'])) {
    $name = trim($_POST['name']);
    $rate_limit = (int)$_POST['rate_limit'];
    $channel_code = trim($_POST['channel_code']);
    
    if (!empty($name) && !empty($channel_code)) {
        $api_key = 'lms_' . bin2hex(random_bytes(16));
        
        $stmt = $conn->prepare("INSERT INTO api_keys (name, api_key, rate_limit, channel_code, created_by) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssisi", $name, $api_key, $rate_limit, $channel_code, $user['id']);
        $stmt->execute();
        $stmt->close();
        
        $success = "API key generated successfully with channel code: $channel_code";
    } else {
        $error = "Name and channel code are required";
    }
}

// Handle name update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_name'])) {
    $key_id = (int)$_POST['key_id'];
    $name = trim($_POST['name']);
    
    if (!empty($name)) {
        $stmt = $conn->prepare("UPDATE api_keys SET name = ? WHERE id = ?");
        $stmt->bind_param("si", $name, $key_id);
        $stmt->execute();
        $stmt->close();
        
        $success = "Name updated successfully!";
    } else {
        $error = "Name is required";
    }
}

// Handle channel code update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_channel'])) {
    $key_id = (int)$_POST['key_id'];
    $channel_code = trim($_POST['channel_code']);
    
    if (!empty($channel_code)) {
        $stmt = $conn->prepare("UPDATE api_keys SET channel_code = ? WHERE id = ?");
        $stmt->bind_param("si", $channel_code, $key_id);
        $stmt->execute();
        $stmt->close();
        
        $success = "Channel code updated successfully!";
    } else {
        $error = "Channel code is required";
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deactivate_key'])) {
    $key_id = (int)$_POST['key_id'];
    
    $stmt = $conn->prepare("UPDATE api_keys SET is_active = 0 WHERE id = ?");
    $stmt->bind_param("i", $key_id);
    $stmt->execute();
    $stmt->close();
    
    $success = "API key deactivated successfully!";
}

// Get all API keys
$stmt = $conn->prepare("SELECT ak.*, u.name as created_by_name FROM api_keys ak LEFT JOIN users u ON ak.created_by = u.id ORDER BY ak.created_at DESC");
$stmt->execute();
$api_keys = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    
    <div class="max-w-6xl mx-auto px-4 py-6">
        <h1 class="text-2xl font-bold mb-6">API Management</h1>
        
        <?php if (isset($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($success)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>
        
        <!-- Generate New API Key -->
        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h2 class="text-lg font-bold mb-4">Generate New API Key</h2>
            <form method="POST" class="space-y-4">
                <div class="grid grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-medium mb-1">Key Name</label>
                        <input type="text" name="name" required class="w-full px-3 py-2 border rounded-lg">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Channel Code</label>
                        <input type="text" name="channel_code" required placeholder="e.g., PARTNER_001" class="w-full px-3 py-2 border rounded-lg">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Rate Limit (per hour)</label>
                        <input type="number" name="rate_limit" value="100" min="1" max="1000" class="w-full px-3 py-2 border rounded-lg">
                    </div>
                </div>
                <button type="submit" name="generate_key" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    <i class="fas fa-key mr-2"></i>Generate API Key
                </button>
            </form>
        </div>
        
        <!-- API Keys List -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="px-6 py-4 border-b">
                <h3 class="font-bold">API Keys</h3>
            </div>
            <table class="w-full">
                <thead class="bg-slate-50">
                    <tr>
                        <th class="px-4 py-3 text-left text-sm">Name</th>
                        <th class="px-4 py-3 text-left text-sm">API Key</th>
                        <th class="px-4 py-3 text-left text-sm">Channel Code</th>
                        <th class="px-4 py-3 text-left text-sm">Rate Limit</th>
                        <th class="px-4 py-3 text-left text-sm">Status</th>
                        <th class="px-4 py-3 text-left text-sm">Created</th>
                        <th class="px-4 py-3 text-left text-sm">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($api_keys as $key): ?>
                        <tr class="border-t">
                            <td class="px-4 py-3">
                                <form method="POST" class="inline-flex items-center gap-2">
                                    <input type="hidden" name="key_id" value="<?= $key['id'] ?>">
                                    <input type="text" name="name" value="<?= htmlspecialchars($key['name']) ?>" 
                                           class="px-2 py-1 text-sm border rounded w-40">
                                    <button type="submit" name="update_name" class="text-blue-600 hover:text-blue-800 text-sm">
                                        <i class="fas fa-save"></i>
                                    </button>
                                </form>
                            </td>
                            <td class="px-4 py-3 font-mono text-sm">
                                <span id="key_<?= $key['id'] ?>" class="blur-sm"><?= htmlspecialchars($key['api_key']) ?></span>
                                <button type="button" onclick="toggleKey(<?= $key['id'] ?>)" class="ml-2 text-blue-600 hover:text-blue-800">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </td>
                            <td class="px-4 py-3">
                                <form method="POST" class="inline-flex items-center gap-2">
                                    <input type="hidden" name="key_id" value="<?= $key['id'] ?>">
                                    <input type="text" name="channel_code" value="<?= htmlspecialchars($key['channel_code'] ?? '') ?>" 
                                           placeholder="Enter channel code" class="px-2 py-1 text-sm border rounded w-32">
                                    <button type="submit" name="update_channel" class="text-blue-600 hover:text-blue-800 text-sm">
                                        <i class="fas fa-save"></i>
                                    </button>
                                </form>
                            </td>
                            <td class="px-4 py-3"><?= $key['rate_limit'] ?>/hour</td>
                            <td class="px-4 py-3">
                                <span class="px-2 py-1 text-xs rounded-full <?= $key['is_active'] ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                                    <?= $key['is_active'] ? 'Active' : 'Inactive' ?>
                                </span>
                            </td>
                            <td class="px-4 py-3 text-sm"><?= date('M d, Y', strtotime($key['created_at'])) ?></td>
                            <td class="px-4 py-3">
                                <?php if ($key['is_active']): ?>
                                    <form method="POST" class="inline">
                                        <input type="hidden" name="key_id" value="<?= $key['id'] ?>">
                                        <button type="submit" name="deactivate_key" onclick="return confirm('Deactivate this API key?')" 
                                                class="text-red-600 hover:text-red-800">
                                            <i class="fas fa-ban"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- API Documentation -->
        <div class="bg-white rounded-lg shadow p-6 mt-6">
            <h2 class="text-lg font-bold mb-4">API Documentation & Integration Examples</h2>
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Widget Integration -->
                <div class="border rounded-lg p-4">
                    <h3 class="font-semibold mb-3 text-green-600">🎯 Method 1: Complete Widget</h3>
                    <p class="text-sm text-gray-600 mb-3">Copy-paste solution with products, form & success page</p>
                    <div class="bg-gray-50 p-3 rounded text-xs font-mono overflow-x-auto">
&lt;div id="lms-widget-container">&lt;/div>
&lt;script src="<?= $_SERVER['HTTP_HOST'] ?>/api/widget.js.php?api_key=YOUR_KEY&channel=PARTNER_001">&lt;/script>
                    </div>
                    <div class="mt-2">
                        <button onclick="generateWidgetCode()" class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded hover:bg-green-200">
                            Generate My Code
                        </button>
                    </div>
                </div>
                
                <!-- Custom API -->
                <div class="border rounded-lg p-4">
                    <h3 class="font-semibold mb-3 text-blue-600">⚡ Method 2: Custom API</h3>
                    <p class="text-sm text-gray-600 mb-3">Build your own UI using our endpoints</p>
                    <div class="bg-gray-50 p-3 rounded text-xs font-mono overflow-x-auto">
// Get products with images
fetch('/api/products', {
  headers: { 'X-API-Key': 'YOUR_KEY' }
})

// Submit lead
fetch('/api/leads', {
  method: 'POST',
  headers: {
    'X-API-Key': 'YOUR_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    name: 'John Doe',
    mobile: '9876543210',
    email: 'john@example.com',
    product_id: 1
    // channel_code automatically assigned from API key
  })
})
                    </div>
                    <div class="mt-3">
                        <a href="/api/custom-integration.html" target="_blank" class="text-xs bg-blue-100 text-blue-700 px-3 py-2 rounded hover:bg-blue-200 inline-block">
                            📚 Complete Integration Guide
                        </a>
                    </div>
                </div>
                
                <!-- Iframe Embed -->
                <div class="border rounded-lg p-4">
                    <h3 class="font-semibold mb-3 text-purple-600">🖼️ Method 3: Iframe Embed</h3>
                    <p class="text-sm text-gray-600 mb-3">Direct embed of our application form</p>
                    <div class="bg-gray-50 p-3 rounded text-xs font-mono overflow-x-auto">
&lt;iframe 
  src="<?= $_SERVER['HTTP_HOST'] ?>/forms/apply_card.php?ref=PARTNER_001" 
  width="100%" 
  height="600" 
  frameborder="0">
&lt;/iframe>
                    </div>
                </div>
                
                <!-- Live Examples -->
                <div class="border rounded-lg p-4">
                    <h3 class="font-semibold mb-3 text-orange-600">🚀 Live Examples</h3>
                    <p class="text-sm text-gray-600 mb-3">See integration methods in action</p>
                    <div class="space-y-2">
                        <a href="/api/example.html" target="_blank" class="block text-sm bg-orange-100 text-orange-700 px-3 py-2 rounded hover:bg-orange-200">
                            📱 Complete Integration Demo
                        </a>
                        <a href="/api/test.html" target="_blank" class="block text-sm bg-blue-100 text-blue-700 px-3 py-2 rounded hover:bg-blue-200">
                            🧪 API Testing Interface
                        </a>
                        <button onclick="showProductsPreview()" class="block w-full text-left text-sm bg-gray-100 text-gray-700 px-3 py-2 rounded hover:bg-gray-200">
                            👁️ Products API Preview
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- API Endpoints -->
            <div class="mt-6 border-t pt-6">
                <h3 class="font-semibold mb-3">📡 Available Endpoints</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div class="bg-gray-50 p-3 rounded">
                        <div class="font-mono text-green-600">GET /api/products</div>
                        <div class="text-gray-600">Fetch products with images & details</div>
                    </div>
                    <div class="bg-gray-50 p-3 rounded">
                        <div class="font-mono text-blue-600">POST /api/leads</div>
                        <div class="text-gray-600">Submit new lead application</div>
                    </div>
                    <div class="bg-gray-50 p-3 rounded">
                        <div class="font-mono text-purple-600">GET /api/leads</div>
                        <div class="text-gray-600">Retrieve your own leads (channel_code required)</div>
                    </div>
                    <div class="bg-gray-50 p-3 rounded">
                        <div class="font-mono text-orange-600">GET /api/widget.js.php</div>
                        <div class="text-gray-600">Complete widget JavaScript</div>
                    </div>
                </div>
            </div>
            
            <!-- Authentication -->
            <div class="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded">
                <h4 class="font-semibold text-yellow-800 mb-2">🔐 Authentication</h4>
                <p class="text-sm text-yellow-700">Include your API key in all requests:</p>
                <code class="text-xs bg-yellow-100 px-2 py-1 rounded">X-API-Key: your_api_key_here</code>
            </div>
        </div>
    </div>
    
    <script>
        function toggleKey(keyId) {
            const element = document.getElementById('key_' + keyId);
            if (element) {
                element.classList.toggle('blur-sm');
            }
        }
        
        function generateWidgetCode() {
            const apiKey = prompt('Enter your API key:');
            const channel = prompt('Enter your channel code (e.g., PARTNER_001):');
            if (apiKey && channel) {
                const code = '<div id="lms-widget-container"></div>\n<script src="' + window.location.origin + '/api/widget.js.php?api_key=' + apiKey + '&channel=' + channel + '"><\/script>';
                navigator.clipboard.writeText(code).then(function() {
                    alert('Widget code copied to clipboard!');
                });
            }
        }
        
        function showProductsPreview() {
            const apiKey = prompt('Enter your API key to test:');
            if (apiKey) {
                fetch('/api/products', {
                    headers: { 'X-API-Key': apiKey }
                })
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    const popup = window.open('', '_blank', 'width=800,height=600');
                    popup.document.write('<html><head><title>Products API Response<\/title><\/head><body style="font-family: monospace; padding: 20px;"><div id="loader" class="loader"><div class="spinner"><\/div><\/div><h2>Products API Response<\/h2><pre>' + JSON.stringify(data, null, 2) + '<\/pre><script src="\/assets\/js\/loading.js"><\/script><\/body><\/html>');
                })
                .catch(function(err) { alert('Error: ' + err.message); });
            }
        }
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>