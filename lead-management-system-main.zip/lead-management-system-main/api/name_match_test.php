<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../includes/name_matcher.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $aadhaarName = $input['aadhaar_name'] ?? '';
    $panName = $input['pan_name'] ?? '';
    $bankName = $input['bank_name'] ?? '';
    
    if (empty($aadhaarName) || empty($panName) || empty($bankName)) {
        http_response_code(400);
        echo json_encode(['error' => 'All three names are required']);
        exit;
    }
    
    $matcher = new KYCNameMatcher();
    $result = $matcher->matchNames($aadhaarName, $panName, $bankName);
    
    // Add input data to response for reference
    $result['input'] = [
        'aadhaar_name' => $aadhaarName,
        'pan_name' => $panName,
        'bank_name' => $bankName
    ];
    
    echo json_encode($result, JSON_PRETTY_PRINT);
    
} else if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Return test interface
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>KYC Name Matching Test</title>
        <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    </head>
    <body class="bg-gray-100 p-8">
    <div id="loader" class="loader"><div class="spinner"></div></div>
        <div class="max-w-4xl mx-auto">
            <h1 class="text-3xl font-bold mb-6">KYC Name Matching Test</h1>
            
            <div class="bg-white rounded-lg shadow p-6 mb-6">
                <h2 class="text-xl font-semibold mb-4">Test Name Matching</h2>
                
                <div class="grid md:grid-cols-3 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium mb-2">Aadhaar Name</label>
                        <input type="text" id="aadhaarName" class="w-full border rounded px-3 py-2" placeholder="SANAM PREET SINGH">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">PAN Name</label>
                        <input type="text" id="panName" class="w-full border rounded px-3 py-2" placeholder="SANAM SINGH">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-2">Bank Name</label>
                        <input type="text" id="bankName" class="w-full border rounded px-3 py-2" placeholder="SANAMPREET SINGH">
                    </div>
                </div>
                
                <button onclick="testMatch()" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                    Test Match
                </button>
            </div>
            
            <div id="result" class="bg-white rounded-lg shadow p-6 hidden">
                <h3 class="text-lg font-semibold mb-4">Result</h3>
                <div id="resultContent"></div>
            </div>
            
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-lg font-semibold mb-4">Pre-defined Test Cases</h3>
                <div class="space-y-2">
                    <button onclick="loadTest('SANAM PREET SINGH', 'SANAM SINGH', 'SANAMPREET SINGH')" class="block w-full text-left p-2 bg-green-50 rounded hover:bg-green-100">
                        AUTO_APPROVE: Joined name case
                    </button>
                    <button onclick="loadTest('RAMAN KUMAR', 'RAMAN KUMAR SHARMA', 'RAMAN KUMAR')" class="block w-full text-left p-2 bg-green-50 rounded hover:bg-green-100">
                        AUTO_APPROVE: Exact match
                    </button>
                    <button onclick="loadTest('SANAM PREET', 'SANAM SINGH', 'PREET KAUR')" class="block w-full text-left p-2 bg-yellow-50 rounded hover:bg-yellow-100">
                        MANUAL_REVIEW: Partial match
                    </button>
                    <button onclick="loadTest('RAMAN KUMAR', 'RAMN KUMAR', 'RAMAN SINGH')" class="block w-full text-left p-2 bg-yellow-50 rounded hover:bg-yellow-100">
                        MANUAL_REVIEW: Spelling error
                    </button>
                    <button onclick="loadTest('RAMAN KUMAR', 'KUMAR SINGH', 'KUMAR SHARMA')" class="block w-full text-left p-2 bg-red-50 rounded hover:bg-red-100">
                        REJECT: Surname only
                    </button>
                    <button onclick="loadTest('AM SINGH', 'RAMAN SINGH', 'SHYAM SINGH')" class="block w-full text-left p-2 bg-red-50 rounded hover:bg-red-100">
                        REJECT: Substring false positive
                    </button>
                </div>
            </div>
        </div>
        
        <script>
            function loadTest(aadhaar, pan, bank) {
                document.getElementById('aadhaarName').value = aadhaar;
                document.getElementById('panName').value = pan;
                document.getElementById('bankName').value = bank;
                testMatch();
            }
            
            function testMatch() {
                const aadhaarName = document.getElementById('aadhaarName').value;
                const panName = document.getElementById('panName').value;
                const bankName = document.getElementById('bankName').value;
                
                if (!aadhaarName || !panName || !bankName) {
                    alert('Please fill all three name fields');
                    return;
                }
                
                fetch(window.location.href, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        aadhaar_name: aadhaarName,
                        pan_name: panName,
                        bank_name: bankName
                    })
                })
                .then(response => response.json())
                .then(data => {
                    displayResult(data);
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error testing match');
                });
            }
            
            function displayResult(data) {
                const resultDiv = document.getElementById('result');
                const contentDiv = document.getElementById('resultContent');
                
                const statusColor = {
                    'AUTO_APPROVE': 'text-green-600 bg-green-100',
                    'MANUAL_REVIEW': 'text-yellow-600 bg-yellow-100',
                    'REJECT': 'text-red-600 bg-red-100'
                };
                
                contentDiv.innerHTML = `
                    <div class="mb-4">
                        <span class="px-3 py-1 rounded-full text-sm font-medium ${statusColor[data.result] || 'text-gray-600 bg-gray-100'}">
                            ${data.result}
                        </span>
                        <span class="ml-2 text-lg font-semibold">Score: ${data.score}%</span>
                    </div>
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <h4 class="font-medium mb-2">Status</h4>
                            <p>Approved: ${data.approved ? 'Yes' : 'No'}</p>
                            <p>Manual Review: ${data.manual_review ? 'Yes' : 'No'}</p>
                        </div>
                        <div>
                            <h4 class="font-medium mb-2">Input Names</h4>
                            <p><strong>Aadhaar:</strong> ${data.input.aadhaar_name}</p>
                            <p><strong>PAN:</strong> ${data.input.pan_name}</p>
                            <p><strong>Bank:</strong> ${data.input.bank_name}</p>
                        </div>
                    </div>
                `;
                
                resultDiv.classList.remove('hidden');
            }
        </script>
        <script src="/assets/js/loading.js"></script>
</body>
    </html>
    <?php
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
?>