<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';
require_once __DIR__ . '/../db_update.php';

// Auto-update database on first API access
checkAndUpdateDatabase();

// Get API key from header
$api_key = $_SERVER['HTTP_X_API_KEY'] ?? null;
if (!$api_key) {
    apiError('API key required', 401);
}

// Validate API key
$api_user = validateApiKey($api_key);
if (!$api_user) {
    apiError('Invalid API key', 401);
}

// Log request
logApiRequest($api_user['id'], '/products', $_SERVER['REQUEST_METHOD'], $_SERVER['REMOTE_ADDR']);

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    apiError('Method not allowed', 405);
}

try {
    $database = new Database();
    $conn = $database->getConnection();
    
    if (!$conn) {
        apiError('Database connection failed', 500);
    }
    
    $category = $_GET['category'] ?? null;
    
    $where = "WHERE status = 'active'";
    $params = [];
    $types = '';
    
    if ($category) {
        $where .= " AND category = ?";
        $params[] = $category;
        $types .= 's';
    }
    
    $query = "SELECT id, name, category, variant, commission_rate, card_image, variant_image, product_highlights, bank_redirect_url FROM products $where ORDER BY category, name";
    
    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    apiResponse($products);
    
} catch (Exception $e) {
    apiError('Internal server error: ' . $e->getMessage(), 500);
}
?>
