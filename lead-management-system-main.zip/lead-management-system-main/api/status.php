<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Status Check</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .status { padding: 10px; margin: 10px 0; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <h1>🔍 Database Status Check</h1>
    
    <?php
    require_once __DIR__ . '/../config/database_updated.php';
    
    try {
        $database = new Database();
        $conn = $database->getConnection();
        
        echo '<div class="status success">✓ Database connection successful</div>';
        
        // Check required tables
        $tables = ['api_keys', 'api_requests', 'leads', 'products', 'users'];
        $missing_tables = [];
        
        echo '<h2>📋 Table Status</h2>';
        echo '<table>';
        echo '<tr><th>Table Name</th><th>Status</th><th>Records</th></tr>';
        
        foreach ($tables as $table) {
            $result = $conn->query("SHOW TABLES LIKE '$table'");
            if ($result->num_rows > 0) {
                $count_result = $conn->query("SELECT COUNT(*) as count FROM $table");
                $count = $count_result->fetch_assoc()['count'];
                echo "<tr><td>$table</td><td style='color: green;'>✓ Exists</td><td>$count</td></tr>";
            } else {
                $missing_tables[] = $table;
                echo "<tr><td>$table</td><td style='color: red;'>✗ Missing</td><td>-</td></tr>";
            }
        }
        echo '</table>';
        
        // Check API-specific columns
        echo '<h2>🔧 API System Status</h2>';
        
        $api_checks = [
            'products.bank_redirect_url' => "SHOW COLUMNS FROM products LIKE 'bank_redirect_url'",
            'leads.channel_code index' => "SHOW INDEX FROM leads WHERE Key_name = 'idx_channel_code'",
            'leads.created_at index' => "SHOW INDEX FROM leads WHERE Key_name = 'idx_created_at'"
        ];
        
        foreach ($api_checks as $check_name => $query) {
            $result = $conn->query($query);
            $status = $result->num_rows > 0 ? '✓ Ready' : '✗ Missing';
            $color = $result->num_rows > 0 ? 'green' : 'red';
            echo "<div style='color: $color; margin: 5px 0;'>$status - $check_name</div>";
        }
        
        // Auto-fix option
        if (!empty($missing_tables) || $conn->query("SHOW TABLES LIKE 'api_keys'")->num_rows == 0) {
            echo '<div class="status info">';
            echo '<h3>🔧 Auto-Fix Available</h3>';
            echo '<p>Some API tables are missing. Click below to auto-create them:</p>';
            echo '<a href="/db_update.php" style="background: #007cba; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Run Database Update</a>';
            echo '</div>';
        } else {
            echo '<div class="status success">';
            echo '<h3>🎉 API System Ready!</h3>';
            echo '<p>All required tables and indexes are present.</p>';
            echo '<a href="/api/manage.php" style="background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Go to API Management</a>';
            echo '</div>';
        }
        
    } catch (Exception $e) {
        echo '<div class="status error">✗ Database connection failed: ' . $e->getMessage() . '</div>';
    }
    ?>
    
    <h2>📚 Quick Links</h2>
    <ul>
        <li><a href="/api/manage.php">API Management</a></li>
        <li><a href="/api/test.html">API Testing</a></li>
        <li><a href="/api/example.html">Integration Examples</a></li>
        <li><a href="/db_update.php">Database Update</a></li>
    </ul>
    <script src="/assets/js/loading.js"></script>
</body>
</html>