<?php
$api_key = 'lms_8188272ffd90118df860b5e768fe6681';
$url = 'http://' . $_SERVER['HTTP_HOST'] . '/api/leads';

$data = [
    'name' => 'Test User API',
    'mobile' => '9876543210',
    'email' => 'testapi@example.com',
    'product_id' => 23
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-Key: ' . $api_key,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

header('Content-Type: application/json');
echo json_encode([
    'status' => $status,
    'response' => json_decode($response, true)
], JSON_PRETTY_PRINT);
?>
