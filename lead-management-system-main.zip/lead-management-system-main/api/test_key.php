<?php
$api_key = 'lms_8188272ffd90118df860b5e768fe6681';
$url = 'http://' . $_SERVER['HTTP_HOST'] . '/api/products';

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['X-API-Key: ' . $api_key]);
$response = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

header('Content-Type: application/json');
echo json_encode([
    'status' => $status,
    'response' => json_decode($response, true)
], JSON_PRETTY_PRINT);
?>
