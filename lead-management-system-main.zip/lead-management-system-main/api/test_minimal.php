<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-API-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

function apiResponse($data, $status = 200, $message = 'Success') {
    http_response_code($status);
    echo json_encode([
        'status' => $status,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

function apiError($message, $status = 400) {
    apiResponse(null, $status, $message);
}

// Simple test endpoint
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    apiResponse(['test' => 'API is working'], 200, 'Test successful');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    apiResponse(['received' => $input], 200, 'POST test successful');
}

apiError('Method not allowed', 405);
?>