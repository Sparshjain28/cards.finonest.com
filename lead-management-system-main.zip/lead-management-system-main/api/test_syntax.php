<?php
// Simple syntax test for API
echo "PHP syntax check passed\n";

// Test basic functions
function testFunction() {
    return "Test function works";
}

echo testFunction();
?>