<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../config/database.php';

function sendResponse($success, $message, $code = 200) {
    http_response_code($code);
    echo json_encode([
        'success' => $success,
        'message' => $message
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendResponse(false, 'Only POST requests allowed', 405);
}

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data) {
    sendResponse(false, 'Invalid JSON', 400);
}

$api_key = $data['api_key'] ?? '';

if ($api_key !== 'FINONEST_API_KEY') {
    sendResponse(false, 'Invalid API key', 401);
}

$lead_id = $data['lead_id'] ?? '';

if (empty($lead_id)) {
    sendResponse(false, 'lead_id is required', 400);
}

try {

    $database = new Database();
    $conn = $database->getConnection(); // PDO connection

    $allowed_fields = [

        'customer_name',
        'status',
        'remark',
        'activation_status',
        'vkyc_status',
        'bkyc_status',
        'cust_type',
        'card_variant_mis',
        'application_no_mis',
        'card_issued_date'

    ];

    $fields = [];
    $values = [];

    foreach ($allowed_fields as $field) {

        if (isset($data[$field]) && $data[$field] !== '') {

            $fields[] = "$field = ?";
            $values[] = $data[$field];

        }

    }

    if (empty($fields)) {
        sendResponse(false, 'No valid fields to update', 400);
    }

    $fields[] = "updated_at = NOW()";

    $sql = "UPDATE leads SET " . implode(', ', $fields) . " WHERE lead_id = ?";

    $values[] = $lead_id;

    $stmt = $conn->prepare($sql);

    $stmt->execute($values);

    if ($stmt->rowCount() === 0) {
        sendResponse(false, 'Lead not found or no changes made', 404);
    }

    sendResponse(true, 'Lead updated successfully', 200);

} catch (Exception $e) {

    sendResponse(false, $e->getMessage(), 500);

}
