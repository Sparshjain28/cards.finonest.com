<?php
header('Content-Type: application/json');
require_once '../includes/timestamp_validator.php';
require_once '../config/timezone.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['timestamp'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Timestamp required']);
        exit;
    }
    
    $validation = validateLeadTimestamp($input['timestamp']);
    
    echo json_encode([
        'status' => 'success',
        'validation' => $validation,
        'server_time' => getAppTimestamp(),
        'timezone' => date_default_timezone_get()
    ]);
    
} else {
    // GET request - return current server time and validation info
    echo json_encode([
        'server_time' => getAppTimestamp(),
        'timezone' => date_default_timezone_get(),
        'business_hours' => isBusinessHours(),
        'unix_timestamp' => time()
    ]);
}
?>