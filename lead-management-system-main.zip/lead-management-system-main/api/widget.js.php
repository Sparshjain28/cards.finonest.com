<?php
require_once 'config.php';

// Get API key from header or query parameter
$api_key = $_SERVER['HTTP_X_API_KEY'] ?? $_GET['api_key'] ?? null;
if (!$api_key) {
    apiError('API key required', 401);
}

// Validate API key
$api_user = validateApiKey($api_key);
if (!$api_user) {
    apiError('Invalid API key', 401);
}

// Log request
logApiRequest($api_user['id'], '/widget', $_SERVER['REQUEST_METHOD'], $_SERVER['REMOTE_ADDR']);

$channel_code = $_GET['channel'] ?? 'API_WIDGET';
$theme = $_GET['theme'] ?? 'light';
$base_url = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];

header('Content-Type: text/javascript');
?>
(function() {
    const API_KEY = '<?= $api_key ?>';
    const CHANNEL_CODE = '<?= $channel_code ?>';
    const BASE_URL = '<?= $base_url ?>';
    
    // Create widget container
    function createWidget(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        container.innerHTML = `
            <div id="lms-widget" style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">
                <div id="lms-loading" style="text-align: center; padding: 40px;">
                    <div style="display: inline-block; width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; animation: spin 1s linear infinite;"></div>
                    <p style="margin-top: 10px; color: #666;">Loading products...</p>
                </div>
                <div id="lms-products" style="display: none;"></div>
                <div id="lms-form" style="display: none;"></div>
                <div id="lms-success" style="display: none;"></div>
            </div>
            <style>
                @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
                .lms-product-card { border: 1px solid #ddd; border-radius: 8px; padding: 16px; margin: 8px; cursor: pointer; transition: all 0.3s; }
                .lms-product-card:hover { box-shadow: 0 4px 8px rgba(0,0,0,0.1); transform: translateY(-2px); }
                .lms-btn { background: #007cba; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-size: 16px; }
                .lms-btn:hover { background: #005a87; }
                .lms-input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px; margin: 8px 0; font-size: 16px; }
            </style>
        `;
        
        loadProducts();
    }
    
    // Load products from API
    function loadProducts() {
        fetch(BASE_URL + '/api/products', {
            headers: { 'X-API-Key': API_KEY }
        })
        .then(r => r.json())
        .then(data => {
            if (data.status === 200) {
                displayProducts(data.data);
            } else {
                showError('Failed to load products');
            }
        })
        .catch(() => showError('Network error'));
    }
    
    // Display products grid
    function displayProducts(products) {
        const html = `
            <h2 style="text-align: center; color: #333; margin-bottom: 24px;">Choose Your Financial Product</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 16px;">
                ${products.map(product => `
                    <div class="lms-product-card" onclick="selectProduct(${product.id})">
                        ${product.card_image ? `<img src="${BASE_URL}/${product.card_image}" alt="${product.name}" style="width: 100%; height: 150px; object-fit: contain; border-radius: 6px;">` : ''}
                        <h3 style="margin: 12px 0 8px 0; color: #333;">${product.name}</h3>
                        ${product.variant ? `<p style="color: #666; font-size: 14px; margin: 4px 0;">${product.variant}</p>` : ''}
                        <p style="color: #007cba; font-weight: bold; margin: 8px 0;">Apply Now</p>
                    </div>
                `).join('')}
            </div>
        `;
        
        document.getElementById('lms-loading').style.display = 'none';
        document.getElementById('lms-products').innerHTML = html;
        document.getElementById('lms-products').style.display = 'block';
        
        // Store products globally
        window.lmsProducts = products;
    }
    
    // Show application form
    window.selectProduct = function(productId) {
        const product = window.lmsProducts.find(p => p.id === productId);
        if (!product) return;
        
        const html = `
            <div style="background: #f9f9f9; padding: 24px; border-radius: 8px;">
                <h2 style="color: #333; margin-bottom: 16px;">Apply for ${product.name}</h2>
                <form id="lms-application-form" onsubmit="submitApplication(event, ${productId})">
                    <input type="text" id="lms-name" placeholder="Full Name *" class="lms-input" required>
                    <input type="tel" id="lms-mobile" placeholder="Mobile Number *" class="lms-input" pattern="[0-9]{10}" required>
                    <input type="email" id="lms-email" placeholder="Email Address *" class="lms-input" required>
                    <div style="margin: 16px 0;">
                        <label style="display: flex; align-items: center; font-size: 14px;">
                            <input type="checkbox" required style="margin-right: 8px;">
                            I agree to Terms & Conditions and Privacy Policy
                        </label>
                    </div>
                    <button type="submit" class="lms-btn" style="width: 100%;">Submit Application</button>
                </form>
                <button onclick="showProducts()" style="background: none; border: none; color: #007cba; margin-top: 12px; cursor: pointer;">← Back to Products</button>
            </div>
        `;
        
        document.getElementById('lms-products').style.display = 'none';
        document.getElementById('lms-form').innerHTML = html;
        document.getElementById('lms-form').style.display = 'block';
    }
    
    // Submit application
    window.submitApplication = function(event, productId) {
        event.preventDefault();
        
        const formData = {
            name: document.getElementById('lms-name').value,
            mobile: document.getElementById('lms-mobile').value,
            email: document.getElementById('lms-email').value,
            product_id: productId,
            channel_code: CHANNEL_CODE
        };
        
        fetch(BASE_URL + '/api/leads', {
            method: 'POST',
            headers: {
                'X-API-Key': API_KEY,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        })
        .then(r => r.json())
        .then(data => {
            if (data.status === 201) {
                showSuccess(data.data);
            } else {
                showError(data.message || 'Application failed');
            }
        })
        .catch(() => showError('Network error'));
    }
    
    // Show success page
    function showSuccess(leadData) {
        const html = `
            <div style="text-align: center; padding: 40px; background: #f0f8f0; border-radius: 8px;">
                <div style="font-size: 48px; color: #28a745; margin-bottom: 16px;">✓</div>
                <h2 style="color: #333; margin-bottom: 16px;">Application Submitted Successfully!</h2>
                <p style="color: #666; margin-bottom: 8px;">Your Lead ID: <strong>${leadData.lead_id}</strong></p>
                <p style="color: #666; margin-bottom: 24px;">We will process your application shortly.</p>
                <button onclick="showProducts()" class="lms-btn">Apply for Another Product</button>
            </div>
        `;
        
        document.getElementById('lms-form').style.display = 'none';
        document.getElementById('lms-success').innerHTML = html;
        document.getElementById('lms-success').style.display = 'block';
    }
    
    // Show products again
    window.showProducts = function() {
        document.getElementById('lms-form').style.display = 'none';
        document.getElementById('lms-success').style.display = 'none';
        document.getElementById('lms-products').style.display = 'block';
    }
    
    // Show error
    function showError(message) {
        document.getElementById('lms-loading').innerHTML = `
            <div style="color: #dc3545; text-align: center; padding: 20px;">
                <p>Error: ${message}</p>
                <button onclick="location.reload()" class="lms-btn" style="background: #dc3545;">Retry</button>
            </div>
        `;
    }
    
    // Auto-initialize if container exists
    if (document.getElementById('lms-widget-container')) {
        createWidget('lms-widget-container');
    }
    
    // Export function for manual initialization
    window.initLMSWidget = createWidget;
})();