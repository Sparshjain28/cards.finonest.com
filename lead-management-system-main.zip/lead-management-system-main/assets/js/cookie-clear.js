// Service worker registration only
if('serviceWorker' in navigator){
  navigator.serviceWorker.register('/service-worker.js');
}