class WhatsAppImageCropper {
    constructor(options = {}) {
        this.options = {
            aspectRatio: 1, // Default to square (1:1)
            maxWidth: 800,
            maxHeight: 800,
            quality: 0.9,
            ...options
        };
        
        this.image = null;
        this.canvas = null;
        this.ctx = null;
        this.cropArea = null;
        this.isDragging = false;
        this.isResizing = false;
        this.startX = 0;
        this.startY = 0;
        this.startWidth = 0;
        this.startHeight = 0;
        this.startLeft = 0;
        this.startTop = 0;
        this.currentHandle = null;
        this.rotation = 0;
        this.scale = 1;
        this.translateX = 0;
        this.translateY = 0;
        
        this.init();
    }
    
    init() {
        this.createModal();
        this.bindEvents();
    }
    
    createModal() {
        // Create modal HTML
        const modalHTML = `
            <div class="image-cropper-modal" id="imageCropperModal">
                <div class="cropper-header">
                    <h3>Crop Image</h3>
                    <div class="cropper-actions">
                        <button type="button" class="cropper-btn" onclick="imageCropper.cancel()">Cancel</button>
                        <button type="button" class="cropper-btn primary" onclick="imageCropper.crop()">Done</button>
                    </div>
                </div>
                
                <div class="cropper-container">
                    <div class="cropper-canvas" id="cropperCanvas">
                        <img class="cropper-image" id="cropperImage" alt="Crop image">
                        <div class="cropper-overlay">
                            <div class="cropper-crop-area" id="cropArea">
                                <div class="cropper-handle nw" data-handle="nw"></div>
                                <div class="cropper-handle ne" data-handle="ne"></div>
                                <div class="cropper-handle sw" data-handle="sw"></div>
                                <div class="cropper-handle se" data-handle="se"></div>
                            </div>
                        </div>
                    </div>
                    <div class="cropper-loading" id="cropperLoading" style="display: none;">Processing...</div>
                </div>
                
                <div class="cropper-controls">
                    <div class="cropper-presets">
                        <button type="button" class="cropper-preset-btn ${this.options.aspectRatio === 1 ? 'active' : ''}" data-ratio="1">1:1</button>
                        <button type="button" class="cropper-preset-btn ${this.options.aspectRatio === 16/9 ? 'active' : ''}" data-ratio="16/9">16:9</button>
                        <button type="button" class="cropper-preset-btn ${this.options.aspectRatio === 4/3 ? 'active' : ''}" data-ratio="4/3">4:3</button>
                        <button type="button" class="cropper-preset-btn ${this.options.aspectRatio === 2/3 ? 'active' : ''}" data-ratio="2/3">2:3</button>
                        <button type="button" class="cropper-preset-btn ${this.options.aspectRatio === 'free' ? 'active' : ''}" data-ratio="free">Free</button>
                    </div>
                    
                    <div class="cropper-control-group">
                        <label>Zoom:</label>
                        <input type="range" class="cropper-slider" id="zoomSlider" min="0.5" max="3" step="0.1" value="1">
                    </div>
                    
                    <div class="cropper-control-group">
                        <button type="button" class="cropper-rotate-btn" id="rotateBtn">
                            <i class="fas fa-rotate-right"></i> Rotate
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        
        // Get elements
        this.modal = document.getElementById('imageCropperModal');
        this.imageEl = document.getElementById('cropperImage');
        this.canvasEl = document.getElementById('cropperCanvas');
        this.cropArea = document.getElementById('cropArea');
        this.loadingEl = document.getElementById('cropperLoading');
        this.zoomSlider = document.getElementById('zoomSlider');
        this.rotateBtn = document.getElementById('rotateBtn');
        
        // Create canvas for actual cropping
        this.canvas = document.createElement('canvas');
        this.ctx = this.canvas.getContext('2d');
    }
    
    bindEvents() {
        // Modal events
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.cancel();
            }
        });
        
        // Crop area events
        this.cropArea.addEventListener('mousedown', (e) => this.startDrag(e));
        this.cropArea.addEventListener('touchstart', (e) => this.startDrag(e.touches[0]));
        
        // Handle events
        document.querySelectorAll('.cropper-handle').forEach(handle => {
            handle.addEventListener('mousedown', (e) => this.startResize(e));
            handle.addEventListener('touchstart', (e) => this.startResize(e.touches[0]));
        });
        
        // Global mouse/touch events
        document.addEventListener('mousemove', (e) => this.handleMove(e));
        document.addEventListener('mouseup', (e) => this.endMove(e));
        document.addEventListener('touchmove', (e) => this.handleMove(e.touches[0]));
        document.addEventListener('touchend', (e) => this.endMove(e));
        
        // Control events
        this.zoomSlider.addEventListener('input', (e) => {
            this.scale = parseFloat(e.target.value);
            this.updateImageTransform();
        });
        
        this.rotateBtn.addEventListener('click', () => {
            this.rotation = (this.rotation + 90) % 360;
            this.updateImageTransform();
        });
        
        // Aspect ratio presets
        document.querySelectorAll('.cropper-preset-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.cropper-preset-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                
                const ratio = e.target.dataset.ratio;
                this.options.aspectRatio = ratio === 'free' ? 'free' : parseFloat(ratio);
                this.updateCropArea();
            });
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (this.modal.classList.contains('active')) {
                if (e.key === 'Escape') this.cancel();
                if (e.key === 'Enter') this.crop();
            }
        });
    }
    
    open(imageFile, callback) {
        this.callback = callback;
        this.showLoading(true);
        
        const reader = new FileReader();
        reader.onload = (e) => {
            this.imageEl.onload = () => {
                this.initializeCropper();
                this.showLoading(false);
            };
            this.imageEl.src = e.target.result;
        };
        reader.readAsDataURL(imageFile);
    }
    
    openFromUrl(imageUrl, callback) {
        this.callback = callback;
        this.showLoading(true);
        
        this.imageEl.onload = () => {
            this.initializeCropper();
            this.showLoading(false);
        };
        this.imageEl.src = imageUrl;
    }
    
    initializeCropper() {
        this.image = this.imageEl;
        this.rotation = 0;
        this.scale = 1;
        this.translateX = 0;
        this.translateY = 0;
        this.zoomSlider.value = 1;
        
        // Reset image transform
        this.updateImageTransform();
        
        // Initialize crop area
        this.updateCropArea();
        
        // Show modal
        this.modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    
    updateImageTransform() {
        const transforms = [
            `rotate(${this.rotation}deg)`,
            `scale(${this.scale})`,
            `translate(${this.translateX}px, ${this.translateY}px)`
        ];
        this.imageEl.style.transform = transforms.join(' ');
    }
    
    updateCropArea() {
        const containerRect = this.canvasEl.getBoundingClientRect();
        const imageRect = this.imageEl.getBoundingClientRect();
        
        // Calculate initial crop area size and position
        let cropWidth, cropHeight;
        
        if (this.options.aspectRatio === 'free') {
            cropWidth = Math.min(imageRect.width * 0.8, containerRect.width * 0.8);
            cropHeight = Math.min(imageRect.height * 0.8, containerRect.height * 0.8);
        } else {
            // Calculate based on aspect ratio
            const maxAreaWidth = imageRect.width * 0.8;
            const maxAreaHeight = imageRect.height * 0.8;
            
            if (maxAreaWidth / this.options.aspectRatio <= maxAreaHeight) {
                cropWidth = maxAreaWidth;
                cropHeight = maxAreaWidth / this.options.aspectRatio;
            } else {
                cropHeight = maxAreaHeight;
                cropWidth = maxAreaHeight * this.options.aspectRatio;
            }
        }
        
        // Center the crop area
        const left = (containerRect.width - cropWidth) / 2;
        const top = (containerRect.height - cropHeight) / 2;
        
        // Apply styles
        this.cropArea.style.width = `${cropWidth}px`;
        this.cropArea.style.height = `${cropHeight}px`;
        this.cropArea.style.left = `${left}px`;
        this.cropArea.style.top = `${top}px`;
    }
    
    startDrag(e) {
        if (e.target.classList.contains('cropper-handle')) return;
        
        this.isDragging = true;
        this.startX = e.clientX;
        this.startY = e.clientY;
        this.startLeft = this.cropArea.offsetLeft;
        this.startTop = this.cropArea.offsetTop;
        
        e.preventDefault();
    }
    
    startResize(e) {
        this.isResizing = true;
        this.currentHandle = e.target.dataset.handle;
        this.startX = e.clientX;
        this.startY = e.clientY;
        this.startWidth = this.cropArea.offsetWidth;
        this.startHeight = this.cropArea.offsetHeight;
        this.startLeft = this.cropArea.offsetLeft;
        this.startTop = this.cropArea.offsetTop;
        
        e.preventDefault();
    }
    
    handleMove(e) {
        if (!this.isDragging && !this.isResizing) return;
        
        const deltaX = e.clientX - this.startX;
        const deltaY = e.clientY - this.startY;
        
        if (this.isDragging) {
            // Move crop area
            const newLeft = Math.max(0, Math.min(this.startLeft + deltaX, this.canvasEl.offsetWidth - this.cropArea.offsetWidth));
            const newTop = Math.max(0, Math.min(this.startTop + deltaY, this.canvasEl.offsetHeight - this.cropArea.offsetHeight));
            
            this.cropArea.style.left = `${newLeft}px`;
            this.cropArea.style.top = `${newTop}px`;
        } else if (this.isResizing) {
            // Resize crop area
            this.resizeCropArea(deltaX, deltaY);
        }
    }
    
    resizeCropArea(deltaX, deltaY) {
        let newWidth = this.startWidth;
        let newHeight = this.startHeight;
        let newLeft = this.startLeft;
        let newTop = this.startTop;
        
        switch (this.currentHandle) {
            case 'se':
                newWidth = Math.max(50, this.startWidth + deltaX);
                newHeight = this.options.aspectRatio === 'free' ? 
                    Math.max(50, this.startHeight + deltaY) : 
                    newWidth / this.options.aspectRatio;
                break;
            case 'sw':
                newWidth = Math.max(50, this.startWidth - deltaX);
                newHeight = this.options.aspectRatio === 'free' ? 
                    Math.max(50, this.startHeight + deltaY) : 
                    newWidth / this.options.aspectRatio;
                newLeft = Math.min(this.startLeft + deltaX, this.startLeft + this.startWidth - 50);
                break;
            case 'ne':
                newWidth = Math.max(50, this.startWidth + deltaX);
                newHeight = this.options.aspectRatio === 'free' ? 
                    Math.max(50, this.startHeight - deltaY) : 
                    newWidth / this.options.aspectRatio;
                newTop = Math.min(this.startTop + deltaY, this.startTop + this.startHeight - 50);
                break;
            case 'nw':
                newWidth = Math.max(50, this.startWidth - deltaX);
                newHeight = this.options.aspectRatio === 'free' ? 
                    Math.max(50, this.startHeight - deltaY) : 
                    newWidth / this.options.aspectRatio;
                newLeft = Math.min(this.startLeft + deltaX, this.startLeft + this.startWidth - 50);
                newTop = Math.min(this.startTop + deltaY, this.startTop + this.startHeight - 50);
                break;
        }
        
        // Apply constraints
        newLeft = Math.max(0, newLeft);
        newTop = Math.max(0, newTop);
        newWidth = Math.min(newWidth, this.canvasEl.offsetWidth - newLeft);
        newHeight = Math.min(newHeight, this.canvasEl.offsetHeight - newTop);
        
        this.cropArea.style.width = `${newWidth}px`;
        this.cropArea.style.height = `${newHeight}px`;
        this.cropArea.style.left = `${newLeft}px`;
        this.cropArea.style.top = `${newTop}px`;
    }
    
    endMove(e) {
        this.isDragging = false;
        this.isResizing = false;
        this.currentHandle = null;
    }
    
    crop() {
        this.showLoading(true);
        
        // Get crop area dimensions and position
        const cropRect = this.cropArea.getBoundingClientRect();
        const imageRect = this.imageEl.getBoundingClientRect();
        const containerRect = this.canvasEl.getBoundingClientRect();
        
        // Calculate actual crop coordinates on the original image
        const scaleX = this.image.naturalWidth / imageRect.width;
        const scaleY = this.image.naturalHeight / imageRect.height;
        
        const cropX = (cropRect.left - imageRect.left) * scaleX;
        const cropY = (cropRect.top - imageRect.top) * scaleY;
        const cropWidth = cropRect.width * scaleX;
        const cropHeight = cropRect.height * scaleY;
        
        // Set canvas size
        this.canvas.width = cropWidth;
        this.canvas.height = cropHeight;
        
        // Create a temporary canvas for rotation and scaling
        const tempCanvas = document.createElement('canvas');
        const tempCtx = tempCanvas.getContext('2d');
        
        // Calculate dimensions for rotated image
        const angle = this.rotation * Math.PI / 180;
        const sin = Math.abs(Math.sin(angle));
        const cos = Math.abs(Math.cos(angle));
        
        tempCanvas.width = this.image.naturalWidth * cos + this.image.naturalHeight * sin;
        tempCanvas.height = this.image.naturalWidth * sin + this.image.naturalHeight * cos;
        
        // Draw rotated image
        tempCtx.save();
        tempCtx.translate(tempCanvas.width / 2, tempCanvas.height / 2);
        tempCtx.rotate(angle);
        tempCtx.drawImage(this.image, -this.image.naturalWidth / 2, -this.image.naturalHeight / 2);
        tempCtx.restore();
        
        // Draw cropped area to main canvas
        this.ctx.drawImage(
            tempCanvas,
            cropX, cropY, cropWidth, cropHeight,
            0, 0, cropWidth, cropHeight
        );
        
        // Convert to blob and callback
        this.canvas.toBlob((blob) => {
            this.showLoading(false);
            this.close();
            if (this.callback) {
                this.callback(blob, this.canvas.toDataURL('image/jpeg', this.options.quality));
            }
        }, 'image/jpeg', this.options.quality);
    }
    
    cancel() {
        this.close();
        if (this.callback) {
            this.callback(null);
        }
    }
    
    close() {
        this.modal.classList.remove('active');
        document.body.style.overflow = '';
        
        // Reset
        this.image = null;
        this.imageEl.src = '';
        this.rotation = 0;
        this.scale = 1;
        this.translateX = 0;
        this.translateY = 0;
    }
    
    showLoading(show) {
        this.loadingEl.style.display = show ? 'block' : 'none';
    }
}

// Global instance
let imageCropper;

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    imageCropper = new WhatsAppImageCropper();
});

// Helper function to trigger cropper
window.cropImage = function(file, callback, options = {}) {
    if (!imageCropper) {
        imageCropper = new WhatsAppImageCropper(options);
    }
    imageCropper.open(file, callback);
};

window.cropImageFromUrl = function(url, callback, options = {}) {
    if (!imageCropper) {
        imageCropper = new WhatsAppImageCropper(options);
    }
    imageCropper.openFromUrl(url, callback);
};
