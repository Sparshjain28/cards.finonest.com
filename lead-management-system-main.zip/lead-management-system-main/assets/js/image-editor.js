// Advanced Image Editor for Product Management
class ImageEditor {
    constructor(canvasId, options = {}) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.image = null;
        this.scale = 1;
        this.rotation = 0;
        this.offsetX = 0;
        this.offsetY = 0;
        this.isDragging = false;
        this.lastX = 0;
        this.lastY = 0;
        
        this.options = {
            width: options.width || 400,
            height: options.height || 250,
            circle: options.circle || false,
            aspectRatio: options.aspectRatio || null
        };
        
        this.setupCanvas();
        this.bindEvents();
    }
    
    setupCanvas() {
        this.canvas.width = this.options.width;
        this.canvas.height = this.options.height;
        this.canvas.style.cursor = 'move';
        this.canvas.style.border = '2px solid #e5e7eb';
        this.canvas.style.borderRadius = '8px';
    }
    
    bindEvents() {
        // Mouse events
        this.canvas.addEventListener('mousedown', this.startDrag.bind(this));
        this.canvas.addEventListener('mousemove', this.drag.bind(this));
        this.canvas.addEventListener('mouseup', this.endDrag.bind(this));
        this.canvas.addEventListener('wheel', this.zoom.bind(this));
        
        // Touch events for mobile
        this.canvas.addEventListener('touchstart', this.handleTouch.bind(this));
        this.canvas.addEventListener('touchmove', this.handleTouch.bind(this));
        this.canvas.addEventListener('touchend', this.endDrag.bind(this));
    }
    
    loadImage(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.onload = () => {
                    this.image = img;
                    this.resetTransform();
                    this.draw();
                    resolve(this.getImageData());
                };
                img.onerror = reject;
                img.src = e.target.result;
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }
    
    resetTransform() {
        this.scale = Math.min(
            this.options.width / this.image.width,
            this.options.height / this.image.height
        );
        this.rotation = 0;
        this.offsetX = 0;
        this.offsetY = 0;
    }
    
    draw() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        if (!this.image) return;
        
        this.ctx.save();
        
        // Apply clipping for circle crop
        if (this.options.circle) {
            this.ctx.beginPath();
            this.ctx.arc(
                this.canvas.width / 2,
                this.canvas.height / 2,
                Math.min(this.canvas.width, this.canvas.height) / 2,
                0,
                2 * Math.PI
            );
            this.ctx.clip();
        }
        
        // Transform
        this.ctx.translate(this.canvas.width / 2, this.canvas.height / 2);
        this.ctx.rotate(this.rotation);
        this.ctx.scale(this.scale, this.scale);
        this.ctx.translate(this.offsetX, this.offsetY);
        
        // Draw image
        this.ctx.drawImage(
            this.image,
            -this.image.width / 2,
            -this.image.height / 2
        );
        
        this.ctx.restore();
        
        // Draw border for circle crop
        if (this.options.circle) {
            this.ctx.strokeStyle = '#e5e7eb';
            this.ctx.lineWidth = 2;
            this.ctx.beginPath();
            this.ctx.arc(
                this.canvas.width / 2,
                this.canvas.height / 2,
                Math.min(this.canvas.width, this.canvas.height) / 2,
                0,
                2 * Math.PI
            );
            this.ctx.stroke();
        }
    }
    
    startDrag(e) {
        this.isDragging = true;
        const rect = this.canvas.getBoundingClientRect();
        this.lastX = e.clientX - rect.left;
        this.lastY = e.clientY - rect.top;
    }
    
    drag(e) {
        if (!this.isDragging) return;
        
        const rect = this.canvas.getBoundingClientRect();
        const currentX = e.clientX - rect.left;
        const currentY = e.clientY - rect.top;
        
        const deltaX = currentX - this.lastX;
        const deltaY = currentY - this.lastY;
        
        this.offsetX += deltaX / this.scale;
        this.offsetY += deltaY / this.scale;
        
        this.lastX = currentX;
        this.lastY = currentY;
        
        this.draw();
    }
    
    endDrag() {
        this.isDragging = false;
    }
    
    zoom(e) {
        e.preventDefault();
        
        const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
        const newScale = this.scale * zoomFactor;
        
        // Limit zoom
        if (newScale > 0.1 && newScale < 5) {
            this.scale = newScale;
            this.draw();
        }
    }
    
    handleTouch(e) {
        e.preventDefault();
        const touch = e.touches[0];
        if (touch) {
            const mouseEvent = new MouseEvent(e.type === 'touchstart' ? 'mousedown' : 'mousemove', {
                clientX: touch.clientX,
                clientY: touch.clientY
            });
            this.canvas.dispatchEvent(mouseEvent);
        }
    }
    
    rotate(degrees) {
        this.rotation += (degrees * Math.PI) / 180;
        this.draw();
    }
    
    zoomIn() {
        if (this.scale < 5) {
            this.scale *= 1.2;
            this.draw();
        }
    }
    
    zoomOut() {
        if (this.scale > 0.1) {
            this.scale *= 0.8;
            this.draw();
        }
    }
    
    reset() {
        if (this.image) {
            this.resetTransform();
            this.draw();
        }
    }
    
    getImageData() {
        return this.canvas.toDataURL('image/png', 0.9);
    }
}

// Utility functions for the product management system
function createImageEditor(inputId, canvasId, previewId, options = {}) {
    const input = document.getElementById(inputId);
    const canvas = document.getElementById(canvasId);
    const preview = document.getElementById(previewId);
    
    let editor = null;
    let imageData = null;
    
    input.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        // Show canvas and hide preview initially
        canvas.classList.remove('hidden');
        preview.classList.add('hidden');
        
        // Create editor
        editor = new ImageEditor(canvasId, options);
        
        // Load image
        editor.loadImage(file).then(data => {
            imageData = data;
            
            // Create control buttons
            createEditorControls(canvas, editor);
            
            // Show preview
            const img = preview.querySelector('img');
            if (img) {
                img.src = data;
                preview.classList.remove('hidden');
            }
        }).catch(error => {
            console.error('Error loading image:', error);
            alert('Error loading image. Please try again.');
        });
    });
    
    return {
        getImageData: () => imageData,
        getEditor: () => editor
    };
}

function createEditorControls(canvas, editor) {
    // Remove existing controls
    const existingControls = canvas.parentNode.querySelector('.editor-controls');
    if (existingControls) {
        existingControls.remove();
    }
    
    // Create control panel
    const controls = document.createElement('div');
    controls.className = 'editor-controls flex flex-wrap gap-2 mt-2';
    controls.innerHTML = `
        <button type="button" onclick="this.parentNode.editor.zoomIn()" class="px-2 py-1 text-xs bg-blue-500 text-white rounded hover:bg-blue-600">
            <i class="fas fa-search-plus"></i> Zoom In
        </button>
        <button type="button" onclick="this.parentNode.editor.zoomOut()" class="px-2 py-1 text-xs bg-blue-500 text-white rounded hover:bg-blue-600">
            <i class="fas fa-search-minus"></i> Zoom Out
        </button>
        <button type="button" onclick="this.parentNode.editor.rotate(90)" class="px-2 py-1 text-xs bg-green-500 text-white rounded hover:bg-green-600">
            <i class="fas fa-redo"></i> Rotate
        </button>
        <button type="button" onclick="this.parentNode.editor.reset()" class="px-2 py-1 text-xs bg-gray-500 text-white rounded hover:bg-gray-600">
            <i class="fas fa-undo"></i> Reset
        </button>
    `;
    
    // Store editor reference
    controls.editor = editor;
    
    // Insert after canvas
    canvas.parentNode.insertBefore(controls, canvas.nextSibling);
}

// Auto-format pin codes
function formatPinCodes(input) {
    let value = input.value.toUpperCase();
    
    if (value === 'ALL') {
        return value;
    }
    
    // Remove non-numeric characters except commas
    value = value.replace(/[^0-9,]/g, '');
    
    // Split by comma, clean each pin code, and rejoin
    const pinCodes = value.split(',')
        .map(pin => pin.trim())
        .filter(pin => pin.length === 6 || pin.length === 0)
        .join(', ');
    
    return pinCodes;
}

// Bulk apply lender logo
function bulkApplyLenderLogo(lenderName, imageData) {
    if (!confirm(`Apply this logo to all ${lenderName} products?`)) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'bulk_apply_logo');
    formData.append('lender', lenderName);
    formData.append('image_data', imageData);
    
    fetch('', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`Logo applied to ${data.count} products`);
            location.reload();
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred');
    });
}

// Export functions for global use
window.ImageEditor = ImageEditor;
window.createImageEditor = createImageEditor;
window.formatPinCodes = formatPinCodes;
window.bulkApplyLenderLogo = bulkApplyLenderLogo;