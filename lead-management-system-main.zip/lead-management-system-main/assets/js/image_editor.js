/**
 * Circular Image Editor - JavaScript Logic
 * WhatsApp DP style image cropping with Cropper.js
 * Handles: Upload, Zoom, Rotate, Auto-fit, Export
 */

(function() {
    'use strict';
    
    let currentCropper = null;
    let currentInputElement = null;
    let currentPreviewContainer = null;
    let originalImageSrc = null;
    
    /**
     * Initialize image cropper for a file input
     * @param {string} inputId - ID of the file input element
     * @param {string} previewContainerId - ID of the preview container
     */
    window.setupImageCropper = function(inputId, previewContainerId) {
        const inputElement = document.getElementById(inputId);
        const previewContainer = document.getElementById(previewContainerId);
        
        if (!inputElement) {
            console.warn('Input element not found:', inputId);
            return;
        }
        
        // Remove any existing event listeners
        const newInput = inputElement.cloneNode(true);
        inputElement.parentNode.replaceChild(newInput, inputElement);
        
        // Add change event listener
        newInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            
            if (!file) return;
            
            // Validate file type
            const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
            if (!validTypes.includes(file.type)) {
                alert('Please upload a valid image file (JPG, PNG, or WEBP)');
                newInput.value = '';
                return;
            }
            
            // Validate file size (5MB)
            if (file.size > 5 * 1024 * 1024) {
                alert('File size must be less than 5MB');
                newInput.value = '';
                return;
            }
            
            // Read and display the image
            const reader = new FileReader();
            reader.onload = function(event) {
                openImageEditor(event.target.result, newInput, previewContainer);
            };
            reader.readAsDataURL(file);
        });
        
        console.log('Image cropper initialized for:', inputId);
    };
    
    /**
     * Open the image editor modal
     */
    function openImageEditor(imageSrc, inputElement, previewContainer) {
        currentInputElement = inputElement;
        currentPreviewContainer = previewContainer;
        originalImageSrc = imageSrc;
        
        const modal = document.getElementById('imageEditorModal');
        const cropImage = document.getElementById('cropImage');
        
        if (!modal || !cropImage) {
            console.error('Image editor modal elements not found');
            return;
        }
        
        // Set image source
        cropImage.src = imageSrc;
        
        // Show modal
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Initialize cropper after image loads
        cropImage.onload = function() {
            initializeCropper();
        };
    }
    
    /**
     * Initialize Cropper.js with circular settings
     */
    function initializeCropper() {
        const cropImage = document.getElementById('cropImage');
        
        // Destroy existing cropper if any
        if (currentCropper) {
            currentCropper.destroy();
        }
        
        // Initialize new cropper
        currentCropper = new Cropper(cropImage, {
            aspectRatio: 1,
            viewMode: 1,
            dragMode: 'move',
            autoCropArea: 1,
            restore: false,
            guides: false,
            center: true,
            highlight: false,
            cropBoxMovable: false,
            cropBoxResizable: false,
            toggleDragModeOnDblclick: false,
            ready: function() {
                // Make crop box circular
                const cropBox = document.querySelector('.cropper-crop-box');
                if (cropBox) {
                    cropBox.style.borderRadius = '50%';
                }
                
                // Auto-fit on load
                autoFitImage();
            },
            zoom: function(e) {
                updateZoomValue(e.detail.ratio);
            }
        });
        
        // Setup control event listeners
        setupControls();
    }
    
    /**
     * Setup control button event listeners
     */
    function setupControls() {
        // Zoom slider
        const zoomSlider = document.getElementById('zoomSlider');
        if (zoomSlider) {
            zoomSlider.oninput = function() {
                const ratio = parseFloat(this.value);
                if (currentCropper) {
                    currentCropper.zoomTo(ratio);
                    updateZoomValue(ratio);
                }
            };
        }
        
        // Rotate left
        const rotateLeftBtn = document.getElementById('rotateLeft');
        if (rotateLeftBtn) {
            rotateLeftBtn.onclick = function() {
                if (currentCropper) {
                    currentCropper.rotate(-90);
                }
            };
        }
        
        // Rotate right
        const rotateRightBtn = document.getElementById('rotateRight');
        if (rotateRightBtn) {
            rotateRightBtn.onclick = function() {
                if (currentCropper) {
                    currentCropper.rotate(90);
                }
            };
        }
        
        // Auto-fit
        const autoFitBtn = document.getElementById('autoFit');
        if (autoFitBtn) {
            autoFitBtn.onclick = autoFitImage;
        }
        
        // Reset
        const resetBtn = document.getElementById('resetImage');
        if (resetBtn) {
            resetBtn.onclick = function() {
                if (currentCropper) {
                    currentCropper.reset();
                    autoFitImage();
                    document.getElementById('zoomSlider').value = 1;
                    updateZoomValue(1);
                }
            };
        }
        
        // Cancel
        const cancelBtn = document.getElementById('cancelEditor');
        if (cancelBtn) {
            cancelBtn.onclick = closeImageEditor;
        }
        
        // Apply changes
        const applyBtn = document.getElementById('applyEditor');
        if (applyBtn) {
            applyBtn.onclick = applyChanges;
        }
        
        // Close button
        const closeBtn = document.querySelector('.image-editor-close');
        if (closeBtn) {
            closeBtn.onclick = closeImageEditor;
        }
        
        // Close on outside click
        const modal = document.getElementById('imageEditorModal');
        if (modal) {
            modal.onclick = function(e) {
                if (e.target === modal) {
                    closeImageEditor();
                }
            };
        }
    }
    
    /**
     * Auto-fit image inside circular crop area
     */
    function autoFitImage() {
        if (!currentCropper) return;
        
        const imageData = currentCropper.getImageData();
        const containerData = currentCropper.getContainerData();
        
        // Calculate the scale to fit image in container
        const scale = Math.max(
            containerData.width / imageData.naturalWidth,
            containerData.height / imageData.naturalHeight
        );
        
        currentCropper.zoomTo(scale);
        currentCropper.moveTo(0, 0);
        
        // Update zoom slider
        const zoomSlider = document.getElementById('zoomSlider');
        if (zoomSlider) {
            zoomSlider.value = scale;
            updateZoomValue(scale);
        }
    }
    
    /**
     * Update zoom value display
     */
    function updateZoomValue(ratio) {
        const zoomValue = document.getElementById('zoomValue');
        if (zoomValue) {
            zoomValue.textContent = Math.round(ratio * 100) + '%';
        }
    }
    
    /**
     * Apply changes and export circular image
     */
    function applyChanges() {
        if (!currentCropper) return;
        
        // Show loading state
        const applyBtn = document.getElementById('applyEditor');
        const originalText = applyBtn.innerHTML;
        applyBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        applyBtn.disabled = true;
        
        try {
            // Get cropped canvas
            const canvas = currentCropper.getCroppedCanvas({
                width: 500,
                height: 500,
                imageSmoothingEnabled: true,
                imageSmoothingQuality: 'high'
            });
            
            // Create circular canvas with transparency
            const circularCanvas = document.createElement('canvas');
            circularCanvas.width = 500;
            circularCanvas.height = 500;
            const ctx = circularCanvas.getContext('2d');
            
            // Draw circular clip path
            ctx.beginPath();
            ctx.arc(250, 250, 250, 0, Math.PI * 2);
            ctx.closePath();
            ctx.clip();
            
            // Draw image
            ctx.drawImage(canvas, 0, 0, 500, 500);
            
            // Convert to blob
            circularCanvas.toBlob(function(blob) {
                if (!blob) {
                    alert('Failed to process image');
                    applyBtn.innerHTML = originalText;
                    applyBtn.disabled = false;
                    return;
                }
                
                // Create a new File object
                const fileName = 'cropped_' + Date.now() + '.png';
                const file = new File([blob], fileName, { type: 'image/png' });
                
                // Create a DataTransfer to set the file input
                const dataTransfer = new DataTransfer();
                dataTransfer.items.add(file);
                currentInputElement.files = dataTransfer.files;
                
                // Show preview
                if (currentPreviewContainer) {
                    currentPreviewContainer.innerHTML = '';
                    
                    const previewLabel = document.createElement('div');
                    previewLabel.className = 'text-xs text-gray-600 mb-2';
                    previewLabel.textContent = 'Edited Image Preview:';
                    currentPreviewContainer.appendChild(previewLabel);
                    
                    const previewImg = document.createElement('img');
                    previewImg.src = circularCanvas.toDataURL('image/png');
                    previewImg.className = 'w-24 h-24 rounded-full border-2 border-blue-500 shadow-md';
                    currentPreviewContainer.appendChild(previewImg);
                    
                    const successMsg = document.createElement('div');
                    successMsg.className = 'text-xs text-green-600 mt-1';
                    successMsg.innerHTML = '<i class="fas fa-check-circle mr-1"></i>Image ready!';
                    currentPreviewContainer.appendChild(successMsg);
                }
                
                // Close modal
                closeImageEditor();
                
                // Reset button
                applyBtn.innerHTML = originalText;
                applyBtn.disabled = false;
                
            }, 'image/png', 0.95);
            
        } catch (error) {
            console.error('Error processing image:', error);
            alert('Failed to process image. Please try again.');
            applyBtn.innerHTML = originalText;
            applyBtn.disabled = false;
        }
    }
    
    /**
     * Close the image editor modal
     */
    function closeImageEditor() {
        const modal = document.getElementById('imageEditorModal');
        
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
        
        // Destroy cropper
        if (currentCropper) {
            currentCropper.destroy();
            currentCropper = null;
        }
        
        // Clear image source
        const cropImage = document.getElementById('cropImage');
        if (cropImage) {
            cropImage.src = '';
        }
        
        // Reset references
        currentInputElement = null;
        currentPreviewContainer = null;
        originalImageSrc = null;
    }
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Image Editor JS loaded and ready');
        });
    } else {
        console.log('Image Editor JS loaded and ready');
    }
    
})();
