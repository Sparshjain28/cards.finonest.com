/**
 * Timestamp validation utilities
 */

class TimestampValidator {
    constructor() {
        this.tolerance = 300; // 5 minutes in seconds
        this.apiEndpoint = '/api/validate_timestamp.php';
    }

    /**
     * Validate timestamp against server time
     */
    async validateTimestamp(timestamp) {
        try {
            const response = await fetch(this.apiEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ timestamp: timestamp })
            });
            
            const result = await response.json();
            return result.validation;
        } catch (error) {
            console.error('Timestamp validation error:', error);
            return { is_valid: false, error: error.message };
        }
    }

    /**
     * Get current server time
     */
    async getServerTime() {
        try {
            const response = await fetch(this.apiEndpoint);
            const result = await response.json();
            return result.server_time;
        } catch (error) {
            console.error('Server time fetch error:', error);
            return null;
        }
    }

    /**
     * Auto-correct form timestamp if needed
     */
    async autoCorrectFormTimestamp(formElement) {
        const timestampField = formElement.querySelector('input[name="created_at"], input[type="datetime-local"]');
        
        if (!timestampField || !timestampField.value) {
            return;
        }

        const validation = await this.validateTimestamp(timestampField.value);
        
        if (validation.needs_correction) {
            // Show warning to user
            this.showTimestampWarning(validation);
            
            // Auto-correct if user confirms
            if (confirm('Timestamp appears incorrect. Auto-correct to server time?')) {
                timestampField.value = this.formatForInput(validation.corrected_timestamp);
                this.showTimestampSuccess('Timestamp corrected');
            }
        }
    }

    /**
     * Format timestamp for datetime-local input
     */
    formatForInput(timestamp) {
        const date = new Date(timestamp + " GMT+0530");
        return date.toISOString().slice(0, 16);
    }

    /**
     * Show timestamp warning
     */
    showTimestampWarning(validation) {
        const warning = document.createElement('div');
        warning.className = 'timestamp-warning bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4';
        warning.innerHTML = `
            <div class="flex">
                <div class="flex-shrink-0">
                    <svg class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm">
                        Timestamp validation failed. Difference: ${validation.time_difference} seconds
                    </p>
                </div>
            </div>
        `;
        
        // Insert warning before form
        const form = document.querySelector('form');
        if (form) {
            form.parentNode.insertBefore(warning, form);
            
            // Remove warning after 10 seconds
            setTimeout(() => warning.remove(), 10000);
        }
    }

    /**
     * Show timestamp success message
     */
    showTimestampSuccess(message) {
        const success = document.createElement('div');
        success.className = 'timestamp-success bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4';
        success.innerHTML = `
            <div class="flex">
                <div class="flex-shrink-0">
                    <svg class="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm">${message}</p>
                </div>
            </div>
        `;
        
        const form = document.querySelector('form');
        if (form) {
            form.parentNode.insertBefore(success, form);
            setTimeout(() => success.remove(), 5000);
        }
    }

    /**
     * Initialize timestamp validation on forms
     */
    init() {
        // Validate on form submission
        document.addEventListener('submit', async (e) => {
            const form = e.target;
            if (form.tagName === 'FORM') {
                await this.autoCorrectFormTimestamp(form);
            }
        });

        // Real-time validation on timestamp fields
        document.addEventListener('change', async (e) => {
            if (e.target.type === 'datetime-local' || e.target.name === 'created_at') {
                if (e.target.value) {
                    const validation = await this.validateTimestamp(e.target.value);
                    if (!validation.is_valid) {
                        e.target.style.borderColor = '#ef4444';
                        e.target.title = `Timestamp validation failed. Difference: ${validation.time_difference} seconds`;
                    } else {
                        e.target.style.borderColor = '#10b981';
                        e.target.title = 'Timestamp is valid';
                    }
                }
            }
        });
    }
}

// Initialize timestamp validator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const validator = new TimestampValidator();
    validator.init();
    
    // Make validator globally available
    window.timestampValidator = validator;
});