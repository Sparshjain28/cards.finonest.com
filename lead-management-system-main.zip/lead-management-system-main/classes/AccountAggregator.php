<?php

class AccountAggregator {
    private $token;
    public $conn;
    
    public function __construct($token = null, $conn = null) {
        $this->token = $token;
        $this->conn = $conn;
    }
    
    public function transformData($inputJson) {
        $input = json_decode($inputJson, true);
        
        return [
            "data" => [
                "clientId" => $input['data']['client_id'] ?? "",
                "accounts" => $this->transformAccounts($input['data']['account_aggregator_json'] ?? [])
            ]
        ];
    }
    
    private function transformAccounts($accounts) {
        $transformed = [];
        
        foreach ($accounts as $account) {
            $transformed[] = [
                "status" => $account['status'] ?? "",
                "accountId" => $account['account_id'] ?? "",
                "profile" => $this->transformProfile($account['profile_details'] ?? []),
                "summary" => $this->transformSummary($account['summary_details'] ?? []),
                "transactions" => $this->transformTransactions($account['transaction_data'] ?? [])
            ];
        }
        
        return $transformed;
    }
    
    private function transformProfile($profile) {
        return [
            "dateOfBirth" => $profile['dob'] ?? "",
            "panNumber" => $profile['pan'] ?? "",
            "fullName" => $profile['name'] ?? "",
            "accountHolderType" => $profile['type'] ?? "",
            "email" => $profile['email'] ?? "",
            "mobileNumber" => $profile['mobile'] ?? "",
            "address" => $profile['address'] ?? "",
            "nomineeStatus" => $profile['nominee'] ?? "",
            "landline" => $profile['landline'] ?? "",
            "isCkycRegistered" => $profile['ckyc_registered'] ?? ""
        ];
    }
    
    private function transformSummary($summary) {
        return [
            "ifscCode" => $summary['ifsc'] ?? "",
            "branchName" => $summary['branch'] ?? "",
            "accountStatus" => $summary['status'] ?? "",
            "currency" => $summary['currency'] ?? "",
            "facility" => $summary['facility'] ?? "",
            "micrCode" => $summary['micr_code'] ?? "",
            "accountType" => $summary['account_type'] ?? "",
            "openingDate" => $summary['opening_date'] ?? "",
            "drawingLimit" => $summary['drawing_limit'] ?? "",
            "currentBalance" => $summary['current_balance'] ?? "",
            "accountSubType" => $summary['account_sub_type'] ?? "",
            "currentOdLimit" => $summary['current_od_limit'] ?? "",
            "balanceUpdatedAt" => $summary['balance_date_time'] ?? ""
        ];
    }
    
    private function transformTransactions($transactionData) {
        $transactions = [
            "startDate" => $transactionData['start_date'] ?? "",
            "endDate" => $transactionData['end_date'] ?? "",
            "items" => []
        ];
        
        if (isset($transactionData['transaction_details'])) {
            foreach ($transactionData['transaction_details'] as $transaction) {
                $transactions['items'][] = [
                    "paymentMode" => $transaction['mode'] ?? "",
                    "transactionType" => $transaction['type'] ?? "",
                    "amount" => $transaction['amount'] ?? "",
                    "narration" => $transaction['narration'] ?? "",
                    "referenceId" => $transaction['reference'] ?? "",
                    "valueDate" => $transaction['value_date'] ?? "",
                    "transactionId" => $transaction['transaction_id'] ?? "",
                    "balanceAfterTransaction" => $transaction['transactional_balance'] ?? $transaction['transaction_balance'] ?? "",
                    "transactionTime" => $transaction['transaction_timestamp'] ?? ""
                ];
            }
        }
        
        return $transactions;
    }
    
    public function processFile($filePath) {
        if (!file_exists($filePath)) {
            throw new Exception("File not found: $filePath");
        }
        
        $jsonData = file_get_contents($filePath);
        return $this->transformData($jsonData);
    }
    
    public function saveTransformedData($data, $outputPath) {
        $json = json_encode($data, JSON_PRETTY_PRINT);
        return file_put_contents($outputPath, $json);
    }
    
    private $apiToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmcmVzaCI6ZmFsc2UsImlhdCI6MTc2NjM5ODg5MiwianRpIjoiMjdiNjdiNWEtZjkyZC00YTZmLTk2NmMtMDhhZjc4ZjAwNmI2IiwidHlwZSI6ImFjY2VzcyIsImlkZW50aXR5IjoiZGV2LmZpbm9uZXN0aW5kaWFAc3VyZXBhc3MuaW8iLCJuYmYiOjE3NjYzOTg4OTIsImV4cCI6MjM5NzExODg5MiwiZW1haWwiOiJmaW5vbmVzdGluZGlhQHN1cmVwYXNzLmlvIiwidGVuYW50X2lkIjoibWFpbiIsInVzZXJfY2xhaW1zIjp7InNjb3BlcyI6WyJ1c2VyIl19fQ.dl1S5S3OxNs3hwxkwtLhcTAN6CmIlYa_hg4yOl5ASlg';
    private $apiBaseUrl = 'https://kyc-api.surepass.app/api/v1/account-aggregator-v2';
    
    public function initConsent($mobile, $pan = null) {
        $curl = curl_init();
        
        $postData = [
            'mobile_number' => $mobile,
            'pan_number' => $pan ?? '',
            'email' => '',
            'input_redirect_url' => '',
            'consent_type' => 'loan_underwriting'
        ];
        
        curl_setopt_array($curl, [
            CURLOPT_URL => $this->apiBaseUrl . '/init',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($postData),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $this->apiToken,
                'Content-Type: application/json'
            ]
        ]);
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curlError = curl_error($curl);
        curl_close($curl);
        
        if ($response === false) {
            return ['success' => false, 'data' => ['message' => 'cURL Error: ' . $curlError]];
        }
        
        if ($httpCode !== 200) {
            return ['success' => false, 'data' => ['message' => 'HTTP ' . $httpCode . ': ' . $response]];
        }
        
        return json_decode($response, true);
    }
    
    public function fetchReport($clientId) {
        $curl = curl_init();
        
        $postData = ['client_id' => $clientId];
        
        curl_setopt_array($curl, [
            CURLOPT_URL => $this->apiBaseUrl . '/fetch-json-report',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($postData),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $this->apiToken,
                'Content-Type: application/json'
            ]
        ]);
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curlError = curl_error($curl);
        curl_close($curl);
        
        if ($response === false) {
            return ['success' => false, 'data' => ['message' => 'cURL Error: ' . $curlError]];
        }
        
        if ($httpCode !== 200) {
            return ['success' => false, 'data' => ['message' => 'HTTP ' . $httpCode . ': ' . $response]];
        }
        
        $decoded = json_decode($response, true);
        if (!$decoded) {
            return ['success' => false, 'data' => ['message' => 'Invalid JSON response: ' . $response]];
        }
        
        return $decoded;
    }
    
    public function refreshData($clientId) {
        $curl = curl_init();
        
        $postData = ['client_id' => $clientId];
        
        curl_setopt_array($curl, [
            CURLOPT_URL => $this->apiBaseUrl . '/refresh-data',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($postData),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $this->apiToken,
                'Content-Type: application/json'
            ]
        ]);
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        
        if ($response === false || $httpCode !== 200) {
            return ['success' => false, 'data' => ['message' => 'API request failed']];
        }
        
        return json_decode($response, true);
    }
    
    public function fetchStatementPdf($clientId) {
        $curl = curl_init();
        
        $postData = ['client_id' => $clientId];
        
        curl_setopt_array($curl, [
            CURLOPT_URL => $this->apiBaseUrl . '/fetch-statement-pdf',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($postData),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $this->apiToken,
                'Content-Type: application/json'
            ]
        ]);
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curlError = curl_error($curl);
        curl_close($curl);
        
        if ($response === false) {
            return ['success' => false, 'data' => ['message' => 'cURL Error: ' . $curlError]];
        }
        
        if ($httpCode !== 200) {
            return ['success' => false, 'data' => ['message' => 'HTTP ' . $httpCode . ': ' . $response]];
        }
        
        $decoded = json_decode($response, true);
        if (!$decoded || !$decoded['success']) {
            return ['success' => false, 'data' => ['message' => 'API Error: ' . ($decoded['message'] ?? $response)]];
        }
        
        $pdfLinks = [];
        if (isset($decoded['data']['reports'])) {
            foreach ($decoded['data']['reports'] as $report) {
                if ($report['status'] === 'READY' && isset($report['statement_report_link'])) {
                    $pdfLinks[] = [
                        'fip_id' => $report['fip_id'],
                        'account_number' => $report['account_number'],
                        'pdf_url' => $report['statement_report_link']
                    ];
                }
            }
        }
        
        return [
            'success' => true,
            'data' => [
                'client_id' => $clientId,
                'reports' => $pdfLinks
            ]
        ];
    }
    
    public function saveReport($clientId, $mobile, $reportData, $userId) {
        if (!$this->conn) return false;
        
        $stmt = $this->conn->prepare("INSERT INTO account_aggregator_reports (client_id, mobile_number, report_data, created_by) VALUES (?, ?, ?, ?)");
        $reportJson = json_encode($reportData);
        $stmt->bind_param("sssi", $clientId, $mobile, $reportJson, $userId);
        
        if ($stmt->execute()) {
            return $this->conn->insert_id;
        }
        return false;
    }
    
    public function getReportById($id) {
        if (!$this->conn) return false;
        
        $stmt = $this->conn->prepare("SELECT * FROM account_aggregator_reports WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_assoc();
    }
    
    public function getAllReports($limit = 50) {
        if (!$this->conn) return [];
        
        $stmt = $this->conn->prepare("SELECT id, client_id, mobile_number, created_at, created_by FROM account_aggregator_reports ORDER BY created_at DESC LIMIT ?");
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    public function getReportsByUser($userId, $limit = 20) {
        if (!$this->conn) return [];
        
        $stmt = $this->conn->prepare("SELECT id, client_id, mobile_number, created_at FROM account_aggregator_reports WHERE created_by = ? ORDER BY created_at DESC LIMIT ?");
        $stmt->bind_param("ii", $userId, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    public function deleteReport($id) {
        if (!$this->conn) return false;
        
        $stmt = $this->conn->prepare("DELETE FROM account_aggregator_reports WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        return $stmt->execute();
    }
    
    public function downloadAsPdf($reportData, $filename = 'statement.pdf') {
        require_once 'TextToPdf.php';
        
        $textContent = $this->generateStatementText($reportData);
        $converter = new TextToPdf();
        $converter->convertTxtToPdf($textContent, $filename);
    }
    
    public function downloadAsTxt($reportData, $filename = 'statement.txt') {
        $textContent = $this->generateStatementText($reportData);
        
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($textContent));
        
        echo $textContent;
        exit();
    }
    
    public function downloadReport($id, $format = 'txt') {
        $report = $this->getReportById($id);
        if (!$report) return false;
        
        $reportData = json_decode($report['report_data'], true);
        $filename = 'statement_' . $id . '.' . $format;
        
        if ($format === 'pdf') {
            $this->downloadAsPdf($reportData, $filename);
        } else {
            $this->downloadAsTxt($reportData, $filename);
        }
    }
    
    private function generateStatementText($data) {
        $margin = "    "; // 4 spaces margin on both sides
        
        // Center align the header
        $headerText = "STATEMENT OF ACCOUNT";
        $padding = (100 - strlen($headerText)) / 2;
        $text = $margin . str_repeat(" ", (int)$padding) . $headerText . "\n";
        $text .= $margin . str_repeat("=", 100) . "\n\n";
        
        if (isset($data['data']['account_aggregator_json'][0])) {
            $account = $data['data']['account_aggregator_json'][0];
            
            $text .= $margin . "Account Holder: " . ($account['profile_details']['name'] ?? 'N/A') . "\n";
            $text .= $margin . "Account Number: " . ($account['masked_account_number'] ?? $account['account_id'] ?? 'N/A') . "\n";
            $text .= $margin . "Bank/FIP: " . ($account['fi_status_details']['fip_id'] ?? 'N/A') . "\n";
            $text .= $margin . "IFSC Code: " . ($account['summary_details']['ifsc'] ?? 'N/A') . "\n";
            $text .= $margin . "Branch: " . ($account['summary_details']['branch'] ?? 'N/A') . "\n";
            $text .= $margin . "Account Type: " . ($account['summary_details']['account_sub_type'] ?? 'N/A') . "\n";
            $text .= $margin . "Current Balance: " . ($account['summary_details']['current_balance'] ?? 'N/A') . "\n";
            $text .= $margin . "PAN: " . ($account['profile_details']['pan'] ?? 'N/A') . "\n";
            $text .= $margin . "DOB: " . ($account['profile_details']['dob'] ?? 'N/A') . "\n";
            $text .= $margin . "Mobile: " . ($account['profile_details']['mobile'] ?? 'N/A') . "\n";
            $text .= $margin . "Email: " . ($account['profile_details']['email'] ?? 'N/A') . "\n";
            $text .= $margin . "Address: " . ($account['profile_details']['address'] ?? 'N/A') . "\n";
            $text .= $margin . "Nominee: " . ($account['profile_details']['nominee'] ?? 'N/A') . "\n";
            $text .= $margin . "Statement Period: " . ($account['transaction_data']['start_date'] ?? 'N/A') . " to " . ($account['transaction_data']['end_date'] ?? 'N/A') . "\n\n";
            
            $text .= $margin . "TRANSACTION HISTORY\n";
            $text .= $margin . str_repeat("=", 100) . "\n";
            $text .= $margin . sprintf("%-10s  %-10s  %-25s  %-12s  %-10s  %-10s  %-15s\n", 
                "Post Date", "Value Date", "Description", "Check no/Txn ID", "Debit", "Credit", "Balance");
            $text .= $margin . str_repeat("-", 100) . "\n";
            
            $totalCredit = 0;
            $totalDebit = 0;
            
            if (isset($account['transaction_data']['transaction_details'])) {
                foreach ($account['transaction_data']['transaction_details'] as $txn) {
                    $debitAmount = ($txn['type'] === 'DEBIT') ? number_format($txn['amount'], 2) : '';
                    $creditAmount = ($txn['type'] === 'CREDIT') ? number_format($txn['amount'], 2) : '';
                    
                    $text .= $margin . sprintf("%-10s  %-10s  %-25s  %-12s  %-10s  %-10s  %-15s\n",
                        date('Y-m-d', strtotime($txn['value_date'] ?? '')),
                        date('Y-m-d', strtotime($txn['transaction_timestamp'] ?? '')),
                        substr($txn['narration'] ?? 'N/A', 0, 25),
                        substr($txn['transaction_id'] ?? 'N/A', 0, 12),
                        $debitAmount,
                        $creditAmount,
                        $txn['transactional_balance'] ?? $txn['transaction_balance'] ?? 'N/A'
                    );
                    
                    if ($txn['type'] === 'CREDIT') {
                        $totalCredit += floatval($txn['amount']);
                    } else {
                        $totalDebit += floatval($txn['amount']);
                    }
                }
            }
            
            $text .= "\n";
            $text .= $margin . str_repeat("=", 100) . "\n";
            $text .= $margin . sprintf("%-50s | %s\n", "Page Total Credit", "Page Total Debit");
            $text .= $margin . sprintf("%-50s | %s\n", number_format($totalCredit, 2), number_format($totalDebit, 2));
            $text .= $margin . sprintf("%-50s | %s\n", "Total Credit", "Total Debit");
            $text .= $margin . sprintf("%-50s | %s\n", number_format($totalCredit, 2), number_format($totalDebit, 2));
            $text .= $margin . sprintf("%-30s : %s\n", "Closing Balance", ($account['summary_details']['current_balance'] ?? 'N/A'));
            $text .= "\n";
            $text .= $margin . sprintf("%-30s : \n", "Signature");
        }
        
        return $text;
    }
}

// Usage example
// $aggregator = new AccountAggregator();
// $transformedData = $aggregator->processFile('historical_report_11_2025-12-30_14-39-00.json');
// $aggregator->saveTransformedData($transformedData, 'transformed_account_data.json');

?>