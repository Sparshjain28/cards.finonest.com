<?php
class BankStatementParser {
    private $conn;
    
    public function __construct($database_connection = null) {
        $this->conn = $database_connection;
        $this->createTablesIfNotExist();
    }
    
    private function createTablesIfNotExist() {
        if (!$this->conn) return;
        
        $sql1 = "CREATE TABLE IF NOT EXISTS bank_statements (
            id INT AUTO_INCREMENT PRIMARY KEY,
            account_number VARCHAR(50) NOT NULL,
            account_holder VARCHAR(255) NOT NULL,
            opening_balance DECIMAL(15,2) DEFAULT 0,
            closing_balance DECIMAL(15,2) DEFAULT 0,
            total_transactions INT DEFAULT 0,
            total_credits DECIMAL(15,2) DEFAULT 0,
            total_debits DECIMAL(15,2) DEFAULT 0,
            net_flow DECIMAL(15,2) DEFAULT 0,
            raw_data TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_by INT NOT NULL
        )";
        
        $sql2 = "CREATE TABLE IF NOT EXISTS bank_transactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            statement_id INT NOT NULL,
            transaction_date DATE NOT NULL,
            description TEXT NOT NULL,
            amount DECIMAL(15,2) NOT NULL,
            transaction_type ENUM('CREDIT', 'DEBIT') NOT NULL,
            balance DECIMAL(15,2) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        
        $this->conn->query($sql1);
        $this->conn->query($sql2);
    }
    
    public function parseStatement($text) {
        $lines = explode("\n", $text);
        $data = [
            'account_info' => $this->extractAccountInfo($lines),
            'transactions' => $this->extractTransactions($lines),
            'summary' => []
        ];
        
        $data['summary'] = $this->calculateSummary($data['transactions']);
        return $data;
    }
    
    public function saveToDatabase($statement_data, $raw_text, $user_id) {
        if (!$this->conn) return false;
        
        $account_info = $statement_data['account_info'];
        $summary = $statement_data['summary'];
        
        $stmt = $this->conn->prepare(
            "INSERT INTO bank_statements (account_number, account_holder, opening_balance, closing_balance, 
             total_transactions, total_credits, total_debits, net_flow, raw_data, created_by) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        
        $stmt->bind_param('ssddidddsi', 
            $account_info['account_number'] ?? '',
            $account_info['account_holder'] ?? '',
            $account_info['opening_balance'] ?? 0,
            $account_info['closing_balance'] ?? 0,
            $summary['transaction_count'],
            $summary['total_credit'],
            $summary['total_debit'],
            $summary['net_flow'],
            $raw_text,
            $user_id
        );
        
        if ($stmt->execute()) {
            $statement_id = $this->conn->insert_id;
            $stmt->close();
            $this->saveTransactions($statement_id, $statement_data['transactions']);
            return $statement_id;
        }
        $stmt->close();
        return false;
    }
    
    private function saveTransactions($statement_id, $transactions) {
        if (!$this->conn || empty($transactions)) return;
        
        $stmt = $this->conn->prepare(
            "INSERT INTO bank_transactions (statement_id, transaction_date, description, amount, transaction_type, balance) 
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        
        foreach ($transactions as $txn) {
            $date = date('Y-m-d', strtotime($txn['date']));
            $stmt->bind_param('issdsd', 
                $statement_id,
                $date,
                $txn['description'],
                $txn['amount'],
                $txn['type'],
                $txn['balance']
            );
            $stmt->execute();
        }
        $stmt->close();
    }
    
    private function extractAccountInfo($lines) {
        $info = [];
        foreach ($lines as $line) {
            if (strpos($line, 'Account No') !== false && strpos($line, ':') !== false) {
                $parts = explode(':', $line, 2);
                if (count($parts) > 1) {
                    $accountLine = trim($parts[1]);
                    if (preg_match('/(\d+)\s+INR\s+(.+)/', $accountLine, $matches)) {
                        $info['account_number'] = $matches[1];
                        $info['account_holder'] = trim($matches[2]);
                    }
                }
            }
            if (strpos($line, 'Opening Balance') !== false) {
                if (preg_match('/Opening Balance\s*:\s*([\d,]+\.\d+)Cr/', $line, $matches)) {
                    $info['opening_balance'] = str_replace(',', '', $matches[1]);
                }
            }
            if (strpos($line, 'Closing Balance') !== false) {
                if (preg_match('/([\d,]+\.\d+)/', $line, $matches)) {
                    $info['closing_balance'] = str_replace(',', '', $matches[1]);
                }
            }
        }
        return $info;
    }
    
    private function extractTransactions($lines) {
        $transactions = [];
        foreach ($lines as $line) {
            if (preg_match('/(\d{2}-\d{2}-\d{4})\s+(\d{2}-\d{2}-\d{4})\s+(.+?)\s+([\d,]+\.\d+)\s+([\d,]+\.\d+)Cr/', $line, $matches)) {
                $amount = str_replace(',', '', $matches[4]);
                $balance = str_replace(',', '', $matches[5]);
                
                $transactions[] = [
                    'date' => $matches[1],
                    'description' => trim($matches[3]),
                    'amount' => $amount,
                    'type' => 'DEBIT',
                    'balance' => $balance
                ];
            }
        }
        return $transactions;
    }
    
    private function calculateSummary($transactions) {
        $total_debit = 0;
        $total_credit = 0;
        
        foreach ($transactions as $txn) {
            if ($txn['type'] === 'DEBIT') {
                $total_debit += $txn['amount'];
            } else {
                $total_credit += $txn['amount'];
            }
        }
        
        return [
            'total_credit' => $total_credit,
            'total_debit' => $total_debit,
            'net_flow' => $total_credit - $total_debit,
            'transaction_count' => count($transactions)
        ];
    }
}
?>