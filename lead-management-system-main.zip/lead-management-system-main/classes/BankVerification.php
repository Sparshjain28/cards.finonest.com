<?php
class BankVerification {
    private $apiToken;
    private $baseUrl = 'https://kyc-api.surepass.io/api/v1/bank-verification/';
    
    public function __construct($apiToken) {
        $this->apiToken = $apiToken;
    }
    
    public function verifyAccount($accountNumber, $ifsc, $includeIfscDetails = true) {
        $data = [
            'id_number' => $accountNumber,
            'ifsc' => $ifsc,
            'ifsc_details' => $includeIfscDetails
        ];
        
        $ch = curl_init($this->baseUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $this->apiToken
            ],
            CURLOPT_POSTFIELDS => json_encode($data)
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) {
            return ['success' => false, 'error' => 'API request failed', 'status_code' => $httpCode];
        }
        
        return json_decode($response, true);
    }
    
    public function saveVerificationResult($conn, $userId, $verificationData) {
        if (!$verificationData['success'] || !isset($verificationData['data'])) {
            return false;
        }
        
        $data = $verificationData['data'];
        $stmt = $conn->prepare(
            "UPDATE users SET 
            bank_verified = 1,
            bank_account_holder_name = ?,
            bank_verification_date = NOW(),
            bank_verification_ref = ?
            WHERE id = ?"
        );
        
        $stmt->bind_param('ssi', 
            $data['full_name'],
            $data['imps_ref_no'],
            $userId
        );
        
        return $stmt->execute();
    }
}
