<?php
// Check if Composer autoloader exists before requiring PHPMailer
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
    define('PHPMAILER_AVAILABLE', true);
} else {
    define('PHPMAILER_AVAILABLE', false);
}

class EmailNotification {
    private $from = 'support@finonest.org';
    private $fromName = 'FinoCards';
    
    public function send($to, $subject, $message) {
        if (!PHPMAILER_AVAILABLE) {
            // Fallback to PHP's mail() function
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: {$this->fromName} <{$this->from}>" . "\r\n";
            
            $fullMessage = $this->template($message);
            return mail($to, $subject, $fullMessage, $headers);
        }
        
        // Use PHPMailer if available
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.zoho.in';
            $mail->SMTPAuth = true;
            $mail->Username = 'support@finonest.org';
            $mail->Password = 'JzjFHd6p7nSd';
            $mail->Port = 587;
            $mail->SMTPSecure = 'tls';
            
            $mail->setFrom($this->from, $this->fromName);
            $mail->addAddress($to);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $this->template($message);
            
            return $mail->send();
        } catch (\PHPMailer\PHPMailer\Exception $e) {
            error_log("Email error: {$mail->ErrorInfo}");
            return false;
        }
    }
    
    private function template($content) {
        return "<!DOCTYPE html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1.0'><style>body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;margin:0;padding:20px;background:#f8fafc;line-height:1.6}.container{max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.1)}.header{background:linear-gradient(135deg,#3b82f6 0%,#1d4ed8 100%);color:#fff;padding:40px 30px;text-align:center}.logo{max-width:120px;height:auto;margin-bottom:15px;background:#fff;padding:10px;border-radius:8px}.header h1{margin:0;font-size:28px;font-weight:700}.content{padding:40px 30px}.info-box{background:#f1f5f9;border-left:4px solid #3b82f6;padding:20px;margin:20px 0;border-radius:8px}.status-badge{display:inline-block;padding:8px 16px;border-radius:20px;font-weight:600;font-size:14px;margin:10px 0}.status-pending{background:#fef3c7;color:#92400e}.status-approved{background:#d1fae5;color:#065f46}.status-rejected{background:#fee2e2;color:#991b1b}.btn{display:inline-block;background:#3b82f6;color:#fff;padding:14px 28px;text-decoration:none;border-radius:8px;font-weight:600;margin:20px 0}.footer{background:#f8fafc;padding:25px 30px;text-align:center;border-top:1px solid #e2e8f0;color:#64748b;font-size:14px}</style></head><body><div class='container'><div class='header'><img src='https://finonest.org/assets/logo1.jpeg' alt='Finonest India' class='logo'><h1>Finonest India</h1><p>Your Trusted Financial Partner</p></div><div class='content'>{$content}</div><div class='footer'><p><strong>Finonest India</strong></p><p>Contact: support@finonest.org | © 2025 Finonest India. All rights reserved.</p></div></div></body></html>";
    }
    
    public function leadCreated($userEmail, $leadId, $productName) {
        $message = "<h2 style='color:#3b82f6;margin-bottom:20px'>Lead Created Successfully</h2><p>Your lead application has been submitted and is now under review.</p><div class='info-box'><strong>Lead ID:</strong> {$leadId}<br><strong>Product:</strong> {$productName}<br><strong>Status:</strong> <span class='status-badge status-pending'>Under Review</span></div><p>We'll notify you once your application is reviewed. This typically takes 24-48 hours.</p>";
        return $this->send($userEmail, "Lead Created - {$leadId}", $message);
    }
    
    public function payoutProcessed($userEmail, $amount, $payoutId) {
        $message = "<h2 style='color:#10b981;margin-bottom:20px'>Payout Processed</h2><p>Great news! Your payout has been successfully processed.</p><div class='info-box'><strong>Payout ID:</strong> {$payoutId}<br><strong>Amount:</strong> <span style='color:#10b981;font-size:24px;font-weight:700'>₹" . number_format($amount) . "</span><br><strong>Status:</strong> <span class='status-badge status-approved'>Paid</span></div><p>The amount will be credited to your registered bank account within 2-3 business days.</p>";
        return $this->send($userEmail, "Payout Processed - ₹" . number_format($amount), $message);
    }
    
    public function emailVerificationOTP($userEmail, $otp) {
        $message = "<h2 style='color:#3b82f6;margin-bottom:20px'>Verify Your Email Address</h2><p>Please use the OTP below to verify your email address and activate your account.</p><div class='info-box' style='text-align:center'><strong>Your OTP:</strong><br><span style='font-size:32px;font-weight:bold;color:#3b82f6;letter-spacing:8px'>{$otp}</span></div><p style='color:#64748b;font-size:14px'>This OTP is valid for 10 minutes. If you didn't create this account, please ignore this email.</p>";
        return $this->send($userEmail, "Email Verification OTP - Finonest India", $message);
    }
}
?>