<?php
require_once __DIR__ . '/../config/timezone.php';
require_once __DIR__ . '/../includes/timestamp_validator.php';

class Lead {
    private $conn;
    private $table_name = "leads";

    public function __construct($db) {
        $this->conn = $db;
    }

    private static function normalizeEmail($email) {
        return strtolower(trim($email));
    }
    
    private static function normalizePhone($phone) {
        // Remove +91, spaces, and non-numeric characters
        $phone = preg_replace('/^\+91/', '', $phone);
        $phone = preg_replace('/[^0-9]/', '', $phone);
        return $phone;
    }

    public function checkDuplicate($mobile, $email, $product_id = null) {
        // Normalize inputs
        $normalized_email = self::normalizeEmail($email);
        $normalized_phone = self::normalizePhone($mobile);
        
        if ($product_id) {
            // Check for specific product duplicate
            $query = "SELECT l.id, l.lead_id, l.customer_name, l.channel_code, l.advisor_name, u.name as created_by_user 
                      FROM " . $this->table_name . " l 
                      LEFT JOIN users u ON l.channel_code = u.channel_code 
                      WHERE LOWER(l.email) = ? AND l.phone = ? AND l.product_id = ? LIMIT 1";
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('ssi', $normalized_email, $normalized_phone, $product_id);
        } else {
            // Legacy check (for backward compatibility)
            $query = "SELECT l.id, l.lead_id, l.customer_name, l.channel_code, l.advisor_name, u.name as created_by_user 
                      FROM " . $this->table_name . " l 
                      LEFT JOIN users u ON l.channel_code = u.channel_code 
                      WHERE l.mobile = ? OR l.email = ? LIMIT 1";
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param('ss', $mobile, $email);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    public function create($data) {
        // Normalize email and phone before storing
        if (isset($data['email'])) {
            $data['email'] = self::normalizeEmail($data['email']);
        }
        if (isset($data['mobile'])) {
            $data['mobile'] = self::normalizePhone($data['mobile']);
        }
        if (isset($data['phone'])) {
            $data['phone'] = self::normalizePhone($data['phone']);
        }
        
        // Build columns and params dynamically so we can include created_at (timezone-aware)
        $columns = [
            'lead_id', 'unique_utm_id', 'channel_code', 'customer_name', 'email', 'mobile', 'phone', 'product_id', 'status'
        ];
        $values = [
            $data['lead_id'] ?? null,
            $data['unique_utm_id'] ?? null,
            $data['channel_code'] ?? null,
            $data['customer_name'] ?? null,
            $data['email'] ?? null,
            $data['mobile'] ?? null,
            $data['phone'] ?? null,
            $data['product_id'] ?? null,
            $data['status'] ?? 'generated'
        ];

        // Add advisor_name if provided
        if (isset($data['advisor_name']) && !empty($data['advisor_name'])) {
            $columns[] = 'advisor_name';
            $values[] = $data['advisor_name'];
        }

        // Validate and correct timestamp if needed
        $data = autoCorrectLeadTimestamp($data);
        
        // Ensure created_at is set in IST if not provided
        if (isset($data['created_at']) && !empty($data['created_at'])) {
            // Validate and normalize provided timestamp
            $created_at = parseTimestamp($data['created_at'])->format('Y-m-d H:i:s');
        } else {
            $created_at = getAppTimestamp();
        }
        $columns[] = 'created_at';
        $values[] = $created_at;
        
        // Log timestamp validation if corrected
        if (isset($data['timestamp_corrected'])) {
            logTimezone('Timestamp auto-corrected for lead: ' . ($data['lead_id'] ?? 'unknown'));
        }

        // Optionally include updated_at if provided
        if (isset($data['updated_at'])) {
            $columns[] = 'updated_at';
            $values[] = $data['updated_at'];
        }

        $placeholders = array_fill(0, count($columns), '?');
        $query = "INSERT INTO " . $this->table_name . " (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";

        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            error_log('Prepare failed: ' . $this->conn->error);
            return false;
        }

        // Build types string: use 's' for strings and 'i' for integers (product_id)
        $types = '';
        foreach ($columns as $col) {
            if ($col === 'product_id') {
                $types .= 'i';
            } else {
                $types .= 's';
            }
        }

        // Bind params dynamically
        $bind_params = [];
        $bind_params[] = & $types;
        for ($i = 0; $i < count($values); $i++) {
            // mysqli bind_param requires references
            $bind_params[] = & $values[$i];
        }

        // Call bind_param with dynamic params
        call_user_func_array([$stmt, 'bind_param'], $bind_params);

        if ($stmt->execute()) {
            return $data['lead_id'];
        }
        error_log('Execute failed: ' . $stmt->error);
        return false;
    }

    public function read($filters = []) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE 1=1";
        $params = [];
        $types = '';

        if (!empty($filters['search'])) {
            $query .= " AND (customer_name LIKE ? OR email LIKE ? OR lead_id LIKE ?)";
            $search_param = '%' . $filters['search'] . '%';
            $params[] = $search_param;
            $params[] = $search_param;
            $params[] = $search_param;
            $types .= 'sss';
        }

        if (!empty($filters['status']) && $filters['status'] !== 'all') {
            $query .= " AND status = ?";
            $params[] = $filters['status'];
            $types .= 's';
        }

        if (!empty($filters['product']) && $filters['product'] !== 'all') {
            $query .= " AND product = ?";
            $params[] = $filters['product'];
            $types .= 's';
        }

        $query .= " ORDER BY created_at DESC";

        $stmt = $this->conn->prepare($query);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function readOne($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    public function update($id, $data) {
        // Use mysqli prepared statement and set updated_at with IST timestamp
        $updated_at = getAppTimestamp();
        $query = "UPDATE " . $this->table_name . " 
                  SET status = ?, notes = ?, rejection_reason = ?, bank_name = ?, updated_at = ?
                  WHERE id = ?";

        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            error_log('Prepare failed (update): ' . $this->conn->error);
            return false;
        }

        $notes = $data['notes'] ?? '';
        $rejection = $data['rejection_reason'] ?? '';
        $bank = $data['bank_name'] ?? '';
        $status = $data['status'];

        $stmt->bind_param('sssssi', $status, $notes, $rejection, $bank, $updated_at, $id);

        return $stmt->execute();
    }

    public function delete($id) {
        // Delete from payouts first (if exists)
        $payout_stmt = $this->conn->prepare("DELETE FROM payouts WHERE lead_id = ?");
        $payout_stmt->bind_param('i', $id);
        $payout_stmt->execute();
        $payout_stmt->close();
        
        // Delete lead
        $stmt = $this->conn->prepare("DELETE FROM leads WHERE id = ?");
        $stmt->bind_param('i', $id);
        $result = $stmt->execute();
        $stmt->close();
        return $result;
    }

    public function getStats() {
        $query = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
                    SUM(CASE WHEN status = 'under-review' THEN 1 ELSE 0 END) as under_review,
                    SUM(CASE WHEN status = 'documents-required' THEN 1 ELSE 0 END) as documents_required,
                    SUM(CASE WHEN status = 'curable' THEN 1 ELSE 0 END) as curable
                  FROM " . $this->table_name;

        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    private function calculateCommission($product, $amount) {
        if ($product === 'Credit Card') {
            if ($amount >= 500000) return 5000;
            if ($amount >= 300000) return 3500;
            if ($amount >= 200000) return 2500;
            return 2000;
        } else { // Personal Loan
            return $amount * 0.01; // 1% of loan amount
        }
    }
}
?>
