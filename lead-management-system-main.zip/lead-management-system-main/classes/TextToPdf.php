<?php

class TextToPdf {
    
    public function convertTxtToPdf($txtContent, $filename = 'document.pdf') {
        $pdf = $this->createMultiPagePdf($txtContent);
        
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($pdf));
        
        echo $pdf;
        exit();
    }
    
    private function createMultiPagePdf($content) {
        $lines = explode("\n", $content);
        $pageWidth = 612;
        $margin = 30;
        $lineHeight = 10;
        $fontSize = 6;
        
        // Remove empty lines at the end
        while (end($lines) === '' && count($lines) > 0) {
            array_pop($lines);
        }
        
        // Calculate dynamic page height based on content
        $totalLines = count($lines);
        $minPageHeight = 400;
        $maxPageHeight = 792;
        $contentHeight = ($totalLines * $lineHeight) + (2 * $margin) + 50;
        $pageHeight = min($maxPageHeight, max($minPageHeight, $contentHeight));
        
        $linesPerPage = floor(($pageHeight - 2 * $margin) / $lineHeight);
        
        // Find where transaction history starts
        $headerEndIndex = 0;
        $transactionStartIndex = 0;
        for ($i = 0; $i < count($lines); $i++) {
            if (strpos($lines[$i], 'TRANSACTION HISTORY') !== false) {
                $headerEndIndex = $i - 1;
                $transactionStartIndex = $i;
                break;
            }
        }
        
        $headerLines = array_slice($lines, 0, $headerEndIndex + 1);
        $transactionLines = array_slice($lines, $transactionStartIndex);
        
        // First page: header + some transactions
        $firstPageTransactionCount = $linesPerPage - count($headerLines);
        $firstPageTransactions = array_slice($transactionLines, 0, $firstPageTransactionCount);
        $remainingTransactions = array_slice($transactionLines, $firstPageTransactionCount);
        
        $pages = [];
        $pages[] = array_merge($headerLines, $firstPageTransactions);
        
        // Remaining pages: just transactions
        if (!empty($remainingTransactions)) {
            $remainingPages = array_chunk($remainingTransactions, $linesPerPage);
            $pages = array_merge($pages, $remainingPages);
        }
        
        $pageCount = count($pages);
        
        $pdf = "%PDF-1.4\n";
        $objCount = 1;
        
        // Catalog
        $pdf .= "$objCount 0 obj\n<< /Type /Catalog /Pages " . ($objCount + 1) . " 0 R >>\nendobj\n";
        $objCount++;
        
        // Pages object
        $pageRefs = [];
        for ($i = 0; $i < $pageCount; $i++) {
            $pageRefs[] = ($objCount + 1 + $i) . " 0 R";
        }
        $pdf .= "$objCount 0 obj\n<< /Type /Pages /Kids [" . implode(' ', $pageRefs) . "] /Count $pageCount >>\nendobj\n";
        $objCount++;
        
        // Font object
        $fontObj = $objCount + $pageCount;
        
        // Page objects and content
        foreach ($pages as $pageIndex => $pageLines) {
            $contentObj = $fontObj + 1 + $pageIndex;
            
            // Calculate page height for this specific page
            $actualContentHeight = count($pageLines) * $lineHeight + (2 * $margin);
            $currentPageHeight = min($pageHeight, $actualContentHeight + 50);
            
            // Page object
            $pdf .= "$objCount 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $pageWidth $currentPageHeight] /Resources << /Font << /F1 $fontObj 0 R >> >> /Contents $contentObj 0 R >>\nendobj\n";
            $objCount++;
        }
        
        // Font
        $pdf .= "$fontObj 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>\nendobj\n";
        
        // Content streams
        foreach ($pages as $pageIndex => $pageLines) {
            $contentObj = $fontObj + 1 + $pageIndex;
            
            // Calculate actual content height for this page
            $actualContentHeight = count($pageLines) * $lineHeight + (2 * $margin);
            $currentPageHeight = min($pageHeight, $actualContentHeight + 50);
            $yPosition = $currentPageHeight - $margin;
            
            $contentStream = "BT\n/F1 $fontSize Tf\n$margin $yPosition Td\n$lineHeight TL\n";
            
            foreach ($pageLines as $line) {
                // Truncate long lines to fit page width
                if (strlen($line) > 150) {
                    $line = substr($line, 0, 150);
                }
                $line = str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $line);
                $contentStream .= "($line) Tj T*\n";
            }
            
            $contentStream .= "ET";
            
            $pdf .= "$contentObj 0 obj\n<< /Length " . strlen($contentStream) . " >>\nstream\n$contentStream\nendstream\nendobj\n";
        }
        
        // Cross-reference table
        $xrefPos = strlen($pdf);
        $totalObjs = $fontObj + $pageCount + 1;
        $pdf .= "xref\n0 $totalObjs\n";
        $pdf .= "0000000000 65535 f \n";
        
        // Add xref entries (simplified)
        for ($i = 1; $i < $totalObjs; $i++) {
            $pdf .= sprintf("%010d 00000 n \n", 10 + ($i - 1) * 100);
        }
        
        // Trailer
        $pdf .= "trailer\n<< /Size $totalObjs /Root 1 0 R >>\n";
        $pdf .= "startxref\n$xrefPos\n%%EOF";
        
        return $pdf;
    }
    
    public function convertFileTopdf($txtFilePath, $outputFilename = null) {
        if (!file_exists($txtFilePath)) {
            throw new Exception("File not found: $txtFilePath");
        }
        
        $content = file_get_contents($txtFilePath);
        $filename = $outputFilename ?: basename($txtFilePath, '.txt') . '.pdf';
        
        $this->convertTxtToPdf($content, $filename);
    }
}

// Usage
if (isset($_GET['convert']) && isset($_GET['file'])) {
    $converter = new TextToPdf();
    $converter->convertFileTopdf($_GET['file']);
}

?>