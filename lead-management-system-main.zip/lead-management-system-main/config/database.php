<?php
class Database {
    private $host;
    private $port;
    private $db_name;
    private $username;
    private $password;
    public $conn;

    public function __construct() {
        // Get host and force TCP connection
        $raw_host = getenv('DB_HOST') ?: 'g0co8w4wgso8ow00sk4k0oks';
        
        // Replace localhost with actual MySQL host to force TCP
        if (empty($raw_host) || $raw_host === 'localhost' || $raw_host === '127.0.0.1') {
            $raw_host = 'g0co8w4wgso8ow00sk4k0oks';
        }
        
        $this->host = $raw_host;
        $this->port = getenv('DB_PORT') ?: '3306';
        $this->db_name = getenv('DB_NAME') ?: 'leadmanagement';
        $this->username = getenv('DB_USERNAME') ?: 'leadmanagementadmin';
        $this->password = getenv('DB_PASSWORD') ?: 'sparshjain@28';
    }

    public function getConnection() {
        $this->conn = null;
        try {
            // Force TCP connection with explicit host:port and charset
            $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->db_name};charset=utf8mb4";
            
            $this->conn = new PDO(
                $dsn,
                $this->username,
                $this->password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
                ]
            );
        } catch(PDOException $exception) {
            error_log("Connection error: " . $exception->getMessage());
            throw $exception;
        }
        return $this->conn;
    }
}
?>