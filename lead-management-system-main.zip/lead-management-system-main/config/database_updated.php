<?php
class Database {
    private $host;
    private $port;
    private $db_name;
    private $username;
    private $password;
    public $conn;

    public function __construct() {
        $this->host = getenv('DB_HOST') ?: '72.61.238.231';
        $this->port = getenv('DB_PORT') ?: '5437';
        $this->db_name = getenv('DB_NAME') ?: 'leadmanagement';
        $this->username = getenv('DB_USERNAME') ?: 'leadmanagementadmin';
        $this->password = getenv('DB_PASSWORD') ?: 'sparshjain@28';
    }

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new mysqli($this->host, $this->username, $this->password, $this->db_name, $this->port);
            
            if ($this->conn->connect_error) {
                error_log("Connection error: " . $this->conn->connect_error);
                throw new Exception("Connection failed: " . $this->conn->connect_error);
            }
            
            $this->conn->set_charset("utf8mb4");
            
            // Performance optimizations (MySQL 8.0+ compatible)
            $this->conn->query("SET SESSION sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
            $this->conn->query("SET SESSION innodb_lock_wait_timeout = 50");
            
        } catch(Exception $exception) {
            error_log("Connection error: " . $exception->getMessage());
            throw $exception;
        }
        return $this->conn;
    }
}
?>