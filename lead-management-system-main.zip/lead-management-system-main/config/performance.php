<?php
// Performance optimizations
ini_set('memory_limit', '256M');
ini_set('max_execution_time', 30);
ini_set('output_buffering', 4096);

// Enable OPcache if available
if (function_exists('opcache_get_status')) {
    ini_set('opcache.enable', 1);
    ini_set('opcache.memory_consumption', 128);
    ini_set('opcache.max_accelerated_files', 4000);
    ini_set('opcache.revalidate_freq', 60);
}

// Start output buffering with gzip if available
if (extension_loaded('zlib') && !ob_get_level()) {
    ob_start('ob_gzhandler');
}

// Set cache headers for static content
function setCacheHeaders($type = 'static') {
    if ($type === 'static') {
        header('Cache-Control: public, max-age=31536000'); // 1 year
        header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 31536000) . ' GMT');
    } else {
        header('Cache-Control: public, max-age=3600'); // 1 hour
        header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 3600) . ' GMT');
    }
}

// Database connection optimization
function optimizeDbConnection($conn) {
    if ($conn) {
        mysqli_query($conn, "SET SESSION query_cache_type = ON");
        mysqli_query($conn, "SET SESSION query_cache_size = 1048576");
    }
}
?>