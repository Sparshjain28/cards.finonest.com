<?php
// Single source of truth for timezone configuration
define('APP_TIMEZONE', 'Asia/Kolkata');

// Set PHP timezone once globally
if (date_default_timezone_get() !== APP_TIMEZONE) {
    date_default_timezone_set(APP_TIMEZONE);
}

// Consistent timestamp generation
function getAppTimestamp($format = 'Y-m-d H:i:s') {
    return date($format);
}

// Timezone-aware DateTime parsing
function parseTimestamp($timestamp) {
    return new DateTime($timestamp, new DateTimeZone(APP_TIMEZONE));
}
?>