#!/bin/bash
set -e

echo "=== Container Startup Debug ==="
echo "Date: $(date)"
echo "PHP Version: $(php -v | head -1)"
echo "Working Directory: $(pwd)"
echo "Files in /var/www/html:"
ls -la /var/www/html/ | head -10

echo "=== PHP Extensions ==="
php -m

echo "=== PHP Configuration Test ==="
php -l /var/www/html/index.php || echo "PHP syntax error in index.php"

echo "=== Database Connection Test ==="
php -r "
\$host = getenv('DB_HOST') ?: 'g0co8w4wgso8ow00sk4k0oks';
\$port = getenv('DB_PORT') ?: '3306';
\$dbname = getenv('DB_NAME') ?: 'leadmanagement';
\$username = getenv('DB_USERNAME') ?: 'leadmanagementadmin';
\$password = getenv('DB_PASSWORD') ?: 'sparshjain@28';
try {
    \$pdo = new PDO(\"mysql:host=\$host:\$port;dbname=\$dbname\", \$username, \$password);
    echo 'Database connection: SUCCESS\n';
} catch (Exception \$e) {
    echo 'Database connection: FAILED - ' . \$e->getMessage() . \"\n\";
}
"

echo "=== Starting Apache ==="
exec apache2-foreground