<?php
// Accept terms for an application (AJAX)
require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json; charset=utf-8');
$database = new Database();
$conn = $database->getConnection();
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
$application_id = isset($_POST['application_id']) ? intval($_POST['application_id']) : 0; // optional
$user_id = $_SESSION['user_id'] ?? null;
if ($product_id <= 0) {
    echo json_encode(['success' => false, 'error' => 'missing_product_id']);
    exit;
}
// If application_id provided, update the record, else store in session (for later linking)
if ($application_id && $application_id > 0) {
    $stmt = $conn->prepare('UPDATE applications SET terms_accepted = 1, accepted_at = NOW() WHERE application_id = ? LIMIT 1');
    $stmt->bind_param('i', $application_id);
    $ok = $stmt->execute();
    $stmt->close();
    if ($ok) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'db_fail']);
    }
    exit;
} else {
    // Store acceptance in session keyed by product_id so when application is created we can persist
    $_SESSION['terms_accepted_for_product_' . $product_id] = ['accepted' => 1, 'accepted_at' => date('Y-m-d H:i:s')];
    echo json_encode(['success' => true, 'stored_in_session' => true]);
    exit;
}
?>