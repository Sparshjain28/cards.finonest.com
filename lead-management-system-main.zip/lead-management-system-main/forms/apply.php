<?php
require_once 'includes/auth.php';
require_once 'config/database_updated.php';
require_once 'classes/Lead.php';

requireLogin();

$error = '';
$success = '';
$selectedProduct = $_GET['product'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $database = new Database();
    $db = $database->getConnection();
    $lead = new Lead($db);
    
    $data = [
        'customer_name' => $_POST['firstName'] . ' ' . $_POST['lastName'],
        'email' => $_POST['email'],
        'phone' => $_POST['phone'],
        'product' => $_POST['product'],
        'product_type' => $_POST['product'] === 'Credit Card' ? $_POST['creditCardType'] : $_POST['purpose'],
        'amount' => $_POST['product'] === 'Credit Card' ? 
                   ($_POST['creditCardType'] === 'platinum' ? 500000 : ($_POST['creditCardType'] === 'gold' ? 300000 : 200000)) :
                   $_POST['loanAmount'],
        'city' => $_POST['city'],
        'monthly_income' => $_POST['monthlyIncome'],
        'employment_type' => $_POST['employmentType'],
        'first_name' => $_POST['firstName'],
        'last_name' => $_POST['lastName'],
        'date_of_birth' => $_POST['dateOfBirth'],
        'pan_card' => $_POST['panCard'],
        'aadhar_card' => $_POST['aadharCard'] ?? '',
        'address' => $_POST['address'],
        'state' => $_POST['state'],
        'pincode' => $_POST['pincode'],
        'company_name' => $_POST['companyName'] ?? '',
        'designation' => $_POST['designation'] ?? '',
        'work_experience' => $_POST['workExperience'] ?? '',
        'loan_amount' => $_POST['loanAmount'] ?? null,
        'credit_card_type' => $_POST['creditCardType'] ?? null,
        'purpose' => $_POST['purpose'] ?? null,
        'notes' => 'Application submitted via online form'
    ];
    
    $leadId = $lead->create($data);
    if ($leadId) {
        $success = "Application submitted successfully! Lead ID: $leadId";
    } else {
        $error = "Failed to submit application. Please try again.";
    }
}

$products = [
    [
        'id' => 'credit-card',
        'name' => 'Credit Card',
        'description' => 'Get instant approval for premium credit cards',
        'features' => ['Instant approval', 'Up to ₹5L limit', 'Reward points', 'Zero annual fee'],
        'commission' => '₹2,000 - ₹5,000',
        'processingTime' => '24-48 hours'
    ],
    [
        'id' => 'personal-loan',
        'name' => 'Personal Loan',
        'description' => 'Quick personal loans with competitive rates',
        'features' => ['Up to ₹25L amount', 'Minimal documentation', 'Quick disbursal', 'Flexible tenure'],
        'commission' => '₹5,000 - ₹15,000',
        'processingTime' => '2-5 business days'
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit New Application - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <!-- Header -->
    <header class="bg-white border-b border-slate-200 shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="flex items-center space-x-2">
                        <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                            <i class="fas fa-credit-card text-white"></i>
                        </div>
                        <h1 class="text-xl font-bold text-slate-900">LeadFlow Pro</h1>
                    </a>
                </div>
                <nav class="flex items-center space-x-6">
                    <a href="dashboard.php" class="text-slate-700 hover:text-blue-600">Dashboard</a>
                    <span class="text-blue-600 font-medium">Apply</span>
                    <a href="leads.php" class="text-slate-700 hover:text-blue-600">Leads</a>
                    <a href="payouts.php" class="text-slate-700 hover:text-blue-600">Payouts</a>
                </nav>
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="mb-8">
            <a href="dashboard.php" class="inline-flex items-center text-slate-600 hover:text-blue-600 mb-4">
                <i class="fas fa-arrow-left mr-2"></i>Back to Dashboard
            </a>
            <h2 class="text-3xl font-bold text-slate-900 mb-2">Submit New Application</h2>
            <p class="text-slate-600">Choose a product and fill out the application form for your customer.</p>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success mb-6">
                <i class="fas fa-check-circle mr-2"></i>
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error mb-6">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if (!$selectedProduct): ?>
            <!-- Product Selection -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php foreach ($products as $product): ?>
                    <div class="card bg-white border-slate-200 shadow-sm hover:shadow-md transition-all cursor-pointer group"
                         onclick="selectProduct('<?php echo $product['id']; ?>')">
                        <div class="p-6 pb-4">
                            <div class="flex items-center space-x-3">
                                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                                    <i class="fas fa-<?php echo $product['id'] === 'credit-card' ? 'credit-card' : 'dollar-sign'; ?> text-blue-600"></i>
                                </div>
                                <div>
                                    <h3 class="text-xl font-semibold text-slate-900"><?php echo $product['name']; ?></h3>
                                    <p class="text-slate-600"><?php echo $product['description']; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="px-6 pb-6 space-y-4">
                            <div class="space-y-2">
                                <?php foreach ($product['features'] as $feature): ?>
                                    <div class="flex items-center space-x-2">
                                        <i class="fas fa-check-circle text-green-600"></i>
                                        <span class="text-sm text-slate-700"><?php echo $feature; ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <div class="flex items-center justify-between pt-4 border-t border-slate-200">
                                <div>
                                    <p class="text-sm text-slate-600">Commission</p>
                                    <p class="font-semibold text-green-600"><?php echo $product['commission']; ?></p>
                                </div>
                                <div>
                                    <p class="text-sm text-slate-600">Processing Time</p>
                                    <p class="font-semibold text-slate-900"><?php echo $product['processingTime']; ?></p>
                                </div>
                            </div>

                            <button class="btn-primary w-full">Select <?php echo $product['name']; ?></button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <!-- Application Form -->
            <div class="max-w-4xl mx-auto">
                <div class="mb-6">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-3">
                            <span class="badge badge-approved">
                                <?php echo $selectedProduct === 'credit-card' ? 'Credit Card' : 'Personal Loan'; ?>
                            </span>
                            <span class="text-slate-600">Application Form</span>
                        </div>
                        <a href="apply.php" class="btn-secondary">Change Product</a>
                    </div>
                </div>

                <form method="POST" class="space-y-8" data-validate>
                    <input type="hidden" name="product" value="<?php echo $selectedProduct === 'credit-card' ? 'Credit Card' : 'Personal Loan'; ?>">
                    
                    <!-- Personal Information -->
                    <div class="card bg-white border-slate-200 shadow-sm">
                        <div class="p-6 pb-4">
                            <h3 class="text-lg font-semibold flex items-center space-x-2">
                                <i class="fas fa-user text-blue-600"></i>
                                <span>Personal Information</span>
                            </h3>
                            <p class="text-slate-600">Basic details of the applicant</p>
                        </div>
                        <div class="px-6 pb-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">First Name *</label>
                                    <input name="firstName" type="text" placeholder="Enter first name" class="form-input" required />
                                </div>
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">Last Name *</label>
                                    <input name="lastName" type="text" placeholder="Enter last name" class="form-input" required />
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">Email Address *</label>
                                    <input name="email" type="email" placeholder="Enter email address" class="form-input" required />
                                </div>
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">Phone Number *</label>
                                    <input name="phone" type="tel" placeholder="Enter phone number" class="form-input" required />
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">Date of Birth *</label>
                                    <input name="dateOfBirth" type="date" class="form-input" required />
                                </div>
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">PAN Card *</label>
                                    <input name="panCard" type="text" placeholder="ABCDE1234F" class="form-input" required />
                                </div>
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">Aadhar Card</label>
                                    <input name="aadharCard" type="text" placeholder="1234 5678 9012" class="form-input" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Address Information -->
                    <div class="card bg-white border-slate-200 shadow-sm">
                        <div class="p-6 pb-4">
                            <h3 class="text-lg font-semibold flex items-center space-x-2">
                                <i class="fas fa-map-marker-alt text-blue-600"></i>
                                <span>Address Information</span>
                            </h3>
                            <p class="text-slate-600">Current residential address</p>
                        </div>
                        <div class="px-6 pb-6 space-y-6">
                            <div class="space-y-2">
                                <label class="block text-slate-900 font-medium">Full Address *</label>
                                <textarea name="address" placeholder="Enter complete address" class="form-input" rows="3" required></textarea>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">City *</label>
                                    <input name="city" type="text" placeholder="Enter city" class="form-input" required />
                                </div>
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">State *</label>
                                    <select name="state" class="form-input" required>
                                        <option value="">Select state</option>
                                        <option value="maharashtra">Maharashtra</option>
                                        <option value="delhi">Delhi</option>
                                        <option value="karnataka">Karnataka</option>
                                        <option value="tamil-nadu">Tamil Nadu</option>
                                        <option value="gujarat">Gujarat</option>
                                        <option value="rajasthan">Rajasthan</option>
                                        <option value="west-bengal">West Bengal</option>
                                        <option value="uttar-pradesh">Uttar Pradesh</option>
                                    </select>
                                </div>
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">PIN Code *</label>
                                    <input name="pincode" type="text" placeholder="Enter PIN code" class="form-input" required />
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Employment Information -->
                    <div class="card bg-white border-slate-200 shadow-sm">
                        <div class="p-6 pb-4">
                            <h3 class="text-lg font-semibold flex items-center space-x-2">
                                <i class="fas fa-building text-blue-600"></i>
                                <span>Employment Information</span>
                            </h3>
                            <p class="text-slate-600">Current employment and income details</p>
                        </div>
                        <div class="px-6 pb-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">Employment Type *</label>
                                    <select name="employmentType" class="form-input" required>
                                        <option value="">Select employment type</option>
                                        <option value="salaried">Salaried</option>
                                        <option value="self-employed">Self Employed</option>
                                        <option value="business">Business Owner</option>
                                        <option value="freelancer">Freelancer</option>
                                    </select>
                                </div>
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">Monthly Income *</label>
                                    <select name="monthlyIncome" class="form-input" required>
                                        <option value="">Select income range</option>
                                        <option value="25000-50000">₹25,000 - ₹50,000</option>
                                        <option value="50000-100000">₹50,000 - ₹1,00,000</option>
                                        <option value="100000-200000">₹1,00,000 - ₹2,00,000</option>
                                        <option value="200000-500000">₹2,00,000 - ₹5,00,000</option>
                                        <option value="500000+">₹5,00,000+</option>
                                    </select>
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">Company Name</label>
                                    <input name="companyName" type="text" placeholder="Enter company name" class="form-input" />
                                </div>
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">Designation</label>
                                    <input name="designation" type="text" placeholder="Enter designation" class="form-input" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Product Details -->
                    <div class="card bg-white border-slate-200 shadow-sm">
                        <div class="p-6 pb-4">
                            <h3 class="text-lg font-semibold flex items-center space-x-2">
                                <i class="fas fa-file-alt text-blue-600"></i>
                                <span>Product Details</span>
                            </h3>
                            <p class="text-slate-600">Specific requirements for the selected product</p>
                        </div>
                        <div class="px-6 pb-6 space-y-6">
                            <?php if ($selectedProduct === 'personal-loan'): ?>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div class="space-y-2">
                                        <label class="block text-slate-900 font-medium">Loan Amount *</label>
                                        <select name="loanAmount" class="form-input" required>
                                            <option value="">Select loan amount</option>
                                            <option value="100000">₹1,00,000</option>
                                            <option value="200000">₹2,00,000</option>
                                            <option value="500000">₹5,00,000</option>
                                            <option value="1000000">₹10,00,000</option>
                                            <option value="1500000">₹15,00,000</option>
                                            <option value="2000000">₹20,00,000</option>
                                            <option value="2500000">₹25,00,000</option>
                                        </select>
                                    </div>
                                    <div class="space-y-2">
                                        <label class="block text-slate-900 font-medium">Purpose</label>
                                        <select name="purpose" class="form-input">
                                            <option value="">Select purpose</option>
                                            <option value="home-renovation">Home Renovation</option>
                                            <option value="medical-emergency">Medical Emergency</option>
                                            <option value="education">Education</option>
                                            <option value="wedding">Wedding</option>
                                            <option value="travel">Travel</option>
                                            <option value="debt-consolidation">Debt Consolidation</option>
                                            <option value="business">Business</option>
                                            <option value="other">Other</option>
                                        </select>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="space-y-2">
                                    <label class="block text-slate-900 font-medium">Credit Card Type *</label>
                                    <select name="creditCardType" class="form-input" required>
                                        <option value="">Select credit card type</option>
                                        <option value="basic">Basic Card</option>
                                        <option value="gold">Gold Card</option>
                                        <option value="platinum">Platinum Card</option>
                                        <option value="premium">Premium Card</option>
                                        <option value="cashback">Cashback Card</option>
                                        <option value="rewards">Rewards Card</option>
                                        <option value="travel">Travel Card</option>
                                    </select>
                                </div>
                            <?php endif; ?>

                            <div class="space-y-4 pt-6 border-t border-slate-200">
                                <div class="flex items-start space-x-3">
                                    <input type="checkbox" name="termsAccepted" class="mt-1 rounded" required />
                                    <div class="space-y-1">
                                        <label class="text-sm font-medium">I accept the terms and conditions *</label>
                                        <p class="text-xs text-slate-600">
                                            By checking this box, you agree to our terms of service and privacy policy.
                                        </p>
                                    </div>
                                </div>

                                <div class="flex items-start space-x-3">
                                    <input type="checkbox" name="dataProcessingConsent" class="mt-1 rounded" required />
                                    <div class="space-y-1">
                                        <label class="text-sm font-medium">I consent to data processing *</label>
                                        <p class="text-xs text-slate-600">
                                            I agree to the processing of my personal data for loan/credit card application purposes.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex items-center justify-between pt-6 border-t border-slate-200">
                        <div class="flex items-center space-x-2 text-sm text-slate-600">
                            <i class="fas fa-exclamation-circle"></i>
                            <span>All fields marked with * are required</span>
                        </div>
                        <button type="submit" class="btn-primary">Submit Application</button>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </main>

    <script src="../assets/js/main.js"></script>
    <script>
        function selectProduct(productId) {
            window.location.href = 'apply.php?product=' + productId;
        }
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>