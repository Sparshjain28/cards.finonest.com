<?php
            $require_auth = true;
            include_once('../config/database_updated.php');
            include_once('../includes/auth.php');
            $database = new Database();
            $conn = $database->getConnection();
            if (!$conn) {
                die("Database connection failed: " . mysqli_connect_error());
            }
            // Fetch only credit card products, including variant
            $products = [];
            $stmt = $conn->prepare("SELECT id, name, variant, commission_rate, card_image, variant_image, product_highlights, payout_source, pin_codes, category FROM products WHERE category = 'Credit Card' AND status = 'active'");
            if ($stmt) {
                $stmt->execute();
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()) {
                    // Get previous payout from timeline - check any timeline record first
                    $timeline_stmt = $conn->prepare("SELECT old_values, changed_fields, payout FROM product_timeline WHERE product_id = ? ORDER BY created_at DESC LIMIT 1");
                    $timeline_stmt->bind_param('i', $row['id']);
                    $timeline_stmt->execute();
                    $timeline_result = $timeline_stmt->get_result();
                    $timeline_row = $timeline_result->fetch_assoc();
                    if ($timeline_row && !empty($timeline_row['changed_fields']) && strpos($timeline_row['changed_fields'], 'commission_rate') !== false) {
                        $fields = explode(',', $timeline_row['changed_fields']);
                        $values = explode('|', $timeline_row['old_values']);
                        $commission_index = array_search('commission_rate', $fields);
                        $row['old_payout'] = ($commission_index !== false && isset($values[$commission_index])) ? floatval($values[$commission_index]) : null;
                    } elseif ($timeline_row && !empty($timeline_row['payout'])) {
                        // Fallback to payout field if old_values not available
                        $row['old_payout'] = floatval($timeline_row['payout']);
                    } else {
                        $row['old_payout'] = null;
                    }
                    $timeline_stmt->close();
                    $products[] = $row;
                }
                $stmt->close();
            }
            // Handle tracking code from URL to auto-select product
            $auto_select_product = null;
            if (isset($_GET['product']) && !empty($_GET['product'])) {
                $tracking_code = $_GET['product'];
                $tracking_stmt = $conn->prepare("SELECT product_id FROM advisor_products WHERE tracking_code = ? LIMIT 1");
                $tracking_stmt->bind_param("s", $tracking_code);
                $tracking_stmt->execute();
                $tracking_result = $tracking_stmt->get_result();
                if ($tracking_result->num_rows > 0) {
                    $tracking_row = $tracking_result->fetch_assoc();
                    $auto_select_product = $tracking_row['product_id'];
                }
                $tracking_stmt->close();
            }

            // Get user_type and referral info from DB if logged in
            $user_type = '';
            $is_admin = 0;
            $is_referred_user = false;
            $team_leader_payouts = [];
            if (isset($_SESSION['user_id'])) {
                $uid = $_SESSION['user_id'];
                $stmt = $conn->prepare("SELECT user_type, is_admin, partner_type FROM users WHERE id = ? LIMIT 1");
                $stmt->bind_param("i", $uid);
                $stmt->execute();
                $stmt->bind_result($utype, $adminFlag, $partnerType);
                if ($stmt->fetch()) {
                    $user_type = $utype;
                    $is_admin = $adminFlag;
                }
                $stmt->close();
                
                // Check if user is referred by someone (has a referrer)
                $referral_check = $conn->prepare("SELECT COUNT(*) FROM referral_users WHERE referred_user_id = ?");
                $referral_check->bind_param("i", $uid);
                $referral_check->execute();
                $referral_check->bind_result($referral_count);
                $referral_check->fetch();
                $is_referred_user = ($referral_count > 0);
                $referral_check->close();
                
                // If user is referred, get team leader set payouts from payout_settings
                if ($is_referred_user) {
                    $payout_stmt = $conn->prepare("SELECT product_id, payout_rate FROM payout_settings WHERE advisor_user_id = ?");
                    $payout_stmt->bind_param("i", $uid);
                    $payout_stmt->execute();
                    $payout_result = $payout_stmt->get_result();
                    while ($payout_row = $payout_result->fetch_assoc()) {
                        $team_leader_payouts[$payout_row['product_id']] = $payout_row['payout_rate'];
                    }
                    $payout_stmt->close();
                    
                    // Set default rates for products without custom rates
                    foreach ($products as &$product) {
                        if (!isset($team_leader_payouts[$product['id']])) {
                            // Set default rate based on category
                            $team_leader_payouts[$product['id']] = ($product['category'] === 'Credit Card') ? 500 : 1.00;
                        }
                    }
                }
            }
            ?>
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Apply for Financial Products - Fino Cards</title>
                <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
                <link rel="stylesheet" href="../assets/css/image-cropper.css">
                <style>
                    /* Custom scrollbar styles */
                    .scrollbar-thin::-webkit-scrollbar {
                        height: 6px;
                        width: 6px;
                    }
                    .scrollbar-thin::-webkit-scrollbar-track {
                        background: #f1f5f9;
                        border-radius: 3px;
                    }
                    .scrollbar-thin::-webkit-scrollbar-thumb {
                        background: #cbd5e1;
                        border-radius: 3px;
                    }
                    .scrollbar-thin::-webkit-scrollbar-thumb:hover {
                        background: #94a3b8;
                    }
                    /* Hide scrollbar for Firefox */
                    .scrollbar-thin {
                        scrollbar-width: thin;
                        scrollbar-color: #cbd5e1 #f1f5f9;
                    }
                    /* Gradient fade effect */
                    .fade-right {
                        background: linear-gradient(to right, transparent, white);
                    }
                    /* Enhanced button hover effects */
                    .lender-btn:hover {
                        transform: translateY(-2px);
                        box-shadow: 0 8px 25px rgba(59, 130, 246, 0.15);
                    }
                    .lender-btn {
                        transition: all 0.2s ease-in-out;
                        width: 40px;
                        height: 40px;
                        border-radius: 50%;
                        overflow: hidden;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }
                    /* Circular images for lender logos */
                    .lender-logo-circle {
                        width: 48px;
                        height: 48px;
                        border-radius: 50%;
                        object-fit: contain;
                        padding: 4px;
                        background: white;
                        border: 1px solid #e2e8f0;
                        transition: all 0.2s ease;
                        display: block;
                    }
                    .lender-badge {
                        position: absolute;
                        top: -2px;
                        right: -2px;
                        background: #1e293b;
                        color: white;
                        font-size: 10px;
                        font-weight: 700;
                        padding: 2px 5px;
                        border-radius: 8px;
                        min-width: 18px;
                        text-align: center;
                        border: 1.5px solid white;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    }
                    .lender-btn:hover .lender-logo-circle {
                        transform: translateY(-2px);
                        border-color: #3b82f6;
                        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
                    }
                    .active-lender .lender-logo-circle {
                        border-color: #3b82f6;
                        background-color: #eff6ff;
                        border-width: 2px;
                    }
                    .lender-card.selected {
                    background-color: #eff6ff;
                    border-width: 2px;
                }

                /* Mobile Modal Styles */
                @media (max-width: 768px) {
                    #pincodeModal[open] .wrapper {
                        transform: translateY(0);
                    }
                    
                    #pincodeModal .wrapper {
                        transform: translateY(100%);
                    }
                }
                </style>
            </head>
            <body class="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
                <?php include '../includes/header.php'; ?>
                <div class="container mx-auto px-4 py-8">
                    <!-- Pincode Search Bar -->
                    <div class="max-w-md mx-auto mb-6">
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-search text-gray-400"></i>
                            </div>
                            <input type="text" id="pincodeSearch" placeholder="Enter pincode to filter" 
                                class="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                                maxlength="6" pattern="[0-9]{6}" oninput="filterByPincode(this.value)">
                            <button type="button" id="clearPincode" onclick="clearPincodeFilter()" 
                                class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 hidden">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <?php if (isset($_GET['error'])): ?>
                    <div class="max-w-2xl mx-auto mb-4">
                        <?php if ($_GET['error'] === 'duplicate'): ?>
                        <div class="bg-red-50 border border-red-200 text-red-800 p-3 rounded-lg flex items-center gap-2">
                            <i class="fas fa-exclamation-triangle"></i>
                            <span><?php echo htmlspecialchars(urldecode($_GET['message'] ?? 'You have already applied for this product recently. Please wait 7 days before applying for the same product again or contact support.')); ?></span>
                        </div>
                        <?php elseif ($_GET['error'] === 'database'): ?>
                        <div class="bg-yellow-50 border border-yellow-200 text-yellow-800 p-3 rounded-lg flex items-center gap-2">
                            <i class="fas fa-info-circle"></i>
                            <span>Unable to connect to database. Please try again later or contact support.</span>
                        </div>
                        <?php elseif ($_GET['error'] === 'submission'): ?>
                        <div class="bg-yellow-50 border border-yellow-200 text-yellow-800 p-3 rounded-lg flex items-center gap-2">
                            <i class="fas fa-info-circle"></i>
                            <span><?php echo htmlspecialchars(urldecode($_GET['message'] ?? 'There was a problem submitting your application. Please try again.')); ?></span>
                        </div>
                        <?php elseif ($_GET['error'] === 'validation'): ?>
                        <div class="bg-yellow-50 border border-yellow-200 text-yellow-800 p-3 rounded-lg flex items-center gap-2">
                            <i class="fas fa-info-circle"></i>
                            <span><?php echo htmlspecialchars(urldecode($_GET['message'] ?? 'Please check your input and try again.')); ?></span>
                        </div>
                        <?php else: ?>
                        <div class="bg-yellow-50 border border-yellow-200 text-yellow-800 p-3 rounded-lg flex items-center gap-2">
                            <i class="fas fa-info-circle"></i>
                            <span>Something went wrong. Please try again.</span>
                        </div>
                        <?php endif; ?>
                    </div>

                    <?php endif; ?>
                    <!-- Product Selection -->
                    <div class="max-w-4xl mx-auto mb-8">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6" id="productGrid">
                            <?php foreach ($products as $product): ?>
                            <div class="bg-white rounded-xl shadow-md p-4 flex flex-row items-stretch hover:bg-blue-50 transition cursor-pointer gap-4 min-h-[264px]"
                                onclick="window.open('apply_form.php?product_id=<?php echo $product['id']; ?>&product_name=<?php echo urlencode($product['name']); ?>', '_self')">
                                <div class="flex-shrink-0 flex flex-col items-center justify-center w-32 rounded-lg overflow-hidden p-0 m-0">
                                    <?php if (!empty($product['card_image'])): ?>
                                        <img src="../assets/<?php echo htmlspecialchars($product['card_image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="object-contain rounded-lg shadow w-full h-full mb-1 max-h-32" loading="lazy">
                                    <?php else: ?>
                                        <i class="fas fa-credit-card text-blue-600 text-3xl mb-1"></i>
                                    <?php endif; ?>
                                    <?php if ((($user_type === 'dsa') || ($is_admin == 1)) && !empty($product['commission_rate'])): ?>
                                        <div class="text-center mt-1" style="visibility: visible !important; opacity: 1 !important;">
                                            <?php if ($is_referred_user && isset($team_leader_payouts[$product['id']])): ?>
                                                <?php 
                                                $is_default_rate = false;
                                                // Check if this is a default rate
                                                $check_custom = $conn->prepare("SELECT id FROM payout_settings WHERE advisor_user_id = ? AND product_id = ?");
                                                $check_custom->bind_param("ii", $uid, $product['id']);
                                                $check_custom->execute();
                                                $custom_exists = $check_custom->get_result()->num_rows > 0;
                                                $check_custom->close();
                                                $is_default_rate = !$custom_exists;
                                                ?>
                                                <span class="font-semibold text-green-700 text-xs block">Payout: ₹<?php echo number_format($team_leader_payouts[$product['id']], 2); ?></span>
                                                <?php if ($is_default_rate): ?>
                                                    <span class="text-yellow-600 text-xs block">Default Rate</span>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php if ($product['old_payout'] !== null && $product['old_payout'] != $product['commission_rate']): ?>
                                                    <span class="font-semibold text-red-600 text-xs block line-through">Old: ₹<?php echo number_format($product['old_payout'], 2); ?></span>
                                                <?php endif; ?>
                                                <span class="font-semibold text-green-700 text-xs block">Current: ₹<?php echo number_format($product['commission_rate'], 2); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="flex flex-col justify-between flex-1 min-w-0 h-full">
                                    <div class="flex flex-col h-full">
                                        <?php if (!empty($product['variant'])): ?>
                                        <span class="font-semibold text-blue-700 text-sm block mb-0 flex items-center gap-2">
                                            <?php if (!empty($product['variant_image'])): ?>
                                                <img src="../assets/<?php echo htmlspecialchars($product['variant_image']); ?>" alt="<?php echo htmlspecialchars($product['variant']); ?>" class="w-4 h-4 object-contain">
                                            <?php endif; ?>
                                            <?php echo htmlspecialchars($product['variant']); ?>
                                        </span>
                                        <?php endif; ?>
                                        <span class="font-bold text-lg text-slate-900 block mb-1"><?php echo htmlspecialchars($product['name']); ?></span>
                                        <?php if (!empty($product['product_highlights'])): ?>
                                        <ul class="text-xs text-slate-600 mb-1 list-disc list-inside pl-4">
                                            <?php foreach (explode("\n", $product['product_highlights']) as $highlight): ?>
                                                <?php if (trim($highlight) !== ''): ?><li><?php echo htmlspecialchars($highlight); ?></li><?php endif; ?>
                                            <?php endforeach; ?>
                                        </ul>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <?php if (empty($products)): ?>
                            <div class="col-span-2 text-center text-slate-500 py-8">No credit card products available at the moment.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- ...existing code... -->

                    <!-- Application Form & Card Details Side by Side -->
                    <div class="max-w-4xl mx-auto" id="applicationForm" style="display: none;">
                        <div class="bg-white rounded-lg shadow-lg p-0 flex flex-col md:flex-row">
                            <!-- Card Details -->
                            <div id="selectedCardDetails" class="w-full md:w-1/2 p-6 border-b md:border-b-0 md:border-r border-slate-100 flex flex-col items-center justify-center">
                                <!-- Card details will be injected here -->
                            </div>
                            <!-- Application Form -->
                            <div class="w-full md:w-1/2 p-6">
                                <div class="text-center mb-6">
                                    <h2 class="text-xl font-semibold text-slate-900" id="selectedProductName">Apply Now</h2>
                                    <p class="text-slate-600">Fill in your details to proceed</p>
                                </div>
                                <form action="submit.php" method="POST" id="leadForm" onsubmit="return validateForm()">
                                    <input type="hidden" name="product_id" id="productId" value="">
                                    <input type="hidden" name="product_url" id="productUrl" value="">
                                    <input type="hidden" name="Channel" id="Channel" value="">
                                    <input type="hidden" name="DSACode" id="DSACode" value="">
                                    <input type="hidden" name="SMCode" id="SMCode" value="">
                                    <input type="hidden" name="LGCode" id="LGCode" value="">
                                    <input type="hidden" name="LCCode" id="LCCode" value="">
                                    <input type="hidden" name="LC2" id="LC2" value="">
                                    <input type="hidden" name="tracking_code" id="trackingCode" value="<?= htmlspecialchars($_GET['product'] ?? '') ?>">
                                    <input type="hidden" name="ref" id="ref" value="<?= htmlspecialchars($_GET['ref'] ?? '') ?>">
                                    <div class="space-y-4">
                                        <div>
                                            <label class="block text-sm font-medium text-slate-700 mb-1">Full Name *</label>
                                            <input type="text" name="name" required 
                                                class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                                placeholder="Enter your full name">
                                        </div>
                                        <div>
                                            <label class="block text-sm font-medium text-slate-700 mb-1">Mobile Number *</label>
                                            <input type="tel" name="mobile" required pattern="[0-9]{10}"
                                                class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                                placeholder="Enter 10-digit mobile number">
                                        </div>
                                        <div>
                                            <label class="block text-sm font-medium text-slate-700 mb-1">Email Address *</label>
                                            <input type="email" name="email" required
                                                class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                                placeholder="Enter your email address">
                                        </div>
                                        <div class="flex items-start space-x-2">
                                                <input type="checkbox" id="terms" required class="mt-1">
                                                <label for="terms" class="text-sm text-slate-600">
                                                    I agree to the <a href="#" id="terms_link" class="text-blue-600">Terms & Conditions</a> and 
                                                    <a href="#" id="privacy_link" class="text-blue-600">Privacy Policy</a>
                                                </label>
                                        </div>
                                        <button type="submit" id="submitBtn"
                                                class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors font-medium">
                                            <span id="submitText">Submit Application</span>
                                            <span id="loadingText" class="hidden flex items-center justify-center">
                                                <div class="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                                Creating Lead...
                                            </span>
                                        </button>
                                    </div>
                                </form>
                                <div class="mt-4 text-center">
                                    <button onclick="history.back()" class="text-blue-600 hover:text-blue-800 text-sm">
                                        ← Back to Products
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                function getParam(name) {
                    const url = new URL(window.location.href);
                    return url.searchParams.get(name) || '';
                }
                function populateTrackingFields() {
                    ['Channel','DSACode','SMCode','LGCode','LCCode','LC2'].forEach(function(param) {
                        var el = document.getElementById(param);
                        if (el) el.value = getParam(param);
                    });
                }
                populateTrackingFields();

                // Card data for JS
                const cardData = <?php echo json_encode($products); ?>;
                console.log('Card data loaded:', cardData.length, 'products');
                console.log('Sample product with pin_codes:', cardData.find(p => p.pin_codes));
                const userType = <?php echo json_encode($user_type); ?>;
                const isAdmin = <?php echo json_encode($is_admin); ?>;
                const isReferredUser = <?php echo json_encode($is_referred_user); ?>;
                const teamLeaderPayouts = <?php echo json_encode($team_leader_payouts); ?>;
                const autoSelectProduct = <?php echo json_encode($auto_select_product); ?>;

                function showApplicationForm(productId, productName, productUrl) {
                    document.getElementById('productGrid').style.display = 'none';
                    document.getElementById('applicationForm').style.display = 'block';
                    document.getElementById('lendersSection').style.display = 'none';
                    document.getElementById('productId').value = productId;
                    document.getElementById('productUrl').value = productUrl;
                    // Find card details
                    const card = cardData.find(c => c.id == productId);
                    let displayName = productName;
                    if (card && card.variant) {
                        displayName = card.variant + ' - ' + card.name;
                    }
                    document.getElementById('selectedProductName').textContent = 'Apply for ' + displayName;
                    populateTrackingFields();
                    // Card details
                    let html = '';
                    if (card) {
                        html += `<div class='w-full flex flex-col items-center'>`;
                        if (card.card_image) {
                            html += `<img src="../assets/${card.card_image}" alt="${card.name}" class="object-contain rounded-lg shadow w-full h-auto" style="max-height:200px;aspect-ratio:16/9;background:transparent;padding:0;margin:0;display:block;">`;
                            html += `</div>`;
                        } else {
                            html += `<div class='w-40 h-24 flex items-center justify-center bg-slate-100 rounded-lg mb-3'><i class='fas fa-credit-card text-blue-600 text-3xl'></i></div>`;
                        }
                        if (card.variant) {
                            html += `<span class='font-semibold text-blue-700 text-sm mb-0 w-full flex items-center gap-2' style='text-align:justify;display:block;'>${card.variant_image ? `<img src="../assets/${card.variant_image}" alt="${card.variant}" class="w-4 h-4 object-contain">` : ''}${card.variant}`;
                            if ((userType === 'dsa' || isAdmin == 1) && card.commission_rate) {
                                if (isReferredUser && teamLeaderPayouts[card.id]) {
                                    html += `<span class='font-semibold text-green-700 text-xs ml-2 block'>Payout: ₹${parseFloat(teamLeaderPayouts[card.id]).toFixed(2)}</span>`;
                                } else {
                                    if (card.old_payout !== null && parseFloat(card.old_payout) != parseFloat(card.commission_rate)) {
                                        html += `<span class='font-semibold text-red-600 text-xs ml-2 block line-through'>Old: ₹${parseFloat(card.old_payout).toFixed(2)}</span>`;
                                    }
                                    html += `<span class='font-semibold text-green-700 text-xs ml-2 block'>Current: ₹${parseFloat(card.commission_rate).toFixed(2)}</span>`;
                                }
                            }
                            html += `</span>`;
                        }
                        html += `<span class='font-bold text-lg text-slate-900 mb-2 w-full' style='text-align:justify;display:block;'>${card.name}</span>`;
                        if (card.product_highlights) {
                            html += `<ul class='text-xs text-slate-600 mb-2 list-disc list-inside w-full' style='text-align:justify;padding-left:1.25rem;'>`;
                            card.product_highlights.split('\n').forEach(h => {
                                if (h.trim() !== '') html += `<li style='width:100%;text-align:justify;'>${h}</li>`;
                            });
                            html += `</ul>`;
                        }
                        html += `</div>`;
                    }
                    document.getElementById('selectedCardDetails').innerHTML = html;
                }
                function showProducts() {
                    document.getElementById('productGrid').style.display = 'grid';
                    document.getElementById('applicationForm').style.display = 'none';
                    document.getElementById('lendersSection').style.display = 'block';
                }
                
                function loadLenders() {
                    console.log('Loading lenders...');
                    fetch('get_lenders.php?pincode=000000')
                        .then(response => {
                            console.log('Response received:', response);
                            return response.json();
                        })
                        .then(data => {
                            console.log('Data received:', data);
                            if (data.success && data.lenders) {
                                const lendersList = document.getElementById('lendersList');
                                if (!lendersList) {
                                    console.error('lendersList element not found');
                                    return;
                                }
                                lendersList.innerHTML = '';
                                
                                // Remove duplicates by name
                                const uniqueLenders = data.lenders.filter((lender, index, self) => 
                                    index === self.findIndex(l => l.name === lender.name)
                                );
                                
                                uniqueLenders.forEach(lender => {
                                    // Use variant_image if available, otherwise fallback to lender.image or placeholder
                                    const lenderProduct = cardData.find(p => p.variant === lender.name);
                                    const logoUrl = lenderProduct && lenderProduct.variant_image ? 
                                        `../${lenderProduct.variant_image}` : 
                                        (lender.image && lender.image.trim() ? `../${lender.image}` : getLenderLogo(lender.name));
                                    
                                    lendersList.innerHTML += `
                                        <button type="button" onclick="filterByLender('${lender.name.replace(/'/g, '\\\'')}')" 
                                                class="lender-btn relative group flex items-center justify-center p-0 transition-all duration-200 flex-shrink-0 h-10" 
                                                title="${lender.name}">
                                            <img src="${logoUrl}" alt="${lender.name}" class="lender-logo-circle transition-transform group-hover:scale-110" loading="eager" onerror="this.src='${getLenderLogo(lender.name)}'; this.onerror=null;">
                                        </button>
                                    `;
                                });
                                
                                console.log('Lenders loaded successfully');
                            } else {
                                console.error('No lenders data or failed response:', data);
                            }
                        })
                        .catch(error => {
                            console.error('Error loading lenders:', error);
                        });
                }
                
                function openFilterModal() {
                    document.getElementById('filterModal').classList.remove('hidden');
                    setTimeout(() => {
                        document.getElementById('filterContent').style.transform = 'translateY(0)';
                    }, 10);
                    loadAllLenders();
                }
                
                // Filtering state
                let filterState = {
                    lender: null,
                    pincode: null
                };

                function applyFilters() {
                    let filtered = cardData;
                    
                    // Filter by lender
                    if (filterState.lender) {
                        filtered = filtered.filter(p => p.variant === filterState.lender);
                    }
                    
                    // Filter by pincode - only show products with the specific pincode
                    if (filterState.pincode) {
                        filtered = filtered.filter(p => {
                            console.log('Checking product:', p.name, 'pin_codes:', p.pin_codes, 'filter pincode:', filterState.pincode);
                            
                            // Skip products with no pin_codes, empty, or ALL - only show products with specific pincodes
                            if (!p.pin_codes || p.pin_codes.trim() === '' || p.pin_codes.toUpperCase().includes('ALL')) {
                                console.log('Product excluded - no pin_codes or ALL');
                                return false;
                            }
                            
                            // Check if the filter pincode is in the product's pin_codes
                            const codes = p.pin_codes.split(',').map(c => c.trim());
                            const matches = codes.includes(filterState.pincode);
                            console.log('Pin codes array:', codes, 'Matches:', matches);
                            return matches;
                        });
                    }
                    
                    updateProductGrid(filtered);
                    
                    // Update lenders list UI to show active lender
                    document.querySelectorAll('.lender-btn').forEach(btn => {
                        const lenderName = btn.getAttribute('data-lender');
                        if (filterState.lender && lenderName === filterState.lender) {
                            btn.classList.add('active-lender');
                        } else {
                            btn.classList.remove('active-lender');
                        }
                    });
                }

                function toggleFilterDropdown() {
                    const dropdown = document.getElementById('filterDropdown');
                    const icon = document.getElementById('dropdownIcon');
                    
                    if (dropdown.classList.contains('hidden')) {
                        dropdown.classList.remove('hidden');
                        icon.style.transform = 'rotate(180deg)';
                        loadDropdownLenders();
                    } else {
                        dropdown.classList.add('hidden');
                        icon.style.transform = 'rotate(0deg)';
                    }
                }
                
                function checkPincodeRealtime(val, source) {
                    if (val.length === 6 && /^[0-9]{6}$/.test(val)) {
                        // Trigger full check when 6 digits are reached
                        if (source === 'dropdown') {
                            checkPincodeDropdown(true); // pass true to keep open
                        } else if (source === 'modal') {
                            checkPincodeModalAuto(); // auto-check in modal
                        } else {
                            checkPincode(true); // pass true to keep open
                        }
                    } else if (val.length === 0) {
                        // Clear filter when input is empty
                        filterState.pincode = null;
                        if (source === 'modal') {
                            // Clear modal results
                            document.getElementById('modalBankGrid').innerHTML = '';
                        }
                        loadLenders();
                        applyFilters();
                    }
                }

                function checkPincodeDropdown(keepOpen = false) {
                    const pincode = document.getElementById('pincodeDropdown').value;
                    if (pincode && (pincode.length !== 6 || !/^[0-9]{6}$/.test(pincode))) {
                        if (!keepOpen) alert('Please enter a valid 6-digit pincode');
                        return;
                    }
                    console.log('Checking pincode:', pincode);
                    
                    filterState.pincode = pincode || null;
                    console.log('Filter state updated:', filterState);
                    
                    // 1. Refresh lender icons based on pincode
                    const searchPincode = pincode || '000000';
                    fetch(`get_lenders.php?pincode=${searchPincode}`)
                        .then(r => r.json())
                        .then(data => {
                            if (data.success) {
                                renderLenders(data.lenders, 'lendersList');
                                renderLenders(data.lenders, 'dropdownLendersList');
                            }
                        });

                    // 2. Apply combined filters
                    applyFilters();

                    if (!keepOpen) {
                        document.getElementById('filterDropdown').classList.add('hidden');
                        document.getElementById('dropdownIcon').style.transform = 'rotate(0deg)';
                    }
                }

                function renderLenders(lenders, containerId) {
                    const list = document.getElementById(containerId);
                    if (!list) return;
                    list.innerHTML = '';
                    
                    // Use the exact design from HTML
                    list.className = 'flex flex-wrap gap-4';
                    
                    lenders.forEach(lender => {
                        const lenderProduct = cardData.find(p => p.variant === lender.name);
                        const logoUrl = lenderProduct && lenderProduct.variant_image ? 
                            `../${lenderProduct.variant_image}` : 
                            (lender.image && lender.image.trim() ? `../${lender.image}` : getLenderLogo(lender.name));
                        
                        // Count cards for this lender (variant)
                        const cardCount = cardData.filter(p => p.variant === lender.name).length;
                        
                        // Check if lender has products available for the current pincode
                        const hasProductsForPincode = filterState.pincode && lenderProduct && lenderProduct.pin_codes && 
                            !lenderProduct.pin_codes.toUpperCase().includes('ALL') &&
                            lenderProduct.pin_codes.split(',').map(c => c.trim()).includes(filterState.pincode);
                        
                        // Create bank card matching HTML design
                        const bankCard = document.createElement('div');
                        
                        if (hasProductsForPincode) {
                            bankCard.className = 'bank-card active flex items-center gap-1 p-1 rounded-md border-2 border-blue-500 bg-blue-50 cursor-pointer transition-all duration-300 hover:shadow-lg';
                        } else {
                            bankCard.className = 'bank-card flex items-center gap-1 p-1 rounded-md border border-gray-200 bg-gray-50 cursor-pointer transition-all duration-300 hover:shadow-md';
                        }
                        
                        bankCard.setAttribute('data-lender', lender.name);
                        bankCard.onclick = () => selectLender(lender.name);
                        bankCard.style.width = '40px';
                        bankCard.style.height = '10px';
                        
                        // Bank logo circle - ultra tiny for reduced height
                        const bankLogo = document.createElement('div');
                        bankLogo.className = 'bank-logo w-3 h-3 rounded-full bg-gray-300 flex items-center justify-center font-bold text-gray-600 flex-shrink-0 text-xs';
                        
                        const logoImg = document.createElement('img');
                        logoImg.src = logoUrl;
                        logoImg.alt = lender.name;
                        logoImg.className = 'w-2 h-2 object-contain rounded-full';
                        logoImg.onerror = function() { 
                            this.style.display = 'none';
                            bankLogo.textContent = lender.name.substring(0, 2).toUpperCase();
                        };
                        
                        bankLogo.appendChild(logoImg);
                        
                        // Add tooltip for lender info since no space for text
                        bankCard.title = `${lender.name} - ${cardCount} cards`;
                        
                        bankCard.appendChild(bankLogo);
                        list.appendChild(bankCard);
                    });
                }
                
                function loadDropdownLenders() {
                    fetch('get_lenders.php?pincode=000000')
                        .then(response => response.json())
                        .then(data => {
                            if (data.success && data.lenders) {
                                const dropdownLendersList = document.getElementById('dropdownLendersList');
                                dropdownLendersList.innerHTML = '';
                                
                                const uniqueLenders = data.lenders.filter((lender, index, self) => 
                                    index === self.findIndex(l => l.name === lender.name)
                                );
                                
                                uniqueLenders.forEach(lender => {
                                    const lenderProduct = cardData.find(p => p.variant === lender.name);
                                    const logoUrl = lenderProduct && lenderProduct.variant_image ? 
                                        `../${lenderProduct.variant_image}` : 
                                        (lender.image && lender.image.trim() ? `../${lender.image}` : getLenderLogo(lender.name));
                                    
                                    const isActive = filterState.lender === lender.name;
                                    
                                    dropdownLendersList.innerHTML += `
                                        <button type="button" onclick="filterByLender('${lender.name.replace(/'/g, '\\\'')}'); toggleFilterDropdown();" 
                                                data-lender="${lender.name.replace(/'/g, '\\\'')}"
                                                class="lender-btn relative group ${isActive ? 'active-lender' : ''}" 
                                                title="${lender.name}">
                                            <img src="${logoUrl}" alt="${lender.name}" class="lender-logo-circle" loading="eager" onerror="this.src='${getLenderLogo(lender.name)}'; this.onerror=null;">
                                            <span class="lender-badge">${lender.count}</span>
                                        </button>
                                    `;
                                });
                            }
                        })
                        .catch(error => console.error('Error:', error));
                }
                
                // Close dropdown when clicking outside
                document.addEventListener('click', function(event) {
                    const dropdown = document.getElementById('filterDropdown');
                    const button = event.target.closest('button[onclick="toggleFilterDropdown()"]');
                    
                    if (!dropdown.contains(event.target) && !button) {
                        dropdown.classList.add('hidden');
                        document.getElementById('dropdownIcon').style.transform = 'rotate(0deg)';
                    }
                });
                
                function closeFilterModal() {
                    document.getElementById('filterContent').style.transform = 'translateY(-100%)';
                    setTimeout(() => {
                        document.getElementById('filterModal').classList.add('hidden');
                    }, 300);
                }
                
                window.filterByLender = function(lenderName) {
                    console.log('Filtering by lender:', lenderName);
                    // Toggle lender filter
                    if (filterState.lender === lenderName) {
                        filterState.lender = null;
                    } else {
                        filterState.lender = lenderName;
                    }
                    applyFilters();
                };
                
                function updateProductGrid(products) {
                    const productGrid = document.getElementById('productGrid');
                    productGrid.innerHTML = '';
                    
                    products.forEach(product => {
                        let payoutHtml = '';
                        if ((userType === 'dsa' || isAdmin == 1) && product.commission_rate) {
                            if (isReferredUser && teamLeaderPayouts[product.id]) {
                                payoutHtml = `<span class="font-semibold text-green-700 text-xs block">Payout: ₹${parseFloat(teamLeaderPayouts[product.id]).toFixed(2)}</span>`;
                            } else {
                                if (product.old_payout !== null && parseFloat(product.old_payout) != parseFloat(product.commission_rate)) {
                                    payoutHtml += `<span class="font-semibold text-red-600 text-xs block line-through">Old: ₹${parseFloat(product.old_payout).toFixed(2)}</span>`;
                                }
                                payoutHtml += `<span class="font-semibold text-green-700 text-xs block">Current: ₹${parseFloat(product.commission_rate).toFixed(2)}</span>`;
                            }
                        }
                        
                        let highlightsHtml = '';
                        if (product.product_highlights) {
                            highlightsHtml = '<ul class="text-xs text-slate-600 mb-1 list-disc list-inside pl-4">';
                            product.product_highlights.split('\n').forEach(highlight => {
                                if (highlight.trim() !== '') {
                                    highlightsHtml += `<li>${highlight}</li>`;
                                }
                            });
                            highlightsHtml += '</ul>';
                        }
                        
                        productGrid.innerHTML += `
                            <div class="bg-white rounded-xl shadow-md p-4 flex flex-row items-stretch hover:bg-blue-50 transition cursor-pointer gap-4 min-h-[264px]"
                                onclick="window.open('apply_form.php?product_id=${product.id}&product_name=${encodeURIComponent(product.name)}', '_blank')">
                                <div class="flex-shrink-0 flex flex-col items-center justify-center w-32 rounded-lg overflow-hidden p-0 m-0">
                                    ${product.card_image ? `<img src="${product.card_image.startsWith('http') ? product.card_image : '../' + product.card_image}" alt="${product.name}" class="object-cover rounded-lg shadow w-full h-full mb-1" loading="lazy">` : '<i class="fas fa-credit-card text-blue-600 text-3xl mb-1"></i>'}
                                    ${payoutHtml ? `<div class="text-center mt-1">${payoutHtml}</div>` : ''}
                                </div>
                                <div class="flex flex-col justify-between flex-1 min-w-0 h-full">
                                    <div class="flex flex-col h-full">
                                    ${product.variant ? `<span class="font-semibold text-blue-700 text-sm block mb-0 flex items-center gap-2">${product.variant_image ? `<img src="${product.variant_image.startsWith('http') ? product.variant_image : '../' + product.variant_image}" alt="${product.variant}" class="w-4 h-4 object-contain">` : ''}${product.variant}</span>` : ''}
                                        <span class="font-bold text-lg text-slate-900 block mb-1">${product.name}</span>
                                        ${highlightsHtml}
                                    </div>
                                </div>
                            </div>
                        `;
                    });
                    
                    if (products.length === 0) {
                        productGrid.innerHTML = '<div class="col-span-2 text-center text-slate-500 py-8">No products found for this lender.</div>';
                    }
                }
                
                function checkPincode(keepOpen = false) {
                    const pincode = document.getElementById('pincodeFilter').value;
                    if (pincode.length !== 6 || !/^[0-9]{6}$/.test(pincode)) {
                        if (!keepOpen) alert('Please enter a valid 6-digit pincode');
                        return;
                    }
                    
                    // Sync with dropdown input and trigger check
                    document.getElementById('pincodeDropdown').value = pincode;
                    checkPincodeDropdown(keepOpen);
                    if (!keepOpen) closeFilterModal();
                }
                
                function loadAllLenders() {
                    fetch('get_lenders.php?pincode=000000')
                        .then(response => response.json())
                        .then(data => {
                            if (data.success && data.lenders) {
                                const allLendersList = document.getElementById('allLendersList');
                                allLendersList.innerHTML = '';
                                
                                // Remove duplicates by name
                                const uniqueLenders = data.lenders.filter((lender, index, self) => 
                                    index === self.findIndex(l => l.name === lender.name)
                                );
                                
                                uniqueLenders.forEach(lender => {
                                    // Use variant_image if available for modal as well
                                    const lenderProduct = cardData.find(p => p.variant === lender.name);
                                    const logoUrl = lenderProduct && lenderProduct.variant_image ? 
                                        `../${lenderProduct.variant_image}` : 
                                        (lender.image && lender.image.trim() ? `../${lender.image}` : getLenderLogo(lender.name));
                                    
                                    const isActive = filterState.lender === lender.name;
                                    
                                    allLendersList.innerHTML += `
                                        <button type="button" onclick="filterByLender('${lender.name.replace(/'/g, '\\\'')}'); closeFilterModal();" 
                                                data-lender="${lender.name.replace(/'/g, '\\\'')}"
                                                class="lender-btn relative group ${isActive ? 'active-lender' : ''}" 
                                                title="${lender.name}">
                                            <img src="${logoUrl}" alt="${lender.name}" class="lender-logo-circle" loading="eager" onerror="this.src='${getLenderLogo(lender.name)}'; this.onerror=null;">
                                            <span class="lender-badge">${lender.count}</span>
                                        </button>
                                    `;
                                });
                            }
                        })
                        .catch(error => console.error('Error:', error));
                }
                
                function getLenderLogo(lenderName) {
                    // Use simple placeholder with first letter instead of external services
                    const firstLetter = lenderName.charAt(0).toUpperCase();
                    return `data:image/svg+xml;base64,${btoa(`<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><rect width="32" height="32" fill="#3B82F6" rx="4"/><text x="16" y="20" text-anchor="middle" fill="white" font-family="Arial" font-size="14" font-weight="bold">${firstLetter}</text></svg>`)}`;
                }
                
                // Load lenders on page load
                // loadLenders();
                
                // Add "Show All" button functionality
                window.showAllProducts = function() {
                    document.getElementById('pincodeDropdown').value = '';
                    document.getElementById('pincodeFilter').value = '';
                    document.getElementById('pincodeModalInput').value = '';
                    filterState.lender = null;
                    filterState.pincode = null;
                    
                    // Load all lenders in main section
                    loadLenders();
                    applyFilters();
                };

                // Auto-select product if tracking code is provided
                if (autoSelectProduct) {
                    const product = cardData.find(c => c.id == autoSelectProduct);
                    if (product) {
                        // Redirect to apply_form.php with the specific product
                        window.location.href = `apply_form.php?product_id=${product.id}&product_name=${encodeURIComponent(product.name)}&ref=${getParam('ref')}&product=${getParam('product')}`;
                    }
                }
                
                // Pincode filtering functions
                function filterByPincode(pincode) {
                    const clearBtn = document.getElementById('clearPincode');
                    const productGrid = document.getElementById('productGrid');
                    
                    console.log('Filtering by pincode:', pincode);
                    console.log('Available products:', cardData.length);
                    
                    if (pincode.length > 0) {
                        clearBtn.classList.remove('hidden');
                    } else {
                        clearBtn.classList.add('hidden');
                        displayFilteredProducts(cardData);
                        return;
                    }
                    
                    if (pincode.length === 6) {
                        const filteredProducts = cardData.filter(product => {
                            console.log('Checking product:', product.name, 'pin_codes:', product.pin_codes);
                            if (!product.pin_codes) return false;
                            if (product.pin_codes.toUpperCase().trim() === 'ALL') return true;
                            
                            // Split by comma and check if pincode exists
                            const pincodes = product.pin_codes.split(',').map(p => p.trim());
                            const hasMatch = pincodes.includes(pincode);
                            console.log('Pincodes array:', pincodes, 'Match for', pincode, ':', hasMatch);
                            return hasMatch;
                        });
                        
                        console.log('Filtered products:', filteredProducts.length);
                        displayFilteredProducts(filteredProducts);
                    }
                }
                
                function clearPincodeFilter() {
                    document.getElementById('pincodeSearch').value = '';
                    document.getElementById('clearPincode').classList.add('hidden');
                    displayFilteredProducts(cardData);
                }
                
                function displayFilteredProducts(products) {
                    const productGrid = document.getElementById('productGrid');
                    productGrid.innerHTML = '';
                    
                    if (products.length === 0) {
                        productGrid.innerHTML = '<div class="col-span-2 text-center text-slate-500 py-8">No products available for this pincode.</div>';
                        return;
                    }
                    
                    products.forEach(product => {
                        let payoutHtml = '';
                        if ((userType === 'dsa' || isAdmin == 1) && product.commission_rate) {
                            if (isReferredUser && teamLeaderPayouts[product.id]) {
                                payoutHtml = `<div class="text-center mt-1"><span class="font-semibold text-green-700 text-xs block">Payout: ₹${parseFloat(teamLeaderPayouts[product.id]).toFixed(2)}</span></div>`;
                            } else {
                                let payoutContent = '';
                                if (product.old_payout !== null && parseFloat(product.old_payout) != parseFloat(product.commission_rate)) {
                                    payoutContent += `<span class="font-semibold text-red-600 text-xs block line-through">Old: ₹${parseFloat(product.old_payout).toFixed(2)}</span>`;
                                }
                                payoutContent += `<span class="font-semibold text-green-700 text-xs block">Current: ₹${parseFloat(product.commission_rate).toFixed(2)}</span>`;
                                payoutHtml = `<div class="text-center mt-1">${payoutContent}</div>`;
                            }
                        }
                        
                        const highlightsHtml = product.product_highlights ? 
                            '<ul class="text-xs text-slate-600 mb-1 list-disc list-inside pl-4">' + 
                            product.product_highlights.split('\n').filter(h => h.trim()).map(h => `<li>${h}</li>`).join('') + 
                            '</ul>' : '';
                        
                        productGrid.innerHTML += `
                            <div class="bg-white rounded-xl shadow-md p-4 flex flex-row items-stretch hover:bg-blue-50 transition cursor-pointer gap-4 min-h-[264px]"
                                onclick="window.open('apply_form.php?product_id=${product.id}&product_name=${encodeURIComponent(product.name)}', '_self')">
                                <div class="flex-shrink-0 flex flex-col items-center justify-center w-32 rounded-lg overflow-hidden p-0 m-0">
                                    ${product.card_image ? `<img src="${product.card_image.startsWith('http') ? product.card_image : '../' + product.card_image}" alt="${product.name}" class="object-cover rounded-lg shadow w-full h-full mb-1" loading="lazy">` : '<i class="fas fa-credit-card text-blue-600 text-3xl mb-1"></i>'}
                                    ${payoutHtml}
                                </div>
                                <div class="flex flex-col justify-between flex-1 min-w-0 h-full">
                                    <div class="flex flex-col h-full">
                                        ${product.variant ? `<span class="font-semibold text-blue-700 text-sm block mb-0 flex items-center gap-2">${product.variant_image ? `<img src="${product.variant_image.startsWith('http') ? product.variant_image : '../' + product.variant_image}" alt="${product.variant}" class="w-4 h-4 object-contain">` : ''}${product.variant}</span>` : ''}
                                        <span class="font-bold text-lg text-slate-900 block mb-1">${product.name}</span>
                                        ${highlightsHtml}
                                    </div>
                                </div>
                            </div>
                        `;
                    });
                }
                
                function showAllProducts() {
                    displayFilteredProducts(cardData);
                }
                
                // Show all products on page load
                document.addEventListener('DOMContentLoaded', function() {
                    displayFilteredProducts(cardData);
                });
                </script>

                <dialog id="privacyModal" class="backdrop:bg-black backdrop:bg-opacity-50 bg-transparent p-0 max-w-4xl w-full max-h-[90vh] rounded-lg">
                    <div class="bg-white rounded-lg shadow-xl max-h-[90vh] flex flex-col">
                        <div class="p-6 border-b border-gray-200">
                            <h3 class="text-xl font-bold text-gray-900">Privacy Policy</h3>
                        </div>
                        <div class="flex-1 overflow-auto p-6">
                            <div id="privacyContent" class="prose prose-sm max-w-none text-gray-700 leading-relaxed">
                                <!-- Privacy content will be loaded here -->
                            </div>
                        </div>
                        <div class="p-6 border-t border-gray-200 flex justify-end">
                            <button type="button" onclick="document.getElementById('privacyModal').close();" 
                                    class="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors">
                                Close
                            </button>
                        </div>
                    </div>
                </dialog>

                <dialog id="termsModal" class="backdrop:bg-black backdrop:bg-opacity-50 bg-transparent p-0 max-w-4xl w-full max-h-[90vh] rounded-lg">
                    <div class="bg-white rounded-lg shadow-xl max-h-[90vh] flex flex-col">
                        <div class="p-6 border-b border-gray-200">
                            <h3 class="text-xl font-bold text-gray-900">Terms & Conditions</h3>
                        </div>
                        <div class="flex-1 overflow-auto p-6">
                            <div id="termsContent" class="prose prose-sm max-w-none text-gray-700 leading-relaxed">
                                <!-- Terms content will be loaded here -->
                            </div>
                        </div>
                        <div class="p-6 border-t border-gray-200 flex justify-end gap-3">
                            <button type="button" onclick="document.getElementById('termsModal').close();" 
                                    class="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors">
                                Close
                            </button>
                            <button id="agreeTermsBtn" 
                                    class="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition-colors font-medium">
                                I Agree
                            </button>
                        </div>
                    </div>
                </dialog>
                <script>
                // Privacy policy modal functionality
                document.getElementById('privacy_link').addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    fetch('get_privacy.php')
                        .then(r => r.json())
                        .then(data => {
                            if (data.success) {
                                document.getElementById('privacyContent').innerHTML = data.privacy || '<p>No privacy policy available.</p>';
                                document.getElementById('privacyModal').showModal();
                            } else {
                                alert('Privacy policy not available');
                            }
                        })
                        .catch(err => {
                            console.error(err);
                            alert('Failed to load privacy policy');
                        });
                });

                // Terms modal behavior for apply_card
                document.getElementById('terms_link').addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    const productId = document.getElementById('productId').value || (cardData.length ? cardData[0].id : '');
                    if (!productId) {
                        alert('Please select a product first to view Terms & Conditions.');
                        return;
                    }
                    // keep checkbox unchecked until user agrees
                    try { document.getElementById('terms').checked = false; } catch(err) {}
                    fetch('get_terms.php?product_id=' + encodeURIComponent(productId)).then(r => r.json()).then(data => {
                        if (data.success) {
                            document.getElementById('termsContent').innerHTML = data.terms || '<p>No terms available.</p>';
                            document.getElementById('termsModal').showModal();
                        } else {
                            alert('Terms not available');
                        }
                    }).catch(err => { console.error(err); alert('Failed to load terms'); });
                });
                // Intercept checkbox click to show modal
                const termsCheckbox = document.getElementById('terms');
                if (termsCheckbox) {
                    termsCheckbox.addEventListener('change', function(e) {
                        if (this.checked) {
                            this.checked = false;
                            const productId = document.getElementById('productId').value || (cardData.length ? cardData[0].id : '');
                            if (!productId) {
                                alert('Please select a product first to view Terms & Conditions.');
                                return;
                            }
                            fetch('get_terms.php?product_id=' + encodeURIComponent(productId)).then(r => r.json()).then(data => {
                                if (data.success) {
                                    document.getElementById('termsContent').innerHTML = data.terms || '<p>No terms available.</p>';
                                    document.getElementById('termsModal').showModal();
                                } else {
                                    alert('Terms not available');
                                }
                            }).catch(err => { console.error(err); alert('Failed to load terms'); });
                        }
                    });
                }
                document.getElementById('agreeTermsBtn').addEventListener('click', function() {
                    const productId = document.getElementById('productId').value || (cardData.length ? cardData[0].id : '');
                    // POST acceptance - no application id yet, so store in session server-side
                    fetch('accept_terms.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: 'product_id=' + encodeURIComponent(productId)
                    }).then(r => r.json()).then(resp => {
                        if (resp.success) {
                            document.getElementById('terms').checked = true;
                            document.getElementById('termsModal').close();
                        } else {
                            alert('Failed to record acceptance');
                        }
                    }).catch(err => { console.error(err); alert('Failed to record acceptance'); });
                });

                // Pincode Modal Functions
                function openPincodeModal() {
                    document.getElementById('pincodeModal').showModal();
                    // Load initial lenders
                    loadModalLenders();
                }

                function closePincodeModal() {
                    document.getElementById('pincodeModal').close();
                }

                function loadModalLenders() {
                    // Don't load any lenders initially - wait for pincode input
                    document.getElementById('modalBankGrid').innerHTML = '<div class="text-center text-gray-400 text-xs">Enter a pincode to see available lenders</div>';
                }

                function renderModalLenders(lenders) {
                    const grid = document.getElementById('modalBankGrid');
                    if (!grid) return;
                    grid.innerHTML = '';
                    
                    console.log('Rendering modal lenders:', lenders);
                    
                    lenders.forEach(lender => {
                        const lenderProduct = cardData.find(p => p.variant === lender.name);
                        
                        const logoUrl = lenderProduct && lenderProduct.variant_image ? 
                            `../${lenderProduct.variant_image}` : 
                            (lender.image && lender.image.trim() ? `../${lender.image}` : getLenderLogo(lender.name));
                        
                        // Count cards for this lender (variant)
                        const cardCount = cardData.filter(p => p.variant === lender.name).length;
                        
                        // Create bank item
                        const bankItem = document.createElement('div');
                        bankItem.className = 'bank flex gap-2 items-center p-2 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors';
                        bankItem.onclick = () => selectLender(lender.name);
                        
                        // Logo
                        const logo = document.createElement('div');
                        logo.className = 'logo w-10 h-10 rounded-lg bg-gray-300 flex items-center justify-center text-sm font-bold text-gray-600 flex-shrink-0';
                        
                        const logoImg = document.createElement('img');
                        logoImg.src = logoUrl;
                        logoImg.alt = lender.name;
                        logoImg.className = 'w-8 h-8 object-contain rounded';
                        logoImg.onerror = function() { 
                            this.style.display = 'none';
                            logo.textContent = lender.name.substring(0, 2).toUpperCase();
                        };
                        
                        logo.appendChild(logoImg);
                        
                        // Info
                        const info = document.createElement('div');
                        info.className = 'flex-1 min-w-0';
                        
                        const name = document.createElement('div');
                        name.className = 'bank-name text-sm font-semibold text-gray-800 truncate';
                        name.textContent = lender.name;
                        
                        const cards = document.createElement('div');
                        cards.className = 'cards text-xs text-red-500';
                        cards.textContent = cardCount === 1 ? '1 card' : `${cardCount} cards`;
                        
                        info.appendChild(name);
                        info.appendChild(cards);
                        
                        bankItem.appendChild(logo);
                        bankItem.appendChild(info);
                        grid.appendChild(bankItem);
                        
                        console.log('Added lender to modal:', lender.name);
                    });
                    
                    console.log('Modal grid now has', grid.children.length, 'items');
                }

                function checkPincodeModal() {
                    const pincode = document.getElementById('pincodeModalInput').value;
                    if (pincode.length !== 6 || !/^[0-9]{6}$/.test(pincode)) {
                        alert('Please enter a valid 6-digit pincode');
                        return;
                    }
                    
                    // Update filter state
                    filterState.pincode = pincode;
                    
                    // Fetch lenders for this pincode
                    fetch(`get_lenders.php?pincode=${pincode}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success && data.lenders) {
                                // Check if any lenders have products for this pincode
                                const availableLenders = data.lenders.filter(lender => {
                                    const lenderProduct = cardData.find(p => p.variant === lender.name);
                                    return lenderProduct && lenderProduct.pin_codes && 
                                        !lenderProduct.pin_codes.toUpperCase().includes('ALL') &&
                                        lenderProduct.pin_codes.split(',').map(c => c.trim()).includes(pincode);
                                });
                                
                                if (availableLenders.length === 0) {
                                    // No cards found for this location
                                    alert('No cards found for your location. Please try a different pincode.');
                                    return;
                                }
                                
                                renderModalLenders(availableLenders);
                            } else {
                                alert('No cards found for your location. Please try a different pincode.');
                            }
                        })
                        .catch(error => {
                            alert('Error checking pincode. Please try again.');
                        });
                    
                    // Apply filters to main grid
                    applyFilters();
                    
                    // Close modal after a delay
                    setTimeout(() => {
                        closePincodeModal();
                    }, 2000);
                }

                function checkPincodeModalAuto() {
                    const pincode = document.getElementById('pincodeModalInput').value;
                    if (pincode.length !== 6 || !/^[0-9]{6}$/.test(pincode)) {
                        return;
                    }
                    
                    // Update filter state
                    filterState.pincode = pincode;
                    
                    console.log('Checking pincode in modal:', pincode);
                    console.log('Available cardData:', cardData);
                    
                    // Filter cardData directly for products available for this pincode
                    const availableProducts = cardData.filter(product => {
                        // Skip products without pin_codes
                        if (!product.pin_codes || product.pin_codes.trim() === '') {
                            console.log(`Skipping ${product.name} - no pin_codes`);
                            return false;
                        }
                        
                        // Include products with 'ALL' pincode
                        if (product.pin_codes.toUpperCase().includes('ALL')) {
                            console.log(`Including ${product.name} - has ALL pincode`);
                            return true;
                        }
                        
                        // Check specific pincode match
                        const pincodes = product.pin_codes.split(',').map(c => c.trim());
                        const isAvailable = pincodes.includes(pincode);
                        
                        console.log(`Product ${product.name} (${product.variant}):`, {
                            pin_codes: product.pin_codes,
                            pincodes: pincodes,
                            isAvailable: isAvailable
                        });
                        
                        return isAvailable;
                    });
                    
                    console.log('Available products:', availableProducts);
                    
                    // Get unique lenders from available products
                    const uniqueLenders = [...new Set(availableProducts.map(p => p.variant))];
                    console.log('Unique lenders:', uniqueLenders);
                    
                    if (uniqueLenders.length === 0) {
                        // Show no results message in modal
                        document.getElementById('modalBankGrid').innerHTML = '<div class="text-center text-gray-500 text-xs col-span-3">No cards found for this pincode</div>';
                        return;
                    }
                    
                    // Create lender objects from unique variants
                    const lenderObjects = uniqueLenders.map(lenderName => ({
                        name: lenderName
                    }));
                    
                    console.log('Lender objects for modal:', lenderObjects);
                    
                    // Show available lenders in modal
                    renderModalLenders(lenderObjects);
                    
                    // Apply filters to main grid
                    applyFilters();
                }

                function filterByPincodeDirect(pincode) {
                    const grid = document.getElementById('lendersList');
                    const allCards = grid.querySelectorAll('.bank-card');
                    
                    if (pincode.trim() === '') {
                        // Show all lenders
                        allCards.forEach(card => card.style.display = 'flex');
                        filterState.pincode = null;
                        applyFilters();
                        return;
                    }
                    
                    // Only filter if valid 6-digit pincode
                    if (pincode.length !== 6 || !/^[0-9]{6}$/.test(pincode)) {
                        return;
                    }
                    
                    // Update filter state
                    filterState.pincode = pincode;
                    
                    // Filter cards based on pincode availability
                    allCards.forEach(card => {
                        const lenderName = card.getAttribute('data-lender');
                        const lenderProduct = cardData.find(p => p.variant === lenderName);
                        
                        const hasProductsForPincode = lenderProduct && lenderProduct.pin_codes && 
                            (lenderProduct.pin_codes.toUpperCase().includes('ALL') ||
                             lenderProduct.pin_codes.split(',').map(c => c.trim()).includes(pincode));
                        
                        if (hasProductsForPincode) {
                            card.style.display = 'flex';
                        } else {
                            card.style.display = 'none';
                        }
                    });
                    
                    // Apply filters to main product grid
                    applyFilters();
                }

                function clearPincodeSearch() {
                    document.getElementById('pincodeSearchInput').value = '';
                    filterByPincodeDirect('');
                }

                // Main section shows all lenders by default, modal shows pincode-specific ones
                
                // Form validation function
                function validateForm() {
                    const name = document.querySelector('input[name="name"]').value.trim();
                    const mobile = document.querySelector('input[name="mobile"]').value.trim();
                    const email = document.querySelector('input[name="email"]').value.trim();
                    const productId = document.getElementById('productId').value;
                    const terms = document.getElementById('terms').checked;
                    
                    if (!name || name.length < 2) {
                        alert('Please enter a valid name (at least 2 characters)');
                        return false;
                    }
                    
                    if (!mobile || !/^[0-9]{10}$/.test(mobile)) {
                        alert('Please enter a valid 10-digit mobile number');
                        return false;
                    }
                    
                    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                        alert('Please enter a valid email address');
                        return false;
                    }
                    
                    if (!productId || productId <= 0) {
                        alert('Please select a product first');
                        return false;
                    }
                    
                    if (!terms) {
                        alert('Please accept the Terms & Conditions to proceed');
                        return false;
                    }
                    
                    // Show loading animation
                    const submitBtn = document.getElementById('submitBtn');
                    const submitText = document.getElementById('submitText');
                    const loadingText = document.getElementById('loadingText');
                    
                    if (submitBtn && submitText && loadingText) {
                        submitBtn.disabled = true;
                        submitBtn.classList.add('opacity-75', 'cursor-not-allowed');
                        submitText.classList.add('hidden');
                        loadingText.classList.remove('hidden');
                    }
                    
                    return true;
                }
                </script>

                <?php include '../includes/footer.php'; ?>
                <script src="/assets/js/loading.js"></script>
</body>
            </html>



    <script src="/assets/js/loading.js"></script>
</body>
</html>
