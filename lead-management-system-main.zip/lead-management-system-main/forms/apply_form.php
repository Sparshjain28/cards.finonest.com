<?php
$require_auth = true;
include_once('../config/database_updated.php');
include_once('../includes/auth.php');

$database = new Database();
$conn = $database->getConnection();

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Get product details
$product_id = $_GET['product_id'] ?? '';
$product_name = $_GET['product_name'] ?? '';

if (empty($product_id)) {
    header('Location: apply_card.php');
    exit;
}

// Fetch product details
$stmt = $conn->prepare("SELECT id, name, variant, commission_rate, card_image, variant_image, product_highlights, category, payout_source FROM products WHERE id = ? AND status = 'active'");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();
$stmt->close();

if (!$product) {
    header('Location: apply_card.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for <?php echo htmlspecialchars($product['name']); ?> - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mx-auto px-4 py-8">
        <div class="mb-4">
            <button onclick="history.back()" class="text-blue-600 hover:text-blue-800 text-sm flex items-center gap-1">
                <i class="fas fa-arrow-left"></i> Back to Products
            </button>
        </div>
        
        <div class="max-w-4xl mx-auto">
            <div class="bg-white rounded-lg shadow-lg p-0 flex flex-col md:flex-row">
                <!-- Card Details -->
                <div class="w-full md:w-1/2 p-6 border-b md:border-b-0 md:border-r border-slate-100 flex flex-col items-center justify-center">
                    <div class='w-full flex flex-col items-center'>
                        <?php if (!empty($product['card_image'])): ?>
                            <?php 
                            $card_image_src = $product['card_image'];
                            if (!preg_match('/^https?:\/\//i', $card_image_src)) {
                                    $card_image_src = '../' . ltrim($card_image_src, '/');
                            }
                            ?>
                            <div class='w-full flex justify-center items-center mb-0 p-0' style="background:#f8fafc;border-radius:1rem;width:100%;max-height:220px;">
                                <img src="<?php echo htmlspecialchars($card_image_src); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="object-contain rounded-lg shadow w-full h-auto" style="max-height:200px;aspect-ratio:16/9;background:transparent;padding:0;margin:0;display:block;">
                            </div>
                        <?php else: ?>
                            <div class='w-40 h-24 flex items-center justify-center bg-slate-100 rounded-lg mb-3'>
                                <i class='fas fa-credit-card text-blue-600 text-3xl'></i>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($product['variant'])): ?>
                            <span class='font-semibold text-blue-700 text-sm mb-0 w-full flex items-center gap-2' style='text-align:justify;display:block;'>
                                <?php if (!empty($product['variant_image'])): ?>
                                    <?php 
                                    $variant_image_src = $product['variant_image'];
                                    if (!preg_match('/^https?:\/\//i', $variant_image_src)) {
                                        $variant_image_src = '../' . ltrim($variant_image_src, '/');
                                    }
                                    ?>
                                    <img src="<?php echo htmlspecialchars($variant_image_src); ?>" alt="<?php echo htmlspecialchars($product['variant']); ?>" class="w-4 h-4 object-contain">
                                <?php endif; ?>
                                <?php echo htmlspecialchars($product['variant']); ?>
                            </span>
                        <?php endif; ?>
                        
                        <span class='font-bold text-lg text-slate-900 mb-2 w-full' style='text-align:justify;display:block;'>
                            <?php echo htmlspecialchars($product['name']); ?>
                        </span>
                        
                        <?php if (!empty($product['product_highlights'])): ?>
                            <ul class='text-xs text-slate-600 mb-2 list-disc list-inside w-full' style='text-align:justify;padding-left:1.25rem;'>
                                <?php foreach (explode("\n", $product['product_highlights']) as $highlight): ?>
                                    <?php if (trim($highlight) !== ''): ?>
                                        <li style='width:100%;text-align:justify;'><?php echo htmlspecialchars($highlight); ?></li>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Application Form -->
                <div class="w-full md:w-1/2 p-6">
                    <div class="text-center mb-6">
                        <h2 class="text-xl font-semibold text-slate-900">
                            Apply for <?php echo !empty($product['variant']) ? htmlspecialchars($product['variant']) . ' - ' : ''; ?><?php echo htmlspecialchars($product['name']); ?>
                        </h2>
                        <p class="text-slate-600">Fill in your details to proceed</p>
                    </div>
                    
                    <form action="submit.php" method="POST" id="leadForm" onsubmit="return validateForm()">
                        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product_id); ?>">
                        <input type="hidden" name="product_url" value="">
                        <input type="hidden" name="Channel" value="<?php echo htmlspecialchars($_GET['Channel'] ?? ''); ?>">
                        <input type="hidden" name="DSACode" value="<?php echo htmlspecialchars($_GET['DSACode'] ?? ''); ?>">
                        <input type="hidden" name="SMCode" value="<?php echo htmlspecialchars($_GET['SMCode'] ?? ''); ?>">
                        <input type="hidden" name="LGCode" value="<?php echo htmlspecialchars($_GET['LGCode'] ?? ''); ?>">
                        <input type="hidden" name="LCCode" value="<?php echo htmlspecialchars($_GET['LCCode'] ?? ''); ?>">
                        <input type="hidden" name="LC2" value="<?php echo htmlspecialchars($_GET['LC2'] ?? ''); ?>">
                        <input type="hidden" name="tracking_code" value="<?php echo htmlspecialchars($_GET['product'] ?? ''); ?>">
                        <input type="hidden" name="ref" value="<?php echo htmlspecialchars($_GET['ref'] ?? ''); ?>">
                        
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-1">Full Name *</label>
                                <input type="text" name="name" required 
                                    class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="Enter your full name">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-1">Mobile Number *</label>
                                <input type="tel" name="mobile" required pattern="[0-9]{10}"
                                    class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="Enter 10-digit mobile number">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-slate-700 mb-1">Email Address *</label>
                                <input type="email" name="email" required
                                    class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="Enter your email address">
                            </div>
                            
                            <div class="flex items-start space-x-2">
                                <input type="checkbox" id="terms" required class="mt-1">
                                <label for="terms" class="text-sm text-slate-600">
                                    I agree to the <a href="#" id="terms_link" class="text-blue-600">Terms & Conditions</a> and 
                                    <a href="#" id="privacy_link" class="text-blue-600">Privacy Policy</a>
                                </label>
                            </div>
                            
                            <button type="submit" id="submitBtn"
                                    class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors font-medium">
                                <span id="submitText">Submit Application</span>
                                <span id="loadingText" class="hidden flex items-center justify-center">
                                    <div class="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                    Creating Lead...
                                </span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Privacy Policy Modal -->
    <dialog id="privacyModal" class="fixed inset-0 z-50 backdrop:bg-black backdrop:bg-opacity-60 bg-transparent p-4 w-full h-full">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-4xl mx-auto my-8 max-h-[85vh] flex flex-col border border-gray-200">
            <div class="flex items-center justify-between p-6 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <svg class="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900">Privacy Policy</h3>
                </div>
                <button type="button" onclick="document.getElementById('privacyModal').close();" 
                        class="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors">
                    <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <div class="flex-1 overflow-auto p-6 bg-gray-50">
                <div id="privacyContent" class="prose prose-sm max-w-none text-gray-700 leading-relaxed bg-white p-6 rounded-lg shadow-sm">
                    <div class="flex items-center justify-center py-8">
                        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                        <span class="ml-3 text-gray-600">Loading privacy policy...</span>
                    </div>
                </div>
            </div>
            <div class="p-6 border-t border-gray-200 bg-white flex justify-end">
                <button type="button" onclick="document.getElementById('privacyModal').close();" 
                        class="px-6 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors font-medium">
                    Close
                </button>
            </div>
        </div>
    </dialog>

    <!-- Terms Modal -->
    <dialog id="termsModal" class="fixed inset-0 z-50 backdrop:bg-black backdrop:bg-opacity-60 bg-transparent p-4 w-full h-full">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-4xl mx-auto my-8 max-h-[85vh] flex flex-col border border-gray-200">
            <div class="flex items-center justify-between p-6 border-b border-gray-200 bg-gradient-to-r from-green-50 to-emerald-50">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900">Terms & Conditions</h3>
                </div>
                <button type="button" onclick="document.getElementById('termsModal').close();" 
                        class="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors">
                    <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <div class="flex-1 overflow-auto p-6 bg-gray-50">
                <div id="termsContent" class="prose prose-sm max-w-none text-gray-700 leading-relaxed bg-white p-6 rounded-lg shadow-sm">
                    <div class="flex items-center justify-center py-8">
                        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
                        <span class="ml-3 text-gray-600">Loading terms & conditions...</span>
                    </div>
                </div>
            </div>
            <div class="p-6 border-t border-gray-200 bg-white flex justify-between items-center">
                <p class="text-sm text-gray-600">Please read and accept the terms to continue</p>
                <div class="flex gap-3">
                    <button type="button" onclick="document.getElementById('termsModal').close();" 
                            class="px-6 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors font-medium">
                        Close
                    </button>
                    <button id="agreeTermsBtn" 
                            class="px-8 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors font-medium shadow-sm">
                        I Agree
                    </button>
                </div>
            </div>
        </div>
    </dialog>

    <script>
    // Privacy policy modal functionality
    document.getElementById('privacy_link').addEventListener('click', function(e) {
        e.preventDefault();
        
        const modal = document.getElementById('privacyModal');
        const content = document.getElementById('privacyContent');
        
        // Show loading state
        content.innerHTML = `
            <div class="flex items-center justify-center py-8">
                <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <span class="ml-3 text-gray-600">Loading privacy policy...</span>
            </div>
        `;
        
        modal.showModal();
        
        fetch('get_privacy.php')
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    content.innerHTML = data.privacy || '<div class="text-center py-8 text-gray-500"><p>No privacy policy available.</p></div>';
                } else {
                    content.innerHTML = '<div class="text-center py-8 text-red-500"><p>Failed to load privacy policy. Please try again.</p></div>';
                }
            })
            .catch(err => {
                console.error('Privacy policy load error:', err);
                content.innerHTML = '<div class="text-center py-8 text-red-500"><p>Failed to load privacy policy. Please check your connection and try again.</p></div>';
            });
    });

    // Terms modal functionality
    document.getElementById('terms_link').addEventListener('click', function(e) {
        e.preventDefault();
        
        const productId = <?php echo json_encode($product_id); ?>;
        if (!productId) {
            alert('Product information not available. Please try again.');
            return;
        }
        
        const modal = document.getElementById('termsModal');
        const content = document.getElementById('termsContent');
        const agreeBtn = document.getElementById('agreeTermsBtn');
        
        // Reset checkbox and disable agree button
        document.getElementById('terms').checked = false;
        agreeBtn.disabled = true;
        agreeBtn.classList.add('opacity-50', 'cursor-not-allowed');
        
        // Show loading state
        content.innerHTML = `
            <div class="flex items-center justify-center py-8">
                <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
                <span class="ml-3 text-gray-600">Loading terms & conditions...</span>
            </div>
        `;
        
        modal.showModal();
        
        fetch('get_terms.php?product_id=' + encodeURIComponent(productId))
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                if (data.success && data.terms) {
                    content.innerHTML = data.terms;
                    // Enable agree button
                    agreeBtn.disabled = false;
                    agreeBtn.classList.remove('opacity-50', 'cursor-not-allowed');
                } else {
                    content.innerHTML = `
                        <div class="text-center py-8 text-yellow-600">
                            <div class="mb-4">
                                <svg class="w-12 h-12 mx-auto text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
                                </svg>
                            </div>
                            <p class="font-medium">Terms & conditions not available for this product.</p>
                            <p class="text-sm mt-2">Please contact support for more information.</p>
                        </div>
                    `;
                }
            })
            .catch(err => {
                console.error('Terms load error:', err);
                content.innerHTML = `
                    <div class="text-center py-8 text-red-500">
                        <div class="mb-4">
                            <svg class="w-12 h-12 mx-auto text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </div>
                        <p class="font-medium">Failed to load terms & conditions.</p>
                        <p class="text-sm mt-2">Please check your connection and try again.</p>
                    </div>
                `;
            });
    });

    // Agree terms functionality
    document.getElementById('agreeTermsBtn').addEventListener('click', function() {
        const productId = <?php echo json_encode($product_id); ?>;
        if (!productId) {
            alert('Product information not available. Please try again.');
            return;
        }
        
        const btn = this;
        const originalText = btn.innerHTML;
        
        // Show loading state
        btn.disabled = true;
        btn.innerHTML = `
            <div class="flex items-center justify-center">
                <div class="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Accepting...
            </div>
        `;
        
        fetch('accept_terms.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'product_id=' + encodeURIComponent(productId)
        })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(resp => {
            if (resp.success) {
                document.getElementById('terms').checked = true;
                document.getElementById('termsModal').close();
                
                // Show success feedback
                const checkbox = document.getElementById('terms');
                checkbox.parentElement.classList.add('bg-green-50', 'border-green-200', 'rounded-md', 'p-2', 'transition-all');
                setTimeout(() => {
                    checkbox.parentElement.classList.remove('bg-green-50', 'border-green-200');
                }, 2000);
            } else {
                throw new Error('Failed to record acceptance');
            }
        })
        .catch(err => {
            console.error('Accept terms error:', err);
            alert('Failed to record acceptance. Please try again.');
        })
        .finally(() => {
            btn.disabled = false;
            btn.innerHTML = originalText;
        });
    });

    // Close modal on backdrop click
    document.getElementById('privacyModal').addEventListener('click', function(e) {
        if (e.target === this) {
            this.close();
        }
    });
    
    document.getElementById('termsModal').addEventListener('click', function(e) {
        if (e.target === this) {
            this.close();
        }
    });

    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.getElementById('privacyModal').close();
            document.getElementById('termsModal').close();
        }
    });
    
    // Form submission loading animation
    document.getElementById('leadForm').addEventListener('submit', function(e) {
        const submitBtn = document.getElementById('submitBtn');
        const submitText = document.getElementById('submitText');
        const loadingText = document.getElementById('loadingText');
        
        // Show loading state
        submitBtn.disabled = true;
        submitBtn.classList.add('opacity-75', 'cursor-not-allowed');
        submitText.classList.add('hidden');
        loadingText.classList.remove('hidden');
    });
    </script>

    <link rel="stylesheet" href="../assets/css/modal-styles.css">
    <?php include '../includes/footer.php'; ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>