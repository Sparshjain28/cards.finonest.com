<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';
$database = new Database();
$conn = $database->getConnection();
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
// Fetch only personal loan products
$products = [];
$stmt = $conn->prepare("SELECT id, name, variant, commission_rate, card_image, product_highlights, payout_source FROM products WHERE category = 'Personal Loan' AND status = 'active'");
if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        // Get previous payout from timeline - check any timeline record first
        $timeline_stmt = $conn->prepare("SELECT old_values, changed_fields, payout FROM product_timeline WHERE product_id = ? ORDER BY created_at DESC LIMIT 1");
        $timeline_stmt->bind_param('i', $row['id']);
        $timeline_stmt->execute();
        $timeline_result = $timeline_stmt->get_result();
        $timeline_row = $timeline_result->fetch_assoc();
        if ($timeline_row && !empty($timeline_row['changed_fields']) && strpos($timeline_row['changed_fields'], 'commission_rate') !== false) {
            $fields = explode(',', $timeline_row['changed_fields']);
            $values = explode('|', $timeline_row['old_values']);
            $commission_index = array_search('commission_rate', $fields);
            $row['old_payout'] = ($commission_index !== false && isset($values[$commission_index])) ? floatval($values[$commission_index]) : null;
        } elseif ($timeline_row && !empty($timeline_row['payout'])) {
            // Fallback to payout field if old_values not available
            $row['old_payout'] = floatval($timeline_row['payout']);
        } else {
            $row['old_payout'] = null;
        }
        $timeline_stmt->close();
        $products[] = $row;
    }
    $stmt->close();
}
// Handle tracking code from URL to auto-select product
$auto_select_product = null;
if (isset($_GET['product']) && !empty($_GET['product'])) {
    $tracking_code = $_GET['product'];
    $tracking_stmt = $conn->prepare("SELECT product_id FROM advisor_products WHERE tracking_code = ? LIMIT 1");
    $tracking_stmt->bind_param("s", $tracking_code);
    $tracking_stmt->execute();
    $tracking_result = $tracking_stmt->get_result();
    if ($tracking_result->num_rows > 0) {
        $tracking_row = $tracking_result->fetch_assoc();
        $auto_select_product = $tracking_row['product_id'];
    }
    $tracking_stmt->close();
}

// Get user_type and referral info from DB if logged in
$user_type = '';
$is_admin = 0;
$is_referred_user = false;
$team_leader_payouts = [];
if (isset($_SESSION['user_id'])) {
    $uid = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT user_type, is_admin, partner_type FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $stmt->bind_result($utype, $adminFlag, $partnerType);
    if ($stmt->fetch()) {
        $user_type = $utype;
        $is_admin = $adminFlag;
    }
    $stmt->close();
    
    // Check if user is referred by someone (has a referrer)
    $referral_check = $conn->prepare("SELECT COUNT(*) FROM referral_users WHERE referred_user_id = ?");
    $referral_check->bind_param("i", $uid);
    $referral_check->execute();
    $referral_check->bind_result($referral_count);
    $referral_check->fetch();
    $is_referred_user = ($referral_count > 0);
    $referral_check->close();
    
    // If user is referred, get team leader set payouts from payout_settings
    if ($is_referred_user) {
        $payout_stmt = $conn->prepare("SELECT product_id, payout_rate FROM payout_settings WHERE advisor_user_id = ?");
        $payout_stmt->bind_param("i", $uid);
        $payout_stmt->execute();
        $payout_result = $payout_stmt->get_result();
        while ($payout_row = $payout_result->fetch_assoc()) {
            $team_leader_payouts[$payout_row['product_id']] = $payout_row['payout_rate'];
        }
        $payout_stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Personal Loan - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include __DIR__ . '/../includes/header.php'; ?>
        <div class="container mx-auto px-4 py-8">
            <div class="text-center mb-8">
                <div class="w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-money-bill-wave text-2xl text-white"></i>
                </div>
                <h1 class="text-3xl font-bold text-slate-900 mb-2">Apply for Personal Loan</h1>
                <p class="text-slate-600">Choose your loan product and get instant approval</p>
            </div>
            <?php if (isset($_GET['error']) && $_GET['error'] === 'duplicate'): ?>
            <div class="max-w-2xl mx-auto mb-4">
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-lg">
                    <strong>Error:</strong> An application already exists for this mobile/email. Please use different details or contact support.
                </div>
            </div>
            <?php endif; ?>
            <!-- Product Selection -->
            <div class="max-w-4xl mx-auto mb-8">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 w-full" id="productGrid">
                    <?php foreach ($products as $product): ?>
                    <div class="bg-white rounded-xl shadow-md p-4 flex flex-col sm:flex-row items-center sm:items-stretch hover:bg-blue-50 transition cursor-pointer w-full"
                        onclick="showApplicationForm('<?php echo $product['id']; ?>', '<?php echo htmlspecialchars($product['name']); ?>', '')">
                        <div class="flex-shrink-0 flex items-center justify-center w-full h-48 sm:h-full sm:w-32 rounded-lg overflow-hidden p-0 m-0">
                            <?php if (!empty($product['card_image'])): ?>
                                <img src="../<?php echo htmlspecialchars($product['card_image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="object-contain rounded-lg shadow h-full w-full" loading="lazy">
                            <?php else: ?>
                                <i class="fas fa-money-bill-wave text-blue-600 text-3xl"></i>
                            <?php endif; ?>
                        </div>
                        <div class="flex flex-col justify-between flex-1 min-w-0 h-full relative">
                            <div>
                                <?php if (!empty($product['variant'])): ?>
                                <span class="font-semibold text-blue-700 text-sm block mb-0 truncate">
                                    <?php echo htmlspecialchars($product['variant']); ?>
                                    <?php if ((($user_type === 'dsa') || ($is_admin == 1)) && !empty($product['commission_rate'])): ?>
                                        <?php if ($is_referred_user && isset($team_leader_payouts[$product['id']])): ?>
                                            <span class="font-semibold text-green-700 text-xs">Payout: ₹<?php echo number_format($team_leader_payouts[$product['id']], 2); ?></span>
                                        <?php elseif ($is_referred_user): ?>
                                            <span class="font-semibold text-green-700 text-xs">Payout: 1.00%</span>
                                        <?php else: ?>
                                            <?php if ($product['old_payout'] !== null && floatval($product['old_payout']) != floatval($product['commission_rate'])): ?>
                                                <span class="font-semibold text-red-600 text-xs line-through">Old: <?php echo number_format($product['old_payout'], 2); ?>%</span>
                                            <?php endif; ?>
                                            <span class="font-semibold text-green-700 text-xs">Current: <?php echo number_format($product['commission_rate'], 2); ?>%</span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </span>
                                <?php endif; ?>
                                <span class="font-bold text-lg text-slate-900 block mb-1 truncate"><?php echo htmlspecialchars($product['name']); ?></span>
                                <?php if (!empty($product['product_highlights'])): ?>
                                <ul class="text-xs text-slate-600 mb-1 list-disc list-inside pl-4">
                                    <?php foreach (explode("\n", $product['product_highlights']) as $highlight): ?>
                                        <?php if (trim($highlight) !== ''): ?><li><?php echo htmlspecialchars($highlight); ?></li><?php endif; ?>
                                    <?php endforeach; ?>
                                </ul>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php if (empty($products)): ?>
                    <div class="col-span-2 text-center text-slate-500 py-8">No personal loan products available at the moment.</div>
                    <?php endif; ?>
                </div>
            </div>
            <!-- Application Form & Product Details Side by Side -->
            <div class="max-w-4xl mx-auto" id="applicationForm" style="display: none;">
                <div class="bg-white rounded-xl shadow-md p-0 flex flex-col md:flex-row">
                    <!-- Product Details -->
                    <div id="selectedCardDetails" class="w-full md:w-1/2 p-6 border-b md:border-b-0 md:border-r border-slate-100 flex flex-col items-center justify-center">
                        <!-- Product details will be injected here -->
                    </div>
                    <!-- Application Form -->
                    <div class="w-full md:w-1/2 p-6">
                        <div class="text-center mb-6">
                            <h2 class="text-xl font-semibold text-slate-900" id="selectedProductName">Apply Now</h2>
                            <p class="text-slate-600">Fill in your details to proceed</p>
                        </div>
                        <form action="submit.php" method="POST" id="leadForm">
                            <input type="hidden" name="product_id" id="productId" value="">
                            <input type="hidden" name="product_url" id="productUrl" value="">
                            <input type="hidden" name="Channel" id="Channel" value="">
                            <input type="hidden" name="DSACode" id="DSACode" value="">
                            <input type="hidden" name="SMCode" id="SMCode" value="">
                            <input type="hidden" name="LGCode" id="LGCode" value="">
                            <input type="hidden" name="LCCode" id="LCCode" value="">
                            <input type="hidden" name="LC2" id="LC2" value="">
                            <input type="hidden" name="tracking_code" id="trackingCode" value="<?= htmlspecialchars($_GET['product'] ?? '') ?>">
                            <input type="hidden" name="ref" id="ref" value="<?= htmlspecialchars($_GET['ref'] ?? '') ?>">
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-1">Full Name *</label>
                                    <input type="text" name="name" required 
                                        class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                                        placeholder="Enter your full name">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-1">Mobile Number *</label>
                                    <input type="tel" name="mobile" required pattern="[0-9]{10}"
                                        class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                                        placeholder="Enter 10-digit mobile number">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-slate-700 mb-1">Email Address *</label>
                                    <input type="email" name="email" required
                                        class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                                        placeholder="Enter your email address">
                                </div>
                                <div class="flex items-start space-x-2">
                                    <input type="checkbox" id="terms" required class="mt-1">
                                        <label for="terms" class="text-sm text-slate-600">
                                            I agree to the <a href="#" id="terms_link" class="text-green-600">Terms & Conditions</a> and 
                                            <a href="#" class="text-green-600">Privacy Policy</a>
                                        </label>
                                </div>
                                <button type="submit" 
                                        class="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition-colors font-medium">
                                    Submit Application
                                </button>
                            </div>
                        </form>
                        <div class="mt-4 text-center">
                            <button onclick="showProducts()" class="text-green-600 hover:text-green-800 text-sm">
                                ← Back to Products
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
        function getParam(name) {
            const url = new URL(window.location.href);
            return url.searchParams.get(name) || '';
        }
        function populateTrackingFields() {
            ['Channel','DSACode','SMCode','LGCode','LCCode','LC2'].forEach(function(param) {
                var el = document.getElementById(param);
                if (el) el.value = getParam(param);
            });
        }
        populateTrackingFields();

        // Product data for JS
        const productData = <?php echo json_encode($products); ?>;
        const userType = <?php echo json_encode($user_type); ?>;
        const isAdmin = <?php echo json_encode($is_admin); ?>;
        const isReferredUser = <?php echo json_encode($is_referred_user); ?>;
        const teamLeaderPayouts = <?php echo json_encode($team_leader_payouts); ?>;
        const autoSelectProduct = <?php echo json_encode($auto_select_product); ?>;

        function showApplicationForm(productId, productName, productUrl) {
            document.getElementById('productGrid').style.display = 'none';
            document.getElementById('applicationForm').style.display = 'block';
            document.getElementById('productId').value = productId;
            document.getElementById('productUrl').value = productUrl;
            // Find product details
            const product = productData.find(c => c.id == productId);
            let displayName = productName;
            if (product && product.variant) {
                displayName = product.variant + ' - ' + product.name;
            }
            document.getElementById('selectedProductName').textContent = 'Apply for ' + displayName;
            populateTrackingFields();
            // Product details
            let html = '';
            if (product) {
                html += `<div class='w-full flex flex-col items-center'>`;
                if (product.card_image) {
                    html += `<div class='w-full flex justify-center items-center mb-0 p-0' style="background:#f8fafc;border-radius:1rem;width:100%;height:220px;">`;
                    html += `<img src="../${product.card_image}" alt="${product.name}" class="object-contain rounded-lg shadow" style="width:100%;height:200px;max-width:100%;max-height:200px;aspect-ratio:16/9;background:transparent;padding:0;margin:0;display:block;">`;
                    html += `</div>`;
                } else {
                    html += `<div class='w-40 h-24 flex items-center justify-center bg-slate-100 rounded-lg mb-3'><i class='fas fa-money-bill-wave text-green-600 text-3xl'></i></div>`;
                }
                if (product.variant) {
                    html += `<span class='font-semibold text-green-700 text-sm mb-0 w-full' style='text-align:justify;display:block;'>${product.variant}`;
                    if ((userType === 'dsa' || isAdmin == 1) && product.commission_rate) {
                        if (isReferredUser && teamLeaderPayouts[product.id]) {
                            html += `<span class='font-semibold text-green-700 text-sm ml-2'>Payout: ₹${parseFloat(teamLeaderPayouts[product.id]).toFixed(2)}</span>`;
                        } else if (isReferredUser) {
                            html += `<span class='font-semibold text-green-700 text-sm ml-2'>Payout: 1.00%</span>`;
                        } else {
                            if (product.old_payout !== null && parseFloat(product.old_payout) != parseFloat(product.commission_rate)) {
                                html += `<span class='font-semibold text-red-600 text-sm ml-2 line-through'>Old: ${parseFloat(product.old_payout).toFixed(2)}%</span>`;
                            }
                            html += `<span class='font-semibold text-green-700 text-sm ml-2'>Current: ${parseFloat(product.commission_rate).toFixed(2)}%</span>`;
                        }
                    }
                    html += `</span>`;
                }
                html += `<span class='font-bold text-lg text-slate-900 mb-2 w-full' style='text-align:justify;display:block;'>${product.name}</span>`;
                if (product.product_highlights) {
                    html += `<ul class='text-xs text-slate-600 mb-2 list-disc list-inside w-full' style='text-align:justify;padding-left:1.25rem;'>`;
                    product.product_highlights.split('\n').forEach(h => {
                        if (h.trim() !== '') html += `<li style='width:100%;text-align:justify;'>${h}</li>`;
                    });
                    html += `</ul>`;
                }
                // Show commission_rate as payout for DSA users or admin
                if ((userType === 'dsa' || isAdmin == 1) && product.commission_rate) {
                    html += `<div class='mt-4 w-full text-right'>`;
                    if (isReferredUser && teamLeaderPayouts[product.id]) {
                        html += `<span class='font-semibold text-green-700 text-base'>Payout: ₹${parseFloat(teamLeaderPayouts[product.id]).toFixed(2)}</span>`;
                    } else if (isReferredUser) {
                        html += `<span class='font-semibold text-green-700 text-base'>Payout: 1.00%</span>`;
                    } else {
                        if (product.old_payout !== null && parseFloat(product.old_payout) != parseFloat(product.commission_rate)) {
                            html += `<span class='font-semibold text-red-600 text-sm block line-through'>Old: ${parseFloat(product.old_payout).toFixed(2)}%</span>`;
                        }
                        html += `<span class='font-semibold text-green-700 text-base'>Current: ${parseFloat(product.commission_rate).toFixed(2)}%</span>`;
                    }
                    html += `</div>`;
                }
                // Do not expose payout source to normal users here
                html += `</div>`;
            }
            document.getElementById('selectedCardDetails').innerHTML = html;
        }
        function showProducts() {
            document.getElementById('productGrid').style.display = 'grid';
            document.getElementById('applicationForm').style.display = 'none';
        }

        // Auto-select product if tracking code is provided
        if (autoSelectProduct) {
            const product = productData.find(c => c.id == autoSelectProduct);
            if (product) {
                // Redirect to apply_form.php with the specific product
                window.location.href = `apply_form.php?product_id=${product.id}&product_name=${encodeURIComponent(product.name)}&ref=${getParam('ref')}&product=${getParam('product')}`;
            }
        }
        </script>
    <!-- Terms Modal -->
    <dialog id="termsModal" class="backdrop:bg-black backdrop:bg-opacity-50 bg-transparent p-0 max-w-4xl w-full max-h-[90vh] rounded-lg">
        <div class="bg-white rounded-lg shadow-xl max-h-[90vh] flex flex-col">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-xl font-bold text-gray-900">Terms & Conditions</h3>
            </div>
            <div class="flex-1 overflow-auto p-6">
                <div id="termsContent" class="prose prose-sm max-w-none text-gray-700 leading-relaxed">
                    <!-- Terms content will be loaded here -->
                </div>
            </div>
            <div class="p-6 border-t border-gray-200 flex justify-end gap-3">
                <button type="button" onclick="document.getElementById('termsModal').close();" 
                        class="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-md transition-colors">
                    Close
                </button>
                <button id="agreeTermsBtn" 
                        class="px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md transition-colors font-medium">
                    I Agree
                </button>
            </div>
        </div>
    </dialog>
    <script>
    // Terms modal behavior for personal loan apply
    document.getElementById('terms_link').addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const productId = document.getElementById('productId').value || '';
        if (!productId) {
            alert('Please select a product first to view Terms & Conditions.');
            return;
        }
        try { document.getElementById('terms').checked = false; } catch(err) {}
        fetch('get_terms.php?product_id=' + encodeURIComponent(productId)).then(r => r.json()).then(data => {
            if (data.success) {
                document.getElementById('termsContent').innerHTML = data.terms || '<p>No terms available.</p>';
                document.getElementById('termsModal').showModal();
            } else {
                alert('Terms not available');
            }
        }).catch(err => { console.error(err); alert('Failed to load terms'); });
    });
    
    // Intercept checkbox click to show modal
    const termsCheckbox = document.getElementById('terms');
    if (termsCheckbox) {
        termsCheckbox.addEventListener('change', function(e) {
            if (this.checked) {
                this.checked = false;
                const productId = document.getElementById('productId').value || '';
                if (!productId) {
                    alert('Please select a product first to view Terms & Conditions.');
                    return;
                }
                fetch('get_terms.php?product_id=' + encodeURIComponent(productId)).then(r => r.json()).then(data => {
                    if (data.success) {
                        document.getElementById('termsContent').innerHTML = data.terms || '<p>No terms available.</p>';
                        document.getElementById('termsModal').showModal();
                    } else {
                        alert('Terms not available');
                    }
                }).catch(err => { console.error(err); alert('Failed to load terms'); });
            }
        });
    }
    
    document.getElementById('agreeTermsBtn').addEventListener('click', function() {
        const productId = document.getElementById('productId').value || '';
        fetch('accept_terms.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'product_id=' + encodeURIComponent(productId)
        }).then(r => r.json()).then(resp => {
            if (resp.success) {
                document.getElementById('terms').checked = true;
                document.getElementById('termsModal').close();
            } else {
                alert('Failed to record acceptance');
            }
        }).catch(err => { console.error(err); alert('Failed to record acceptance'); });
    });
    </script>
        <?php include __DIR__ . '/../includes/footer.php'; ?>
        <script src="/assets/js/loading.js"></script>
</body>
    </html>
