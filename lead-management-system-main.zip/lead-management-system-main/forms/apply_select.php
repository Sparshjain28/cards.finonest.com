<?php
require_once __DIR__ . '/../includes/auth.php';
// No forced login for this page, but check permissions if logged in

// Get available products based on user permissions
$availableProducts = [];

if (isLoggedIn()) {
    // Check permissions for each product type
    if (hasPermission('products.view') || !isLoggedIn()) {
        $availableProducts = [
            'credit_card' => true,
            'personal_loan' => true,
            'offline_personal' => hasPermission('products.edit') || isAdmin(),
            'car_loan' => true,
            'business_loan' => hasPermission('products.edit') || isAdmin()
        ];
    } else {
        // Basic user - show only basic products
        $availableProducts = [
            'credit_card' => true,
            'personal_loan' => true,
            'offline_personal' => false,
            'car_loan' => true,
            'business_loan' => false
        ];
    }
} else {
    // Not logged in - show all public products
    $availableProducts = [
        'credit_card' => true,
        'personal_loan' => true,
        'offline_personal' => false,
        'car_loan' => true,
        'business_loan' => false
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply - Choose Product Type</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Custom styles for better mobile experience */
        @media (max-width: 640px) {
            .option-card {
                min-height: 120px;
                transition: all 0.3s ease;
            }
            .option-card:active {
                transform: scale(0.98);
            }
        }
    </style>
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mx-auto px-4 py-8 max-w-md">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-slate-800 mb-2">What would you like to apply for?</h1>
            <p class="text-slate-600">Select an option below to get started</p>
        </div>

        <div class="space-y-4">
            <?php
            // Pass channel_code from session or URL to application links
            $channel_code = '';
            if (isset($_SESSION['channel_code'])) {
                $channel_code = $_SESSION['channel_code'];
            } elseif (isset($_GET['Channel'])) {
                $channel_code = $_GET['Channel'];
            }
            $url_suffix = $channel_code ? '?Channel=' . urlencode($channel_code) : '';
            
            $options = [
                [
                    'key' => 'credit_card',
                    'title' => 'Credit Card',
                    'icon' => 'credit-card',
                    'description' => 'Apply for a new credit card with exclusive benefits',
                    'url' => '/forms/apply_card.php' . $url_suffix,
                    'gradient' => 'from-purple-500 to-indigo-600'
                ],
                [
                    'key' => 'personal_loan',
                    'title' => 'Personal Loan',
                    'icon' => 'hand-holding-usd',
                    'description' => 'Get funds for your personal needs',
                    'url' => '/forms/apply_personal.php' . $url_suffix,
                    'gradient' => 'from-blue-500 to-cyan-600'
                ],
                [
                    'key' => 'offline_personal',
                    'title' => 'Offline Personal Loan',
                    'icon' => 'file-alt',
                    'description' => 'Apply for personal loan with offline processing',
                    'url' => '/forms/offline_pl_form.php' . $url_suffix,
                    'gradient' => 'from-indigo-500 to-purple-600'
                ],
                [
                    'key' => 'car_loan',
                    'title' => 'Car Loan',
                    'icon' => 'car',
                    'description' => 'Finance your dream car with competitive rates',
                    'url' => '/forms/apply_car.php' . $url_suffix,
                    'gradient' => 'from-emerald-500 to-teal-600'
                ],
                [
                    'key' => 'business_loan',
                    'title' => 'Business Loan',
                    'icon' => 'building',
                    'description' => 'Grow your business with flexible financing',
                    'url' => '/forms/business_loan_form.php' . $url_suffix,
                    'gradient' => 'from-orange-500 to-red-600'
                ]
            ];
            
            foreach ($options as $option) {
                // Check if user has access to this product
                if (!isset($availableProducts[$option['key']]) || !$availableProducts[$option['key']]) {
                    continue;
                }
                echo '
                <a href="' . $option['url'] . '" class="block group">
                    <div class="option-card bg-white rounded-xl shadow-sm p-6 flex items-center space-x-4 border border-gray-100 hover:border-blue-100 hover:shadow-md transition-all duration-300">
                        <div class="flex-shrink-0 w-14 h-14 rounded-xl bg-gradient-to-br ' . $option['gradient'] . ' flex items-center justify-center text-white text-2xl">
                            <i class="fas fa-' . $option['icon'] . '"></i>
                        </div>
                        <div class="flex-1 min-w-0">
                            <h3 class="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">' . $option['title'] . '</h3>
                            <p class="text-sm text-gray-500 truncate">' . $option['description'] . '</p>
                        </div>
                        <div class="text-gray-400 group-hover:text-blue-500 transition-colors">
                            <i class="fas fa-chevron-right"></i>
                        </div>
                    </div>
                </a>';
            }
            ?>
        </div>

        <div class="mt-8 text-center">
            <a href="/" class="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium">
                <i class="fas fa-arrow-left mr-2"></i> Back to Home
            </a>
        </div>
    </div>

    <script>
    // Enhanced logo click handler
    document.addEventListener('DOMContentLoaded', function() {
        // Handle logo clicks - redirect to home page instead of dashboard
        var logoLinks = document.querySelectorAll('header a[href*="dashboard"], header a[href="/"], header a[href="/index.php"]');
        logoLinks.forEach(function(logo) {
            logo.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                window.location.href = '/';
            });
        });

        // Add ripple effect to option cards
        document.querySelectorAll('.option-card').forEach(card => {
            card.addEventListener('click', function(e) {
                const rect = this.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                const ripple = document.createElement('span');
                ripple.className = 'ripple';
                ripple.style.left = `${x}px`;
                ripple.style.top = `${y}px`;
                this.appendChild(ripple);
                
                setTimeout(() => ripple.remove(), 1000);
            });
        });
    });
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
