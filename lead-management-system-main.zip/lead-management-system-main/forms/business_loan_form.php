<?php
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Business Loan - Lead Generation Form</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="bg-gradient-to-r from-orange-500 to-red-600 p-6 text-white">
                <h1 class="text-2xl font-bold">BUSINESS LOAN – LEAD GENERATION FORM</h1>
                <p class="text-orange-100">Quick Lead Capture Format for DSA / Sales / Field Executive</p>
            </div>
            
            <form method="POST" action="../pages/submit.php" class="p-6 space-y-8">
                <input type="hidden" name="product_type" value="business_loan">
                
                <!-- Business Type -->
                <div class="space-y-4">
                    <h3 class="text-lg font-bold text-slate-800 border-b pb-2">1st QUESTION – BUSINESS TYPE</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Nature of Business *</label>
                            <input type="text" name="nature_of_business" required class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Business Vintage *</label>
                            <div class="flex gap-2">
                                <input type="number" name="business_years" placeholder="Years" class="w-1/2 px-4 py-3 border border-slate-300 rounded-xl">
                                <input type="number" name="business_months" placeholder="Months" class="w-1/2 px-4 py-3 border border-slate-300 rounded-xl">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Business Premises -->
                <div class="space-y-4">
                    <h3 class="text-lg font-bold text-slate-800 border-b pb-2">BUSINESS PREMISES</h3>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-2">Business Premises Type *</label>
                        <div class="flex gap-4">
                            <label class="flex items-center">
                                <input type="radio" name="premises_type" value="owned" class="mr-2">
                                <span>☐ Owned</span>
                            </label>
                            <label class="flex items-center">
                                <input type="radio" name="premises_type" value="rented" class="mr-2">
                                <span>☐ Rented</span>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Loan Requirement -->
                <div class="space-y-4">
                    <h3 class="text-lg font-bold text-slate-800 border-b pb-2">LOAN REQUIREMENT</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Loan Type *</label>
                            <div class="space-y-2">
                                <label class="flex items-center">
                                    <input type="radio" name="loan_type" value="business_loan" class="mr-2">
                                    <span>☐ Business Loan</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="loan_type" value="working_capital" class="mr-2">
                                    <span>☐ Working Capital</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="loan_type" value="od_cc" class="mr-2">
                                    <span>☐ OD / CC</span>
                                </label>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Required Loan Amount *</label>
                            <input type="text" name="loan_amount" placeholder="₹" class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Tenure</label>
                            <input type="text" name="tenure" placeholder="Months / Years" class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Purpose of Loan</label>
                            <input type="text" name="loan_purpose" class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                    </div>
                </div>

                <!-- Financial Snapshot -->
                <div class="space-y-4">
                    <h3 class="text-lg font-bold text-slate-800 border-b pb-2">FINANCIAL SNAPSHOT</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Monthly Turnover</label>
                            <input type="text" name="monthly_turnover" placeholder="₹" class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Annual Turnover</label>
                            <input type="text" name="annual_turnover" placeholder="₹" class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                    </div>
                </div>

                <!-- Business Registration -->
                <div class="space-y-4">
                    <h3 class="text-lg font-bold text-slate-800 border-b pb-2">BUSINESS REGISTRATION DETAILS</h3>
                    <div>
                        <label class="block text-sm font-medium text-slate-700 mb-2">Business Registration Available</label>
                        <div class="space-y-2">
                            <label class="flex items-center">
                                <input type="checkbox" name="registration[]" value="udyam" class="mr-2">
                                <span>☐ UDYAM / UDYOG AADHAAR</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" name="registration[]" value="gst" class="mr-2">
                                <span>☐ GST REGISTRATION</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" name="registration[]" value="shop_act" class="mr-2">
                                <span>☐ SHOP ACT LICENSE</span>
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" name="registration[]" value="other" class="mr-2">
                                <span>☐ OTHER LICENSE (Specify):</span>
                                <input type="text" name="other_license" placeholder="Specify" class="ml-2 px-3 py-2 border border-slate-300 rounded-lg">
                            </label>
                            <label class="flex items-center">
                                <input type="checkbox" name="registration[]" value="none" class="mr-2">
                                <span>☐ NO REGISTRATION AVAILABLE</span>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- ITR Details -->
                <div class="space-y-4">
                    <h3 class="text-lg font-bold text-slate-800 border-b pb-2">ITR DETAILS</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">ITR Filed</label>
                            <div class="flex gap-4">
                                <label class="flex items-center">
                                    <input type="radio" name="itr_filed" value="yes" class="mr-2">
                                    <span>☐ Yes</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="itr_filed" value="no" class="mr-2">
                                    <span>☐ No</span>
                                </label>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">No. of Years ITR Available</label>
                            <div class="space-y-1">
                                <label class="flex items-center">
                                    <input type="radio" name="itr_years" value="1" class="mr-2">
                                    <span>☐ 1 Year</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="itr_years" value="2" class="mr-2">
                                    <span>☐ 2 Years</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="itr_years" value="3" class="mr-2">
                                    <span>☐ 3 Years</span>
                                </label>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Latest ITR Year</label>
                            <input type="text" name="latest_itr_year" class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                    </div>
                </div>

                <!-- Banking & Credit -->
                <div class="space-y-4">
                    <h3 class="text-lg font-bold text-slate-800 border-b pb-2">BANKING & CREDIT</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Primary Bank Name</label>
                            <input type="text" name="primary_bank" class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">CIBIL Score (If Known)</label>
                            <input type="text" name="cibil_score" class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                    </div>
                </div>

                <!-- References -->
                <div class="space-y-4">
                    <h3 class="text-lg font-bold text-slate-800 border-b pb-2">REFERENCES (Optional)</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Reference Name</label>
                            <input type="text" name="reference_name" class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Contact No.</label>
                            <input type="tel" name="reference_contact" class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                    </div>
                </div>

                <!-- Personal Details -->
                <div class="space-y-4">
                    <h3 class="text-lg font-bold text-slate-800 border-b pb-2">PERSONAL DETAILS</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Full Name *</label>
                            <input type="text" name="full_name" required class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Mobile Number *</label>
                            <input type="tel" name="mobile" required pattern="[0-9]{10}" class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">Email Address *</label>
                            <input type="email" name="email" required class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-slate-700 mb-2">PAN Number *</label>
                            <input type="text" name="pan" required pattern="[A-Z]{5}[0-9]{4}[A-Z]{1}" class="w-full px-4 py-3 border border-slate-300 rounded-xl">
                        </div>
                    </div>
                </div>

                <!-- Declaration -->
                <div class="bg-slate-50 p-4 rounded-xl">
                    <h3 class="text-lg font-bold text-slate-800 mb-3">DECLARATION</h3>
                    <label class="flex items-start">
                        <input type="checkbox" name="declaration" required class="mr-3 mt-1">
                        <span class="text-sm text-slate-700">I authorize the company / DSA to contact me and verify the above details for business loan eligibility, KYC verification, and credit assessment.</span>
                    </label>
                </div>

                <!-- Submit Button -->
                <div class="pt-6">
                    <button type="submit" class="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white py-4 px-6 rounded-xl font-bold text-lg hover:from-orange-600 hover:to-red-700 transition-all shadow-lg">
                        <i class="fas fa-paper-plane mr-2"></i>
                        Submit Business Loan Application
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>