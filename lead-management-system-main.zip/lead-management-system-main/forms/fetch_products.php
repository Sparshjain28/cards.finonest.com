<?php
require_once '../config/database_updated.php';

header('Content-Type: application/json');

$database = new Database();
$conn = $database->getConnection();

$products = [];
$stmt = $conn->prepare("SELECT id, name, category, bank_redirect_url, utm_template_url, commission_rate FROM products WHERE category = 'Credit Card' AND status = 'active' ORDER BY id DESC");
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $products[] = [
        'id' => $row['id'],
        'name' => htmlspecialchars($row['name']),
        'category' => htmlspecialchars($row['category']),
        'bank_redirect_url' => htmlspecialchars($row['bank_redirect_url']),
        'utm_template_url' => htmlspecialchars($row['utm_template_url']),
        'commission' => '₹' . number_format($row['commission_rate'], 0), // Format for display
        'description' => 'Apply for ' . htmlspecialchars($row['name']) . ' and get exclusive benefits.', // Placeholder description
        'features' => ['Instant approval', 'Reward points', 'Zero annual fee'] // Placeholder features
    ];
}

echo json_encode($products);
$stmt->close();
$conn->close();
?>
