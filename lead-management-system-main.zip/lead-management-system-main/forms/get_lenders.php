<?php
include_once('../config/database_updated.php');
$database = new Database();
$conn = $database->getConnection();

header('Content-Type: application/json');

if (!isset($_GET['pincode']) || empty($_GET['pincode'])) {
    echo json_encode(['success' => false, 'message' => 'Pincode required']);
    exit;
}

$pincode = $_GET['pincode'];
$pincode_filter = "";

if ($pincode !== '000000') {
    // Escaping for security (though using prepare)
    $pincode_esc = $conn->real_escape_string($pincode);
    $pincode_filter = " AND (pin_codes IS NULL OR pin_codes = '' OR pin_codes LIKE '%ALL%' OR FIND_IN_SET('$pincode_esc', REPLACE(pin_codes, ' ', '')) > 0 OR pin_codes LIKE '%$pincode_esc%')";
}

// Get variants with card count from products table
$query = "SELECT variant as lender, variant_image, MAX(pin_codes) as pin_codes, COUNT(*) as card_count 
          FROM products 
          WHERE category = 'Credit Card' AND status = 'active' AND variant IS NOT NULL AND variant != '' 
          $pincode_filter
          GROUP BY variant, variant_image 
          ORDER BY card_count DESC";

$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->get_result();

$lenders = [];
while ($row = $result->fetch_assoc()) {
    $lenders[] = [
        'name' => $row['lender'],
        'count' => $row['card_count'],
        'image' => $row['variant_image'],
        'pin_codes' => $row['pin_codes']
    ];
}

echo json_encode(['success' => true, 'lenders' => $lenders]);
?>