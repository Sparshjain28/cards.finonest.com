<?php
require_once __DIR__ . '/../config/database_updated.php';
header('Content-Type: application/json; charset=utf-8');

try {
    $database = new Database();
    $conn = $database->getConnection();

    // Fetch privacy policy from settings table
    $stmt = $conn->prepare('SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1');
    $setting_key = 'privacy_policy';
    $stmt->bind_param('s', $setting_key);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();

    if ($row && !empty($row['setting_value'])) {
        echo json_encode(['success' => true, 'privacy' => $row['setting_value']]);
    } else {
        // Default privacy policy if none exists
        $default_privacy = '
        <div class="privacy-content">
            <h4>Information We Collect</h4>
            <p>We collect personal information including name, contact details, financial information, and identity documents for loan/credit card processing.</p>
            
            <h4>How We Use Your Information</h4>
            <ul>
                <li>Process your loan/credit applications</li>
                <li>Verify your identity and creditworthiness</li>
                <li>Communicate about your application status</li>
                <li>Comply with regulatory requirements</li>
            </ul>
            
            <h4>Information Sharing</h4>
            <p>We share your information with:</p>
            <ul>
                <li>Partner banks and financial institutions</li>
                <li>Credit bureaus (CIBIL, Experian, etc.)</li>
                <li>Regulatory authorities as required</li>
                <li>Service providers for application processing</li>
            </ul>
            
            <h4>Data Security</h4>
            <p>We implement industry-standard security measures including encryption, secure servers, and access controls to protect your personal information.</p>
            
            <h4>Your Rights</h4>
            <p>You have the right to access, update, or delete your personal information. Contact us at privacy@finocards.com for any privacy-related queries.</p>
            
            <h4>Contact Information</h4>
            <p>For privacy concerns: <strong>privacy@finocards.com</strong><br>
            Customer Support: <strong>support@finocards.com</strong><br>
            Phone: <strong>1800-XXX-XXXX</strong></p>
        </div>';
        
        echo json_encode(['success' => true, 'privacy' => $default_privacy]);
    }
    
} catch (Exception $e) {
    error_log('Privacy policy fetch error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'database_error']);
}
?>