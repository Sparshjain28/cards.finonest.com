<?php
require_once __DIR__ . '/../config/database_updated.php';
header('Content-Type: application/json; charset=utf-8');

try {
    $database = new Database();
    $conn = $database->getConnection();
    
    $product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
    
    if ($product_id <= 0) {
        // Return generic terms if no product ID provided
        $generic_terms = getGenericTerms('general');
        echo json_encode(['success' => true, 'terms' => $generic_terms]);
        exit;
    }
    
    // First try to get product-specific terms
    $stmt = $conn->prepare('SELECT terms_content, name, category FROM products WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
    
    if ($row) {
        if (!empty($row['terms_content'])) {
            // Sanitize admin-provided terms to prevent XSS while preserving newlines
            // We escape HTML entities and convert newlines to <br> for safe display
            $safe = nl2br(htmlspecialchars($row['terms_content'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
            echo json_encode(['success' => true, 'terms' => $safe]);
        } else {
            // Fallback to generic terms based on category (trusted HTML)
            $generic_terms = getGenericTerms($row['category']);
            echo json_encode(['success' => true, 'terms' => $generic_terms]);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'product_not_found']);
    }
    
} catch (Exception $e) {
    error_log('Terms fetch error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'database_error']);
}

function getGenericTerms($category) {
    $terms = [
        'Credit Card' => '
        <div class="terms-content">
            <h4>Credit Card Terms & Conditions</h4>
            <p><strong>1. Eligibility:</strong> Applicant must be 21-65 years old with minimum monthly income of ₹25,000.</p>
            <p><strong>2. Interest Rates:</strong> Annual Percentage Rate (APR) ranges from 11.99% to 47.76% based on creditworthiness.</p>
            <p><strong>3. Fees:</strong> Annual fee, late payment charges, and over-limit fees apply as per schedule.</p>
            <p><strong>4. Credit Limit:</strong> Subject to bank approval and credit assessment.</p>
            <p><strong>5. Repayment:</strong> Minimum 5% of outstanding balance due monthly.</p>
            <p><strong>6. Documentation:</strong> Valid ID, income proof, and address verification required.</p>
            <p><strong>7. Processing:</strong> Application processing may take 7-14 working days.</p>
            <p><strong>8. Cancellation:</strong> Card can be cancelled anytime with 30 days notice.</p>
        </div>
        ',
        'Personal Loan' => '
        <div class="terms-content">
            <h4>Personal Loan Terms & Conditions</h4>
            <p><strong>1. Loan Amount:</strong> Minimum ₹50,000 to Maximum ₹40,00,000 based on eligibility.</p>
            <p><strong>2. Interest Rate:</strong> Starting from 10.99% per annum, subject to credit profile.</p>
            <p><strong>3. Tenure:</strong> 12 to 84 months repayment period available.</p>
            <p><strong>4. Processing Fee:</strong> Up to 3% of loan amount + applicable taxes.</p>
            <p><strong>5. Eligibility:</strong> Minimum age 23 years, maximum 58 years at loan maturity.</p>
            <p><strong>6. Income Requirement:</strong> Minimum ₹25,000 monthly for salaried, ₹2,00,000 annual for self-employed.</p>
            <p><strong>7. Documentation:</strong> Income proof, bank statements, ID and address proof required.</p>
            <p><strong>8. Prepayment:</strong> Allowed after 12 EMIs with charges as applicable.</p>
        </div>
        ',
        'Car Loan' => '
        <div class="terms-content">
            <h4>Car Loan Terms & Conditions</h4>
            <p><strong>1. Loan Amount:</strong> Up to 90% of vehicle on-road price, maximum ₹1 crore.</p>
            <p><strong>2. Interest Rate:</strong> Starting from 8.50% per annum for new cars.</p>
            <p><strong>3. Tenure:</strong> Up to 7 years for new cars, 5 years for used cars.</p>
            <p><strong>4. Down Payment:</strong> Minimum 10% of vehicle cost required.</p>
            <p><strong>5. Age Criteria:</strong> Vehicle should not be more than 5 years old for used car loans.</p>
            <p><strong>6. Insurance:</strong> Comprehensive insurance mandatory throughout loan tenure.</p>
            <p><strong>7. Processing Fee:</strong> 0.5% to 1% of loan amount + taxes.</p>
            <p><strong>8. Foreclosure:</strong> Allowed after 6 months with prepayment charges.</p>
        </div>
        '
    ];
    
    return $terms[$category] ?? '
    <div class="terms-content">
        <h4>General Terms & Conditions</h4>
        <p><strong>1. Eligibility:</strong> Subject to bank/lender approval and credit assessment.</p>
        <p><strong>2. Documentation:</strong> Valid identity proof, address proof, and income documents required.</p>
        <p><strong>3. Processing:</strong> Application processing time varies by product and lender.</p>
        <p><strong>4. Fees & Charges:</strong> Processing fees and other charges as applicable.</p>
        <p><strong>5. Terms:</strong> All terms subject to final approval by the lending institution.</p>
        <p><strong>6. Application:</strong> By proceeding, you agree to these terms and conditions.</p>
        <p><strong>7. Contact:</strong> For queries, please contact our customer support team.</p>
    </div>
    ';
}
?>