<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

// Database connection
$database = new Database();
$conn = $database->getConnection();

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Fetch products from the database
$query = "SELECT id, name, product_code FROM products WHERE status = 'active'";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Error fetching products: " . mysqli_error($conn));
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <title>Lead Form</title>
</head>
<body>
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <h1>Lead Form</h1>
    <form action="submit.php" method="post">
        <label for="name">Full Name:</label><br>
        <input type="text" id="name" name="name" required><br><br>

        <label for="mobile">Mobile Number:</label><br>
        <input type="text" id="mobile" name="mobile" required><br><br>

        <label for="email">Email Address:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="product">Product:</label><br>
        <select id="product" name="product_id" required>
            <option value="">Select a product</option>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<option value='" . $row['id'] . "'>" . $row['name'] . " (" . $row['product_code'] . ")</option>";
            }
            ?>
        </select><br><br>

        <input type="submit" value="Submit">
    </form>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
