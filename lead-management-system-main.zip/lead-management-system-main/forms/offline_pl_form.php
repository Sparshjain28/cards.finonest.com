<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';

$database = new Database();
$conn = $database->getConnection();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate PAN using existing API
    $pan = strtoupper(trim($_POST['pan_no']));
    
    if (strlen($pan) === 10) {
        require_once __DIR__ . '/../includes/kyc_data_handler.php';
        $apiConfig = require_once __DIR__ . '/../config/api_config.php';
        $kycConfig = $apiConfig['kyc_api'];
        
        require_once __DIR__ . '/../includes/aadhaar_verification.php';
        $kycVerifier = new KYCVerification(
            $kycConfig['base_url'],
            $kycConfig['client_user_id'],
            $kycConfig['secret_key'],
            $kycConfig['access_key']
        );
        
        $result = $kycVerifier->verifyPAN($pan);
        
        if (isset($result['data']['data']['full_name'])) {
            // Save offline PL application
            $stmt = $conn->prepare("INSERT INTO offline_pl_applications (
                bank_name, name, mobile, alt_mobile, dob, father_name, mother_name, 
                marital_status, wife_name, pan_no, current_address, current_pincode, 
                current_landmark, stay_duration_years, stay_duration_months, residence_type,
                personal_email, official_email, qualification, company_name, company_address,
                company_pincode, company_landmark, designation, current_job_years, 
                current_job_months, total_exp_years, total_exp_months, ref1_name, ref1_contact,
                ref1_address, ref2_name, ref2_contact, ref2_address, executive_name, 
                pan_verified_name, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            
            $stmt->bind_param('sssssssssssssiisssssssssiiiissssss',
                $_POST['bank_name'], $_POST['name'], $_POST['mobile'], $_POST['alt_mobile'],
                $_POST['dob'], $_POST['father_name'], $_POST['mother_name'], $_POST['marital_status'],
                $_POST['wife_name'], $pan, $_POST['current_address'], $_POST['current_pincode'],
                $_POST['current_landmark'], $_POST['stay_years'], $_POST['stay_months'], $_POST['residence_type'],
                $_POST['personal_email'], $_POST['official_email'], $_POST['qualification'], $_POST['company_name'],
                $_POST['company_address'], $_POST['company_pincode'], $_POST['company_landmark'], $_POST['designation'],
                $_POST['current_job_years'], $_POST['current_job_months'], $_POST['total_exp_years'], $_POST['total_exp_months'],
                $_POST['ref1_name'], $_POST['ref1_contact'], $_POST['ref1_address'], $_POST['ref2_name'],
                $_POST['ref2_contact'], $_POST['ref2_address'], $_POST['executive_name'], $result['data']['data']['full_name']
            );
            
            if ($stmt->execute()) {
                $success = 'Application submitted successfully! PAN verified for: ' . $result['data']['data']['full_name'];
            } else {
                $error = 'Failed to save application';
            }
        } else {
            $error = 'PAN verification failed';
        }
    } else {
        $error = 'Invalid PAN number';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offline Personal Loan Application</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
</head>
<body class="bg-gray-50 min-h-screen p-4">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="max-w-4xl mx-auto bg-white rounded-lg shadow p-6">
        <h1 class="text-2xl font-bold mb-6 text-center">OFFLINE PERSONAL LOAN APPLICATION</h1>
        
        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST" class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">BANK NAME *</label>
                    <input type="text" name="bank_name" required class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">NAME *</label>
                    <input type="text" name="name" required class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">MOBILE NO. *</label>
                    <input type="tel" name="mobile" required pattern="[0-9]{10}" class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">ALTERNATE MOB NO.</label>
                    <input type="tel" name="alt_mobile" pattern="[0-9]{10}" class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">DATE OF BIRTH *</label>
                    <input type="date" name="dob" required class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">FATHER NAME *</label>
                    <input type="text" name="father_name" required class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">MOTHER NAME *</label>
                    <input type="text" name="mother_name" required class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">MARITAL STATUS *</label>
                    <select name="marital_status" required class="w-full px-3 py-2 border rounded-md">
                        <option value="">Select</option>
                        <option value="Single">Single</option>
                        <option value="Married">Married</option>
                        <option value="Divorced">Divorced</option>
                        <option value="Widowed">Widowed</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">WIFE NAME</label>
                    <input type="text" name="wife_name" class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">PAN NO. *</label>
                    <input type="text" name="pan_no" required maxlength="10" class="w-full px-3 py-2 border rounded-md uppercase">
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium mb-1">CURRENT RESIDENCE ADDRESS *</label>
                <textarea name="current_address" required rows="2" class="w-full px-3 py-2 border rounded-md"></textarea>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">PINCODE *</label>
                    <input type="text" name="current_pincode" required pattern="[0-9]{6}" class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">LANDMARK</label>
                    <input type="text" name="current_landmark" class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">DURATION OF STAY</label>
                    <div class="flex gap-2">
                        <input type="number" name="stay_years" placeholder="Years" min="0" class="w-1/2 px-3 py-2 border rounded-md">
                        <input type="number" name="stay_months" placeholder="Months" min="0" max="11" class="w-1/2 px-3 py-2 border rounded-md">
                    </div>
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium mb-1">TYPE OF RESIDENCE *</label>
                <div class="flex gap-4">
                    <label><input type="radio" name="residence_type" value="OWNED" required> OWNED</label>
                    <label><input type="radio" name="residence_type" value="RENTED" required> RENTED</label>
                    <label><input type="radio" name="residence_type" value="COMPANY PROVIDED" required> COMPANY PROVIDED</label>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">PERSONAL EMAIL ID *</label>
                    <input type="email" name="personal_email" required class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">OFFICIAL EMAIL ID</label>
                    <input type="email" name="official_email" class="w-full px-3 py-2 border rounded-md">
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium mb-1">QUALIFICATION *</label>
                <div class="flex gap-4">
                    <label><input type="radio" name="qualification" value="GRADUATE" required> GRADUATE</label>
                    <label><input type="radio" name="qualification" value="POST GRADUATE" required> POST GRADUATE</label>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">COMPANY NAME *</label>
                    <input type="text" name="company_name" required class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">DESIGNATION *</label>
                    <input type="text" name="designation" required class="w-full px-3 py-2 border rounded-md">
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium mb-1">COMPANY ADDRESS *</label>
                <textarea name="company_address" required rows="2" class="w-full px-3 py-2 border rounded-md"></textarea>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">COMPANY PINCODE *</label>
                    <input type="text" name="company_pincode" required pattern="[0-9]{6}" class="w-full px-3 py-2 border rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">COMPANY LANDMARK</label>
                    <input type="text" name="company_landmark" class="w-full px-3 py-2 border rounded-md">
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium mb-1">WORK EXPERIENCE</label>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">CURRENT JOB</label>
                        <div class="flex gap-2">
                            <input type="number" name="current_job_years" placeholder="Years" min="0" class="w-1/2 px-3 py-2 border rounded-md">
                            <input type="number" name="current_job_months" placeholder="Months" min="0" max="11" class="w-1/2 px-3 py-2 border rounded-md">
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs text-gray-600 mb-1">TOTAL EXPERIENCE</label>
                        <div class="flex gap-2">
                            <input type="number" name="total_exp_years" placeholder="Years" min="0" class="w-1/2 px-3 py-2 border rounded-md">
                            <input type="number" name="total_exp_months" placeholder="Months" min="0" max="11" class="w-1/2 px-3 py-2 border rounded-md">
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="border p-4 rounded">
                    <h3 class="font-medium mb-2">REFERENCE 1 (SENIOR)</h3>
                    <div class="space-y-2">
                        <input type="text" name="ref1_name" placeholder="Name" class="w-full px-3 py-2 border rounded-md">
                        <input type="tel" name="ref1_contact" placeholder="Contact No." class="w-full px-3 py-2 border rounded-md">
                        <textarea name="ref1_address" placeholder="Address" rows="2" class="w-full px-3 py-2 border rounded-md"></textarea>
                    </div>
                </div>
                <div class="border p-4 rounded">
                    <h3 class="font-medium mb-2">REFERENCE 2 (COLLEAGUE)</h3>
                    <div class="space-y-2">
                        <input type="text" name="ref2_name" placeholder="Name" class="w-full px-3 py-2 border rounded-md">
                        <input type="tel" name="ref2_contact" placeholder="Contact No." class="w-full px-3 py-2 border rounded-md">
                        <textarea name="ref2_address" placeholder="Address" rows="2" class="w-full px-3 py-2 border rounded-md"></textarea>
                    </div>
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium mb-1">EXECUTIVE NAME *</label>
                <input type="text" name="executive_name" required class="w-full px-3 py-2 border rounded-md">
            </div>

            <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-md hover:bg-blue-700 font-medium">
                Submit Application
            </button>
        </form>
    </div>
    <script src="/assets/js/loading.js"></script>
</body>
</html>