<?php
session_start(); // Start session at the very beginning

require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../classes/Lead.php';
require_once __DIR__ . '/../config/timezone.php';
require_once __DIR__ . '/../includes/margin_helper.php';
require_once __DIR__ . '/../includes/notification_helper.php';

// Security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die('Method not allowed');
}

// Require logged-in user - no anonymous lead creation
if (empty($_SESSION['user_id'])) {
    header('Location: ../login.php?error=login_required&message=' . urlencode('Please login to create leads'));
    exit;
}

// Input validation and sanitization
function validateInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function validateMobile($mobile) {
    return preg_match('/^[0-9]{10}$/', $mobile);
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Generate 6-digit alphanumeric Lead ID
function generateAlphaNumericLeadId($length = 6) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $leadId = '';
    for ($i = 0; $i < $length; $i++) {
        $leadId .= $characters[random_int(0, strlen($characters) - 1)];
    }
    return $leadId;
}

// Collect and validate form data
$name = validateInput($_POST['name'] ?? '');
$mobile = validateInput($_POST['mobile'] ?? '');
$email = validateInput($_POST['email'] ?? '');
$product_id = (int)($_POST['product_id'] ?? 0);
$advisor_name = validateInput($_POST['advisor_name'] ?? '');
$unique_utm_id = validateInput($_POST['unique_utm_id'] ?? '');
$channel_code = validateInput($_POST['channel_code'] ?? $_POST['Channel'] ?? '');
$tracking_code = validateInput($_POST['tracking_code'] ?? '');
$ref_code = validateInput($_POST['ref'] ?? '');

// Debug: Log what we received
error_log('Lead submission - POST data: ' . print_r($_POST, true));
error_log('Lead submission - Initial channel_code: ' . $channel_code);
error_log('Lead submission - tracking_code: ' . $tracking_code);
error_log('Lead submission - ref_code: ' . $ref_code);
error_log('Lead submission - unique_utm_id: ' . $unique_utm_id);

$errors = [];
if (empty($name) || strlen($name) < 2) $errors[] = 'Valid name is required';
if (!validateMobile($mobile)) $errors[] = 'Valid 10-digit mobile number is required';
if (!validateEmail($email)) $errors[] = 'Valid email address is required';
if ($product_id <= 0) $errors[] = 'Valid product selection is required';

if (!empty($errors)) {
    $error_message = urlencode(implode(', ', $errors));
    header('Location: apply_card.php?error=validation&message=' . $error_message);
    exit;
}

try {
    // Database connection
    $database = new Database();
    $conn = $database->getConnection();
    if (!$conn) {
        throw new Exception('Database connection failed: ' . mysqli_connect_error());
    }
    
    // Test database connection
    if (!mysqli_ping($conn)) {
        throw new Exception('Database connection lost');
    }

    // If tracking code is provided, get the advisor's channel code from it
    if (!empty($tracking_code)) {
        $tracking_check = $conn->prepare("SELECT ap.advisor_id, u.channel_code FROM advisor_products ap JOIN users u ON ap.advisor_id = u.id WHERE ap.tracking_code = ? LIMIT 1");
        $tracking_check->bind_param("s", $tracking_code);
        $tracking_check->execute();
        $tracking_result = $tracking_check->get_result();
        if ($tracking_result->num_rows > 0) {
            $tracking_row = $tracking_result->fetch_assoc();
            $channel_code = $tracking_row['channel_code'];
        }
        $tracking_check->close();
    } elseif (!empty($ref_code)) {
        // Fallback to ref code if no tracking code
        $channel_code = $ref_code;
    } elseif (!empty($unique_utm_id)) {
        // Extract channel code from unique_utm_id if available
        $utm_parts = explode('_', $unique_utm_id);
        if (count($utm_parts) >= 2) {
            $channel_code = $utm_parts[0]; // First part is usually channel code
        }
    }
    
    // Use logged-in user's system-generated channel code (REQUIRED)
    if (!empty($_SESSION['user_id'])) {
        $user_stmt = $conn->prepare("SELECT channel_code, name FROM users WHERE id = ? LIMIT 1");
        $user_stmt->bind_param("i", $_SESSION['user_id']);
        $user_stmt->execute();
        $user_result = $user_stmt->get_result();
        if ($user_row = $user_result->fetch_assoc()) {
            if (!empty($user_row['channel_code'])) {
                $channel_code = $user_row['channel_code'];
                // Set advisor name from logged-in user
                if (empty($advisor_name)) {
                    $advisor_name = $user_row['name'];
                }
            } else {
                throw new Exception('User account missing channel code - contact administrator');
            }
        } else {
            throw new Exception('Invalid user session - please login again');
        }
        $user_stmt->close();
    } else {
        throw new Exception('User login required to create leads');
    }
    
    // Debug: Log final channel_code
    error_log('Lead submission - Final channel_code: ' . $channel_code);

    // Check for duplicate leads per product
    $lead = new Lead($conn);
    $duplicate = $lead->checkDuplicate($mobile, $email, $product_id);
    if ($duplicate) {
        $error_msg = 'User already applied for this product';
        if (!empty($duplicate['created_by_user'])) {
            $error_msg .= ' created by ' . $duplicate['created_by_user'];
        } elseif (!empty($duplicate['advisor_name'])) {
            $error_msg .= ' created by ' . $duplicate['advisor_name'];
        }
        
        // Check if this is an AJAX request
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            http_response_code(409);
            echo json_encode([
                "status" => "duplicate",
                "msg" => $error_msg
            ]);
            exit;
        }
        
        // Normal UI request - show alert and redirect back
        echo "<script>
            alert('" . addslashes($error_msg) . "');
            window.history.back();
        </script>";
        exit;
    }

    // Generate 6-digit alphanumeric lead_id
    $modified_lead_id = generateAlphaNumericLeadId(6);

    // Get product details (use correct column name commission_rate)
$product_stmt = $conn->prepare("SELECT name, bank_redirect_url, utm_template_url, commission_rate FROM products WHERE id = ? AND status = 'active'");
$product_stmt->bind_param("i", $product_id);
$product_stmt->execute();
$product_result = $product_stmt->get_result();
if ($product_result->num_rows === 0) throw new Exception('Invalid product selected');
$product = $product_result->fetch_assoc();
$product_stmt->close();

    // Prepare lead data
    $lead_data = [
        'lead_id' => $modified_lead_id,
        'unique_utm_id' => $unique_utm_id,
        'channel_code' => $channel_code,
        'customer_name' => $name,
        'email' => $email,
        'mobile' => $mobile,
        'phone' => $mobile,
        'product_id' => $product_id,
        'status' => 'generated',
        'advisor_name' => $advisor_name,
    ];

    // Create Lead
    $lead_result = $lead->create($lead_data);
    if (!$lead_result) {
        error_log('Lead creation failed. Data: ' . print_r($lead_data, true));
        throw new Exception('Failed to save lead');
    }
    
    error_log('Lead created successfully with ID: ' . $lead_result);

    // Log status change with proper timestamp
    $lead_db_id = $conn->insert_id;
    $current_time = getAppTimestamp();
    $history_stmt = $conn->prepare("INSERT INTO lead_status_history (lead_id, old_status, new_status, changed_by, notes, created_at) VALUES (?, NULL, 'generated', 'system', 'Lead created from application form', ?)");
    $history_stmt->bind_param("is", $lead_db_id, $current_time);
    $history_stmt->execute();
    $history_stmt->close();
    
    // Send email notification
    notifyUser('lead_created', $email, [
        'lead_id' => $modified_lead_id,
        'product_name' => $product['name']
    ]);
    
    
    // Update lead data with commission
$lead_data['commission'] = $product['commission_rate'];

   // Calculate bonus amount
$bonus_amount = $product['commission_rate'] * 0.05;

   // Create payout record using commission_rate from products
$payout_stmt = $conn->prepare("INSERT INTO payouts (lead_id, channel_code, commission_amount, bonus_amount, status) VALUES (?, ?, ?, ?, 'pending')");
$payout_stmt->bind_param("isdd", $lead_db_id, $channel_code, $product['commission_rate'], $bonus_amount);
$payout_stmt->execute();
$payout_stmt->close();

    // Calculate margin for team leader if user is referred
    $channel_user_query = "SELECT id FROM users WHERE channel_code = ? LIMIT 1";
    $channel_stmt = $conn->prepare($channel_user_query);
    $channel_stmt->bind_param("s", $channel_code);
    $channel_stmt->execute();
    $channel_result = $channel_stmt->get_result();
    if ($channel_user = $channel_result->fetch_assoc()) {
        calculateTeamLeaderMargin($conn, $lead_db_id, $product['commission_rate'], $channel_user['id']);
    }
    $channel_stmt->close();

    // Close database connection
    $conn->close();

    // Replace lead ID in bank redirect URL
    $redirect_url = str_replace(
        ['{lead id}', '{leadId}', '{lead_id}'],
        $modified_lead_id,
        $product['bank_redirect_url']
    );

    // Check if this is a referral link (has tracking code) or logged-in user
    if (!empty($tracking_code)) {
        // Referral link users - redirect directly to bank URL
        if (!empty($redirect_url) && filter_var($redirect_url, FILTER_VALIDATE_URL)) {
            error_log('Redirecting referral user to bank URL: ' . $redirect_url);
            header('Location: ' . $redirect_url);
            exit;
        } else {
            // If bank URL is invalid, fall back to thank you page
            error_log('Invalid bank URL, redirecting to thank you page');
            header('Location: thank_you.php?lead_id=' . urlencode($modified_lead_id) . '&source=referral');
            exit;
        }
    } elseif (!empty($_SESSION['user_id'])) {
        // Logged-in users - redirect to thank you page with bank URL
        error_log('Redirecting logged-in user to thank you page with URL: ' . $redirect_url);
        header('Location: thank_you.php?redirect_url=' . urlencode($redirect_url) . '&lead_id=' . urlencode($modified_lead_id) . '&source=dashboard');
        exit;
    } else {
        // Anonymous users - redirect to thank you page
        error_log('Redirecting anonymous user to thank you page with URL: ' . $redirect_url);
        header('Location: thank_you.php?redirect_url=' . urlencode($redirect_url) . '&lead_id=' . urlencode($modified_lead_id));
        exit;
    }

} catch (Exception $e) {
    error_log("Lead submission error: " . $e->getMessage());
    error_log("Error trace: " . $e->getTraceAsString());
    error_log("POST data: " . print_r($_POST, true));
    error_log("Session data: " . print_r($_SESSION, true));
    
    // More specific error handling
    if (strpos($e->getMessage(), 'Database') !== false) {
        header('Location: apply_card.php?error=database&message=' . urlencode('Database connection failed'));
    } elseif (strpos($e->getMessage(), 'Duplicate') !== false) {
        header('Location: apply_card.php?error=duplicate');
    } else {
        header('Location: apply_card.php?error=submission&message=' . urlencode($e->getMessage()));
    }
    exit;
}
// footer include intentionally omitted here because submission handler returns/redirects earlier
?>
