<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You!</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-50 flex items-center justify-center">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="bg-white rounded-lg shadow-lg p-8 max-w-md w-full text-center">
        <div class="text-green-500 text-6xl mb-4">
            <i class="fas fa-check-circle"></i>
        </div>
        <h1 class="text-3xl font-bold text-slate-800 mb-4">Thank You!</h1>
        <p class="text-slate-600 mb-6">Your application has been submitted successfully.</p>
        <?php if (isset($_GET['lead_id'])): ?>
            <p class="text-lg font-semibold text-blue-600 mb-6">Your Lead ID: <?php echo htmlspecialchars($_GET['lead_id']); ?></p>
        <?php endif; ?>
    <p class="text-sm text-slate-500 mb-6">We will process your application shortly.</p>
        <?php 
            $redirect_url = isset($_GET['redirect_url']) ? $_GET['redirect_url'] : 'https://example.com';
        ?>
        <div class="mb-4 flex flex-col gap-2 items-center">
            <button onclick="copyRedirectUrl()" class="bg-green-100 text-green-700 px-4 py-2 rounded hover:bg-green-200 font-medium flex items-center gap-2"><i class='fas fa-copy'></i> Copy Redirect Link</button>
            <a href="<?php echo htmlspecialchars($redirect_url); ?>" target="_blank" class="bg-blue-100 text-blue-700 px-4 py-2 rounded hover:bg-blue-200 font-medium flex items-center gap-2"><i class='fas fa-external-link-alt'></i> Open in New Tab</a>
        </div>
        <input type="text" id="redirectUrlInput" value="<?php echo htmlspecialchars($redirect_url); ?>" style="position:absolute;left:-9999px;">
        <a href="../adviser/dashboard.php" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition">Go to Dashboard</a>
    </div>

    <?php
    $redirect_url = isset($_GET['redirect_url']) ? htmlspecialchars($_GET['redirect_url']) : 'https://example.com';
    echo "<script>
        function copyRedirectUrl() {
            var copyText = document.getElementById('redirectUrlInput');
            copyText.type = 'text';
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            document.execCommand('copy');
            copyText.type = 'hidden';
            alert('Redirect link copied!');
        }
    </script>";
    ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
