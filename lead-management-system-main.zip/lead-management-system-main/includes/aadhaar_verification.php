<?php
class KYCVerification {
    private $baseUrl;
    private $clientUserId;
    private $secretKey;
    private $accessKey;
    private $serviceIds;
    
    public function __construct($baseUrl, $clientUserId = '', $secretKey = '', $accessKey = '') {
        $this->baseUrl = $baseUrl;
        $this->clientUserId = $clientUserId;
        $this->secretKey = $secretKey;
        $this->accessKey = $accessKey;
        
        // Load service IDs from config
        $apiConfig = require __DIR__ . '/../config/api_config.php';
        $this->serviceIds = $apiConfig['kyc_api']['service_ids'];
    }
    
    public function generateOTP($aadhaarNumber) {
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->baseUrl . '/core-svc/api/v2/exp/validation-service/aadhaar-kyc-otp',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode([
                "uid" => $aadhaarNumber
            ]),
            CURLOPT_HTTPHEADER => array(
                'client-user-id: ' . $this->clientUserId,
                'secret-key: ' . $this->secretKey,
                'access-key: ' . $this->accessKey,
                'service-id: ' . $this->serviceIds['aadhaar_otp'],
                'Content-Type: application/json'
            ),
        ));
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        
        if ($response === false) {
            return ['success' => false, 'error' => 'Network error'];
        }
        
        $data = json_decode($response, true);
        $success = $httpCode === 200 && isset($data['data']['sessionId']);
        return [
            'success' => $success,
            'data' => $data,
            'session_id' => $data['data']['sessionId'] ?? '',
            'http_code' => $httpCode
        ];
    }
    
    public function submitOTP($sessionId, $otp) {
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->baseUrl . '/core-svc/api/v2/exp/validation-service/aadhaar-kyc',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode([
                "sessionId" => $sessionId,
                "otp" => $otp
            ]),
            CURLOPT_HTTPHEADER => array(
                'client-user-id: ' . $this->clientUserId,
                'secret-key: ' . $this->secretKey,
                'access-key: ' . $this->accessKey,
                'service-id: ' . $this->serviceIds['aadhaar_kyc'],
                'Content-Type: application/json'
            ),
        ));
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        
        if ($response === false) {
            return ['success' => false, 'error' => 'Network error'];
        }
        
        $data = json_decode($response, true);
        $success = $httpCode === 200 && isset($data['data']);
        return [
            'success' => $success,
            'data' => $data,
            'http_code' => $httpCode
        ];
    }
    
    public function verifyPAN($panNumber) {
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->baseUrl . '/core-svc/api/v2/exp/validation-service/pan-premium',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode([
                "pan" => $panNumber
            ]),
            CURLOPT_HTTPHEADER => array(
                'client-user-id: ' . $this->clientUserId,
                'secret-key: ' . $this->secretKey,
                'access-key: ' . $this->accessKey,
                'Content-Type: application/json'
            ),
        ));
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        
        if ($response === false) {
            return ['success' => false, 'error' => 'Network error'];
        }
        
        $data = json_decode($response, true);
        return [
            'success' => $httpCode === 200 && isset($data['data']),
            'data' => $data,
            'http_code' => $httpCode
        ];
    }
    
    public function verifyBank($accountNumber, $ifsc) {
        $apiConfig = require __DIR__ . '/../config/api_config.php';
        $surepassToken = $apiConfig['surepass']['api_token'];
        
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://kyc-api.surepass.io/api/v1/bank-verification/',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode([
                "id_number" => $accountNumber,
                "ifsc" => $ifsc,
                "ifsc_details" => true
            ]),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Bearer ' . $surepassToken
            ),
        ));
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curlError = curl_error($curl);
        curl_close($curl);
        
        error_log("Bank API - Account: $accountNumber, IFSC: $ifsc");
        error_log("Bank API Response: " . $response);
        error_log("Bank API HTTP Code: " . $httpCode);
        if ($curlError) error_log("Bank API cURL Error: " . $curlError);
        
        if ($response === false) {
            return ['success' => false, 'error' => 'Network error: ' . $curlError];
        }
        
        $data = json_decode($response, true);
        return [
            'success' => $httpCode === 200,
            'data' => $data,
            'http_code' => $httpCode
        ];
    }
    
    public function verifyUPI($upiId) {
        $apiConfig = require __DIR__ . '/../config/api_config.php';
        $surepassToken = $apiConfig['surepass']['api_token'];
        
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://kyc-api.surepass.io/api/v1/bank-verification/upi-verification',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode([
                "id_number" => $upiId
            ]),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $surepassToken
            ],
        ));
        
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curlError = curl_error($curl);
        curl_close($curl);
        
        error_log("UPI API Response: " . $response);
        error_log("UPI HTTP Code: " . $httpCode);
        
        if ($response === false) {
            return ['success' => false, 'error' => 'Network error: ' . $curlError];
        }
        
        $data = json_decode($response, true);
        return [
            'success' => $httpCode === 200,
            'data' => $data,
            'http_code' => $httpCode
        ];
    }
}
?>
