<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Start output buffering before any output
if (!ob_get_level()) {
    ob_start();
}

// IMMEDIATE session validation - prevent any content loading for invalid sessions
if (isset($_GET['logout']) && $_GET['logout']) {
    session_unset();
    session_destroy();
    header('Location: /Auth/login.php');
    exit();
}

// Auto-run migration
require_once __DIR__ . '/../config/timezone.php';

// Centralized auth/session helper

// Session should already be started by calling script

// 30 minutes inactivity timeout
$SESSION_TIMEOUT = 30 * 60;

// Logout handling via ?logout=1
if (isset($_GET['logout']) && $_GET['logout']) {
    session_unset();
    session_destroy();
    header('Location: /Auth/login.php');
    exit();
}

// Clear all cookies function
function clearAllCookies() {
    if (isset($_SERVER['HTTP_COOKIE'])) {
        $cookies = explode(';', $_SERVER['HTTP_COOKIE']);
        foreach($cookies as $cookie) {
            $parts = explode('=', $cookie);
            $name = trim($parts[0]);
            setcookie($name, '', time()-3600, '/');
            setcookie($name, '', time()-3600, '/', $_SERVER['HTTP_HOST']);
            setcookie($name, '', time()-3600, '/', '.' . $_SERVER['HTTP_HOST']);
        }
    }
}

// Check inactivity ONLY if user is logged in
if (!empty($_SESSION['user_id']) && isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $SESSION_TIMEOUT)) {
    clearAllCookies();
    session_unset();
    session_destroy();
    header('Location: /Auth/login.php?timeout=1');
    exit();
}

// Update last activity timestamp ONLY for valid sessions
if (!empty($_SESSION['user_id'])) {
    $_SESSION['LAST_ACTIVITY'] = time();
}

function isLoggedIn() {
    // Check if session exists and is not expired
    if (empty($_SESSION['user_id'])) {
        return false;
    }
    
    // Check session timeout
    global $SESSION_TIMEOUT;
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $SESSION_TIMEOUT)) {
        session_unset();
        session_destroy();
        return false;
    }
    
    return true;
}

function requireLogin() {
    // Immediate session check without any output
    if (empty($_SESSION['user_id'])) {
        // Clear any output buffer
        if (ob_get_level()) {
            ob_end_clean();
        }
        session_unset();
        session_destroy();
        header('Location: /Auth/login.php?required=1');
        exit();
    }
    
    // Check session timeout
    global $SESSION_TIMEOUT;
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $SESSION_TIMEOUT)) {
        // Clear any output buffer
        if (ob_get_level()) {
            ob_end_clean();
        }
        session_unset();
        session_destroy();
        header('Location: /Auth/login.php?timeout=1');
        exit();
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        // Clear any output buffer
        if (ob_get_level()) {
            ob_end_clean();
        }
        header('Location: /Auth/login.php?access_denied=1');
        exit();
    }
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    
    require_once __DIR__ . '/../config/database_updated.php';
    $database = new Database();
    $conn = $database->getConnection();
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($user = $result->fetch_assoc()) {
        return $user;
    }
    
    return [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'] ?? null,
        'email' => $_SESSION['user_email'] ?? null,
        'channel_code' => $_SESSION['channel_code'] ?? null,
        'is_admin' => !empty($_SESSION['is_admin']) ? true : false
    ];
}

function isAdmin() {
    if (!isLoggedIn()) return false;
    
    // Check session first for performance
    if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
        return true;
    }
    
    // Quick database check
    require_once __DIR__ . '/../config/database_updated.php';
    $database = new Database();
    $conn = $database->getConnection();
    
    $stmt = $conn->prepare("SELECT role_id FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    return $user && $user['role_id'] == 1;
}

function isManager() {
    if (!isLoggedIn()) return false;
    
    // Quick database check
    require_once __DIR__ . '/../config/database_updated.php';
    $database = new Database();
    $conn = $database->getConnection();
    
    $stmt = $conn->prepare("SELECT role_id FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    return $user && $user['role_id'] == 2;
}

function getUserRole() {
    if (!isLoggedIn()) return null;
    
    if (file_exists(__DIR__ . '/role_manager.php') && file_exists(__DIR__ . '/../config/database_updated.php')) {
        require_once __DIR__ . '/../config/database_updated.php';
        require_once __DIR__ . '/role_manager.php';
        
        $database = new Database();
        $conn = $database->getConnection();
        $roleManager = new RoleManager($conn);
        return $roleManager->getUserRole($_SESSION['user_id']);
    }
    
    return null;
}

function loginUserSession($userRow) {
    // $userRow is an associative array from users table
    $_SESSION['user_id'] = $userRow['id'];
    $_SESSION['user_name'] = $userRow['name'] ?? null;
    $_SESSION['user_email'] = $userRow['email'] ?? null;
    $_SESSION['channel_code'] = $userRow['channel_code'] ?? null;
    $_SESSION['is_admin'] = !empty($userRow['is_admin']) ? 1 : 0;
    $_SESSION['LAST_ACTIVITY'] = time();
    
    // Clear cached permissions on login
    unset($_SESSION['permissions']);
}

function logout() {
    clearAllCookies();
    session_unset();
    session_destroy();
    header('Location: /Auth/login.php');
    exit();
}

function hasPermission($permissionName) {
    if (!isLoggedIn()) return false;
    
    // Admin has all permissions
    if (isAdmin()) return true;

    // Check user-specific permissions first (for individual manager permissions)
    if (file_exists(__DIR__ . '/../config/database_updated.php')) {
        require_once __DIR__ . '/../config/database_updated.php';
        
        $database = new Database();
        $conn = $database->getConnection();
        
        // Check individual user permissions
        $stmt = $conn->prepare("
            SELECT up.granted FROM user_permissions up
            JOIN permissions p ON up.permission_id = p.id
            WHERE up.user_id = ? AND p.name = ?
        ");
        $stmt->bind_param('is', $_SESSION['user_id'], $permissionName);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            return (bool)$row['granted'];
        }
        
        // Fall back to role permissions
        $stmt = $conn->prepare("
            SELECT 1 FROM users u 
            JOIN roles r ON u.role_id = r.id 
            JOIN role_permissions rp ON r.id = rp.role_id 
            JOIN permissions p ON rp.permission_id = p.id 
            WHERE u.id = ? AND p.name = ?
        ");
        $stmt->bind_param('is', $_SESSION['user_id'], $permissionName);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }
    
    return false;
}

