<?php
function checkBankingDetails($conn, $user_id) {
    $stmt = $conn->prepare("SELECT bank_name, account_number, ifsc_code, pan_number, aadhar_number FROM users WHERE id = ?");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    return !empty($result['bank_name']) && 
           !empty($result['account_number']) && 
           !empty($result['ifsc_code']) && 
           !empty($result['pan_number']) && 
           !empty($result['aadhar_number']);
}

function requireBankingDetails($conn, $user_id, $redirect_url = null) {
    // Check if user is DSA
    $stmt = $conn->prepare("SELECT user_type FROM users WHERE id = ?");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    // Only require banking details for DSA users
    if ($result && $result['user_type'] === 'dsa' && !checkBankingDetails($conn, $user_id)) {
        $redirect = $redirect_url ? '?redirect=' . urlencode($redirect_url) : '';
        header("Location: /banking_details.php" . $redirect);
        exit;
    }
}
?>