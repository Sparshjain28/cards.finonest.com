<?php
// Banking popup placeholder - can be expanded later if needed
?>
<!-- Banking popup placeholder -->