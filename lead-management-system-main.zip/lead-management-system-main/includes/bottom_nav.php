<!-- Bottom Navigation Bar for Mobile -->
<?php
$is_admin = isAdmin();
$is_manager = isManager();
$is_adviser = !$is_admin && !$is_manager;
?>
<nav class="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-lg flex justify-around py-2 z-50 md:hidden">
    <a href="<?php echo $is_admin ? '/admin/dashboard.php' : ($is_manager ? '/manager/dashboard.php' : '/adviser/dashboard.php'); ?>" class="flex flex-col items-center text-blue-600">
        <i class="fas fa-home text-xl"></i>
        <span class="text-xs">Home</span>
    </a>
    <a href="/leads/leads_updated.php" class="flex flex-col items-center text-slate-600">
        <i class="fas fa-users text-xl"></i>
        <span class="text-xs">Leads</span>
    </a>
    <?php if ($is_manager): ?>
    <a href="/manager/team.php" class="flex flex-col items-center bg-blue-600 text-white rounded-full p-3 -mt-6 shadow-lg">
        <i class="fas fa-users-cog text-xl"></i>
    </a>
    <?php else: ?>
    <a href="/apply.html" class="flex flex-col items-center bg-blue-600 text-white rounded-full p-3 -mt-6 shadow-lg">
        <i class="fas fa-plus text-xl"></i>
    </a>
    <?php endif; ?>
    <a href="<?php echo $is_admin ? '/admin/payouts.php' : ($is_manager ? '/admin/payouts.php' : '/adviser/payouts.php'); ?>" class="flex flex-col items-center text-slate-600">
        <i class="fas fa-wallet text-xl"></i>
        <span class="text-xs">Payouts</span>
    </a>
    <a href="/pages/profile.php" class="flex flex-col items-center text-slate-600">
        <i class="fas fa-user text-xl"></i>
        <span class="text-xs">Profile</span>
    </a>
</nav>