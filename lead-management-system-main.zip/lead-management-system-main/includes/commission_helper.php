<?php
// Commission Helper Functions for Margin Trading System

function getCommissionForUser($conn, $userId, $productId, $leadAmount = null) {
    // Get user's referral info
    $referral_query = "SELECT referrer_user_id FROM referral_users WHERE referred_user_id = ? AND level = 1";
    $ref_stmt = $conn->prepare($referral_query);
    $ref_stmt->bind_param("i", $userId);
    $ref_stmt->execute();
    $referrer = $ref_stmt->get_result()->fetch_assoc();
    $ref_stmt->close();
    
    // Get product info
    $product_query = "SELECT commission_rate, category FROM products WHERE id = ?";
    $prod_stmt = $conn->prepare($product_query);
    $prod_stmt->bind_param("i", $productId);
    $prod_stmt->execute();
    $product = $prod_stmt->get_result()->fetch_assoc();
    $prod_stmt->close();
    
    $master_commission = $product['commission_rate'] ?? 0;
    $commission_type = 'standard';
    $final_commission = $master_commission;
    
    // If user was referred, check for custom rate or set default
    if ($referrer) {
        $settings_query = "SELECT payout_rate, rate_type FROM payout_settings 
                          WHERE user_id = ? AND advisor_user_id = ? 
                          AND (product_id = ? OR product_id IS NULL) 
                          ORDER BY product_id DESC LIMIT 1";
        $settings_stmt = $conn->prepare($settings_query);
        $settings_stmt->bind_param("iii", $referrer['referrer_user_id'], $userId, $productId);
        $settings_stmt->execute();
        $custom_rate = $settings_stmt->get_result()->fetch_assoc();
        $settings_stmt->close();
        
        if ($custom_rate && $custom_rate['payout_rate'] > 0) {
            if ($custom_rate['rate_type'] === 'card_amount') {
                $final_commission = $custom_rate['payout_rate'];
            } else {
                $final_commission = ($master_commission * $custom_rate['payout_rate'] / 100);
            }
            $commission_type = 'referral';
        } else {
            // Set default rates for referred users if no custom rate exists
            $default_rate = getDefaultReferralRate($product['category']);
            if ($default_rate > 0) {
                if ($product['category'] === 'Credit Card') {
                    $final_commission = $default_rate;
                } else {
                    $final_commission = ($master_commission * $default_rate / 100);
                }
                $commission_type = 'referral_default';
            }
        }
    }
    
    return [
        'amount' => $final_commission,
        'type' => $commission_type,
        'master_amount' => $master_commission,
        'is_referred' => !empty($referrer),
        'referrer_id' => $referrer['referrer_user_id'] ?? null
    ];
}

/**
 * Get default referral rates for channel referral program
 * Credit Cards: 500 (₹500)
 * Personal Loans: 1% (1.00)
 */
function getDefaultReferralRate($productCategory) {
    switch ($productCategory) {
        case 'Credit Card':
            return 500; // ₹500
        case 'Personal Loan':
            return 1.00; // 1%
        default:
            return 0;
    }
}

function calculateMarginProfit($conn, $userId, $productId, $masterPayout) {
    // Get all L1 advisors for this user
    $advisors_query = "SELECT ru.referred_user_id, ps.payout_rate, ps.rate_type
                       FROM referral_users ru
                       LEFT JOIN payout_settings ps ON ps.user_id = ? AND ps.advisor_user_id = ru.referred_user_id 
                       AND (ps.product_id = ? OR ps.product_id IS NULL)
                       WHERE ru.referrer_user_id = ? AND ru.level = 1";
    $advisors_stmt = $conn->prepare($advisors_query);
    $advisors_stmt->bind_param("iii", $userId, $productId, $userId);
    $advisors_stmt->execute();
    $advisors = $advisors_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $advisors_stmt->close();
    
    $total_paid_to_downline = 0;
    foreach ($advisors as $advisor) {
        if ($advisor['payout_rate'] > 0) {
            if ($advisor['rate_type'] === 'card_amount') {
                $total_paid_to_downline += $advisor['payout_rate'];
            } else {
                $total_paid_to_downline += ($masterPayout * $advisor['payout_rate'] / 100);
            }
        }
    }
    
    return $masterPayout - $total_paid_to_downline;
}
?>
