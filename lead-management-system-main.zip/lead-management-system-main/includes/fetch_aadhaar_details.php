<?php
function fetchAadhaarDetailsFromAPI($email, $conn) {
    $stmt = $conn->prepare("SELECT response_data FROM api_responses WHERE user_email = ? AND api_type = 'aadhaar_submit' ORDER BY created_at DESC LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    if ($result) {
        $apiData = json_decode($result['response_data'], true);
        if (isset($apiData['data'])) {
            return [
                'name' => $apiData['data']['full_name'] ?? '',
                'dob' => $apiData['data']['dob'] ?? '',
                'gender' => $apiData['data']['gender'] ?? '',
                'profile_image' => $apiData['data']['profile_image'] ?? '',
                'address' => $apiData['data']['address'] ?? []
            ];
        }
    }
    return null;
}
?>