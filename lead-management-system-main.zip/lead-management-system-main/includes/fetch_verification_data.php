<?php
function fetchAndSaveVerificationData($email, $conn) {
    // Fetch Aadhaar submit API response
    $stmt = $conn->prepare("SELECT response_data FROM api_responses WHERE user_email = ? AND api_type = 'aadhaar_submit' ORDER BY created_at DESC LIMIT 1");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $aadhaarResponse = json_decode($row['response_data'], true);
        
        if ($aadhaarResponse && isset($aadhaarResponse['data'])) {
            $data = $aadhaarResponse['data'];
            
            $updateStmt = $conn->prepare("UPDATE users SET aadhaar_name = ?, aadhaar_dob = ?, aadhaar_gender = ?, aadhaar_address = ?, profile_image = ? WHERE email = ?");
            $name = $data['full_name'] ?? $data['name'] ?? '';
            $dob = $data['dob'] ?? '';
            $gender = $data['gender'] ?? $data['sex'] ?? '';
            $address = is_array($data['address']) ? json_encode($data['address']) : ($data['address'] ?? '');
            $profileImage = $data['profile_image'] ?? $data['photo'] ?? '';
            
            $updateStmt->bind_param('ssssss', $name, $dob, $gender, $address, $profileImage, $email);
            $updateStmt->execute();
            $updateStmt->close();
        }
    }
    $stmt->close();
    
    // Fetch PAN API response
    $stmt = $conn->prepare("SELECT response_data FROM api_responses WHERE user_email = ? AND api_type = 'pan' ORDER BY created_at DESC LIMIT 1");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $panResponse = json_decode($row['response_data'], true);
        
        if ($panResponse && isset($panResponse['data'])) {
            $data = $panResponse['data'];
            
            $updateStmt = $conn->prepare("UPDATE users SET pan_name = ?, pan_dob = ?, pan_father_name = ? WHERE email = ?");
            $panName = $data['full_name'] ?? $data['name'] ?? '';
            $panDob = $data['dob'] ?? '';
            $fatherName = $data['father_name'] ?? '';
            
            $updateStmt->bind_param('ssss', $panName, $panDob, $fatherName, $email);
            $updateStmt->execute();
            $updateStmt->close();
        }
    }
    $stmt->close();
}

function getUserProfileData($email, $conn) {
    $stmt = $conn->prepare("SELECT aadhaar_name, aadhaar_dob, aadhaar_gender, aadhaar_address, profile_image, pan_name, pan_dob, pan_father_name FROM users WHERE email = ?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}
?>