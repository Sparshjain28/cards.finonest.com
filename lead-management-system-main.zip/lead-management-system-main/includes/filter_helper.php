<?php
function preserveFiltersInForm($base_url) {
    $params = [];
    
    // Preserve common filter parameters
    $preserve_params = ['filter', 'status', 'search', 'page', 'limit', 'sort', 'order'];
    
    foreach ($preserve_params as $param) {
        if (isset($_GET[$param]) && !empty($_GET[$param])) {
            $params[] = $param . '=' . urlencode($_GET[$param]);
        }
    }
    
    $query_string = !empty($params) ? '?' . implode('&', $params) : '';
    return $base_url . $query_string;
}
?>