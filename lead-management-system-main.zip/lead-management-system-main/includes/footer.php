<!-- footer.php: Bottom Navigation Bar for Mobile -->
<nav class="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-2xl flex justify-around items-end pb-2 pt-1 z-50 md:hidden" style="padding-bottom: max(0.5rem, env(safe-area-inset-bottom));">
    <?php $is_admin = !empty($_SESSION['is_admin']); ?>
    <a href="<?php echo $is_admin ? '../admin/dashboard.php' : '../adviser/dashboard.php'; ?>" class="flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition-all <?php if(basename($_SERVER['PHP_SELF'])=='dashboard.php'){echo 'text-blue-600';}else{echo 'text-slate-500 hover:text-slate-700';} ?>">
        <i class="fas fa-home text-2xl"></i>
        <span class="text-[10px] font-medium">Home</span>
    </a>
    <a href="../leads/leads_updated.php" class="flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition-all <?php if(basename($_SERVER['PHP_SELF'])=='leads.php'){echo 'text-blue-600';}else{echo 'text-slate-500 hover:text-slate-700';} ?>">
        <i class="fas fa-users text-2xl"></i>
        <span class="text-[10px] font-medium">Leads</span>
    </a>
    <button onclick="openApplySheet()" class="flex items-center justify-center w-14 h-14 -mt-8 rounded-full shadow-xl transition-all active:scale-95 <?php if(in_array(basename($_SERVER['PHP_SELF']),['apply.html','apply_card.html','apply_personal.html','apply_select.html'])){echo 'bg-gradient-to-br from-blue-600 to-blue-700';}else{echo 'bg-gradient-to-br from-blue-500 to-blue-600';} ?>">
        <i class="fas fa-plus text-white text-2xl"></i>
    </button>
    <a href="<?php echo $is_admin ? '../admin/payouts.php' : '../adviser/payouts.php'; ?>" class="flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition-all <?php if(basename($_SERVER['PHP_SELF'])=='payouts.php'){echo 'text-blue-600';}else{echo 'text-slate-500 hover:text-slate-700';} ?>">
        <i class="fas fa-money-bill-wave text-2xl"></i>
        <span class="text-[10px] font-medium">Payout</span>
    </a>
    <button onclick="toggleMobileMenu()" class="flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition-all text-slate-500 hover:text-slate-700">
        <i class="fas fa-bars text-2xl"></i>
        <span class="text-[10px] font-medium">Menu</span>
    </button>
</nav>

<!-- Bottom Sheet Overlay -->
<div id="applyOverlay" class="fixed inset-0 bg-black bg-opacity-50 z-[60] hidden transition-opacity duration-300" onclick="closeApplySheet()"></div>

<!-- Bottom Sheet -->
<div id="applySheet" class="fixed bottom-0 left-0 right-0 bg-white rounded-t-3xl shadow-2xl z-[70] transform translate-y-full transition-transform duration-300 md:hidden">
    <div class="p-6">
        <!-- Sheet Handle -->
        <div class="w-12 h-1 bg-slate-300 rounded-full mx-auto mb-4"></div>
        
        <!-- Title -->
        <h3 class="text-xl font-bold text-slate-800 mb-6">Apply For</h3>
        
        <!-- Options -->
        <div class="space-y-3">
            <!-- Credit Card -->
            <a href="../forms/apply_card.php" class="flex items-center p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl hover:shadow-md transition-all active:scale-95">
                <div class="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mr-4">
                    <i class="fas fa-credit-card text-white text-xl"></i>
                </div>
                <div class="flex-1">
                    <h4 class="font-semibold text-slate-800">Credit Card</h4>
                    <p class="text-xs text-slate-600">Apply for credit card</p>
                </div>
                <i class="fas fa-chevron-right text-slate-400"></i>
            </a>
            
            <!-- Personal Loan -->
            <a href="../forms/apply_personal.php" class="flex items-center p-4 bg-gradient-to-r from-green-50 to-green-100 rounded-xl hover:shadow-md transition-all active:scale-95">
                <div class="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center mr-4">
                    <i class="fas fa-file-invoice-dollar text-white text-xl"></i>
                </div>
                <div class="flex-1">
                    <h4 class="font-semibold text-slate-800">Personal Loan</h4>
                    <p class="text-xs text-slate-600">Apply for personal loan</p>
                </div>
                <i class="fas fa-chevron-right text-slate-400"></i>
            </a>
            
            <!-- Car Loan -->
            <a href="../forms/apply_car.php" class="flex items-center p-4 bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl hover:shadow-md transition-all active:scale-95">
                <div class="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center mr-4">
                    <i class="fas fa-car text-white text-xl"></i>
                </div>
                <div class="flex-1">
                    <h4 class="font-semibold text-slate-800">Car Loan</h4>
                    <p class="text-xs text-slate-600">Apply for car loan</p>
                </div>
                <i class="fas fa-chevron-right text-slate-400"></i>
            </a>
            
            <!-- Offline Personal Loan -->
            <a href="../forms/offline_pl_form.php" class="flex items-center p-4 bg-gradient-to-r from-indigo-50 to-indigo-100 rounded-xl hover:shadow-md transition-all active:scale-95">
                <div class="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center mr-4">
                    <i class="fas fa-file-alt text-white text-xl"></i>
                </div>
                <div class="flex-1">
                    <h4 class="font-semibold text-slate-800">Offline Personal Loan</h4>
                    <p class="text-xs text-slate-600">Direct processing</p>
                </div>
                <i class="fas fa-chevron-right text-slate-400"></i>
            </a>
            
            <!-- Business Loan -->
            <a href="../forms/business_loan_form.php" class="flex items-center p-4 bg-gradient-to-r from-orange-50 to-orange-100 rounded-xl hover:shadow-md transition-all active:scale-95">
                <div class="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center mr-4">
                    <i class="fas fa-building text-white text-xl"></i>
                </div>
                <div class="flex-1">
                    <h4 class="font-semibold text-slate-800">Business Loan</h4>
                    <p class="text-xs text-slate-600">Business financing</p>
                </div>
                <i class="fas fa-chevron-right text-slate-400"></i>
            </a>
        </div>
        
        <!-- Safe Area Padding -->
        <div class="h-4"></div>
    </div>
</div>

<style>
/* Bottom Sheet Animations */
#applyOverlay.show {
    display: block;
    animation: fadeIn 0.3s ease-out;
}

#applySheet.show {
    transform: translateY(0);
}

@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* Prevent body scroll when sheet is open */
body.sheet-open {
    overflow: hidden;
}
</style>

<script>
// Open bottom sheet
function openApplySheet() {
    const overlay = document.getElementById('applyOverlay');
    const sheet = document.getElementById('applySheet');
    
    overlay.classList.remove('hidden');
    overlay.classList.add('show');
    document.body.classList.add('sheet-open');
    
    setTimeout(() => {
        sheet.classList.add('show');
    }, 10);
}

// Close bottom sheet
function closeApplySheet() {
    const overlay = document.getElementById('applyOverlay');
    const sheet = document.getElementById('applySheet');
    
    sheet.classList.remove('show');
    overlay.classList.remove('show');
    document.body.classList.remove('sheet-open');
    
    setTimeout(() => {
        overlay.classList.add('hidden');
    }, 300);
}

// Close on ESC key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeApplySheet();
        closeMobileMenu();
    }
});

// Mobile Menu Functions
function toggleMobileMenu() {
    const menu = document.getElementById('mobileMenu');
    const panel = document.getElementById('mobileMenuPanel');
    
    if (menu.classList.contains('hidden')) {
        menu.classList.remove('hidden');
        document.body.classList.add('sheet-open');
        setTimeout(() => {
            panel.classList.remove('translate-x-full');
        }, 10);
    } else {
        closeMobileMenu();
    }
}

function closeMobileMenu() {
    const menu = document.getElementById('mobileMenu');
    const panel = document.getElementById('mobileMenuPanel');
    
    panel.classList.add('translate-x-full');
    document.body.classList.remove('sheet-open');
    setTimeout(() => {
        menu.classList.add('hidden');
    }, 300);
}

// Close mobile menu when clicking overlay
document.addEventListener('click', function(event) {
    const mobileMenu = document.getElementById('mobileMenu');
    if (event.target === mobileMenu) {
        closeMobileMenu();
    }
});
</script>

<!-- Mobile Menu Overlay -->
<div id="mobileMenu" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden md:hidden">
    <div class="fixed right-0 top-0 h-full w-80 bg-white shadow-lg transform translate-x-full transition-transform duration-300" id="mobileMenuPanel">
        <div class="p-4 border-b flex items-center justify-between">
            <h3 class="font-semibold text-slate-900">Menu</h3>
            <button onclick="closeMobileMenu()" class="text-slate-500 hover:text-slate-700">
                <i class="fas fa-times text-lg"></i>
            </button>
        </div>
        <div class="p-4">
            <?php
            $current_user = getCurrentUser();
            $is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
            $is_adviser = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 0;
            ?>
            <div class="flex items-center space-x-3 mb-6 pb-4 border-b">
                <?php if (!empty($current_user['profile_image'])): ?>
                    <img src="<?= htmlspecialchars($current_user['profile_image']) ?>" alt="Profile" class="w-12 h-12 rounded-full object-cover">
                <?php else: ?>
                    <div class="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-lg font-semibold">
                        <?= strtoupper(substr($current_user['name'] ?? 'U', 0, 1)) ?>
                    </div>
                <?php endif; ?>
                <div>
                    <p class="font-semibold text-slate-900"><?= htmlspecialchars($current_user['name'] ?? 'User') ?></p>
                    <p class="text-sm text-slate-500"><?= htmlspecialchars($current_user['email'] ?? '') ?></p>
                </div>
            </div>
            <nav class="space-y-2">
                <a href="<?php echo $is_admin ? '/admin/dashboard.php' : ($is_adviser ? '/adviser/dashboard.php' : '/login.php'); ?>" class="flex items-center space-x-3 p-3 text-slate-700 hover:bg-slate-100 rounded-lg">
                    <i class="fas fa-home text-blue-600 w-5"></i>
                    <span>Home</span>
                </a>
                <a href="<?php echo $is_admin ? '/admin/products.php' : '/forms/apply_select.php'; ?>" class="flex items-center space-x-3 p-3 text-slate-700 hover:bg-slate-100 rounded-lg">
                    <i class="fas fa-cube text-green-600 w-5"></i>
                    <span>Products</span>
                </a>
                <a href="/leads/leads_updated.php" class="flex items-center space-x-3 p-3 text-slate-700 hover:bg-slate-100 rounded-lg">
                    <i class="fas fa-users text-purple-600 w-5"></i>
                    <span>Leads</span>
                </a>
                <a href="<?php echo $is_admin ? '/admin/payouts.php' : ($is_adviser ? '/adviser/payouts.php' : '/login.php'); ?>" class="flex items-center space-x-3 p-3 text-slate-700 hover:bg-slate-100 rounded-lg">
                    <i class="fas fa-wallet text-orange-600 w-5"></i>
                    <span>Payouts</span>
                </a>
                <?php if ($is_adviser): ?>
                <a href="/adviser/refer_and_earn.php" class="flex items-center space-x-3 p-3 text-slate-700 hover:bg-slate-100 rounded-lg">
                    <i class="fas fa-users-cog text-indigo-600 w-5"></i>
                    <span>My Team</span>
                </a>
                <?php endif; ?>
                <a href="/pages/profile.php" class="flex items-center space-x-3 p-3 text-slate-700 hover:bg-slate-100 rounded-lg">
                    <i class="fas fa-user text-slate-600 w-5"></i>
                    <span>Profile</span>
                </a>
                <a href="/Auth/logout.php" class="flex items-center space-x-3 p-3 text-red-600 hover:bg-red-50 rounded-lg">
                    <i class="fas fa-sign-out-alt text-red-600 w-5"></i>
                    <span>Logout</span>
                </a>
            </nav>
        </div>
    </div>
</div>
