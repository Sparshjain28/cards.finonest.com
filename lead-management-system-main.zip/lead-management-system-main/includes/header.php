<!-- header.php: Reusable header for all pages -->
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fino Cards</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Tailwind-like utilities -->
    <style>
    .bg-slate-50 { background-color: #f8fafc; }
    .text-slate-700 { color: #334155; }
    .text-slate-900 { color: #0f172a; }
    .text-blue-600 { color: #2563eb; }
    .bg-blue-600 { background-color: #2563eb; }
    .rounded-xl { border-radius: 0.75rem; }
    .shadow-sm { box-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05); }
    .min-h-screen { min-height: 100vh; }
    .fixed-card-shape { aspect-ratio: 1.6/1; min-height: 200px; display: flex; flex-direction: column; }
    a { text-decoration: none !important; }
    a:hover { text-decoration: none !important; }
    .card-icon { width: 48px; height: 48px; display: flex; align-items: center; justify-content: center; border-radius: 12px; }
    .card-icon i { font-size: 24px; }
    
    /* Sticky header styles */
    .sticky-header {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        right: 0 !important;
        z-index: 9999 !important;
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
    }
    
    /* Body padding to account for fixed header */
    body {
        padding-top: 70px !important;
    }
    </style>
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/assets/css/style.css">
    <!-- PWA Manifest & Theme Color -->
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#1a73e8">
    <link rel="apple-touch-icon" href="/assets/icons/icon-192.png">
    <!-- PWA Manifest & Theme Color -->
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#1a73e8">
    <!-- iOS PWA support -->
    <link rel="apple-touch-icon" href="/assets/icons/icon-192.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="Finonest">
    <meta name="description" content="Your gateway to premium financial solutions.">
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/app.js"></script>
    <script src="/assets/js/cookie-clear.js"></script>
</head>
<body class="bg-slate-50 min-h-screen">
    <div id="loader" class="loader"><div class="spinner"></div></div>
<header class="sticky-header w-full bg-white shadow-md py-2.5 px-4 flex items-center justify-between">
    <?php
    $current_page = basename($_SERVER['PHP_SELF']);
    if ($current_page != 'index.php' && $current_page != 'dashboard.php'): ?>
        <button onclick="history.back()" class="text-slate-700 hover:text-blue-600 font-medium mr-3 md:hidden">
            <i class="fas fa-arrow-left"></i>
        </button>
    <?php endif; ?>
    <div class="flex-1 flex justify-center md:justify-start">
        <?php
        // Redirect to appropriate home page based on user role
        $homeUrl = '/';
        if (isLoggedIn()) {
            if (isAdmin()) {
                $homeUrl = '/admin/dashboard.php';
            } elseif (isManager()) {
                $homeUrl = '/manager/dashboard.php';
            } else {
                $homeUrl = '/adviser/dashboard.php';
            }
        }
        ?>
        <a href="<?php echo $homeUrl; ?>" class="flex items-center">
            <img src="/assets/logo.jpeg" alt="Logo" class="h-8 w-auto sm:h-10">
        </a>
    </div>
    
    <!-- Current Time Display -->
    <div class="absolute left-1/2 transform -translate-x-1/2 hidden md:block">
        <div id="currentTime" class="text-sm font-semibold text-slate-700"></div>
    </div>
    <div class="flex items-center space-x-4">
    <?php
        $is_admin = isAdmin();
        $is_manager = isManager();
        $is_adviser = !$is_admin && !$is_manager;
        $current_user = getCurrentUser();
        
        // Get Aadhaar photo if available
        if (isset($_SESSION['user_id']) && empty($current_user['profile_image'])) {
            require_once __DIR__ . '/kyc_data_handler.php';
            require_once __DIR__ . '/../config/database_updated.php';
            $database = new Database();
            $conn = $database->getConnection();
            $kycHandler = new KYCDataHandler($conn);
            $aadhaarData = $kycHandler->getAadhaarData($_SESSION['user_id']);
            if (!empty($aadhaarData['photo'])) {
                $current_user['profile_image'] = 'data:image/jpeg;base64,' . $aadhaarData['photo'];
            }
        }
    ?>
    <a href="<?php echo $is_admin ? '/admin/dashboard.php' : ($is_manager ? '/manager/dashboard.php' : ($is_adviser ? '/adviser/dashboard.php' : '/login.php')); ?>" class="text-slate-700 hover:text-blue-600 font-medium text-sm hidden md:inline">
        <i class="fas fa-home mr-1"></i>Dashboard
    </a>
    <a href="/leads/leads_updated.php" class="text-slate-700 hover:text-blue-600 font-medium text-sm hidden md:inline">
        <i class="fas fa-users mr-1"></i>Leads
    </a>
    <a href="<?php echo $is_admin ? '/admin/payouts.php' : ($is_manager ? '/admin/payouts.php' : ($is_adviser ? '/adviser/payouts.php' : '/login.php')); ?>" class="text-slate-700 hover:text-blue-600 font-medium text-sm hidden md:inline">
        <i class="fas fa-wallet mr-1"></i>Payouts
    </a>
    <?php if ($is_admin): ?>
    <a href="/admin/notices.php" class="text-slate-700 hover:text-blue-600 font-medium text-sm hidden md:inline">
        <i class="fas fa-bullhorn mr-1"></i>Notices
    </a>
    <?php 
    // Determine correct path to API based on current directory
    $current_dir = dirname($_SERVER['PHP_SELF']);
    $api_path = ($current_dir === '/admin') ? '../api/manage.php' : '/api/manage.php';
    ?>
    <a href="<?php echo $api_path; ?>" class="text-slate-700 hover:text-blue-600 font-medium text-sm hidden md:inline">
        <i class="fas fa-code mr-1"></i>API
    </a>
    <?php endif; ?>
    
    <!-- Profile Dropdown (Desktop Only) -->
    <div class="relative hidden md:block">
        <button onclick="toggleProfile()" class="flex items-center space-x-2 text-slate-700 hover:text-blue-600 font-medium">
            <?php if (!empty($current_user['profile_image'])): ?>
                <img src="<?= htmlspecialchars($current_user['profile_image']) ?>" alt="Profile" class="w-8 h-8 rounded-full object-cover">
            <?php else: ?>
                <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                    <?= strtoupper(substr($current_user['name'] ?? 'U', 0, 1)) ?>
                </div>
            <?php endif; ?>
            <span class="hidden lg:inline"><?= htmlspecialchars($current_user['name'] ?? 'User') ?></span>
            <i class="fas fa-chevron-down text-xs"></i>
        </button>
        <div id="profileDropdown" class="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border hidden z-50">
            <div class="p-4 border-b">
                <div class="flex items-center space-x-3">
                    <?php if (!empty($current_user['profile_image'])): ?>
                        <img src="<?= htmlspecialchars($current_user['profile_image']) ?>" alt="Profile" class="w-12 h-12 rounded-full object-cover">
                    <?php else: ?>
                        <div class="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-lg font-semibold">
                            <?= strtoupper(substr($current_user['name'] ?? 'U', 0, 1)) ?>
                        </div>
                    <?php endif; ?>
                    <div>
                        <p class="font-semibold text-slate-900"><?= htmlspecialchars($current_user['name'] ?? 'User') ?></p>
                        <p class="text-sm text-slate-500"><?= htmlspecialchars($current_user['email'] ?? '') ?></p>
                        <p class="text-xs text-blue-600"><?= ucfirst($current_user['user_type'] ?? 'User') ?></p>
                    </div>
                </div>
            </div>
            
            <?php if (!empty($current_user['bank_name'])): ?>
            <div class="p-4 border-b bg-slate-50">
                <h4 class="text-xs font-semibold text-slate-700 mb-2">Banking Information</h4>
                <div class="space-y-1 text-xs">
                    <div class="flex justify-between">
                        <span class="text-slate-500">Bank:</span>
                        <span class="text-slate-900"><?= htmlspecialchars($current_user['bank_name'] ?? 'N/A') ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-slate-500">Account:</span>
                        <span class="text-slate-900"><?= htmlspecialchars($current_user['account_number'] ?? 'N/A') ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-slate-500">IFSC:</span>
                        <span class="text-slate-900"><?= htmlspecialchars($current_user['ifsc_code'] ?? 'N/A') ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-slate-500">PAN:</span>
                        <span class="text-slate-900"><?= htmlspecialchars($current_user['pan_number'] ?? 'N/A') ?></span>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="p-2">
                <a href="/pages/profile.php" class="block px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 rounded">
                    <i class="fas fa-user mr-2"></i>Profile
                </a>
                <a href="/Auth/logout.php" class="block px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded">
                    <i class="fas fa-sign-out-alt mr-2"></i>Logout
                </a>
            </div>
        </div>
    </div>
    
    </div>
    
    <script>
    function toggleProfile() {
        const dropdown = document.getElementById('profileDropdown');
        dropdown.classList.toggle('hidden');
    }
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(event) {
        const dropdown = document.getElementById('profileDropdown');
        const profileButton = document.querySelector('[onclick="toggleProfile()"]');
        
        if (!profileButton.contains(event.target)) {
            dropdown.classList.add('hidden');
        }
    });
    
    // Update current time
    function updateTime() {
        const now = new Date();
        const options = {
            timeZone: 'Asia/Kolkata',
            hour12: true,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        };
        const timeString = now.toLocaleTimeString('en-IN', options).toUpperCase();
        document.getElementById('currentTime').textContent = timeString;
    }
    
    // Update time immediately and then every second
    updateTime();
    setInterval(updateTime, 1000);
    </script>
</header>

<?php include __DIR__ . '/banking_popup.php'; ?>
