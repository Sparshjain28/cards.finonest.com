<?php
/**
 * Image Orientation Fix Helper
 * Fixes image orientation based on EXIF data
 */

function fixImageOrientation($imagePath) {
    if (!file_exists($imagePath)) {
        return false;
    }
    
    // Check if exif extension is available
    if (!extension_loaded('exif')) {
        error_log('EXIF extension not available for image orientation fix');
        return false;
    }
    
    // Check if GD extension is available
    if (!extension_loaded('gd')) {
        error_log('GD extension not available for image processing');
        return false;
    }
    
    // Get image info
    $imageInfo = getimagesize($imagePath);
    if (!$imageInfo) {
        return false;
    }
    
    $mimeType = $imageInfo['mime'];
    
    // Only process JPEG images as they commonly have EXIF orientation data
    if ($mimeType !== 'image/jpeg') {
        return true; // Return true for non-JPEG images (no processing needed)
    }
    
    // Read EXIF data
    $exif = @exif_read_data($imagePath);
    if (!$exif || !isset($exif['Orientation'])) {
        return true; // No orientation data, image is fine as is
    }
    
    $orientation = $exif['Orientation'];
    
    // Only process if rotation is needed
    if ($orientation == 1) {
        return true; // Normal orientation, no rotation needed
    }
    
    // Check image dimensions to avoid unnecessary processing
    $width = $imageInfo[0];
    $height = $imageInfo[1];
    
    // If image is already taller than wide and orientation is normal, skip processing
    if ($orientation == 1 && $height > $width) {
        return true; // Already vertical, no processing needed
    }
    
    // Load the image
    $image = imagecreatefromjpeg($imagePath);
    if (!$image) {
        error_log('Failed to load JPEG image: ' . $imagePath);
        return false;
    }
    
    // Rotate based on orientation
    $rotatedImage = null;
    switch ($orientation) {
        case 3:
            $rotatedImage = imagerotate($image, 180, 0);
            break;
        case 6:
            $rotatedImage = imagerotate($image, -90, 0);
            break;
        case 8:
            $rotatedImage = imagerotate($image, 90, 0);
            break;
        case 2:
            // Flip horizontal
            imageflip($image, IMG_FLIP_HORIZONTAL);
            $rotatedImage = $image;
            break;
        case 4:
            // Flip vertical
            imageflip($image, IMG_FLIP_VERTICAL);
            $rotatedImage = $image;
            break;
        case 5:
            // Rotate 90° and flip horizontal
            $rotatedImage = imagerotate($image, 90, 0);
            if ($rotatedImage) {
                imageflip($rotatedImage, IMG_FLIP_HORIZONTAL);
            }
            break;
        case 7:
            // Rotate -90° and flip horizontal
            $rotatedImage = imagerotate($image, -90, 0);
            if ($rotatedImage) {
                imageflip($rotatedImage, IMG_FLIP_HORIZONTAL);
            }
            break;
        default:
            // Unknown orientation, keep original
            $rotatedImage = $image;
    }
    
    if (!$rotatedImage) {
        imagedestroy($image);
        error_log('Failed to rotate image: ' . $imagePath);
        return false;
    }
    
    // Save the corrected image with high quality
    $result = imagejpeg($rotatedImage, $imagePath, 95);
    
    // Clean up memory
    if ($rotatedImage !== $image) {
        imagedestroy($image);
    }
    imagedestroy($rotatedImage);
    
    if ($result) {
        error_log('Image orientation fixed: ' . $imagePath . ' (orientation: ' . $orientation . ')');
    }
    
    return $result;
}

function processUploadedImage($tmpPath, $destPath) {
    // Move the uploaded file first
    if (!move_uploaded_file($tmpPath, $destPath)) {
        error_log('Failed to move uploaded file from ' . $tmpPath . ' to ' . $destPath);
        return false;
    }
    
    // Fix orientation
    $orientationFixed = fixImageOrientation($destPath);
    
    if (!$orientationFixed) {
        error_log('Image orientation fix failed for: ' . $destPath);
        // Don't return false here as the file was uploaded successfully
        // The orientation fix is a bonus feature
    }
    
    return true;
}

function saveBase64ImageWithOrientation($base64String, $prefix) {
    if (empty($base64String)) return null;
    
    if (strpos($base64String, 'base64,') !== false) {
        $base64String = explode('base64,', $base64String)[1];
    }
    
    $data = base64_decode($base64String);
    if (!$data) return null;

    $filename = $prefix . '_' . time() . '_' . rand(1000,9999) . '.jpg';
    $dest = __DIR__ . '/../assets/cards/' . $filename;
    
    if (!is_dir(__DIR__ . '/../assets/cards')) { 
        mkdir(__DIR__ . '/../assets/cards', 0777, true); 
    }
    
    if (file_put_contents($dest, $data)) {
        // Fix orientation after saving
        fixImageOrientation($dest);
        return 'assets/cards/' . $filename;
    }
    
    return null;
}
?>