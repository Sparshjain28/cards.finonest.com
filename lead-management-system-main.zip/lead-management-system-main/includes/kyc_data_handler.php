<?php
class KYCDataHandler {
    private $conn;
    
    public function __construct($connection) {
        $this->conn = $connection;
    }
    
    public function saveAadhaarData($userId, $email, $aadhaarData) {
        $stmt = $this->conn->prepare("INSERT INTO aadhaar_verifications (user_id, user_email, aadhaar_number, name, dob, gender, house, street, locality, landmark, district, state, pincode, full_address, photo, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
        
        $addressParts = [];
        if (!empty($aadhaarData['house'])) $addressParts[] = $aadhaarData['house'];
        if (!empty($aadhaarData['street'])) $addressParts[] = $aadhaarData['street'];
        if (!empty($aadhaarData['locality'])) $addressParts[] = $aadhaarData['locality'];
        if (!empty($aadhaarData['landmark'])) $addressParts[] = $aadhaarData['landmark'];
        if (!empty($aadhaarData['district'])) $addressParts[] = $aadhaarData['district'];
        if (!empty($aadhaarData['state'])) $addressParts[] = $aadhaarData['state'];
        if (!empty($aadhaarData['pincode'])) $addressParts[] = $aadhaarData['pincode'];
        $fullAddress = implode(', ', $addressParts);
        
        $stmt->bind_param('issssssssssssss', 
            $userId, $email, $aadhaarData['aadhaar_number'], $aadhaarData['name'], 
            $aadhaarData['dob'], $aadhaarData['gender'], $aadhaarData['house'], 
            $aadhaarData['street'], $aadhaarData['locality'], $aadhaarData['landmark'],
            $aadhaarData['district'], $aadhaarData['state'], $aadhaarData['pincode'],
            $fullAddress, $aadhaarData['photo']
        );
        
        return $stmt->execute();
    }
    
    public function savePANData($userId, $email, $panData) {
        // Check for name matching with Aadhaar data
        $status = 'pending';
        $aadhaarData = $this->getAadhaarData($userId);
        
        if ($aadhaarData && $this->checkNameMatch($aadhaarData['name'], $panData['full_name'])) {
            $status = 'approved';
            error_log("Auto-approved KYC for user $userId - Name match found");
        }
        
        $stmt = $this->conn->prepare("INSERT INTO pan_verifications (user_id, user_email, pan_number, full_name, first_name, middle_name, last_name, dob, father_name, gender, aadhaar_link_status, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        if (!$stmt) {
            error_log("PAN prepare failed: " . $this->conn->error);
            return false;
        }
        
        $stmt->bind_param('isssssssssss',
            $userId, $email, $panData['pan_number'], $panData['full_name'],
            $panData['first_name'], $panData['middle_name'], $panData['last_name'],
            $panData['dob'], $panData['father_name'], $panData['gender'],
            $panData['aadhaar_link_status'], $status
        );
        
        $result = $stmt->execute();
        if (!$result) {
            error_log("PAN execute failed: " . $stmt->error);
        }
        
        return $result;
    }
    
    public function saveBankData($userId, $email, $bankData) {
        error_log("Saving bank data: " . json_encode($bankData));

        // Convert boolean to integer
        $accountExists = $bankData['account_exists'] ? 1 : 0;

        // Insert + Update (Upsert)
        $stmt = $this->conn->prepare("
            INSERT INTO bank_verifications 
            (user_id, user_email, account_number, ifsc_code, bank_name, branch_name, account_holder_name, account_exists, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')
            ON DUPLICATE KEY UPDATE
                account_number = VALUES(account_number),
                ifsc_code = VALUES(ifsc_code),
                bank_name = VALUES(bank_name),
                branch_name = VALUES(branch_name),
                account_holder_name = VALUES(account_holder_name),
                account_exists = VALUES(account_exists),
                status = 'pending',
                verified_at = NOW()
        ");

        if (!$stmt) {
            error_log('Bank prepare failed: ' . $this->conn->error);
            return false;
        }

        $stmt->bind_param(
            'issssssi',
            $userId,
            $email,
            $bankData['account_number'],
            $bankData['ifsc_code'],
            $bankData['bank_name'],
            $bankData['branch_name'],
            $bankData['account_holder_name'],
            $accountExists
        );

        $result = $stmt->execute();

        if (!$result) {
            error_log("Bank execute failed: " . $stmt->error);
        }

        $stmt->close();
        return $result;
    }
    
    public function getAadhaarData($userId) {
        $stmt = $this->conn->prepare("SELECT * FROM aadhaar_verifications WHERE user_id = ? ORDER BY verified_at DESC LIMIT 1");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result;
    }
    
    public function deleteUserKYCData($userId) {
        try {
            $this->conn->autocommit(false);
            
            $tables = ['aadhaar_verifications', 'pan_verifications', 'bank_verifications', 'api_responses', 'user_notice_reads'];
            
            foreach ($tables as $table) {
                $stmt = $this->conn->prepare("DELETE FROM $table WHERE user_id = ?");
                if ($stmt) {
                    $stmt->bind_param('i', $userId);
                    $stmt->execute();
                    $stmt->close();
                }
            }
            
            $this->conn->commit();
            $this->conn->autocommit(true);
            return true;
        } catch (Exception $e) {
            $this->conn->rollback();
            $this->conn->autocommit(true);
            return false;
        }
    }
    
    public function getPANData($userId) {
        $stmt = $this->conn->prepare("SELECT * FROM pan_verifications WHERE user_id = ? ORDER BY verified_at DESC LIMIT 1");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    public function getBankData($userId) {
        $stmt = $this->conn->prepare("SELECT * FROM bank_verifications WHERE user_id = ? ORDER BY verified_at DESC LIMIT 1");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    private function checkNameMatch($aadhaarName, $panName) {
        // Normalize names for comparison
        $aadhaarName = strtolower(trim(preg_replace('/\s+/', ' ', $aadhaarName)));
        $panName = strtolower(trim(preg_replace('/\s+/', ' ', $panName)));
        
        // Direct match
        if ($aadhaarName === $panName) {
            return true;
        }
        
        // Check if names contain same words (order independent)
        $aadhaarWords = explode(' ', $aadhaarName);
        $panWords = explode(' ', $panName);
        
        // At least 80% words should match
        $matchCount = 0;
        foreach ($aadhaarWords as $word) {
            if (in_array($word, $panWords)) {
                $matchCount++;
            }
        }
        
        $matchPercentage = ($matchCount / count($aadhaarWords)) * 100;
        return $matchPercentage >= 80;
    }
}
?>