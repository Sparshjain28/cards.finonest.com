<?php
// Margin calculation helper for channel program

/**
 * Calculate and record margin for team leader when referred user generates a lead
 */
function calculateTeamLeaderMargin($conn, $lead_id, $actual_commission, $advisor_user_id) {
    // Get team leader (referrer) for this advisor
    $referrer_query = "SELECT referrer_user_id FROM referral_users WHERE referred_user_id = ? AND level = 1 LIMIT 1";
    $stmt = $conn->prepare($referrer_query);
    $stmt->bind_param("i", $advisor_user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $referrer = $result->fetch_assoc();
    $stmt->close();
    
    if (!$referrer) return;
    
    $team_leader_id = $referrer['referrer_user_id'];
    
    // Get lead details
    $lead_query = "SELECT product_id FROM leads WHERE id = ?";
    $stmt = $conn->prepare($lead_query);
    $stmt->bind_param("i", $lead_id);
    $stmt->execute();
    $lead_result = $stmt->get_result();
    $lead_data = $lead_result->fetch_assoc();
    $stmt->close();
    
    if (!$lead_data) return;
    
    // Get payout setting for this advisor and product (set by team leader)
    $payout_query = "SELECT payout_rate FROM payout_settings WHERE user_id = ? AND advisor_user_id = ? AND (product_id = ? OR product_id IS NULL) ORDER BY product_id DESC LIMIT 1";
    $stmt = $conn->prepare($payout_query);
    $stmt->bind_param("iii", $team_leader_id, $advisor_user_id, $lead_data['product_id']);
    $stmt->execute();
    $payout_result = $stmt->get_result();
    $payout_setting = $payout_result->fetch_assoc();
    $stmt->close();
    
    if (!$payout_setting) return;
    
    $set_amount = $payout_setting['payout_rate'];
    $margin_amount = $actual_commission - $set_amount;
    
    // Record advisor earning (the set amount) in payout_ledger
    $advisor_query = "INSERT INTO payout_ledger (user_id, source_user_id, lead_id, level, earning_type, amount, product_id, status, created_at) VALUES (?, ?, ?, 1, 'referral', ?, ?, 'pending', NOW())";
    $stmt = $conn->prepare($advisor_query);
    $stmt->bind_param("iiidi", $advisor_user_id, $team_leader_id, $lead_id, $set_amount, $lead_data['product_id']);
    $stmt->execute();
    $stmt->close();
    
    // Record margin earning for team leader
    if ($margin_amount > 0) {
        $margin_query = "INSERT INTO payout_ledger (user_id, source_user_id, lead_id, level, earning_type, amount, product_id, status, created_at) VALUES (?, ?, ?, 1, 'margin', ?, ?, 'pending', NOW())";
        $stmt = $conn->prepare($margin_query);
        $stmt->bind_param("iiidi", $team_leader_id, $advisor_user_id, $lead_id, $margin_amount, $lead_data['product_id']);
        $stmt->execute();
        $stmt->close();
    }
    
    // Update advisor payout to set amount only
    $update_payout = "UPDATE payouts SET commission_amount = ? WHERE lead_id = ?";
    $stmt = $conn->prepare($update_payout);
    $stmt->bind_param("di", $set_amount, $lead_id);
    $stmt->execute();
    $stmt->close();
}

/**
 * Get total margin earnings for a user
 */
function getTotalMarginEarnings($conn, $user_id, $status = null) {
    try {
        $query = "SELECT SUM(amount) as total FROM payout_ledger WHERE user_id = ? AND earning_type = 'margin'";
        $params = [$user_id];
        
        if ($status) {
            $query .= " AND status = ?";
            $params[] = $status;
        }
        
        $stmt = $conn->prepare($query);
        if (!$stmt) return 0;
        
        $stmt->bind_param(str_repeat("i", 1) . str_repeat("s", count($params) - 1), ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();
        
        return $row['total'] ?? 0;
    } catch (Exception $e) {
        return 0;
    }
}
?>