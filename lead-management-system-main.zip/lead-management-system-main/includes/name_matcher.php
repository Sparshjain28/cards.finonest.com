<?php

class KYCNameMatcher {
    
    // Common titles and prefixes to remove
    private $titles = ['mr', 'ms', 'mrs', 'shri', 'sri', 'smt', 'dr', 'prof', 's/o', 'd/o', 'w/o', 'c/o'];
    
    // Common surnames (DO NOT remove these - they're important for identity)
    private $surnames = ['singh', 'sharma', 'kumar', 'gupta', 'agarwal', 'jain', 'shah', 'patel', 'yadav', 'verma'];
    
    /**
     * Main name matching function
     */
    public function matchNames($aadhaarName, $panName, $bankName) {
        // Normalize all names
        $aadhaar = $this->normalizeName($aadhaarName);
        $pan = $this->normalizeName($panName);
        $bank = $this->normalizeName($bankName);
        
        // Tokenize names
        $aadhaarTokens = $this->tokenizeName($aadhaar);
        $panTokens = $this->tokenizeName($pan);
        $bankTokens = $this->tokenizeName($bank);
        
        // Get first name from Aadhaar (most reliable source)
        $firstName = $aadhaarTokens[0] ?? '';
        
        if (empty($firstName)) {
            return $this->createResponse('REJECT', false, false, 0);
        }
        
        // Check for exact matches
        $panMatch = $this->hasExactTokenMatch($firstName, $panTokens);
        $bankMatch = $this->hasExactTokenMatch($firstName, $bankTokens);
        
        // Check for joined name matches (SANAM PREET -> SANAMPREET)
        $joinedName = $this->createJoinedName($aadhaarTokens);
        $panJoinedMatch = $joinedName ? $this->hasExactTokenMatch($joinedName, $panTokens) : false;
        $bankJoinedMatch = $joinedName ? $this->hasExactTokenMatch($joinedName, $bankTokens) : false;
        
        // AUTO_APPROVE: First name exists in both PAN and Bank
        if (($panMatch && $bankMatch) || ($panJoinedMatch && $bankJoinedMatch)) {
            return $this->createResponse('AUTO_APPROVE', true, false, 100);
        }
        
        // AUTO_APPROVE: Joined name exists in Bank (common case)
        if ($bankJoinedMatch && $panMatch) {
            return $this->createResponse('AUTO_APPROVE', true, false, 95);
        }
        
        // Check if only surname matches (REJECT case)
        if ($this->isOnlySurnameMatch($aadhaarTokens, $panTokens, $bankTokens)) {
            return $this->createResponse('REJECT', false, false, 10);
        }
        
        // MANUAL_REVIEW: First name exists in only one source
        if ($panMatch || $bankMatch || $panJoinedMatch || $bankJoinedMatch) {
            return $this->createResponse('MANUAL_REVIEW', false, true, 70);
        }
        
        // Check fuzzy similarity for potential spelling mistakes
        $fuzzyScore = $this->calculateFuzzyScore($firstName, $panTokens, $bankTokens);
        
        if ($fuzzyScore >= 80) {
            return $this->createResponse('MANUAL_REVIEW', false, true, $fuzzyScore);
        }
        
        // REJECT: No meaningful match found
        return $this->createResponse('REJECT', false, false, $fuzzyScore);
    }
    
    /**
     * Normalize name by removing special characters and titles
     */
    private function normalizeName($name) {
        if (empty($name)) return '';
        
        // Convert to lowercase
        $name = strtolower(trim($name));
        
        // Remove special characters except spaces
        $name = preg_replace('/[^a-z\s]/', ' ', $name);
        
        // Remove extra spaces
        $name = preg_replace('/\s+/', ' ', $name);
        
        // Remove titles
        $tokens = explode(' ', $name);
        $tokens = array_filter($tokens, function($token) {
            return !in_array($token, $this->titles) && strlen($token) > 1;
        });
        
        return implode(' ', $tokens);
    }
    
    /**
     * Tokenize name into individual words
     */
    private function tokenizeName($name) {
        return array_filter(explode(' ', $name), function($token) {
            return strlen($token) > 1; // Ignore single characters
        });
    }
    
    /**
     * Check if a token exists exactly in the token array
     */
    private function hasExactTokenMatch($searchToken, $tokens) {
        return in_array($searchToken, $tokens, true);
    }
    
    /**
     * Create joined name from first two tokens (SANAM PREET -> SANAMPREET)
     */
    private function createJoinedName($tokens) {
        if (count($tokens) >= 2) {
            return $tokens[0] . $tokens[1];
        }
        return null;
    }
    
    /**
     * Check if only surname matches (should be rejected)
     */
    private function isOnlySurnameMatch($aadhaarTokens, $panTokens, $bankTokens) {
        // Get potential surnames from Aadhaar
        $aadhaarSurnames = array_intersect($aadhaarTokens, $this->surnames);
        
        if (empty($aadhaarSurnames)) {
            return false;
        }
        
        // Check if only surnames match in other documents
        foreach ($aadhaarSurnames as $surname) {
            $panHasSurname = in_array($surname, $panTokens);
            $bankHasSurname = in_array($surname, $bankTokens);
            
            // If surname matches but no first name matches, it's surname-only
            if (($panHasSurname || $bankHasSurname)) {
                $firstName = $aadhaarTokens[0] ?? '';
                $panFirstMatch = in_array($firstName, $panTokens);
                $bankFirstMatch = in_array($firstName, $bankTokens);
                
                if (!$panFirstMatch && !$bankFirstMatch) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * Calculate fuzzy similarity score using Levenshtein distance
     */
    private function calculateFuzzyScore($firstName, $panTokens, $bankTokens) {
        $maxScore = 0;
        $allTokens = array_merge($panTokens, $bankTokens);
        
        foreach ($allTokens as $token) {
            // Skip if it's a surname-only match
            if (in_array($token, $this->surnames) && !in_array($firstName, $this->surnames)) {
                continue;
            }
            
            $similarity = $this->calculateLevenshteinSimilarity($firstName, $token);
            $maxScore = max($maxScore, $similarity);
        }
        
        return $maxScore;
    }
    
    /**
     * Calculate Levenshtein similarity percentage
     */
    private function calculateLevenshteinSimilarity($str1, $str2) {
        $len1 = strlen($str1);
        $len2 = strlen($str2);
        
        if ($len1 == 0 || $len2 == 0) {
            return 0;
        }
        
        $distance = levenshtein($str1, $str2);
        $maxLen = max($len1, $len2);
        
        return round((1 - $distance / $maxLen) * 100);
    }
    
    /**
     * Create standardized response
     */
    private function createResponse($result, $approved, $manualReview, $score) {
        return [
            'approved' => $approved,
            'manual_review' => $manualReview,
            'result' => $result,
            'score' => $score
        ];
    }
}

// Usage example and test cases
if (basename(__FILE__) == basename($_SERVER['PHP_SELF'])) {
    $matcher = new KYCNameMatcher();
    
    // Test cases
    $testCases = [
        // AUTO_APPROVE cases
        ['SANAM PREET SINGH', 'SANAM SINGH', 'SANAMPREET SINGH', 'Should AUTO_APPROVE - joined name'],
        ['RAMAN KUMAR', 'RAMAN KUMAR SHARMA', 'RAMAN KUMAR', 'Should AUTO_APPROVE - exact match'],
        
        // MANUAL_REVIEW cases
        ['SANAM PREET', 'SANAM SINGH', 'PREET KAUR', 'Should MANUAL_REVIEW - partial match'],
        ['RAMAN KUMAR', 'RAMN KUMAR', 'RAMAN SINGH', 'Should MANUAL_REVIEW - spelling error'],
        
        // REJECT cases
        ['RAMAN KUMAR', 'KUMAR SINGH', 'KUMAR SHARMA', 'Should REJECT - surname only'],
        ['SANAM PREET', 'RAMAN SINGH', 'AMIT KUMAR', 'Should REJECT - no match'],
        ['AM SINGH', 'RAMAN SINGH', 'SHYAM SINGH', 'Should REJECT - substring false positive'],
    ];
    
    echo "<h2>KYC Name Matching Test Results</h2>\n";
    
    foreach ($testCases as $i => $case) {
        $result = $matcher->matchNames($case[0], $case[1], $case[2]);
        
        echo "<div style='margin: 10px 0; padding: 10px; border: 1px solid #ccc;'>\n";
        echo "<strong>Test " . ($i + 1) . ":</strong> {$case[3]}<br>\n";
        echo "Aadhaar: {$case[0]} | PAN: {$case[1]} | Bank: {$case[2]}<br>\n";
        echo "<strong>Result:</strong> {$result['result']} (Score: {$result['score']})<br>\n";
        echo "</div>\n";
    }
}
?>