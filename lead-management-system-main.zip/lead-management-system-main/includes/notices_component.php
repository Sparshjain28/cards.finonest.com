<?php
function getActiveNotices($conn, $user_id) {
    // Get user data including role and partner type
    $user_query = "SELECT u.*, r.name as role_name FROM users u LEFT JOIN roles r ON u.role_id = r.id WHERE u.id = ?";
    $user_stmt = $conn->prepare($user_query);
    $user_stmt->bind_param('i', $user_id);
    $user_stmt->execute();
    $user_data = $user_stmt->get_result()->fetch_assoc();
    $user_stmt->close();
    
    if (!$user_data) {
        return [];
    }
    
    // Determine user role for visibility filtering
    $user_role = 'user'; // default
    
    // Check admin status first
    if (!empty($user_data['is_admin'])) {
        $user_role = 'admin';
    }
    // Check partner type first (priority for notices)
    elseif (!empty($user_data['partner_type'])) {
        $user_role = $user_data['partner_type'];
    }
    // Then check role from roles table
    elseif (!empty($user_data['role_name'])) {
        $user_role = strtolower($user_data['role_name']);
        // Map adviser to advisor for consistency
        if ($user_role === 'adviser') {
            $user_role = 'advisor';
        }
    }
    
    // Build visibility condition based on user role
    $visibility_conditions = [];
    
    // Everyone can see 'all' notices
    $visibility_conditions[] = "n.visibility = 'all'";
    
    // Add specific role visibility
    switch ($user_role) {
        case 'admin':
        case 'manager':
            $visibility_conditions[] = "n.visibility = 'full'";
            break;
        case 'advisor':
        case 'adviser':
            $visibility_conditions[] = "n.visibility = 'advisor'";
            break;
        case 'channel_partner':
            $visibility_conditions[] = "n.visibility = 'channel_partner'";
            break;
        case 'network_partner':
        case 'network_program':
            $visibility_conditions[] = "n.visibility = 'network_program'";
            break;
    }
    
    $visibility_condition = "AND (" . implode(' OR ', $visibility_conditions) . ")";
    
    $query = "SELECT n.* FROM notices n 
              LEFT JOIN user_notice_reads unr ON n.id = unr.notice_id AND unr.user_id = ?
              WHERE n.is_active = 1 
              AND (n.expires_at IS NULL OR n.expires_at > NOW())
              AND unr.id IS NULL
              $visibility_condition
              ORDER BY n.created_at DESC";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    return $result;
}

function markNoticeAsRead($conn, $user_id, $notice_id) {
    $stmt = $conn->prepare("INSERT IGNORE INTO user_notice_reads (user_id, notice_id) VALUES (?, ?)");
    $stmt->bind_param('ii', $user_id, $notice_id);
    $stmt->execute();
    $stmt->close();
}

function renderNotices($notices) {
    if (empty($notices)) return '';
    
    ob_start();
    ?>
    <div id="noticesContainer" class="mb-6">
        <?php foreach ($notices as $notice): ?>
            <div class="notice-alert mb-3 p-4 rounded-lg border-l-4 <?php 
                echo $notice['type'] === 'info' ? 'bg-blue-50 border-blue-400 text-blue-800' : 
                    ($notice['type'] === 'warning' ? 'bg-yellow-50 border-yellow-400 text-yellow-800' : 
                    ($notice['type'] === 'success' ? 'bg-green-50 border-green-400 text-green-800' : 'bg-red-50 border-red-400 text-red-800')); 
            ?>" data-notice-id="<?= $notice['id'] ?>">
                <div class="flex justify-between items-start">
                    <div class="flex-1">
                        <div class="flex items-center gap-2 mb-1">
                            <i class="fas fa-<?php 
                                echo $notice['type'] === 'info' ? 'info-circle' : 
                                    ($notice['type'] === 'warning' ? 'exclamation-triangle' : 
                                    ($notice['type'] === 'success' ? 'check-circle' : 'times-circle')); 
                            ?>"></i>
                            <h4 class="font-semibold"><?= htmlspecialchars($notice['title']) ?></h4>
                        </div>
                        <p class="text-sm"><?= htmlspecialchars($notice['message']) ?></p>
                        <p class="text-xs mt-1 opacity-75"><?= date('M d, Y H:i', strtotime($notice['created_at'])) ?></p>
                    </div>
                    <button onclick="dismissNotice(<?= $notice['id'] ?>)" class="text-gray-500 hover:text-gray-700 ml-4">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <script>
    function dismissNotice(noticeId) {
        fetch('<?= $_SERVER['PHP_SELF'] ?>', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'dismiss_notice=' + noticeId
        }).then(() => {
            document.querySelector('[data-notice-id="' + noticeId + '"]').remove();
        });
    }
    </script>
    <?php
    return ob_get_clean();
}
?>