<?php
require_once __DIR__ . '/../classes/EmailNotification.php';

function notifyUser($type, $userEmail, $data) {
    $emailer = new EmailNotification();
    
    switch($type) {
        case 'lead_created':
            return $emailer->leadCreated($userEmail, $data['lead_id'], $data['product_name']);
        case 'lead_status_update':
            return $emailer->leadStatusUpdate($userEmail, $data['lead_id'], $data['old_status'], $data['new_status']);
        case 'payout_processed':
            return $emailer->payoutProcessed($userEmail, $data['amount'], $data['payout_id']);
        case 'application_submitted':
            return $emailer->applicationSubmitted($userEmail, $data['lead_id'], $data['product_name'], $data['amount']);
        case 'user_signup':
            return $emailer->userSignup($userEmail, $data['user_name'], $data['password'] ?? null);
        case 'user_login':
            return $emailer->userLogin($userEmail, $data['user_name']);
        case 'kyc_status':
            return $emailer->kycStatusUpdate($userEmail, $data['user_name'], $data['status'], $data['remarks'] ?? '');
        default:
            return false;
    }
}
