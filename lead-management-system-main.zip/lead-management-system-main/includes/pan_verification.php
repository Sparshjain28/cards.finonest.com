<?php

function verifyPAN($panNumber, $apiToken = null) {
    if (!$apiToken) {
        $config = require __DIR__ . '/../config/api_config.php';
        $apiToken = $config['surepass']['api_token'];
    }
    
    $url = 'https://kyc-api.surepass.app/api/v1/pan/pan-comprehensive';
    
    $data = json_encode(['id_number' => $panNumber]);
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $apiToken,
        'Content-Type: application/json'
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200) {
        return json_decode($response, true);
    }
    
    return ['success' => false, 'message' => 'API request failed', 'http_code' => $httpCode, 'response' => $response];
}
