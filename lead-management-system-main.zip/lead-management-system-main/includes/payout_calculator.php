<?php
function calculateLeadPayout($commission_rate, $cust_type = null, $bkyc_status = null) {
    $commission_amount = floatval($commission_rate);
    $deduction_amount = 0;
    
    return [
        'commission_amount' => $commission_amount,
        'deduction_amount' => $deduction_amount
    ];
}
?>
