<?php
// Referral Helper Functions for Multi-Level Referral System

/**
 * Recursively trace referral chain to find all ancestors
 * Returns array of ancestor user IDs in order: [direct_referrer, level2_referrer, level3_referrer]
 */
function traceReferralChain($conn, $user_id, $max_level = 3) {
    $chain = [];
    $current_user_id = $user_id;
    $level = 0;
    
    while ($level < $max_level && $current_user_id) {
        // Find who referred this user
        // Check referral_users first (most reliable for direct referrals)
        $query = "SELECT referrer_user_id 
                 FROM referral_users 
                 WHERE referred_user_id = ? AND level = 1
                 LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $current_user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            $referrer_id = $row['referrer_user_id'];
            if ($referrer_id && !in_array($referrer_id, $chain)) {
                $chain[] = $referrer_id;
                $current_user_id = $referrer_id;
                $level++;
            } else {
                break; // Circular reference or no more ancestors
            }
        } else {
            break; // No referrer found
        }
        $stmt->close();
    }
    
    return $chain; // Returns [direct_referrer, level2_referrer, level3_referrer]
}

/**
 * Build referral hierarchy when a new user signs up
 * Logic: Me → A (L1), A → B (L2 for me), B → C (L3 for me)
 */
function buildReferralHierarchy($conn, $new_user_id, $direct_referrer_id) {
    // Get referrer chain: [direct_referrer, level2_referrer, level3_referrer]
    $ancestors = traceReferralChain($conn, $direct_referrer_id, 2);
    
    // Level 1: Direct referrer gets the new user as L1
    $ref_query = "SELECT referral_code, partner_type FROM users WHERE id = ?";
    $stmt = $conn->prepare($ref_query);
    $stmt->bind_param("i", $direct_referrer_id);
    $stmt->execute();
    $ref_info = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($ref_info && $ref_info['partner_type'] === 'network_partner') {
        $insert = "INSERT INTO referral_hierarchy (referrer_user_id, referred_user_id, level, referral_code) 
                   VALUES (?, ?, 1, ?) ON DUPLICATE KEY UPDATE referral_code = ?";
        $stmt = $conn->prepare($insert);
        $stmt->bind_param("iiss", $direct_referrer_id, $new_user_id, $ref_info['referral_code'], $ref_info['referral_code']);
        $stmt->execute();
        $stmt->close();
    }
    
    // Set default payout rates for channel referral program
    if ($ref_info && $ref_info['partner_type'] === 'channel_partner') {
        setDefaultReferralRates($conn, $direct_referrer_id, $new_user_id);
    }
    
    // Level 2: Direct referrer's referrer gets new user as L2
    if (count($ancestors) >= 1) {
        $l2_referrer_id = $ancestors[0];
        $stmt = $conn->prepare($ref_query);
        $stmt->bind_param("i", $l2_referrer_id);
        $stmt->execute();
        $l2_info = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($l2_info && $l2_info['partner_type'] === 'network_partner') {
            $insert = "INSERT INTO referral_hierarchy (referrer_user_id, referred_user_id, level, referral_code) 
                       VALUES (?, ?, 2, ?) ON DUPLICATE KEY UPDATE referral_code = ?";
            $stmt = $conn->prepare($insert);
            $stmt->bind_param("iiss", $l2_referrer_id, $new_user_id, $l2_info['referral_code'], $l2_info['referral_code']);
            $stmt->execute();
            $stmt->close();
        }
    }
    
    // Level 3: L2 referrer's referrer gets new user as L3
    if (count($ancestors) >= 2) {
        $l3_referrer_id = $ancestors[1];
        $stmt = $conn->prepare($ref_query);
        $stmt->bind_param("i", $l3_referrer_id);
        $stmt->execute();
        $l3_info = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($l3_info && $l3_info['partner_type'] === 'network_partner') {
            $insert = "INSERT INTO referral_hierarchy (referrer_user_id, referred_user_id, level, referral_code) 
                       VALUES (?, ?, 3, ?) ON DUPLICATE KEY UPDATE referral_code = ?";
            $stmt = $conn->prepare($insert);
            $stmt->bind_param("iiss", $l3_referrer_id, $new_user_id, $l3_info['referral_code'], $l3_info['referral_code']);
            $stmt->execute();
            $stmt->close();
        }
    }
}

/**
 * Set default referral rates for channel referral program
 * Credit Cards: 500 (₹500)
 * Personal Loans: 1% (1.00)
 */
function setDefaultReferralRates($conn, $referrer_id, $advisor_id) {
    // Get all active products to set default rates
    $products_query = "SELECT id, category FROM products WHERE status = 'active'";
    $products_result = $conn->query($products_query);
    
    while ($product = $products_result->fetch_assoc()) {
        $default_rate = 0;
        $rate_type = 'card_amount';
        
        switch ($product['category']) {
            case 'Credit Card':
                $default_rate = 500; // ₹500
                $rate_type = 'card_amount';
                break;
            case 'Personal Loan':
                $default_rate = 1.00; // 1%
                $rate_type = 'loan_percentage';
                break;
            default:
                continue 2; // Skip this product
        }
        
        // Insert default rate if not already exists
        $insert_query = "INSERT INTO payout_settings 
                        (user_id, advisor_user_id, product_id, product_category, payout_rate, rate_type) 
                        VALUES (?, ?, ?, ?, ?, ?) 
                        ON DUPLICATE KEY UPDATE 
                        payout_rate = IF(payout_rate = 0, VALUES(payout_rate), payout_rate)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("iiisds", $referrer_id, $advisor_id, $product['id'], $product['category'], $default_rate, $rate_type);
        $stmt->execute();
        $stmt->close();
    }
}

/**
 * Get team members by level using proper hierarchy chain
 * This ensures correct level assignment based on referral chain
 */
function getTeamMembersByLevelProper($conn, $user_id, $level, $partner_type) {
    if ($level === 1) {
        // Direct referrals from referral_users
        $query = "SELECT DISTINCT u.id, u.name, u.phone, u.city, u.location, u.created_at,
                         ru.signup_date, ru.status, ru.created_at as referral_date
                  FROM referral_users ru
                  JOIN users u ON ru.referred_user_id = u.id
                  WHERE ru.referrer_user_id = ? AND ru.level = 1
                  ORDER BY ru.signup_date DESC";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $user_id);
    } else {
        // Level 2 and 3: Get from referral_hierarchy
        if ($partner_type === 'network_partner') {
            $query = "SELECT DISTINCT u.id, u.name, u.phone, u.city, u.location, u.created_at,
                             rh.created_at as signup_date, rh.created_at as referral_date, 'active' as status
                      FROM referral_hierarchy rh
                      JOIN users u ON rh.referred_user_id = u.id
                      WHERE rh.referrer_user_id = ? AND rh.level = ?
                      ORDER BY rh.created_at DESC";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ii", $user_id, $level);
        } else {
            return []; // Channel partner only sees L1
        }
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $members = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    return $members;
}

/**
 * Rebuild hierarchy for a specific user
 * Useful for fixing missing hierarchy entries
 */
function rebuildUserHierarchy($conn, $user_id) {
    // Get all users this user directly referred
    $direct_refs_query = "SELECT referred_user_id FROM referral_users WHERE referrer_user_id = ?";
    $stmt = $conn->prepare($direct_refs_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $direct_refs = $stmt->get_result();
    
    while ($ref = $direct_refs->fetch_assoc()) {
        $referred_id = $ref['referred_user_id'];
        // Rebuild hierarchy for this referred user
        buildReferralHierarchy($conn, $referred_id, $user_id);
    }
    $stmt->close();
}

/**
 * Calculate and record payout for network partner
 */
function calculateNetworkPartnerPayout($conn, $lead_id, $payout_amount) {
    // Get the lead's channel_code and find the user
    $lead_query = "SELECT channel_code FROM leads WHERE id = ?";
    $stmt = $conn->prepare($lead_query);
    $stmt->bind_param("i", $lead_id);
    $stmt->execute();
    $lead = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (empty($lead)) return;
    
    $user_query = "SELECT id FROM users WHERE channel_code = ?";
    $stmt = $conn->prepare($user_query);
    $stmt->bind_param("s", $lead['channel_code']);
    $stmt->execute();
    $user_result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (empty($user_result)) return;
    
    $source_user_id = $user_result['id'];
    
    // Find all network partners who should earn from this
    $hierarchy_query = "SELECT DISTINCT referrer_user_id, level 
                       FROM referral_hierarchy 
                       WHERE referred_user_id = ?";
    $stmt = $conn->prepare($hierarchy_query);
    $stmt->bind_param("i", $source_user_id);
    $stmt->execute();
    $hierarchy_result = $stmt->get_result();
    
    $percentages = [1 => 0.05, 2 => 0.02, 3 => 0.01]; // 5%, 2%, 1%
    
    while ($row = $hierarchy_result->fetch_assoc()) {
        $referrer_id = $row['referrer_user_id'];
        $level = $row['level'];
        
        // Check if referrer is network partner
        $partner_check = "SELECT partner_type FROM users WHERE id = ?";
        $check_stmt = $conn->prepare($partner_check);
        $check_stmt->bind_param("i", $referrer_id);
        $check_stmt->execute();
        $partner = $check_stmt->get_result()->fetch_assoc();
        $check_stmt->close();
        
        if ($partner && $partner['partner_type'] === 'network_partner') {
            $earning = $payout_amount * $percentages[$level];
            
            // Get product info
            $product_query = "SELECT l.product_id, p.category FROM leads l 
                             JOIN products p ON l.product_id = p.id 
                             WHERE l.id = ?";
            $prod_stmt = $conn->prepare($product_query);
            $prod_stmt->bind_param("i", $lead_id);
            $prod_stmt->execute();
            $prod_result = $prod_stmt->get_result()->fetch_assoc();
            $prod_stmt->close();
            
            // Insert into payout_ledger
            $ledger_insert = "INSERT INTO payout_ledger 
                              (user_id, source_user_id, lead_id, level, earning_type, amount, product_id, product_category, status) 
                              VALUES (?, ?, ?, ?, 'referral_percentage', ?, ?, ?, 'pending')";
            $ledger_stmt = $conn->prepare($ledger_insert);
            $ledger_stmt->bind_param("iiiidss", 
                $referrer_id, 
                $source_user_id, 
                $lead_id, 
                $level, 
                $earning,
                $prod_result['product_id'] ?? null,
                $prod_result['category'] ?? null
            );
            $ledger_stmt->execute();
            $ledger_stmt->close();
        }
    }
}

/**
 * Calculate and record payout for channel partner
 */
function calculateChannelPartnerPayout($conn, $lead_id, $payout_amount) {
    // Get the lead's channel_code and find the user
    $lead_query = "SELECT channel_code, product_id FROM leads WHERE id = ?";
    $stmt = $conn->prepare($lead_query);
    $stmt->bind_param("i", $lead_id);
    $stmt->execute();
    $lead = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (empty($lead)) return;
    
    $user_query = "SELECT id FROM users WHERE channel_code = ?";
    $stmt = $conn->prepare($user_query);
    $stmt->bind_param("s", $lead['channel_code']);
    $stmt->execute();
    $user_result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (empty($user_result)) return;
    
    $source_user_id = $user_result['id'];
    
    // Find channel partners who have this user as L1
    $referrer_query = "SELECT DISTINCT referrer_user_id 
                       FROM referral_users 
                       WHERE referred_user_id = ? AND level = 1";
    $stmt = $conn->prepare($referrer_query);
    $stmt->bind_param("i", $source_user_id);
    $stmt->execute();
    $referrer_result = $stmt->get_result();
    
    while ($row = $referrer_result->fetch_assoc()) {
        $referrer_id = $row['referrer_user_id'];
        
        // Check if referrer is channel partner
        $partner_check = "SELECT partner_type FROM users WHERE id = ?";
        $check_stmt = $conn->prepare($partner_check);
        $check_stmt->bind_param("i", $referrer_id);
        $check_stmt->execute();
        $partner = $check_stmt->get_result()->fetch_assoc();
        $check_stmt->close();
        
        if ($partner && $partner['partner_type'] === 'channel_partner') {
            // Get payout setting for this advisor and product
            $setting_query = "SELECT payout_rate, rate_type FROM payout_settings 
                             WHERE user_id = ? AND advisor_user_id = ? 
                             AND (product_id = ? OR product_id IS NULL)
                             ORDER BY product_id DESC
                             LIMIT 1";
            $setting_stmt = $conn->prepare($setting_query);
            $setting_stmt->bind_param("iii", $referrer_id, $source_user_id, $lead['product_id']);
            $setting_stmt->execute();
            $setting = $setting_stmt->get_result()->fetch_assoc();
            $setting_stmt->close();
            
            if ($setting) {
                $advisor_payout = $setting['payout_rate'];
                $margin = $payout_amount - $advisor_payout;
                
                if ($margin > 0) {
                    // Get product info
                    $product_query = "SELECT category FROM products WHERE id = ?";
                    $prod_stmt = $conn->prepare($product_query);
                    $prod_stmt->bind_param("i", $lead['product_id']);
                    $prod_stmt->execute();
                    $prod_result = $prod_stmt->get_result()->fetch_assoc();
                    $prod_stmt->close();
                    
                    // Insert into payout_ledger
                    $ledger_insert = "INSERT INTO payout_ledger 
                                      (user_id, source_user_id, lead_id, level, earning_type, amount, product_id, product_category, status) 
                                      VALUES (?, ?, ?, 1, 'margin_control', ?, ?, ?, 'pending')";
                    $ledger_stmt = $conn->prepare($ledger_insert);
                    $ledger_stmt->bind_param("iiiiss", 
                        $referrer_id, 
                        $source_user_id, 
                        $lead_id, 
                        $margin,
                        $lead['product_id'],
                        $prod_result['category'] ?? null
                    );
                    $ledger_stmt->execute();
                    $ledger_stmt->close();
                }
            }
        }
    }
}
