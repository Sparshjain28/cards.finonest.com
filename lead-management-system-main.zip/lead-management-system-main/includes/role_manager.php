<?php
class RoleManager {
    private $conn;
    
    public function __construct($connection) {
        $this->conn = $connection;
    }
    
    public function hasPermission($userId, $permission) {
        $stmt = $this->conn->prepare("
            SELECT 1 FROM users u 
            JOIN roles r ON u.role_id = r.id 
            JOIN role_permissions rp ON r.id = rp.role_id 
            JOIN permissions p ON rp.permission_id = p.id 
            WHERE u.id = ? AND p.name = ?
        ");
        $stmt->bind_param('is', $userId, $permission);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }
    
    public function getUserRole($userId) {
        $stmt = $this->conn->prepare("
            SELECT r.name, r.display_name FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.id = ?
        ");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    public function getUserPermissions($userId) {
        $stmt = $this->conn->prepare("
            SELECT p.name, p.display_name, p.category FROM users u 
            JOIN roles r ON u.role_id = r.id 
            JOIN role_permissions rp ON r.id = rp.role_id 
            JOIN permissions p ON rp.permission_id = p.id 
            WHERE u.id = ?
        ");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $permissions = [];
        while ($row = $result->fetch_assoc()) {
            $permissions[] = $row;
        }
        return $permissions;
    }
    
    public function assignRole($userId, $roleId) {
        $stmt = $this->conn->prepare("UPDATE users SET role_id = ? WHERE id = ?");
        $stmt->bind_param('ii', $roleId, $userId);
        return $stmt->execute();
    }
    
    public function getAllRoles() {
        $result = $this->conn->query("SELECT * FROM roles ORDER BY name");
        $roles = [];
        while ($row = $result->fetch_assoc()) {
            $roles[] = $row;
        }
        return $roles;
    }
    
    public function getAllPermissions() {
        $result = $this->conn->query("SELECT * FROM permissions ORDER BY category, name");
        $permissions = [];
        while ($row = $result->fetch_assoc()) {
            $permissions[$row['category']][] = $row;
        }
        return $permissions;
    }
    
    public function getRolePermissions($roleId) {
        $stmt = $this->conn->prepare("
            SELECT p.id FROM role_permissions rp 
            JOIN permissions p ON rp.permission_id = p.id 
            WHERE rp.role_id = ?
        ");
        $stmt->bind_param('i', $roleId);
        $stmt->execute();
        $result = $stmt->get_result();
        $permissions = [];
        while ($row = $result->fetch_assoc()) {
            $permissions[] = $row['id'];
        }
        return $permissions;
    }

    public function getRolePermissionNames($roleId) {
        $stmt = $this->conn->prepare("
            SELECT p.name FROM role_permissions rp 
            JOIN permissions p ON rp.permission_id = p.id 
            WHERE rp.role_id = ?
        ");
        $stmt->bind_param('i', $roleId);
        $stmt->execute();
        $result = $stmt->get_result();
        $permissions = [];
        while ($row = $result->fetch_assoc()) {
            $permissions[] = $row['name'];
        }
        return $permissions;
    }
    
    public function updateRolePermissions($roleId, $permissionIds) {
        // Delete existing permissions
        $stmt = $this->conn->prepare("DELETE FROM role_permissions WHERE role_id = ?");
        $stmt->bind_param('i', $roleId);
        $stmt->execute();
        
        // Insert new permissions
        if (!empty($permissionIds)) {
            $stmt = $this->conn->prepare("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)");
            $pid = 0; // Temp variable for binding
            $stmt->bind_param('ii', $roleId, $pid);
            
            foreach ($permissionIds as $permissionId) {
                $pid = (int)$permissionId; // Ensure integer
                if (!$stmt->execute()) {
                    // Log error but continue
                    error_log("Result of permission insert for role $roleId, perm $permissionId: " . ($stmt->error ?: 'Success'));
                }
            }
            $stmt->close();
        }
        return true;
    }
    
    // Manager-specific data filtering methods
    public function getManagerAssignedUsers($managerId) {
        $stmt = $this->conn->prepare("
            SELECT u.id, u.name, u.email, r.display_name as role_name 
            FROM users u 
            LEFT JOIN roles r ON u.role_id = r.id 
            WHERE u.assigned_manager_id = ? OR u.id = ?
            ORDER BY u.name
        ");
        $stmt->bind_param('ii', $managerId, $managerId);
        $stmt->execute();
        $result = $stmt->get_result();
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        return $users;
    }
    
    public function getManagerLeadsQuery($managerId) {
        // Return WHERE clause for filtering leads based on manager permissions
        return "(l.channel_code IN (SELECT channel_code FROM users WHERE assigned_manager_id = $managerId) OR l.channel_code IN (SELECT channel_code FROM users WHERE id = $managerId))";
    }
    
    public function getManagerPayoutsQuery($managerId) {
        // Return WHERE clause for filtering payouts based on manager permissions
        return "(p.user_id = $managerId OR EXISTS (
            SELECT 1 FROM users u WHERE u.id = p.user_id AND u.assigned_manager_id = $managerId
        ))";
    }
    
    public function canManagerAccessUser($managerId, $userId) {
        $stmt = $this->conn->prepare("
            SELECT 1 FROM users 
            WHERE id = ? AND (assigned_manager_id = ? OR id = ?)
        ");
        $stmt->bind_param('iii', $userId, $managerId, $managerId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }
    
    public function canManagerAccessLead($managerId, $leadId) {
        $stmt = $this->conn->prepare("
            SELECT 1 FROM leads l
            WHERE l.id = ? AND (
                l.created_by = ? OR 
                l.assigned_to = ? OR 
                EXISTS (SELECT 1 FROM users u WHERE u.id = l.created_by AND u.assigned_manager_id = ?)
            )
        ");
        $stmt->bind_param('iiii', $leadId, $managerId, $managerId, $managerId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }
    
    // Individual manager permission methods
    public function setUserPermission($userId, $permissionName, $granted = true) {
        // Check if user_permissions table exists
        $result = $this->conn->query("SHOW TABLES LIKE 'user_permissions'");
        if ($result->num_rows == 0) {
            return false; // Table doesn't exist
        }
        
        $stmt = $this->conn->prepare("SELECT id FROM permissions WHERE name = ?");
        $stmt->bind_param('s', $permissionName);
        $stmt->execute();
        $result = $stmt->get_result();
        $permission = $result->fetch_assoc();
        
        if (!$permission) return false;
        
        $stmt = $this->conn->prepare("
            INSERT INTO user_permissions (user_id, permission_id, granted) 
            VALUES (?, ?, ?) 
            ON DUPLICATE KEY UPDATE granted = VALUES(granted)
        ");
        $stmt->bind_param('iii', $userId, $permission['id'], $granted);
        return $stmt->execute();
    }
    
    public function getUserSpecificPermissions($userId) {
        $stmt = $this->conn->prepare("
            SELECT p.name, p.display_name, p.category, up.granted
            FROM user_permissions up
            JOIN permissions p ON up.permission_id = p.id
            WHERE up.user_id = ?
        ");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $permissions = [];
        while ($row = $result->fetch_assoc()) {
            $permissions[] = $row;
        }
        return $permissions;
    }
    
    public function removeUserPermission($userId, $permissionName) {
        $stmt = $this->conn->prepare("
            DELETE up FROM user_permissions up
            JOIN permissions p ON up.permission_id = p.id
            WHERE up.user_id = ? AND p.name = ?
        ");
        $stmt->bind_param('is', $userId, $permissionName);
        return $stmt->execute();
    }
}

// Helper function for manager check - moved to auth.php to avoid redeclaration
?>
