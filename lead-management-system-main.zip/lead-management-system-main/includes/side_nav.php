<?php
// side_nav.php - Side navigation for md+ screens
?>
<nav class="hidden md:flex flex-col w-56 min-h-screen bg-white border-r border-slate-200 shadow-lg py-8 px-4 sticky top-0 z-40">
    <div class="mb-8 flex items-center gap-2">
        <img src="assets/img/logo.png" alt="Logo" class="h-8 w-8 rounded-full bg-slate-100" onerror="this.style.display='none'">
        <span class="font-bold text-lg text-blue-700">Fino Cards</span>
    </div>
    <?php $is_admin = !empty($_SESSION['is_admin']); ?>
    <a href="<?php echo $is_admin ? 'admin/dashboard.php' : 'adviser/dashboard.php'; ?>" class="flex items-center gap-3 px-3 py-2 rounded-lg text-slate-700 hover:bg-blue-50 mb-1 font-medium">
        <i class="fas fa-home text-blue-600"></i> Dashboard
    </a>
    <a href="leads/leads_updated.php" class="flex items-center gap-3 px-3 py-2 rounded-lg text-slate-700 hover:bg-blue-50 mb-1 font-medium">
        <i class="fas fa-users text-green-600"></i> Leads
    </a>
    <a href="forms/apply.html" class="flex items-center gap-3 px-3 py-2 rounded-lg text-slate-700 hover:bg-blue-50 mb-1 font-medium">
        <i class="fas fa-plus text-blue-500"></i> New Application
    </a>
    <a href="<?php echo $is_admin ? 'admin/payouts.php' : 'adviser/payouts.php'; ?>" class="flex items-center gap-3 px-3 py-2 rounded-lg text-slate-700 hover:bg-blue-50 mb-1 font-medium">
        <i class="fas fa-money-bill-wave text-purple-600"></i> Payouts
    </a>
    <a href="pages/docs_to_share.php" class="flex items-center gap-3 px-3 py-2 rounded-lg text-slate-700 hover:bg-blue-50 mb-1 font-medium">
        <i class="fas fa-folder-open text-yellow-600"></i> Library
    </a>
    <a href="leads/visiting_card.php" class="flex items-center gap-3 px-3 py-2 rounded-lg text-slate-700 hover:bg-blue-50 mb-1 font-medium">
        <i class="fas fa-user text-slate-600"></i> Profile
    </a>
    <div class="flex-1"></div>
    <a href="?logout=1" class="flex items-center gap-2 px-3 py-2 rounded-lg text-red-600 hover:bg-red-50 font-medium">
        <i class="fas fa-sign-out-alt"></i> Logout
    </a>
</nav>
