<?php
/**
 * Timestamp validation helper for lead accuracy
 */
require_once __DIR__ . '/../config/timezone.php';

/**
 * Validate lead timestamp against HTTP header time
 * @param string $lead_timestamp - The timestamp from lead data
 * @param array $headers - HTTP headers (optional, will use $_SERVER if not provided)
 * @return array - Validation result with status and corrected timestamp
 */
function validateLeadTimestamp($lead_timestamp, $headers = null) {
    // Get header time from HTTP_DATE or current server time
    $header_time = getHeaderTime($headers);
    
    // Parse timestamps with timezone context
    $lead_time = parseTimestamp($lead_timestamp);
    $header_time_dt = parseTimestamp($header_time);
    
    // Calculate time difference in seconds
    $time_diff = abs($header_time_dt->getTimestamp() - $lead_time->getTimestamp());
    
    // Allow 5 minutes tolerance (300 seconds)
    $tolerance = 300;
    
    $result = [
        'is_valid' => $time_diff <= $tolerance,
        'time_difference' => $time_diff,
        'lead_timestamp' => $lead_timestamp,
        'header_timestamp' => $header_time,
        'corrected_timestamp' => $header_time,
        'needs_correction' => $time_diff > $tolerance
    ];
    
    // Log suspicious timestamps
    if ($time_diff > $tolerance) {
        logTimestampIssue($result);
    }
    
    return $result;
}

/**
 * Get accurate time from HTTP headers or server
 */
function getHeaderTime($headers = null) {
    // Try to get time from HTTP headers first
    if ($headers && isset($headers['Date'])) {
        return parseTimestamp($headers['Date'])->format('Y-m-d H:i:s');
    }
    
    // Check $_SERVER for HTTP_DATE
    if (isset($_SERVER['HTTP_DATE'])) {
        return parseTimestamp($_SERVER['HTTP_DATE'])->format('Y-m-d H:i:s');
    }
    
    // Fallback to current server time in IST
    return getAppTimestamp();
}

/**
 * Log timestamp validation issues
 */
function logTimestampIssue($validation_result) {
    $log_dir = __DIR__ . '/../logs';
    if (!is_dir($log_dir)) {
        @mkdir($log_dir, 0755, true);
    }
    
    if (is_dir($log_dir) && is_writable($log_dir)) {
        $log_entry = sprintf(
            "%s [TIMESTAMP_ISSUE] Lead: %s | Header: %s | Diff: %d seconds | IP: %s\n",
            date('Y-m-d H:i:s'),
            $validation_result['lead_timestamp'],
            $validation_result['header_timestamp'],
            $validation_result['time_difference'],
            $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        );
        error_log($log_entry, 3, $log_dir . '/timestamp_validation.log');
    }
}

/**
 * Auto-correct lead timestamp if validation fails
 * @param array $lead_data - Lead data array
 * @return array - Lead data with corrected timestamp
 */
function autoCorrectLeadTimestamp($lead_data) {
    if (!isset($lead_data['created_at'])) {
        $lead_data['created_at'] = getAppTimestamp();
        return $lead_data;
    }
    
    $validation = validateLeadTimestamp($lead_data['created_at']);
    
    if ($validation['needs_correction']) {
        $lead_data['created_at'] = $validation['corrected_timestamp'];
        $lead_data['timestamp_corrected'] = true;
        
        // Log the correction
        error_log(sprintf(
            "Auto-corrected timestamp for lead: %s -> %s",
            $validation['lead_timestamp'],
            $validation['corrected_timestamp']
        ));
    }
    
    return $lead_data;
}

/**
 * Check if timestamp is within business hours (9 AM - 9 PM IST)
 */
function isBusinessHours($timestamp = null) {
    $timestamp = $timestamp ?: getAppTimestamp();
    $hour = (int)parseTimestamp($timestamp)->format('H');
    return $hour >= 9 && $hour <= 21;
}

/**
 * Get timestamp validation stats
 */
function getTimestampValidationStats($conn) {
    $query = "SELECT 
                COUNT(*) as total_leads,
                COUNT(CASE WHEN created_at > NOW() THEN 1 END) as future_timestamps,
                COUNT(CASE WHEN created_at < DATE_SUB(NOW(), INTERVAL 1 DAY) THEN 1 END) as old_timestamps,
                COUNT(CASE WHEN TIME(created_at) NOT BETWEEN '09:00:00' AND '21:00:00' THEN 1 END) as off_hours
              FROM leads 
              WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
    
    $result = $conn->query($query);
    return $result ? $result->fetch_assoc() : [];
}
?>