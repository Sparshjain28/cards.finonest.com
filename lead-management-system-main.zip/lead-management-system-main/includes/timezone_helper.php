<?php
// Timezone helper functions

/**
 * Get current timestamp in IST format for database insertion
 */
function getCurrentTimestamp() {
    return date('Y-m-d H:i:s');
}

/**
 * Get current date in IST format
 */
function getCurrentDate() {
    return date('Y-m-d');
}

/**
 * Debug log for timezone verification
 */
function logTimezone($context = '') {
    $log_dir = __DIR__ . '/../logs';
    if (!is_dir($log_dir)) {
        @mkdir($log_dir, 0755, true);
    }
    if (is_dir($log_dir) && is_writable($log_dir)) {
        $log_entry = date('Y-m-d H:i:s') . " [IST] - $context - PHP TZ: " . date_default_timezone_get() . "\n";
        error_log($log_entry, 3, $log_dir . '/timezone_debug.log');
    }
}

/**
 * Ensure timezone is set correctly
 */
function ensureTimezone() {
    if (date_default_timezone_get() !== 'Asia/Kolkata') {
        date_default_timezone_set('Asia/Kolkata');
    }
}
?>