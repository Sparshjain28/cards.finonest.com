<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/role_manager.php';
require_once __DIR__ . '/config/database_updated.php';

if (isLoggedIn()) {
    $database = new Database();
    $conn = $database->getConnection();
    $roleManager = new RoleManager($conn);
    $role = $roleManager->getUserRole($_SESSION['user_id']);
    
    if ($role) {
        switch($role['name']) {
            case 'admin':
                header('Location: /admin/dashboard.php');
                break;
            case 'manager':
                header('Location: /manager/dashboard.php');
                break;
            default:
                header('Location: /adviser/dashboard.php');
        }
    } else {
        // Get user info to assign default role
        $stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
        $stmt->bind_param('i', $_SESSION['user_id']);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        
        // Assign default role
        $defaultRoleId = $user['is_admin'] ? 1 : 3; // admin or adviser
        // Check if user should be manager (you can add logic here)
        // For now, all non-admin users get adviser role
        $roleManager->assignRole($_SESSION['user_id'], $defaultRoleId);
        
        if ($user['is_admin']) {
            header('Location: /admin/dashboard.php');
        } else {
            header('Location: /adviser/dashboard.php');
        }
    }
    exit();
}

$success = '';
if (isset($_GET['kyc']) && $_GET['kyc'] == 1) {
    $success = 'KYC verification completed successfully. You can now login.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Fino Cards</title>

<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#1e40af">

<link rel="apple-touch-icon" href="/assets/logo.jpeg">
<link rel="icon" href="/assets/logo.jpeg">

<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<link rel="stylesheet" href="/assets/css/loading.css">

<style>
.hero-bg{background:linear-gradient(135deg,#e0e7ff 0%,#1e40af 100%)}
.card{box-shadow:0 10px 20px rgba(30,64,175,.08)}
.logo-img{background:#fff;padding:1rem;border-radius:1rem}
</style>
</head>

<body class="min-h-screen hero-bg flex items-center justify-center p-4">

<div id="loader" class="loader"><div class="spinner"></div></div>

<div class="w-full max-w-3xl bg-white rounded-2xl card p-8 text-center">

<img src="/assets/logo.jpeg" class="mx-auto mb-6 w-44 logo-img">

<h1 class="text-3xl font-extrabold text-blue-700 mb-4">
Fino Cards – Credit Cards & Personal Loans
</h1>

<p class="text-slate-700 mb-6">
Apply online for credit cards and personal loans with quick approval and secure processing.
</p>

<a href="/Auth/login.php"
class="block bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
Sign In
</a>

<button id="pwa-install-btn"
class="mt-4 bg-green-600 text-white px-6 py-3 rounded-lg shadow hover:bg-green-700 font-semibold transition w-full hidden">
<i class="fas fa-download mr-2"></i> Install Fino Cards App
</button>

</div>

<script>
let deferredPrompt;
const installBtn = document.getElementById('pwa-install-btn');

// Register Service Worker
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(reg => console.log('SW registered:', reg))
        .catch(err => console.log('SW registration failed:', err));
}

// Show install button
window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    installBtn.classList.remove('hidden');
});

// Install action
installBtn.addEventListener('click', async () => {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        deferredPrompt = null;
        installBtn.classList.add('hidden');
    }
});

// Hide after install
window.addEventListener('appinstalled', () => {
    installBtn.classList.add('hidden');
});
</script>

<script src="/assets/js/loading.js"></script>

</body>
</html>