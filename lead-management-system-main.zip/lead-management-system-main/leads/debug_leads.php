<?php
// Debug version of leads_updated.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Starting debug...<br>";

try {
    echo "1. Including auth...<br>";
    require_once __DIR__ . '/../includes/auth.php';
    echo "2. Auth included successfully<br>";
    
    echo "3. Checking login...<br>";
    requireLogin();
    echo "4. Login check passed<br>";
    
    echo "5. Getting current user...<br>";
    $user = getCurrentUser();
    echo "6. User: " . ($user ? $user['name'] : 'null') . "<br>";
    
    echo "7. Including database...<br>";
    require_once __DIR__ . '/../config/database_updated.php';
    echo "8. Database included<br>";
    
    echo "9. Creating database connection...<br>";
    $database = new Database();
    $conn = $database->getConnection();
    echo "10. Database connected<br>";
    
    echo "11. Including Lead class...<br>";
    require_once __DIR__ . '/../classes/Lead.php';
    echo "12. Lead class included<br>";
    
    echo "13. Testing simple query...<br>";
    $test_query = $conn->prepare("SELECT COUNT(*) as count FROM leads LIMIT 1");
    $test_query->execute();
    $result = $test_query->get_result()->fetch_assoc();
    echo "14. Query result: " . $result['count'] . " leads found<br>";
    
    echo "15. All checks passed! The issue is likely in the main file logic.<br>";
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "<br>";
    echo "File: " . $e->getFile() . "<br>";
    echo "Line: " . $e->getLine() . "<br>";
} catch (Error $e) {
    echo "FATAL ERROR: " . $e->getMessage() . "<br>";
    echo "File: " . $e->getFile() . "<br>";
    echo "Line: " . $e->getLine() . "<br>";
}
?>