<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../includes/notification_helper.php';

requireLogin();

$user = getCurrentUser();
$database = new Database();
$conn = $database->getConnection();

// Auto-create disbursed_amount column if it doesn't exist
try {
    $check_column = $conn->query("SHOW COLUMNS FROM leads LIKE 'disbursed_amount'");
    if ($check_column && $check_column->num_rows == 0) {
        $conn->query("ALTER TABLE leads ADD COLUMN disbursed_amount DECIMAL(15,2) NULL DEFAULT NULL");
    }
} catch (Exception $e) {
    // Silently continue if column creation fails
    error_log('Column creation failed: ' . $e->getMessage());
}

// Get lead ID
$lead_id = isset($_GET['lead_id']) ? (int) $_GET['lead_id'] : 0;
if (!$lead_id) {
    echo '<div style="padding:2rem; color:red;">Invalid lead ID.</div>';
    exit;
}

// Fetch lead details
$stmt = $conn->prepare("SELECT l.*, p.name as product_name, p.category, p.payout_source, u.name as advisor_name FROM leads l JOIN products p ON l.product_id = p.id LEFT JOIN users u ON l.channel_code = u.channel_code WHERE l.id = ? LIMIT 1");
$stmt->bind_param('i', $lead_id);
$stmt->execute();
$lead = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$lead) {
    echo '<div style="padding:2rem; color:red;">Lead not found.</div>';
    exit;
}

// Handle update (admin editable fields)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($user['is_admin'])) {
    $customer_name = $_POST['customer_name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $product_id = isset($_POST['product_id']) ? (int) $_POST['product_id'] : null;
    $channel_code = $_POST['channel_code'] ?? '';
    $remark = $_POST['remark'] ?? '';
    $activation_status = $_POST['activation_status'] ?? '';
    $card_variant_mis = $_POST['card_variant_mis'] ?? '';
    $application_no_mis = $_POST['application_no_mis'] ?? '';
    $status = $_POST['status'] ?? '';
    $disbursed_amount = isset($_POST['disbursed_amount']) ? floatval($_POST['disbursed_amount']) : null;

    $updated_at = (new DateTime('now', new DateTimeZone('Asia/Kolkata')))->format('Y-m-d H:i:s');

    $old_status = $lead['status'];

    // Check if disbursed_amount column exists before including it in update
    $has_disbursed_column = false;
    try {
        $check_col = $conn->query("SHOW COLUMNS FROM leads LIKE 'disbursed_amount'");
        $has_disbursed_column = ($check_col && $check_col->num_rows > 0);
    } catch (Exception $e) {
        $has_disbursed_column = false;
    }

    if ($has_disbursed_column) {
        $cust_type = !empty($_POST['cust_type']) ? $_POST['cust_type'] : null;
        $card_issued_date = !empty($_POST['card_issued_date']) ? $_POST['card_issued_date'] : null;
        $vkyc_status = !empty($_POST['vkyc_status']) ? $_POST['vkyc_status'] : null;
        $bkyc_status = !empty($_POST['bkyc_status']) ? $_POST['bkyc_status'] : null;

        $stmt = $conn->prepare("UPDATE leads SET customer_name = ?, phone = ?, email = ?, product_id = ?, channel_code = ?, remark = ?, activation_status = ?, card_variant_mis = ?, application_no_mis = ?, status = ?, cust_type = ?, card_issued_date = ?, vkyc_status = ?, bkyc_status = ?, disbursed_amount = ?, updated_at = ? WHERE id = ?");
        $stmt->bind_param('sssissssssssssdsi', $customer_name, $phone, $email, $product_id, $channel_code, $remark, $activation_status, $card_variant_mis, $application_no_mis, $status, $cust_type, $card_issued_date, $vkyc_status, $bkyc_status, $disbursed_amount, $updated_at, $lead_id);
    } else {
        $cust_type = !empty($_POST['cust_type']) ? $_POST['cust_type'] : null;
        $card_issued_date = !empty($_POST['card_issued_date']) ? $_POST['card_issued_date'] : null;
        $vkyc_status = !empty($_POST['vkyc_status']) ? $_POST['vkyc_status'] : null;
        $bkyc_status = !empty($_POST['bkyc_status']) ? $_POST['bkyc_status'] : null;

        $stmt = $conn->prepare("UPDATE leads SET customer_name = ?, phone = ?, email = ?, product_id = ?, channel_code = ?, remark = ?, activation_status = ?, card_variant_mis = ?, application_no_mis = ?, status = ?, cust_type = ?, card_issued_date = ?, vkyc_status = ?, bkyc_status = ?, updated_at = ? WHERE id = ?");
        $stmt->bind_param('sssissssssssssi', $customer_name, $phone, $email, $product_id, $channel_code, $remark, $activation_status, $card_variant_mis, $application_no_mis, $status, $cust_type, $card_issued_date, $vkyc_status, $bkyc_status, $updated_at, $lead_id);
    }
    $stmt->execute();
    $stmt->close();
    
    // Get cust_type and bkyc_status for HDFC logic
    $cust_type = !empty($_POST['cust_type']) ? $_POST['cust_type'] : null;
    $bkyc_status = !empty($_POST['bkyc_status']) ? $_POST['bkyc_status'] : null;

    // Update payout for Personal Loans based on disbursed amount
    if ($lead['category'] === 'Personal Loan' && $disbursed_amount > 0) {
        // Get the commission rate for this product
        $product_stmt = $conn->prepare("SELECT commission_rate FROM products WHERE id = ? LIMIT 1");
        $product_stmt->bind_param('i', $product_id);
        $product_stmt->execute();
        $product_result = $product_stmt->get_result();

        if ($product_data = $product_result->fetch_assoc()) {
            $commission_rate = $product_data['commission_rate'];

            // Calculate new commission: disbursed_amount × (commission_rate / 100)
            $new_commission_amount = $disbursed_amount * ($commission_rate / 100);

            // Update the payout record
            $update_payout = $conn->prepare("UPDATE payouts SET commission_amount = ? WHERE lead_id = ?");
            $update_payout->bind_param('di', $new_commission_amount, $lead_id);
            $update_payout->execute();
            $update_payout->close();
        }
        $product_stmt->close();
    }

    // Credit Card Payout Logic (ETB + BKYC)
    $product_check = $conn->prepare("SELECT name, category, commission_rate FROM products WHERE id = ? LIMIT 1");
    $product_check->bind_param('i', $product_id);
    $product_check->execute();
    $product_info = $product_check->get_result()->fetch_assoc();
    $product_check->close();

    if ($product_info && $product_info['category'] === 'Credit Card') {
        $new_commission = $product_info['commission_rate'];
        $deduction = 0;

        // Rule 1: If customer type is ETB, set payout to ₹1000
        if (!empty($cust_type) && $cust_type === 'ETB') {
            $new_commission = 1000;
        }

        // Rule 2: If BKYC is completed, deduct ₹320
        if (!empty($bkyc_status) && $bkyc_status === 'COMPLETED') {
            $deduction = 320;
        }

        // Debug log
        error_log("Credit Card Payout Update - Lead ID: $lead_id, Commission: $new_commission, Deduction: $deduction, Cust Type: $cust_type, BKYC: $bkyc_status");

        // Update payout with new commission and deduction
        $update_payout = $conn->prepare("UPDATE payouts SET commission_amount = ?, deduction_amount = ? WHERE lead_id = ?");
        $update_payout->bind_param('ddi', $new_commission, $deduction, $lead_id);
        $update_payout->execute();
        $affected = $update_payout->affected_rows;
        error_log("Payout update affected rows: $affected");
        $update_payout->close();
    }

    // Send notification if status changed
    if ($old_status !== $status) {
        notifyUser('lead_status_update', $email, [
            'lead_id' => $lead['lead_id'],
            'old_status' => $old_status,
            'new_status' => $status
        ]);
    }

    header("Location: leads_updated.php?updated=1");
    exit;
}

// Fetch products for select list
$products = [];
$pstmt = $conn->prepare("SELECT id, name FROM products ORDER BY name");
$pstmt->execute();
$resp = $pstmt->get_result();
while ($r = $resp->fetch_assoc())
    $products[] = $r;
$pstmt->close();

// Fetch advisors (channel_code + name)
$advisors = [];
$ast = $conn->prepare("SELECT channel_code, name FROM users WHERE is_admin = 0 ORDER BY name");
$ast->execute();
$resa = $ast->get_result();
while ($a = $resa->fetch_assoc())
    $advisors[] = $a;
$ast->close();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Lead</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
</head>

<body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="max-w-xl mx-auto mt-10 bg-white rounded-lg shadow p-8">
        <h2 class="text-2xl font-bold mb-6">Edit Lead</h2>
        <?php if (isset($_GET['updated'])): ?>
            <div class="mb-4 p-3 bg-green-50 border border-green-200 text-green-700 rounded">Updated successfully.</div>
        <?php endif; ?>
        <form method="POST">
            <div class="grid grid-cols-1 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Customer Name</label>
                    <input type="text" name="customer_name"
                        value="<?= htmlspecialchars($lead['customer_name'] ?? $lead['name'] ?? '') ?>"
                        class="w-full px-3 py-2 border rounded">
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium mb-1">Phone</label>
                        <input type="text" name="phone"
                            value="<?= htmlspecialchars($lead['phone'] ?? $lead['mobile'] ?? '') ?>"
                            class="w-full px-3 py-2 border rounded">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Email</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($lead['email'] ?? '') ?>"
                            class="w-full px-3 py-2 border rounded">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium mb-1">Product</label>
                        <select name="product_id" class="w-full px-3 py-2 border rounded">
                            <?php foreach ($products as $p): ?>
                                <option value="<?= $p['id'] ?>" <?= ($lead['product_id'] == $p['id'] ? 'selected' : '') ?>>
                                    <?= htmlspecialchars($p['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Advisor</label>
                        <select name="channel_code" class="w-full px-3 py-2 border rounded">
                            <?php foreach ($advisors as $a): ?>
                                <option value="<?= htmlspecialchars($a['channel_code']) ?>"
                                    <?= ($lead['channel_code'] == $a['channel_code'] ? 'selected' : '') ?>>
                                    <?= htmlspecialchars($a['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Status</label>
                    <select name="status" id="statusSelect" class="w-full px-3 py-2 border rounded">
                        <?php
                        $all_status = ['generated', 'in_process', 'declined', 'approved', 'activated', 'disbursed', 'curable'];
                        $is_card = ($lead['category'] === 'Credit Card');
                        foreach ($all_status as $st):
                            // Hide Activated, Disbursed, Curable for card leads
                            $hide = $is_card && in_array($st, ['activated', 'disbursed', 'curable']);
                            ?>
                            <option value="<?= $st ?>" <?= ($lead['status'] === $st ? 'selected' : '') ?>     <?= $hide ? 'style="display:none;" disabled' : '' ?>><?= ucwords(str_replace('_', ' ', $st)) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php if ($lead['category'] === 'Credit Card'): ?>
                    <div>
                        <label class="block text-sm font-medium mb-1">Activation Status</label>
                        <select name="activation_status" class="w-full px-3 py-2 border rounded">
                            <option value="" <?= empty($lead['activation_status']) ? 'selected' : '' ?>>-</option>
                            <option value="Inactive" <?= ($lead['activation_status'] === 'Inactive' ? 'selected' : '') ?>>
                                Inactive</option>
                            <option value="Active" <?= ($lead['activation_status'] === 'Active' ? 'selected' : '') ?>>Active
                            </option>
                        </select>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium mb-1">Card Variant (MIS)</label>
                            <input type="text" name="card_variant_mis"
                                value="<?= htmlspecialchars($lead['card_variant_mis'] ?? '') ?>"
                                class="w-full px-3 py-2 border rounded">
                        </div>
                        <div>
                            <label class="block text-sm font-medium mb-1">Application No (MIS)</label>
                            <input type="text" name="application_no_mis"
                                value="<?= htmlspecialchars($lead['application_no_mis'] ?? '') ?>"
                                class="w-full px-3 py-2 border rounded">
                        </div>
                    </div>
                    <div class="grid grid-cols-3 gap-4">
                        <div>
                            <label class="block text-sm font-medium mb-1">Cust Type</label>
                            <select name="cust_type" class="w-full px-3 py-2 border rounded">
                                <option value="" <?= empty($lead['cust_type']) ? 'selected' : '' ?>>-</option>
                                <option value="ETB" <?= ($lead['cust_type'] === 'ETB' ? 'selected' : '') ?>>ETB</option>
                                <option value="NTB" <?= ($lead['cust_type'] === 'NTB' ? 'selected' : '') ?>>NTB</option>
                                <option value="ETCC" <?= ($lead['cust_type'] === 'ETCC' ? 'selected' : '') ?>>ETCC</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium mb-1">VKYC Status</label>
                            <select name="vkyc_status" class="w-full px-3 py-2 border rounded">
                                <option value="" <?= empty($lead['vkyc_status']) ? 'selected' : '' ?>>-</option>
                                <option value="PENDING" <?= ($lead['vkyc_status'] === 'PENDING' ? 'selected' : '') ?>>PENDING
                                </option>
                                <option value="EXPIRED" <?= ($lead['vkyc_status'] === 'EXPIRED' ? 'selected' : '') ?>>EXPIRED
                                </option>
                                <option value="REJECTED" <?= ($lead['vkyc_status'] === 'REJECTED' ? 'selected' : '') ?>>
                                    REJECTED</option>
                                <option value="COMPLETED" <?= ($lead['vkyc_status'] === 'COMPLETED' ? 'selected' : '') ?>>
                                    COMPLETED</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium mb-1">BKYC Status</label>
                            <select name="bkyc_status" class="w-full px-3 py-2 border rounded">
                                <option value="" <?= empty($lead['bkyc_status']) ? 'selected' : '' ?>>-</option>
                                <option value="PENDING" <?= ($lead['bkyc_status'] === 'PENDING' ? 'selected' : '') ?>>PENDING
                                </option>
                                <option value="EXPIRED" <?= ($lead['bkyc_status'] === 'EXPIRED' ? 'selected' : '') ?>>EXPIRED
                                </option>
                                <option value="REJECTED" <?= ($lead['bkyc_status'] === 'REJECTED' ? 'selected' : '') ?>>
                                    REJECTED</option>
                                <option value="COMPLETED" <?= ($lead['bkyc_status'] === 'COMPLETED' ? 'selected' : '') ?>>
                                    COMPLETED</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Card Issued Date</label>
                        <input type="date" name="card_issued_date"
                            value="<?= htmlspecialchars($lead['card_issued_date'] ?? '') ?>"
                            class="w-full px-3 py-2 border rounded">
                    </div>
                <?php endif; ?>
                <?php if ($lead['category'] === 'Personal Loan'): ?>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium mb-1">Application No (MIS)</label>
                            <input type="text" name="application_no_mis"
                                value="<?= htmlspecialchars($lead['application_no_mis'] ?? '') ?>"
                                class="w-full px-3 py-2 border rounded">
                        </div>
                        <div>
                            <label class="block text-sm font-medium mb-1">Disbursed Amount</label>
                            <input type="number" name="disbursed_amount"
                                value="<?= htmlspecialchars($lead['disbursed_amount'] ?? '') ?>" step="0.01" min="0"
                                class="w-full px-3 py-2 border rounded" placeholder="Enter disbursed amount">
                        </div>
                    </div>
                <?php endif; ?>
                <div>
                    <label class="block text-sm font-medium mb-1">Remark</label>
                    <textarea name="remark" rows="3"
                        class="w-full px-3 py-2 border rounded"><?php echo htmlspecialchars($lead['remark'] ?? ''); ?></textarea>
                </div>
            </div>
            <div class="flex justify-end gap-2 mt-4">
                <a href="leads_updated.php" class="px-4 py-2 bg-slate-200 rounded">Cancel</a>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Save</button>
            </div>
        </form>
        <div class="mt-6 text-xs text-slate-500">
            <div><b>Product:</b> <?php echo htmlspecialchars($lead['product_name']); ?>
                (<?php echo htmlspecialchars($lead['category']); ?>)</div>
            <div><b>Advisor:</b> <?php echo htmlspecialchars($lead['advisor_name'] ?? '-'); ?></div>
            <div><b>Payout Source:</b> <?php echo htmlspecialchars($lead['payout_source'] ?? '-'); ?></div>
        </div>
    </div>
    <script src="/assets/js/loading.js"></script>
</body>

</html>
