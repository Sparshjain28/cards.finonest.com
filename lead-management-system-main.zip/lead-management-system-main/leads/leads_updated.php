<?php
// leads_updated.php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../classes/Lead.php';
require_once __DIR__ . '/../config/timezone.php';
require_once __DIR__ . '/../includes/role_manager.php';

requireLogin();

// Function to preserve filter state in redirects
function getFilterQueryString()
{
    $query_params = [];
    foreach (['status', 'search', 'category', 'lead_create_from', 'lead_create_till', 'advisor_filter', 'advisor_number', 'customer_name', 'customer_number', 'lead_status_filter', 'lender_filter', 'bank_filter', 'lead_type_filter'] as $param) {
        if (!empty($_GET[$param])) {
            $query_params[$param] = $_GET[$param];
        }
    }
    return !empty($query_params) ? '&' . http_build_query($query_params) : '';
}

$user = getCurrentUser();
$is_admin = !empty($user['is_admin']);
$is_manager = isManager();
$database = new Database();
$conn = $database->getConnection();
$roleManager = new RoleManager($conn);
$lead_obj = new Lead($conn); // Instantiate Lead class

// Filters & Query Building (moved up to ensure $where_clause is defined for export)
$status_filter = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? 'all';
$lead_create_from = $_GET['lead_create_from'] ?? '';
$lead_create_till = $_GET['lead_create_till'] ?? '';
$advisor_filter = $_GET['advisor_filter'] ?? 'all';
$advisor_number = $_GET['advisor_number'] ?? '';
$customer_name = $_GET['customer_name'] ?? '';
$customer_number = $_GET['customer_number'] ?? '';
$lead_status_filter = $_GET['lead_status_filter'] ?? 'all';
$lead_sub_status_filter = $_GET['lead_sub_status_filter'] ?? 'all';
$lender_filter = $_GET['lender_filter'] ?? 'all';
$bank_filter = $_GET['bank_filter'] ?? 'all';
$lead_type_filter = $_GET['lead_type_filter'] ?? 'all';
$pending_action_filter = $_GET['pending_action_filter'] ?? 'all';

$where = [];
$params = [];
$types = '';
if (!$is_admin) {
    if ($is_manager) {
        // Manager sees leads from assigned users only
        $managerLeadsWhere = $roleManager->getManagerLeadsQuery($_SESSION['user_id']);
        $where[] = "($managerLeadsWhere)";
    } else {
        // Regular user sees only their own leads
        $where[] = "l.channel_code = ?";
        $params[] = $user['channel_code'];
        $types .= 's';
    }
}
if ($status_filter !== 'all') {
    $where[] = "l.status = ?";
    $params[] = $status_filter;
    $types .= 's';
}
if ($category_filter !== 'all') {
    $where[] = "p.category = ?";
    $params[] = $category_filter;
    $types .= 's';
}
if (strlen($search) > 0) {
    $where[] = "(l.name LIKE ? OR l.mobile LIKE ? OR l.email LIKE ? OR l.lead_id LIKE ?)";
    $s = "%$search%";
    $params[] = $s;
    $params[] = $s;
    $params[] = $s;
    $params[] = $s;
    $types .= 'ssss';
}
if (!empty($lead_create_from)) {
    $where[] = "DATE(l.created_at) >= ?";
    $params[] = $lead_create_from;
    $types .= 's';
}
if (!empty($lead_create_till)) {
    $where[] = "DATE(l.created_at) <= ?";
    $params[] = $lead_create_till;
    $types .= 's';
}
if ($advisor_filter !== 'all') {
    $where[] = "l.channel_code IN (SELECT channel_code FROM users WHERE id = ?)";
    $params[] = $advisor_filter;
    $types .= 'i';
}
if (!empty($advisor_number)) {
    $where[] = "l.advisor_number LIKE ?";
    $params[] = "%$advisor_number%";
    $types .= 's';
}
if (!empty($customer_name)) {
    $where[] = "l.customer_name LIKE ?";
    $params[] = "%$customer_name%";
    $types .= 's';
}
if (!empty($customer_number)) {
    $where[] = "l.customer_number LIKE ?";
    $params[] = "%$customer_number%";
    $types .= 's';
}
if ($lead_status_filter !== 'all') {
    $where[] = "l.status = ?";
    $params[] = $lead_status_filter;
    $types .= 's';
}
if ($lead_sub_status_filter !== 'all') {
    $where[] = "l.sub_status = ?";
    $params[] = $lead_sub_status_filter;
    $types .= 's';
}
if ($lender_filter !== 'all') {
    $where[] = "p.name = ?";
    $params[] = $lender_filter;
    $types .= 's';
}
if ($bank_filter !== 'all') {
    $where[] = "p.variant = ?";
    $params[] = $bank_filter;
    $types .= 's';
}
if ($lead_type_filter !== 'all') {
    $where[] = "p.category = ?";
    $params[] = $lead_type_filter;
    $types .= 's';
}
if ($pending_action_filter !== 'all') {
    $where[] = "l.pending_action = ?";
    $params[] = $pending_action_filter;
    $types .= 's';
}
$where_clause = '';
if (!empty($where)) {
    $where_clause = 'WHERE ' . implode(' AND ', $where);
}

// Download Template CSV
if (isset($_GET['template']) && $_GET['template'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=leads_import_template.csv');
    $output = fopen('php://output', 'w');
    
    // Template headers as specified
    $template_headers = [
        'lead_id', 'customer_name', 'status', 'remark', 'application_no_mis',
        'cust_type', 'card_variant_mis', 'vkyc_status', 'bkyc_status',
        'card_issued_date', 'activation_status', 'disbursed_amount'
    ];
    
    fputcsv($output, $template_headers);
    fclose($output);
    exit;
}

// Export Leads as CSV
// —————————————————————
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=leads_export_' . date('Ymd_His') . '.csv');
    $output = fopen('php://output', 'w');
    
    // Complete headers with data as specified
    $export_headers = [
        'created_at', 'channel_code', 'advisor_name', 'product_category', 'bank_name', 'product_name',
        'lead_id', 'customer_name', 'phone', 'email', 'status', 'remark', 'application_no_mis',
        'cust_type', 'card_variant_mis', 'vkyc_status', 'bkyc_status', 'card_issued_date',
        'activation_status', 'disbursed_amount', 'updated_at'
    ];
    
    fputcsv($output, $export_headers);
    
    // Build export query with all required fields
    $sql_export = "SELECT l.created_at, l.channel_code, 
                          COALESCE(l.advisor_name, u.name, 'Unknown Advisor') AS advisor_name,
                          p.category AS product_category, p.variant AS bank_name, p.name AS product_name,
                          l.lead_id, l.customer_name, 
                          COALESCE(l.mobile, l.phone) AS phone, l.email, l.status, l.remark, 
                          l.application_no_mis, l.cust_type, l.card_variant_mis, l.vkyc_status, 
                          l.bkyc_status, l.card_issued_date, l.activation_status, l.disbursed_amount, 
                          l.updated_at
                   FROM leads l 
                   JOIN products p ON l.product_id = p.id 
                   LEFT JOIN users u ON l.channel_code = u.channel_code AND u.channel_code IS NOT NULL AND u.channel_code != ''
                   $where_clause ORDER BY l.created_at DESC";
    
    $stmt_export = $conn->prepare($sql_export);
    if (!empty($params)) {
        $stmt_export->bind_param($types, ...$params);
    }
    $stmt_export->execute();
    $res_export = $stmt_export->get_result();
    
    while ($row = $res_export->fetch_assoc()) {
        $row_out = [];
        foreach ($export_headers as $col) {
            $row_out[] = $row[$col] ?? '';
        }
        fputcsv($output, $row_out);
    }
    fclose($output);
    exit;
}

// —————————————————————
// Import Leads from Excel/CSV (dynamic update of only provided columns)
// —————————————————————
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_leads']) && isset($_FILES['import_file'])) {
    $uploaded = $_FILES['import_file'];
    $tmpPath = $uploaded['tmp_name'] ?? '';
    $origName = $uploaded['name'] ?? '';
    if (empty($tmpPath) || !is_uploaded_file($tmpPath)) {
        header("Location: leads_updated.php?import_error=1");
        exit;
    }

    // Load DB columns and build allowed columns (blacklist sensitive columns)
    $sql_columns = "SHOW COLUMNS FROM leads";
    $columns_res = $conn->query($sql_columns);
    $db_columns = [];
    while ($col = $columns_res->fetch_assoc()) {
        $db_columns[] = $col['Field'];
    }
    // Columns we will never allow to be updated from import
    $blacklist = ['id', 'lead_id', 'unique_utm_id', 'created_at'];
    $allowed_columns = array_values(array_diff($db_columns, $blacklist));

    // Helper: normalize header -> db column style (lowercase, spaces/dashes -> underscore)
    $normalize = function ($h) {
        return strtolower(trim(str_replace([' ', '-'], '_', $h)));
    };

    // Ensure PhpSpreadsheet is available for .xls/.xlsx; fall back to CSV parsing for .csv
    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    $rows = [];

    if (in_array($ext, ['xls', 'xlsx'])) {
        // Try to include composer autoload
        if (!file_exists(__DIR__ . '/../vendor/autoload.php')) {
            // Not installed; redirect with error
            header("Location: leads_updated.php?import_error=no_phpspreadsheet");
            exit;
        }
        require_once __DIR__ . '/../vendor/autoload.php';
        try {
            // Use string class names to avoid static analyzer errors when vendor isn't installed
            $ioFactoryClass = 'PhpOffice\\PhpSpreadsheet\\IOFactory';
            $coordinateClass = 'PhpOffice\\PhpSpreadsheet\\Cell\\Coordinate';

            $spreadsheet = $ioFactoryClass::load($tmpPath);
            $sheet = $spreadsheet->getActiveSheet();
            // Use getHighestRow/getHighestColumn for broader compatibility
            $highestRow = $sheet->getHighestRow();
            $highestColumn = $sheet->getHighestColumn();
            $highestColumnIndex = $coordinateClass::columnIndexFromString($highestColumn);
            // Read header
            $header = [];
            for ($col = 1; $col <= $highestColumnIndex; $col++) {
                $coord = $coordinateClass::stringFromColumnIndex($col) . '1';
                $cell = $sheet->getCell($coord);
                $val = $cell ? $cell->getCalculatedValue() : null;
                $header[] = $normalize($val);
            }
            // Read data rows
            for ($row = 2; $row <= $highestRow; $row++) {
                $line = [];
                $empty = true;
                for ($col = 1; $col <= $highestColumnIndex; $col++) {
                    $coord = $coordinateClass::stringFromColumnIndex($col) . $row;
                    $cell = $sheet->getCell($coord);
                    $v = $cell ? $cell->getCalculatedValue() : null;
                    if ($v !== null && $v !== '')
                        $empty = false;
                    $line[] = is_scalar($v) ? trim((string) $v) : $v;
                }
                if ($empty)
                    continue;
                $rows[] = array_combine($header, $line);
            }
        } catch (Exception $e) {
            error_log('Import: PhpSpreadsheet failed to load file: ' . $e->getMessage());
            header("Location: leads_updated.php?import_error=1");
            exit;
        }
    } else {
        // Treat as CSV (also supports .csv uploads)
        if (($handle = fopen($tmpPath, 'r')) !== false) {
            $headerRow = fgetcsv($handle);
            if ($headerRow === false) {
                fclose($handle);
                header("Location: leads_updated.php?import_error=empty_csv");
                exit;
            }
            $header = array_map($normalize, $headerRow);
            while (($data = fgetcsv($handle)) !== false) {
                // pad shorter rows
                if (count($data) < count($header)) {
                    $data = array_merge($data, array_fill(0, count($header) - count($data), ''));
                }
                $line = array_map('trim', $data);
                $rows[] = array_combine($header, $line);
            }
            fclose($handle);
        }
    }

    // Process rows
    $updatedCount = 0;
    $skippedCount = 0;
    $dtz = new DateTimeZone('Asia/Kolkata');
    $now = (new DateTime('now', $dtz))->format('Y-m-d H:i:s');

    foreach ($rows as $row) {
        // Find lead_id (allow lead_id or lead id)
        $lead_id = $row['lead_id'] ?? ($row['lead id'] ?? null);
        if (empty($lead_id)) {
            $skippedCount++; // missing lead id
            continue;
        }
        // Fetch existing lead
        $sel = $conn->prepare('SELECT * FROM leads WHERE lead_id = ? LIMIT 1');
        $sel->bind_param('s', $lead_id);
        $sel->execute();
        $result = $sel->get_result();
        $existing = $result->fetch_assoc();
        $sel->close();
        if (!$existing) {
            $skippedCount++; // not found
            continue;
        }

        // Build updates only for allowed columns that have NON-EMPTY data in the import
        $updates = [];
        $values = [];
        foreach ($row as $hdr => $val) {
            // Normalize header to candidate column name
            $candidate = preg_replace('/[^a-z0-9_]/', '', strtolower($hdr));
            if ($candidate === '')
                continue;
            // Only consider if it's an allowed db column
            if (in_array($candidate, $allowed_columns, true)) {
                // FIXED: Only update if the import value is NOT empty/blank
                $newVal = trim($val);
                if ($newVal !== '' && $newVal !== null) {
                    // Compare with existing value; update only if different
                    $existingVal = isset($existing[$candidate]) ? trim((string) $existing[$candidate]) : '';
                    if ($newVal !== $existingVal) {
                        $updates[] = $candidate;
                        $values[] = $newVal;
                    }
                }
                // If import value is empty/blank, skip this column entirely (preserve existing data)
            }
        }

        if (empty($updates)) {
            $skippedCount++; // no changes
            continue;
        }

        // Ensure column names are safe (alphanumeric + underscore) and exist in db
        $setParts = [];
        foreach ($updates as $c) {
            if (!preg_match('/^[a-z0-9_]+$/', $c))
                continue;
            if (!in_array($c, $allowed_columns, true))
                continue;
            $setParts[] = "`" . $c . "` = ?";
        }
        if (empty($setParts)) {
            $skippedCount++;
            continue;
        }

        // Add updated_at automatically
        $setParts[] = '`updated_at` = ?';
        $values[] = $now;
        $types = str_repeat('s', count($values));
        // WHERE lead_id = ?
        $values[] = $lead_id;
        $types .= 's';

        $sql = 'UPDATE leads SET ' . implode(', ', $setParts) . ' WHERE lead_id = ?';
        $ustmt = $conn->prepare($sql);
        if ($ustmt === false) {
            error_log('Import: Failed to prepare update statement: ' . $conn->error);
            $skippedCount++;
            continue;
        }
        // bind_param requires references
        $bind_names[] = $types;
        for ($i = 0; $i < count($values); $i++) {
            $bind_name = 'bind' . $i;
            $$bind_name = $values[$i];
            $bind_names[] = &$$bind_name;
        }
        call_user_func_array([$ustmt, 'bind_param'], $bind_names);
        if (!$ustmt->execute()) {
            error_log('Import: Update failed for lead_id ' . $lead_id . ': ' . $ustmt->error);
            $ustmt->close();
            $skippedCount++;
            // reset bind names for next iteration
            unset($bind_names);
            continue;
        }
        $ustmt->close();
        // reset bind names for next iteration
        unset($bind_names);
        $updatedCount++;
    }

    // Redirect back with summary
    header('Location: leads_updated.php?imported=1&updated=' . $updatedCount . '&skipped=' . $skippedCount);
    exit;
}
// Handle Remark Update (Admin Inline)
// —————————————————————
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_remark']) && $is_admin) {
    $lead_id = (int) $_POST['lead_id'];
    $new_remark = $_POST['new_remark'];
    $updated_at = getAppTimestamp();
    $stmt = $conn->prepare("UPDATE leads SET remark = ?, updated_at = ? WHERE id = ?");
    $stmt->bind_param("ssi", $new_remark, $updated_at, $lead_id);
    $stmt->execute();
    $stmt->close();
    header("Location: leads_updated.php?updated=1" . getFilterQueryString());
    exit;
}

// —————————————————————
// Handle Status Update (Advisor or Admin via form)
// —————————————————————
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $lead_id = (int) $_POST['lead_id'];
    $new_status = $_POST['new_status'];
    $notes = $_POST['notes'] ?? '';

    // Get old status first
    $old_status = null;
    $old_stmt = $conn->prepare("SELECT status FROM leads WHERE id = ?");
    $old_stmt->bind_param("i", $lead_id);
    $old_stmt->execute();
    $old_stmt->bind_result($old_status);
    $old_stmt->fetch();
    $old_stmt->close();

    // Update the lead's status
    $updated_at = getAppTimestamp();
    $upd = $conn->prepare("UPDATE leads SET status = ?, updated_at = ? WHERE id = ?");
    $upd->bind_param("ssi", $new_status, $updated_at, $lead_id);
    $upd->execute();
    $upd->close();

    // Insert into history
    $history = $conn->prepare("
        INSERT INTO lead_status_history (lead_id, old_status, new_status, changed_by, notes)
        VALUES (?, ?, ?, ?, ?)
    ");
    $changed_by = $user['name'];
    $history->bind_param("issss", $lead_id, $old_status, $new_status, $changed_by, $notes);
    $history->execute();
    $history->close();

    header("Location: leads_updated.php?updated=1" . getFilterQueryString());
    exit;
}

// —————————————————————
// Handle Admin Inline Status Update
// —————————————————————
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status_admin']) && $is_admin) {
    $lead_id = (int) $_POST['lead_id'];
    $new_status = $_POST['new_status'];

    // Get old status first
    $old_status = null;
    $old_stmt = $conn->prepare("SELECT status FROM leads WHERE id = ?");
    $old_stmt->bind_param("i", $lead_id);
    $old_stmt->execute();
    $old_stmt->bind_result($old_status);
    $old_stmt->fetch();
    $old_stmt->close();

    // Update the lead's status
    $updated_at = getAppTimestamp();
    $stmt2 = $conn->prepare("UPDATE leads SET status = ?, updated_at = ? WHERE id = ?");
    $stmt2->bind_param("ssi", $new_status, $updated_at, $lead_id);
    $stmt2->execute();
    $stmt2->close();

    // Insert into history
    $history = $conn->prepare("
        INSERT INTO lead_status_history (lead_id, old_status, new_status, changed_by, notes)
        VALUES (?, ?, ?, ?, ?)
    ");
    $changed_by = $user['name'];
    $notes = ''; // Empty notes for inline updates
    $history->bind_param("issss", $lead_id, $old_status, $new_status, $changed_by, $notes);
    $history->execute();
    $history->close();

    header("Location: leads_updated.php?updated=1" . getFilterQueryString());
    exit;
}

// Handle Admin Bulk Delete
// —————————————————————
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_delete']) && $is_admin) {
    $lead_ids = $_POST['selected_leads'] ?? [];
    $deleted_count = 0;

    if (!empty($lead_ids) && is_array($lead_ids)) {
        foreach ($lead_ids as $lead_id) {
            $lead_id = (int) $lead_id;
            if ($lead_obj->delete($lead_id)) {
                $deleted_count++;
            }
        }
    }

    header("Location: leads_updated.php?bulk_deleted=" . $deleted_count . getFilterQueryString());
    exit;
}

// —————————————————————
// Handle Admin Delete
// —————————————————————
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_lead']) && $is_admin) {
    $lead_id = (int) $_POST['lead_id'];

    if ($lead_obj->delete($lead_id)) { // Use the Lead class's delete method
        header("Location: leads_updated.php?deleted=1" . getFilterQueryString());
        exit;
    } else {
        // Handle error if deletion fails
        error_log("Failed to delete lead with ID: " . $lead_id);
        header("Location: leads_updated.php?error=delete_failed" . getFilterQueryString());
        exit;
    }
}

// —————————————————————
// AJAX: Status History (JSON)
// —————————————————————
if (isset($_GET['history']) && isset($_GET['lead_id'])) {
    header('Content-Type: application/json');
    $lead_id = (int) $_GET['lead_id'];

    // Check if lead_status_history table exists, if not create sample data
    $table_check = $conn->query("SHOW TABLES LIKE 'lead_status_history'");
    if ($table_check->num_rows == 0) {
        // Table doesn't exist, return empty array
        echo json_encode([]);
        exit;
    }

    $hstmt = $conn->prepare("
        SELECT old_status, new_status, changed_by, notes, created_at
        FROM lead_status_history
        WHERE lead_id = ?
        ORDER BY created_at DESC
    ");

    if (!$hstmt) {
        echo json_encode(['error' => 'Database prepare failed: ' . $conn->error]);
        exit;
    }

    $hstmt->bind_param("i", $lead_id);
    if (!$hstmt->execute()) {
        echo json_encode(['error' => 'Query execution failed: ' . $hstmt->error]);
        exit;
    }

    $res = $hstmt->get_result();
    $out = [];
    while ($row = $res->fetch_assoc()) {
        $out[] = $row;
    }
    $hstmt->close();

    echo json_encode($out);
    exit;
}
// —————————————————————
// Handle Admin MIS Update (Card Variant (MIS) and Application No (MIS))
// —————————————————————
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_mis']) && $is_admin) {
    $lead_id = (int) $_POST['lead_id'];
    $card_variant_mis = $_POST['card_variant_mis'] ?? '';
    $application_no_mis = $_POST['application_no_mis'] ?? '';
    $updated_at = getAppTimestamp();
    $stmt_mis = $conn->prepare("UPDATE leads SET card_variant_mis = ?, application_no_mis = ?, updated_at = ? WHERE id = ?");
    $stmt_mis->bind_param('sssi', $card_variant_mis, $application_no_mis, $updated_at, $lead_id);
    $stmt_mis->execute();
    $stmt_mis->close();
    header("Location: leads_updated.php?updated=1" . getFilterQueryString());
    exit;
}

// Handle Admin MIS single-field updates (separate small forms in desktop table)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_mis_field']) && $is_admin) {
    $lead_id = (int) $_POST['lead_id'];
    $field = $_POST['update_mis_field'];
    if ($field === 'card_variant') {
        $card_variant_mis = $_POST['card_variant_mis'] ?? '';
        $updated_at = getAppTimestamp();
        $stmt_mis = $conn->prepare("UPDATE leads SET card_variant_mis = ?, updated_at = ? WHERE id = ?");
        $stmt_mis->bind_param('ssi', $card_variant_mis, $updated_at, $lead_id);
        $stmt_mis->execute();
        $stmt_mis->close();
    } elseif ($field === 'application_no') {
        $application_no_mis = $_POST['application_no_mis'] ?? '';
        $updated_at = getAppTimestamp();
        $stmt_mis = $conn->prepare("UPDATE leads SET application_no_mis = ?, updated_at = ? WHERE id = ?");
        $stmt_mis->bind_param('ssi', $application_no_mis, $updated_at, $lead_id);
        $stmt_mis->execute();
        $stmt_mis->close();
    }
    header("Location: leads_updated.php?updated=1" . getFilterQueryString());
    exit;
}

// —————————————————————
// Handle Admin Activation Status Update (single-field, inline)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_activation']) && $is_admin) {
    $lead_id = (int) ($_POST['lead_id'] ?? 0);
    $activation_status = trim($_POST['activation_status'] ?? '');
    $updated_at = getAppTimestamp();
    $astmt = $conn->prepare("UPDATE leads SET activation_status = ?, updated_at = ? WHERE id = ?");
    $astmt->bind_param('ssi', $activation_status, $updated_at, $lead_id);
    $astmt->execute();
    $astmt->close();
    header("Location: leads_updated.php?updated=1" . getFilterQueryString());
    exit;
}

// —————————————————————
// Filters & Query Building
// —————————————————————
$status_filter = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? 'all';

// New filter parameters
$lead_create_from = $_GET['lead_create_from'] ?? '';
$lead_create_till = $_GET['lead_create_till'] ?? '';
$advisor_filter = $_GET['advisor_filter'] ?? 'all';
$advisor_number = $_GET['advisor_number'] ?? '';
$customer_name = $_GET['customer_name'] ?? '';
$customer_number = $_GET['customer_number'] ?? '';
$lead_status_filter = $_GET['lead_status_filter'] ?? 'all';
$lead_sub_status_filter = $_GET['lead_sub_status_filter'] ?? 'all';
$lender_filter = $_GET['lender_filter'] ?? 'all';
$bank_filter = $_GET['bank_filter'] ?? 'all';
$lead_type_filter = $_GET['lead_type_filter'] ?? 'all';
$pending_action_filter = $_GET['pending_action_filter'] ?? 'all';


$where = [];
$params = [];
$types = '';

// Non-admin: restrict to user's channel or manager's assigned users
if (!$is_admin) {
    if ($is_manager) {
        // Manager sees leads from assigned users only
        $managerLeadsWhere = $roleManager->getManagerLeadsQuery($_SESSION['user_id']);
        $where[] = "($managerLeadsWhere)";
    } else {
        // Regular user sees only their own leads
        $where[] = "l.channel_code = ?";
        $params[] = $user['channel_code'];
        $types .= 's';
    }
}
if ($status_filter !== 'all') {
    $where[] = "l.status = ?";
    $params[] = $status_filter;
    $types .= 's';
}
if ($category_filter !== 'all') {
    $where[] = "p.category = ?";
    $params[] = $category_filter;
    $types .= 's';
}
if (strlen($search) > 0) {
    $where[] = "(l.name LIKE ? OR l.mobile LIKE ? OR l.email LIKE ? OR l.lead_id LIKE ?)";
    $s = "%$search%";
    $params[] = $s;
    $params[] = $s;
    $params[] = $s;
    $params[] = $s;
    $types .= 'ssss';
}

// Apply new dynamic filters
if (!empty($lead_create_from)) {
    $where[] = "DATE(l.created_at) >= ?";
    $params[] = $lead_create_from;
    $types .= 's';
}
if (!empty($lead_create_till)) {
    $where[] = "DATE(l.created_at) <= ?";
    $params[] = $lead_create_till;
    $types .= 's';
}
if ($advisor_filter !== 'all') {
    $where[] = "l.channel_code IN (SELECT channel_code FROM users WHERE id = ?)";
    $params[] = $advisor_filter;
    $types .= 'i';
}
// Removed advisor_number filter - column doesn't exist in leads table
if (!empty($customer_name)) {
    $where[] = "l.customer_name LIKE ?";
    $params[] = "%$customer_name%";
    $types .= 's';
}
// Removed customer_number filter - column doesn't exist in leads table (use phone or mobile instead)
if ($lead_status_filter !== 'all') {
    $where[] = "l.status = ?";
    $params[] = $lead_status_filter;
    $types .= 's';
}
// Assuming lead_sub_status, lender, lead_type, pending_action are columns in the leads table
if ($lead_sub_status_filter !== 'all') {
    $where[] = "l.sub_status = ?"; // Assuming 'sub_status' column
    $params[] = $lead_sub_status_filter;
    $types .= 's';
}
// Lender = Product Name (from products table)
if ($lender_filter !== 'all') {
    $where[] = "p.name = ?";
    $params[] = $lender_filter;
    $types .= 's';
}
if ($bank_filter !== 'all') {
    $where[] = "p.variant = ?";
    $params[] = $bank_filter;
    $types .= 's';
}
// Lead Type = Product Category (from products table)
if ($lead_type_filter !== 'all') {
    $where[] = "p.category = ?";
    $params[] = $lead_type_filter;
    $types .= 's';
}
if ($pending_action_filter !== 'all') {
    $where[] = "l.pending_action = ?"; // Assuming 'pending_action' column
    $params[] = $pending_action_filter;
    $types .= 's';
}


$where_clause = '';
if (!empty($where)) {
    $where_clause = 'WHERE ' . implode(' AND ', $where);
}

// Auto-create missing columns if they don't exist
$columns_to_add = [
    'cust_type' => "ENUM('ETB', 'NTB', 'ETCC') DEFAULT NULL COMMENT 'Customer Type: ETB/NTB/ETCC'",
    'card_issued_date' => "DATE DEFAULT NULL COMMENT 'Card Issued Date'",
    'vkyc_status' => "ENUM('PENDING', 'EXPIRED', 'REJECTED', 'COMPLETED') DEFAULT NULL COMMENT 'VKYC Status'",
    'bkyc_status' => "ENUM('PENDING', 'EXPIRED', 'REJECTED', 'COMPLETED') DEFAULT NULL COMMENT 'BKYC Status'",
    'application_no_mis' => "VARCHAR(100) DEFAULT NULL COMMENT 'Application Number MIS'",
    'card_variant_mis' => "VARCHAR(100) DEFAULT NULL COMMENT 'Card Variant MIS'",
    'activation_status' => "VARCHAR(50) DEFAULT NULL COMMENT 'Activation Status'",
    'disbursed_amount' => "DECIMAL(10,2) DEFAULT NULL COMMENT 'Disbursed Amount'"
];

foreach ($columns_to_add as $column => $definition) {
    $check = $conn->query("SHOW COLUMNS FROM leads LIKE '$column'");
    if ($check->num_rows == 0) {
        $conn->query("ALTER TABLE leads ADD COLUMN $column $definition");
    }
}

// Main Query with product & user data
$sql = "
    SELECT l.*, p.name AS product_name, p.category, p.payout_source,
           p.variant, p.bank_redirect_url, l.remark, l.activation_status,
           l.cust_type, l.card_issued_date, l.vkyc_status, l.bkyc_status,
           COALESCE(l.advisor_name, u.name, 'Unknown Advisor') AS advisor_name,
           l.created_at,
           l.updated_at
    FROM leads l
    JOIN products p ON l.product_id = p.id
    LEFT JOIN users u ON l.channel_code = u.channel_code AND u.channel_code IS NOT NULL AND u.channel_code != ''
    $where_clause
    ORDER BY l.created_at DESC
";
$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$leads = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Status counts (for dashboard)
$stats_sql = "
    SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN status = 'generated' THEN 1 ELSE 0 END) AS `generated`,
      SUM(CASE WHEN status = 'in_process' THEN 1 ELSE 0 END) AS in_process,
      SUM(CASE WHEN status = 'declined' THEN 1 ELSE 0 END) AS declined,
      SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved,
      SUM(CASE WHEN status = 'activated' THEN 1 ELSE 0 END) AS activated,
      SUM(CASE WHEN status = 'disbursed' THEN 1 ELSE 0 END) AS disbursed,
      SUM(CASE WHEN status = 'curable' THEN 1 ELSE 0 END) AS curable
    FROM leads l
";
if (!$is_admin) {
    if ($is_manager) {
        $managerLeadsWhere = $roleManager->getManagerLeadsQuery($_SESSION['user_id']);
        $stats_sql .= " WHERE $managerLeadsWhere";
        $sst = $conn->prepare($stats_sql);
    } else {
        $stats_sql .= " WHERE channel_code = ?";
        $sst = $conn->prepare($stats_sql);
        $sst->bind_param("s", $user['channel_code']);
    }
} else {
    $sst = $conn->prepare($stats_sql);
}
$sst->execute();
$stats = $sst->get_result()->fetch_assoc();
$sst->close();

// Fetch distinct bank names for the filter
$banks_stmt = $conn->prepare("SELECT DISTINCT variant FROM products WHERE variant IS NOT NULL AND variant != '' ORDER BY variant");
$banks_stmt->execute();
$banks = $banks_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$banks_stmt->close();

function getStatusBadge($status)
{
    // normalize status: trim, lowercase, convert spaces to underscores
    $s = strtolower(trim(str_replace(' ', '_', (string) $status)));
    $badges = [
        'generated' => 'bg-yellow-100 text-yellow-800',
        'in_process' => 'bg-yellow-100 text-yellow-800',
        'declined' => 'bg-red-100 text-red-800',
        'approved' => 'bg-green-100 text-green-800',
        'activated' => 'bg-green-100 text-green-800',
        'disbursed' => 'bg-green-100 text-green-800',
        'curable' => 'bg-orange-100 text-orange-800'
    ];
    return $badges[$s] ?? 'bg-gray-100 text-gray-800';
}

// Helper function to format database timestamp as IST
function formatDatabaseTime($timestamp, $format = 'M d, Y g:i A')
{
    if (empty($timestamp))
        return '-';

    // Create DateTime object and explicitly set to IST
    $dt = new DateTime($timestamp, new DateTimeZone('Asia/Kolkata'));
    return $dt->format($format);
}

function normalizeStatusLabel($status)
{
    $s = strtolower(trim((string) $status));
    $s = str_replace(['_', '-'], ' ', $s);
    $s = preg_replace('/\s+/', ' ', $s);
    return ucwords($s);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leads Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <style>
        html,
        body {
            height: auto !important;
            min-height: auto !important;
            margin: 0;
        }

        .min-h-screen,
        .h-screen {
            min-height: auto !important;
            height: auto !important;
        }

        .flex-1 {
            flex: none !important;
        }

        .pb-24,
        .pb-32 {
            padding-bottom: 0 !important;
        }

        .mb-24,
        .mb-32 {
            margin-bottom: 0 !important;
        }

        .lead-details {
            transition: max-height 0.3s ease-out, opacity 0.2s ease-out;
            max-height: 0;
            opacity: 0;
            overflow: hidden;
        }

        .lead-details.expanded {
            max-height: 800px;
            opacity: 1;
        }

        .lead-card {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .lead-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body class="bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include __DIR__ . '/../includes/header.php'; ?>

    <main class="w-full mx-auto py-4">
        <!-- Filter Bar: All Leads heading for admin, Download/Import/Filter buttons grouped -->
        <div
            class="bg-white rounded-lg shadow border p-2 mb-3 flex flex-col sm:flex-row gap-2 items-start sm:items-center justify-between">
            <!-- All Leads heading (admin only) -->
            <?php if ($is_admin): ?>
                <h3 class="text-lg font-semibold text-slate-900">All Leads (<?= count($leads) ?>)</h3>
            <?php endif; ?>

            <!-- Right side container: messages and buttons grouped together -->
            <div class="flex flex-wrap gap-2 items-center <?php echo $is_admin ? '' : 'ml-auto'; ?>">
                <?php if (isset($_GET['bulk_deleted'])): ?>
                    <span class="text-green-700 font-semibold text-xs sm:text-sm">✅ <?= (int) $_GET['bulk_deleted'] ?> Leads
                        Deleted</span>
                <?php endif; ?>
                <?php if (isset($_GET['imported'])): ?>
                    <?php $u = (int) ($_GET['updated'] ?? 0);
                    $s = (int) ($_GET['skipped'] ?? 0); ?>
                    <span class="text-green-700 font-semibold text-xs sm:text-sm">✅ <?= $u ?> Leads Updated</span>
                    <span class="text-yellow-700 font-semibold text-xs sm:text-sm">⚠️ <?= $s ?> Skipped</span>
                <?php endif; ?>
                <?php if (isset($_GET['import_error'])): ?>
                    <?php $err = htmlspecialchars($_GET['import_error']); ?>
                    <span class="text-red-700 font-semibold text-xs sm:text-sm">Import error: <?= $err ?></span>
                <?php endif; ?>

                <!-- Download, Import, Template and Filter buttons grouped together (admin only for Download/Import) -->
                <?php if ($is_admin): ?>
                    <form method="GET" action="" class="inline-block">
                        <input type="hidden" name="export" value="csv">
                        <?php
                        foreach ($_GET as $key => $value) {
                            if ($key !== 'export' && $key !== 'page' && $key !== 'template') {
                                if (is_array($value)) {
                                    foreach ($value as $item) {
                                        echo '<input type="hidden" name="' . htmlspecialchars($key) . '[]" value="' . htmlspecialchars($item) . '">';
                                    }
                                } else {
                                    echo '<input type="hidden" name="' . htmlspecialchars($key) . '" value="' . htmlspecialchars($value) . '">';
                                }
                            }
                        }
                        ?>
                        <button type="submit"
                            class="bg-green-600 text-white px-3 py-2 rounded-lg hover:bg-green-700 flex items-center text-sm">
                            <i class="fas fa-download mr-1 sm:mr-2"></i>
                            <span class="hidden sm:inline">Export</span>
                        </button>
                    </form>
                    <a href="?template=csv"
                        class="bg-purple-600 text-white px-3 py-2 rounded-lg hover:bg-purple-700 flex items-center text-sm inline-flex">
                        <i class="fas fa-file-csv mr-1 sm:mr-2"></i>
                        <span class="hidden sm:inline">Template</span>
                    </a>
                    <form method="POST" enctype="multipart/form-data" action="" class="inline-block">
                        <label
                            class="bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 cursor-pointer flex items-center mb-0 text-sm"
                            title="Import leads (.csv, .xls, .xlsx)">
                            <i class="fas fa-file-import mr-1 sm:mr-2"></i>
                            <span class="hidden sm:inline">Import</span>
                            <input type="file" name="import_file" accept=".csv,.xls,.xlsx" class="hidden"
                                onchange="this.form.submit()">
                        </label>
                        <input type="hidden" name="import_leads" value="1">
                    </form>
                <?php endif; ?>

                <button type="button" id="toggleFilterBtn"
                    class="bg-white border border-slate-200 text-slate-700 px-3 py-2 rounded-lg shadow-sm hover:bg-slate-100 transition text-sm">
                    <i class="fas fa-filter mr-1 sm:mr-2"></i>
                    <span class="hidden sm:inline">Filter</span>
                </button>
            </div>
        </div>
        <!-- (Removed duplicate filter button section) -->

        <!-- Advanced Filter Bar: Hidden by default, toggled by Filter button -->
        <div id="advancedFilterBar" class="bg-white rounded-lg shadow border p-2 mb-3" style="display:none;">
            <form method="GET" action="leads_updated.php" class="space-y-2">
                <!-- Mobile: Stack all filters vertically, Desktop: Grid layout -->
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2">
                    <input type="date" name="lead_create_from" placeholder="Lead Create From"
                        value="<?= htmlspecialchars($_GET['lead_create_from'] ?? '') ?>"
                        class="w-full px-2 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                    <input type="date" name="lead_create_till" placeholder="Lead Create Till"
                        value="<?= htmlspecialchars($_GET['lead_create_till'] ?? '') ?>"
                        class="w-full px-2 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                    <select name="advisor_filter"
                        class="w-full px-2 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                        <option value="all">All Advisors</option>
                        <?php
                        $selected_advisor = $_GET['advisor_filter'] ?? '';
                        if ($is_admin) {
                            $advisors_stmt = $conn->prepare("SELECT id, name FROM users WHERE is_admin = 0 ORDER BY name");
                            $advisors_stmt->execute();
                            $advisors = $advisors_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                            $advisors_stmt->close();
                            foreach ($advisors as $advisor):
                                ?>
                                <option value="<?= htmlspecialchars($advisor['id']) ?>" <?= ($selected_advisor == $advisor['id'] ? 'selected' : '') ?>>
                                    <?= htmlspecialchars($advisor['name']) ?>
                                </option>
                            <?php endforeach;
                        } else {
                            // Advisor: only show self
                            ?>
                            <option value="<?= htmlspecialchars($user['id']) ?>" selected>
                                <?= htmlspecialchars($user['name']) ?>
                            </option>
                        <?php } ?>
                    </select>
                    <input type="text" name="advisor_number" placeholder="Advisor Number"
                        value="<?= htmlspecialchars($_GET['advisor_number'] ?? '') ?>"
                        class="w-full px-2 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                    <input type="text" name="customer_name" placeholder="Customer Name"
                        value="<?= htmlspecialchars($_GET['customer_name'] ?? '') ?>"
                        class="w-full px-2 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                    <input type="text" name="customer_number" placeholder="Customer Number"
                        value="<?= htmlspecialchars($_GET['customer_number'] ?? '') ?>"
                        class="w-full px-2 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                    <select name="lead_status_filter"
                        class="w-full px-2 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                        <option value="all">All Status</option>
                        <?php
                        $all_status_filter = ['generated', 'in_process', 'declined', 'approved', 'activated', 'disbursed', 'curable'];
                        $selected_lead_status = $_GET['lead_status_filter'] ?? '';
                        foreach ($all_status_filter as $st): ?>
                            <option value="<?= $st ?>" <?= ($selected_lead_status === $st ? 'selected' : '') ?>>
                                <?= ucwords(str_replace('_', ' ', $st)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="lead_sub_status_filter"
                        class="w-full px-2 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                        <option value="all">All Sub Status</option>
                        <?php
                        $selected_lead_sub_status = $_GET['lead_sub_status_filter'] ?? '';
                        foreach ($all_status_filter as $st): ?>
                            <option value="<?= $st ?>" <?= ($selected_lead_sub_status === $st ? 'selected' : '') ?>>
                                <?= ucwords(str_replace('_', ' ', $st)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="lender_filter"
                        class="w-full px-2 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                        <option value="all">All Lenders</option>
                        <?php
                        $selected_lender = $_GET['lender_filter'] ?? '';
                        if ($is_admin) {
                            $products_stmt = $conn->prepare("SELECT DISTINCT name FROM products ORDER BY name");
                            $products_stmt->execute();
                            $products = $products_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                            $products_stmt->close();
                        } else {
                            // Advisor: only show products assigned to their channel
                            $products_stmt = $conn->prepare("SELECT DISTINCT p.name FROM products p JOIN leads l ON l.product_id = p.id WHERE l.channel_code = ? ORDER BY p.name");
                            $products_stmt->bind_param("s", $user['channel_code']);
                            $products_stmt->execute();
                            $products = $products_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                            $products_stmt->close();
                        }
                        foreach ($products as $product):
                            ?>
                            <option value="<?= htmlspecialchars($product['name']) ?>" <?= ($selected_lender == $product['name'] ? 'selected' : '') ?>>
                                <?= htmlspecialchars($product['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="bank_filter"
                        class="w-full px-2 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                        <option value="all">All Banks</option>
                        <?php
                        $selected_bank = $_GET['bank_filter'] ?? '';
                        foreach ($banks as $bank):
                            ?>
                            <option value="<?= htmlspecialchars($bank['variant']) ?>" <?= ($selected_bank == $bank['variant'] ? 'selected' : '') ?>>
                                <?= htmlspecialchars($bank['variant']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="lead_type_filter"
                        class="w-full px-2 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                        <option value="all">All Lead Types</option>
                        <?php
                        $selected_lead_type = $_GET['lead_type_filter'] ?? '';
                        if ($is_admin) {
                            $categories_stmt = $conn->prepare("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != '' ORDER BY category");
                            $categories_stmt->execute();
                            $categories = $categories_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                            $categories_stmt->close();
                        } else {
                            // Advisor: only show categories of products assigned to their channel
                            $categories_stmt = $conn->prepare("SELECT DISTINCT p.category FROM products p JOIN leads l ON l.product_id = p.id WHERE l.channel_code = ? AND p.category IS NOT NULL AND p.category != '' ORDER BY p.category");
                            $categories_stmt->bind_param("s", $user['channel_code']);
                            $categories_stmt->execute();
                            $categories = $categories_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                            $categories_stmt->close();
                        }
                        foreach ($categories as $cat):
                            ?>
                            <option value="<?= htmlspecialchars($cat['category']) ?>"
                                <?= ($selected_lead_type == $cat['category'] ? 'selected' : '') ?>>
                                <?= htmlspecialchars($cat['category']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="pending_action_filter"
                        class="w-full px-2 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm">
                        <option value="all">All Pending Actions</option>
                        <?php
                        $selected_pending_action = $_GET['pending_action_filter'] ?? '';
                        $pending_actions = ['document_pending', 'verification_pending', 'approval_pending', 'disbursement_pending'];
                        foreach ($pending_actions as $action): ?>
                            <option value="<?= $action ?>" <?= ($selected_pending_action === $action ? 'selected' : '') ?>>
                                <?= ucwords(str_replace('_', ' ', $action)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="flex flex-col sm:flex-row gap-2 pt-1">
                    <button type="button" id="clearFilterBtn"
                        class="w-full sm:w-auto bg-gray-200 text-gray-800 px-3 py-1.5 rounded-lg hover:bg-gray-300 text-sm">Clear
                        Filters</button>
                    <button type="submit"
                        class="w-full sm:w-auto bg-blue-600 text-white px-3 py-1.5 rounded-lg hover:bg-blue-700 text-sm">Apply
                        Filters</button>
                </div>
            </form>
        </div>

        <!-- Dynamic Filter Layout -->
        <div id="dynamicFilter" class="bg-white rounded-lg shadow border p-2 sm:p-6 mb-4 hidden">
            <form method="GET" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <!-- Row 1 -->
                <div>
                    <label for="lead_create_from" class="block text-sm font-medium text-slate-700 mb-1">Lead Create
                        From</label>
                    <input type="date" id="lead_create_from" name="lead_create_from"
                        value="<?= htmlspecialchars($_GET['lead_create_from'] ?? '') ?>"
                        class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label for="lead_create_till" class="block text-sm font-medium text-slate-700 mb-1">Lead Create
                        Till</label>
                    <input type="date" id="lead_create_till" name="lead_create_till"
                        value="<?= htmlspecialchars($_GET['lead_create_till'] ?? '') ?>"
                        class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label for="advisor_filter" class="block text-sm font-medium text-slate-700 mb-1">Advisor</label>
                    <select id="advisor_filter" name="advisor_filter"
                        class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="all">All Advisors</option>
                        <!-- Options will be dynamically loaded or fetched from DB -->
                        <?php
                        // Example: Fetch advisors from database
                        $advisors_stmt = $conn->prepare("SELECT id, name FROM users WHERE is_admin = 0 ORDER BY name");
                        $advisors_stmt->execute();
                        $advisors = $advisors_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                        $advisors_stmt->close();
                        $selected_advisor = $_GET['advisor_filter'] ?? '';
                        foreach ($advisors as $advisor):
                            ?>
                            <option value="<?= htmlspecialchars($advisor['id']) ?>" <?= ($selected_advisor == $advisor['id'] ? 'selected' : '') ?>>
                                <?= htmlspecialchars($advisor['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Row 2 -->
                <div>
                    <label for="advisor_number" class="block text-sm font-medium text-slate-700 mb-1">Advisor
                        Number</label>
                    <input type="text" id="advisor_number" name="advisor_number" placeholder="Advisor Number"
                        value="<?= htmlspecialchars($_GET['advisor_number'] ?? '') ?>"
                        class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label for="customer_name" class="block text-sm font-medium text-slate-700 mb-1">Customer
                        Name</label>
                    <input type="text" id="customer_name" name="customer_name" placeholder="Customer Name"
                        value="<?= htmlspecialchars($_GET['customer_name'] ?? '') ?>"
                        class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label for="customer_number" class="block text-sm font-medium text-slate-700 mb-1">Customer
                        Number</label>
                    <input type="text" id="customer_number" name="customer_number" placeholder="Customer Number"
                        value="<?= htmlspecialchars($_GET['customer_number'] ?? '') ?>"
                        class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>

                <!-- Row 3 -->
                <div>
                    <label for="lead_status_filter" class="block text-sm font-medium text-slate-700 mb-1">Lead
                        Status</label>
                    <select id="lead_status_filter" name="lead_status_filter"
                        class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="all">All Status</option>
                        <?php
                        $all_status_filter = ['generated', 'in_process', 'declined', 'approved', 'activated', 'disbursed', 'curable'];
                        $selected_lead_status = $_GET['lead_status_filter'] ?? '';
                        foreach ($all_status_filter as $st): ?>
                            <option value="<?= $st ?>" <?= ($selected_lead_status === $st ? 'selected' : '') ?>>
                                <?= ucwords(str_replace('_', ' ', $st)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <!-- Lead Sub Status filter removed from dynamic layout -->
                <div>
                    <label for="lender_filter" class="block text-sm font-medium text-slate-700 mb-1">Lender</label>
                    <select id="lender_filter" name="lender_filter"
                        class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="all">All Lenders</option>
                        <!-- Options will be dynamically loaded or fetched from DB -->
                    </select>
                </div>

                <!-- Row 4 -->
                <div>
                    <label for="lead_type_filter" class="block text-sm font-medium text-slate-700 mb-1">Lead
                        Type</label>
                    <select id="lead_type_filter" name="lead_type_filter"
                        class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="all">All Lead Types</option>
                        <!-- Options will be dynamically loaded or fetched from DB -->
                    </select>
                </div>
                <!-- Pending Action filter removed from dynamic layout -->

                <div class="flex items-end gap-3 mt-auto">
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                        <i class="fas fa-filter mr-2"></i>Apply Filter
                    </button>
                    <button type="button" id="clearFilterBtn"
                        class="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300">
                        Clear
                    </button>
                </div>
            </form>
        </div>

        <!-- Mobile Card View -->
        <div class="md:hidden space-y-2 px-1">
            <h3 class="text-lg font-semibold text-slate-900 mb-2">All Leads (<?= count($leads) ?>)</h3>
            <?php foreach ($leads as $lead): ?>
                <div class="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
                    <!-- Card Header -->
                    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 px-3 py-2 border-b border-slate-200">
                        <div class="flex justify-between items-center">
                            <div class="flex flex-col">
                                <h4 class="text-sm font-bold text-slate-900">
                                    <?= htmlspecialchars($lead['customer_name'] ?? $lead['name'] ?? 'N/A') ?>
                                </h4>
                                <p class="text-xs text-slate-600 font-medium">
                                    <?= htmlspecialchars($lead['lead_id'] ?? 'N/A') ?>
                                </p>
                            </div>
                            <span
                                class="inline-flex px-2 py-1 text-xs font-bold rounded-full <?= getStatusBadge($lead['status']) ?>">
                                <?= ucwords(str_replace('_', ' ', $lead['status'])) ?>
                            </span>
                        </div>
                    </div>

                    <!-- Card Body -->
                    <div class="p-3 space-y-2">
                        <!-- Contact Info -->
                        <div class="grid grid-cols-2 gap-2">
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-phone text-blue-500 text-sm"></i>
                                <div>
                                    <p class="text-xs text-slate-500 font-medium">Phone</p>
                                    <p class="text-sm font-semibold text-slate-900">
                                        <?= htmlspecialchars($lead['mobile'] ?: ($lead['phone'] ?? 'N/A')) ?>
                                    </p>
                                </div>
                            </div>
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-envelope text-green-500 text-sm"></i>
                                <div class="flex-1 min-w-0">
                                    <p class="text-xs text-slate-500 font-medium">Email</p>
                                    <p class="text-sm font-semibold text-slate-900 truncate"
                                        title="<?= htmlspecialchars($lead['email'] ?? 'N/A') ?>">
                                        <?= htmlspecialchars($lead['email'] ?? 'N/A') ?>
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- Product Info -->
                        <div class="bg-slate-50 rounded-lg p-2">
                            <div class="grid grid-cols-2 gap-2">
                                <div class="min-w-0">
                                    <p class="text-xs text-slate-500 font-medium mb-1">Product</p>
                                    <p class="text-sm font-semibold text-slate-900 break-words"
                                        title="<?= htmlspecialchars($lead['product_name'] ?? 'N/A') ?>">
                                        <?= htmlspecialchars($lead['product_name'] ?? 'N/A') ?>
                                    </p>
                                </div>
                                <div class="min-w-0">
                                    <p class="text-xs text-slate-500 font-medium mb-1">Bank</p>
                                    <p class="text-sm font-semibold text-slate-900 break-words"
                                        title="<?= htmlspecialchars($lead['variant'] ?? 'N/A') ?>">
                                        <?= htmlspecialchars($lead['variant'] ?? 'N/A') ?>
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- Date & Advisor -->
                        <div class="grid grid-cols-2 gap-2">
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-calendar text-purple-500 text-sm"></i>
                                <div>
                                    <p class="text-xs text-slate-500 font-medium">Created</p>
                                    <p class="text-sm font-semibold text-slate-900">
                                        <?= formatDatabaseTime($lead['created_at_ist'] ?? $lead['created_at'], 'M d, Y') ?>
                                    </p>
                                </div>
                            </div>
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-user-tie text-orange-500 text-sm"></i>
                                <div class="flex-1 min-w-0">
                                    <p class="text-xs text-slate-500 font-medium">Advisor</p>
                                    <p class="text-sm font-semibold text-slate-900 truncate"
                                        title="<?= htmlspecialchars($lead['advisor_name'] ?? 'N/A') ?>">
                                        <?= htmlspecialchars($lead['advisor_name'] ?? 'N/A') ?>
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- MIS Info -->
                        <?php if (!empty($lead['card_variant_mis']) || !empty($lead['application_no_mis'])): ?>
                            <div class="bg-yellow-50 rounded-lg p-2">
                                <p class="text-xs text-yellow-700 font-bold mb-1">MIS Information</p>
                                <div class="grid grid-cols-1 gap-1">
                                    <?php if (!empty($lead['card_variant_mis'])): ?>
                                        <div>
                                            <p class="text-xs text-slate-500 font-medium">Card Variant</p>
                                            <p class="text-sm font-semibold text-slate-900">
                                                <?= htmlspecialchars($lead['card_variant_mis']) ?>
                                            </p>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($lead['application_no_mis'])): ?>
                                        <div>
                                            <p class="text-xs text-slate-500 font-medium">Application No</p>
                                            <p class="text-sm font-semibold text-slate-900">
                                                <?= htmlspecialchars($lead['application_no_mis']) ?>
                                            </p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <!-- Remark -->
                        <?php if (!empty($lead['remark'])): ?>
                            <div class="bg-blue-50 rounded-lg p-2">
                                <p class="text-xs text-blue-700 font-bold mb-1">Remark</p>
                                <p class="text-sm text-slate-900"><?= nl2br(htmlspecialchars($lead['remark'])) ?></p>
                            </div>
                        <?php endif; ?>

                        <!-- Activation Status -->
                        <?php if (!empty($lead['activation_status'])): ?>
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-check-circle text-green-500 text-sm"></i>
                                <div>
                                    <p class="text-xs text-slate-500 font-medium">Activation Status</p>
                                    <p class="text-sm font-semibold text-slate-900">
                                        <?= htmlspecialchars($lead['activation_status']) ?>
                                    </p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Card Footer -->
                    <div class="bg-slate-50 px-3 py-2 border-t border-slate-200">
                        <div class="flex justify-between items-center">
                            <button type="button" onclick="viewHistory(<?= $lead['id'] ?>)"
                                class="inline-flex items-center px-2 py-1 text-xs font-medium text-blue-600 bg-blue-100 rounded-lg hover:bg-blue-200 transition-colors">
                                <i class="fas fa-history mr-1"></i>
                                History
                            </button>
                            <button type="button"
                                onclick="copyApplicationUrl('<?= htmlspecialchars($lead['lead_id'] ?? '') ?>', '<?= htmlspecialchars($lead['bank_redirect_url'] ?? '') ?>')"
                                class="inline-flex items-center px-2 py-1 text-xs font-medium text-green-600 bg-green-100 rounded-lg hover:bg-green-200 transition-colors">
                                <i class="fas fa-copy mr-1"></i>
                                Copy URL
                            </button>
                            <?php if ($is_admin || $is_manager): ?>
                                <button type="button" onclick="showAdminInfoHover(<?= $lead['id'] ?>)"
                                    class="inline-flex items-center px-2 py-1 text-xs font-medium text-purple-600 bg-purple-100 rounded-lg hover:bg-purple-200 transition-colors">
                                    <i class="fas fa-info-circle mr-1"></i>
                                    Info
                                </button>
                            <?php endif; ?>
                            <?php if ($is_admin): ?>
                                <a href="edit_lead.php?lead_id=<?= $lead['id'] ?>"
                                    class="inline-flex items-center px-2 py-1 text-xs font-medium text-yellow-600 bg-yellow-100 rounded-lg hover:bg-yellow-200 transition-colors">
                                    <i class="fas fa-edit mr-1"></i>
                                    Edit
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Desktop Table View: simplified styling (compact, no horizontal scroll) -->
        <?php $all_status = ['generated', 'in_process', 'declined', 'approved', 'activated', 'disbursed', 'curable']; ?>
        <div class="hidden md:block">
            <?php if ($is_admin): ?>
                <!-- Bulk Actions Bar -->
                <div class="bg-white rounded-lg shadow mb-2 p-2 flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <input type="checkbox" id="selectAll" class="rounded">
                        <label for="selectAll" class="text-sm font-medium">Select All</label>
                        <span id="selectedCount" class="text-sm text-gray-600">(0 selected)</span>
                    </div>
                    <button id="bulkDeleteBtn"
                        class="bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700 disabled:opacity-50"
                        disabled>
                        <i class="fas fa-trash mr-1"></i>Delete Selected
                    </button>
                </div>
            <?php endif; ?>
            <div class="bg-white rounded-lg shadow">
                <!-- Wrap table in a scrollable container so header can be sticky -->
                <div class="overflow-y-auto max-h-[calc(100vh-160px)]" style="position: relative;">
                    <!-- Use table-auto so cells can size naturally and avoid text overlap; add break/overflow helpers on cells -->
                    <table class="w-full text-xs">
                        <thead class="bg-gray-50">
                            <tr class="text-left text-xs text-slate-700">
                                <?php if ($is_admin): ?>
                                    <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10 w-8">
                                        <input type="checkbox" class="rounded" disabled>
                                    </th>
                                <?php endif; ?>
                                <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10">Lead ID</th>
                                <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10">Date/Time</th>
                                <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10">Name</th>
                                <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10">Phone</th>
                                <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10">Type</th>
                                <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10">Product</th>
                                <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10">Bank</th>
                                <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10">Advisor</th>
                                <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10">Status</th>
                                <?php if ($is_manager): ?>
                                <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10"><span
                                            class="material-icons text-blue-600 hover:text-blue-800"
                                            title="Admin Info">info</span></th>
                                <?php endif; ?>
                                <?php if ($is_admin || $is_manager): ?>
                                <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10"><span
                                            class="material-icons text-blue-600 hover:text-blue-800"
                                            title="Admin Info">info</span></th>
                                <?php endif; ?>
                                <th class="px-1 py-1 font-semibold sticky top-0 bg-gray-50 z-10">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white text-xs">
                            <?php foreach ($leads as $lead): ?>
                                <tr
                                    class="hover:bg-slate-50 cursor-pointer desktop-lead-row align-top text-xs border-b border-gray-100">
                                    <?php if ($is_admin): ?>
                                        <td class="px-1 py-1">
                                            <input type="checkbox" class="lead-checkbox rounded" value="<?= $lead['id'] ?>">
                                        </td>
                                    <?php endif; ?>
                                    <td class="px-1 py-1 font-mono text-xs text-blue-900 truncate">
                                        <?= htmlspecialchars($lead['lead_id'] ?? '-') ?>
                                    </td>
                                    <?php if ($is_admin): ?>
                                        <td class="px-1 py-1 text-xs">
                                            <?= formatDatabaseTime($lead['created_at_ist'] ?? $lead['created_at']) ?>
                                        </td>
                                        <td class="px-1 py-1 break-words">
                                            <?= htmlspecialchars($lead['customer_name'] ?: ($lead['name'] ?? '-')) ?>
                                        </td>
                                        <td class="px-1 py-1 truncate">
                                            <?= !empty($lead['mobile']) ? htmlspecialchars($lead['mobile']) : (!empty($lead['phone']) ? htmlspecialchars($lead['phone']) : '-') ?>
                                        </td>
                                        <td class="px-1 py-1 break-words">
                                            <?= htmlspecialchars($lead['category'] ?? '-') ?>
                                        </td>
                                        <td class="px-1 py-1 break-words">
                                            <?= htmlspecialchars($lead['product_name'] ?? '-') ?>
                                        </td>
                                        <td class="px-1 py-1 truncate"><?= htmlspecialchars($lead['variant'] ?? '-') ?>
                                        </td>
                                        <td class="px-1 py-1 break-words">
                                            <?= htmlspecialchars($lead['advisor_name'] ?? '-') ?>
                                        </td>
                                        <td class="px-1 py-1">
                                            <span
                                                class="inline-flex px-2 py-0.5 text-[11px] font-semibold rounded-full <?= getStatusBadge($lead['status']) ?>">
                                                <?= normalizeStatusLabel($lead['status']) ?>
                                            </span>
                                        </td>
                                        <?php if ($is_admin || $is_manager): ?>
                                            <td class="px-1 py-1 text-center">
                                                <button onmouseover="showAdminInfoHover(<?= $lead['id'] ?>)"
                                                    onmouseout="hideAdminInfoHover()" class="text-blue-600 hover:text-blue-800">
                                                    <span class="material-icons">info_outline</span>
                                                </button>
                                            </td>
                                        <?php endif; ?>
                                        <td class="px-1 py-1">
                                            <div class="flex items-center gap-1 flex-wrap">
                                                <button type="button"
                                                    onclick="copyApplicationUrl('<?= htmlspecialchars($lead['lead_id'] ?? '') ?>', '<?= htmlspecialchars($lead['bank_redirect_url'] ?? '') ?>')"
                                                    class="text-[11px] bg-green-500 text-white px-2 py-0.5 rounded">Copy</button>
                                                <?php if ($is_admin): ?>
                                                <a href="edit_lead.php?lead_id=<?= $lead['id'] ?>"
                                                    class="text-[11px] bg-yellow-500 text-white px-2 py-0.5 rounded">Edit</a>
                                                <form method="POST" class="inline-block" action="">
                                                    <input type="hidden" name="lead_id" value="<?= $lead['id'] ?>">
                                                    <button type="submit" name="delete_lead"
                                                        class="text-[11px] bg-red-500 text-white px-2 py-0.5 rounded"
                                                        onclick="return confirm('Delete this lead?');">Delete</button>
                                                </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    <?php else: ?>
                                        <td class="px-1 py-1">
                                            <?= formatDatabaseTime($lead['created_at_ist'] ?? $lead['created_at']) ?>
                                        </td>
                                        <td class="px-1 py-1 break-words">
                                            <?= htmlspecialchars($lead['customer_name'] ?? $lead['name']) ?>
                                        </td>
                                        <td class="px-1 py-1 truncate">
                                            <?= !empty($lead['mobile']) ? htmlspecialchars($lead['mobile']) : (!empty($lead['phone']) ? htmlspecialchars($lead['phone']) : '-') ?>
                                        </td>
                                        <td class="px-1 py-1 break-words">
                                            <?= htmlspecialchars($lead['category'] ?? '-') ?>
                                        </td>
                                        <td class="px-1 py-1 break-words">
                                            <?= htmlspecialchars($lead['product_name']) ?>
                                        </td>
                                        <td class="px-1 py-1 truncate"><?= htmlspecialchars($lead['variant'] ?? '-') ?>
                                        </td>
                                        <td class="px-1 py-1 break-words">
                                            <?= htmlspecialchars($lead['advisor_name'] ?? '-') ?>
                                        </td>
                                        <td class="px-1 py-1">
                                            <span
                                                class="inline-flex px-2 py-0.5 text-[11px] font-semibold rounded-full <?= getStatusBadge($lead['status']) ?>">
                                                <?= ucwords(str_replace('_', ' ', $lead['status'])) ?>
                                            </span>
                                        </td>
                                        <?php if ($is_manager): ?>
                                            <td class="px-1 py-1 text-center">
                                                <button onmouseover="showAdminInfoHover(<?= $lead['id'] ?>)"
                                                    onmouseout="hideAdminInfoHover()" class="text-blue-600 hover:text-blue-800">
                                                    <span class="material-icons">info_outline</span>
                                                </button>
                                            </td>
                                        <?php endif; ?>
                                        <td class="px-1 py-1">
                                            <div class="flex items-center gap-1">
                                                <button type="button" onclick="viewHistory(<?= $lead['id'] ?>)"
                                                    class="text-[11px] bg-blue-500 text-white px-2 py-0.5 rounded">History</button>
                                                <button type="button"
                                                    onclick="copyApplicationUrl('<?= htmlspecialchars($lead['lead_id'] ?? '') ?>', '<?= htmlspecialchars($lead['bank_redirect_url'] ?? '') ?>')"
                                                    class="text-[11px] bg-green-500 text-white px-2 py-0.5 rounded">Copy
                                                    URL</button>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </main>

    <!-- Bulk Delete Modal -->
    <div id="bulkDeleteModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg shadow-xl max-w-md w-full">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-red-600 mb-4">Confirm Bulk Delete</h3>
                    <p class="text-gray-700 mb-4">Are you sure you want to delete <span id="deleteCount">0</span>
                        selected leads? This action cannot be undone.</p>
                    <form method="POST" id="bulkDeleteForm">
                        <input type="hidden" name="bulk_delete" value="1">
                        <div id="selectedLeadsInputs"></div>
                        <div class="flex justify-end space-x-3">
                            <button type="button" onclick="closeBulkDeleteModal()"
                                class="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
                            <button type="submit"
                                class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700">Delete
                                Leads</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modals -->
    <div id="statusModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg shadow-xl max-w-md w-full">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-slate-900 mb-4">Update Lead Status</h3>
                    <form method="POST">
                        <input type="hidden" name="update_status" value="1">
                        <input type="hidden" name="lead_id" id="modalLeadId">
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-slate-700 mb-2">New Status</label>
                            <select name="new_status" id="modalStatus"
                                class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <?php foreach ($all_status as $st): ?>
                                    <option value="<?= $st ?>"><?= ucwords(str_replace('_', ' ', $st)) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-slate-700 mb-2">Notes (Optional)</label>
                            <textarea name="notes" rows="3"
                                class="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Add any notes..."></textarea>
                        </div>
                        <div class="flex justify-end space-x-3">
                            <button type="button" onclick="closeModal()"
                                class="px-4 py-2 text-slate-600 hover:text-slate-800">Cancel</button>
                            <button type="submit"
                                class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Update
                                Status</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div id="leadDetailModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-2 sm:p-4">
            <div class="bg-white rounded-lg shadow-xl max-w-3xl w-full mx-2 max-h-[90vh] flex flex-col">
                <div class="p-4 sm:p-6 overflow-y-auto">
                    <h3 class="text-lg font-semibold text-slate-900 mb-4">Lead Details</h3>
                    <div id="leadDetailBody"></div>
                    <div class="flex justify-end mt-4">
                        <button type="button" onclick="closeLeadDetailModal()"
                            class="px-4 py-2 text-slate-600 hover:text-slate-800">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Hover popup for admin info -->
    <div id="adminInfoHover"
        class="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg shadow-xl p-4 max-w-md w-full mx-2 hidden z-50 border">
        <div id="adminInfoContent"></div>
    </div>

    <?php include __DIR__ . '/../includes/footer.php'; ?>


    <script>
        // Filter bar toggle
        document.addEventListener('DOMContentLoaded', () => {
            const filterBtn = document.getElementById('toggleFilterBtn');
            const filterBar = document.getElementById('advancedFilterBar');
            if (filterBtn && filterBar) {
                filterBtn.addEventListener('click', () => {
                    filterBar.style.display = (filterBar.style.display === 'none' || filterBar.style.display === '') ? 'flex' : 'none';
                });
            }
            // Clear button resets all fields in the advanced filter bar
            const clearBtn = document.getElementById('clearFilterBtn');
            if (clearBtn && filterBar) {
                clearBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    // Clear all form fields
                    filterBar.querySelectorAll('input, select').forEach(el => {
                        if (el.tagName === 'SELECT') {
                            el.selectedIndex = 0;
                        } else {
                            el.value = '';
                        }
                    });
                    // Submit the form to clear filters
                    window.location.href = 'leads_updated.php';
                });
            }

            // ...existing code for mobile card expand/collapse and actions dropdown...
            document.querySelectorAll('.lead-details').forEach(details => {
                details.classList.remove('expanded');
                details.setAttribute('aria-hidden', 'true');
                const btn = details.parentElement.querySelector('.mobile-lead-toggle');
                if (btn) {
                    btn.setAttribute('aria-expanded', 'false');
                    const chevron = btn.querySelector('i.fa-chevron-down, i.fa-chevron-up');
                    if (chevron) {
                        chevron.classList.remove('fa-chevron-up');
                        chevron.classList.add('fa-chevron-down');
                    }
                }
            });
            function collapseCard(details, btn) {
                if (!details) return;
                details.classList.remove('expanded');
                details.setAttribute('aria-hidden', 'true');
                details.style.maxHeight = '0px';
                if (btn) {
                    btn.setAttribute('aria-expanded', 'false');
                    const chevron = btn.querySelector('i.fa-chevron-up, i.fa-chevron-down');
                    if (chevron) {
                        chevron.classList.remove('fa-chevron-up');
                        chevron.classList.add('fa-chevron-down');
                    }
                }
            }
            document.querySelectorAll('.mobile-lead-toggle').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const card = btn.closest('.lead-card') || btn.closest('.bg-white');
                    const details = card.querySelector('.lead-details');
                    if (!details) return;
                    document.querySelectorAll('.lead-details').forEach(d => {
                        if (d !== details) {
                            const otherBtn = d.parentElement.querySelector('.mobile-lead-toggle');
                            collapseCard(d, otherBtn);
                        }
                    });
                    const isOpen = details.classList.contains('expanded');
                    const chevron = btn.querySelector('i.fa-chevron-down, i.fa-chevron-up');
                    if (isOpen) {
                        collapseCard(details, btn);
                    } else {
                        details.setAttribute('aria-hidden', 'false');
                        details.classList.add('expanded');
                        details.style.maxHeight = '0px';
                        details.offsetHeight;
                        details.style.maxHeight = (details.scrollHeight + 20) + 'px';
                        btn.setAttribute('aria-expanded', 'true');
                        if (chevron) {
                            chevron.classList.add('fa-chevron-up');
                            chevron.classList.remove('fa-chevron-down');
                        }
                    }
                });
            });
            document.addEventListener('click', () => {
                document.querySelectorAll('.actions-dropdown').forEach(drop => drop.classList.add('hidden'));
            });
            document.querySelectorAll('.actions-btn').forEach(btn => {
                btn.addEventListener('click', e => {
                    e.stopPropagation();
                    document.querySelectorAll('.actions-dropdown').forEach(d => {
                        if (d !== btn.nextElementSibling) {
                            d.classList.add('hidden');
                        }
                    });
                    const dd = btn.nextElementSibling;
                    if (dd) dd.classList.toggle('hidden');
                });
            });
        });

        function toggleActionsDropdown(btn) {
            event.stopPropagation();
            document.querySelectorAll('.actions-dropdown').forEach(d => {
                if (d !== btn.nextElementSibling) {
                    d.classList.add('hidden');
                }
            });
            const dd = btn.nextElementSibling;
            if (dd) dd.classList.toggle('hidden');
        }

        function viewHistory(leadId) {
            // Add cache-busting timestamp to ensure fresh data after status updates
            fetch(`leads_updated.php?history=1&lead_id=${leadId}&_t=${Date.now()}`)
                .then(res => {
                    if (!res.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return res.json();
                })
                .then(data => {
                    let html = `<h3 class="text-base sm:text-lg font-semibold mb-3">Status History for Lead #${leadId}</h3>`;
                    if (!data || data.length === 0) {
                        html += '<div class="text-slate-500 p-4">No history found.</div>';
                    } else {
                        html += `<div class="overflow-x-auto -mx-4 sm:mx-0"><div class="inline-block min-w-full align-middle"><table class="min-w-full text-xs sm:text-sm border-collapse"><thead class="bg-gray-50"><tr><th class="border p-1.5 sm:p-2 text-left whitespace-nowrap">Date</th><th class="border p-1.5 sm:p-2 text-left whitespace-nowrap">Old Status</th><th class="border p-1.5 sm:p-2 text-left whitespace-nowrap">New Status</th><th class="border p-1.5 sm:p-2 text-left whitespace-nowrap">Changed By</th><th class="border p-1.5 sm:p-2 text-left whitespace-nowrap">Notes</th></tr></thead><tbody>`;
                        data.forEach(r => {
                            const formattedDate = r.created_at ? new Date(r.created_at + " GMT+0530").toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short", hour12: true }) : '-';
                            html += `<tr class="hover:bg-gray-50">
                        <td class="border p-1.5 sm:p-2 whitespace-nowrap text-xs sm:text-sm">${formattedDate}</td>
                        <td class="border p-1.5 sm:p-2 whitespace-nowrap text-xs sm:text-sm">${r.old_status || '-'}</td>
                        <td class="border p-1.5 sm:p-2 whitespace-nowrap text-xs sm:text-sm">${r.new_status || '-'}</td>
                        <td class="border p-1.5 sm:p-2 whitespace-nowrap text-xs sm:text-sm">${r.changed_by || '-'}</td>
                        <td class="border p-1.5 sm:p-2 text-xs sm:text-sm">${r.notes || '-'}</td>
                    </tr>`;
                        });
                        html += `</tbody></table></div></div>`;
                    }
                    document.getElementById('leadDetailBody').innerHTML = html;
                    document.getElementById('leadDetailModal').classList.remove('hidden');
                })
                .catch(error => {
                    console.error('Error fetching history:', error);
                    document.getElementById('leadDetailBody').innerHTML = `<div class="text-red-500 p-4 text-sm">Error loading history: ${error.message}</div>`;
                    document.getElementById('leadDetailModal').classList.remove('hidden');
                });
        }

        function closeLeadDetailModal() {
            document.getElementById('leadDetailModal').classList.add('hidden');
        }

        function closeModal() {
            document.getElementById('statusModal').classList.add('hidden');
        }

        function copyApplicationUrl(leadId, bankRedirectUrl) {
            if (!leadId || leadId.trim() === '') {
                alert('Lead ID is missing or empty');
                return;
            }

            let applicationUrl;
            if (bankRedirectUrl && bankRedirectUrl.trim() !== '') {
                applicationUrl = bankRedirectUrl.replace(/{lead_id}/g, leadId);
            } else {
                applicationUrl = `https://www.idfcfirstbank.com/credit-card/ntb-diy/apply?utm_source=Partner&utm_medium=Choiceconnect&utm_campaign=C0079055_${leadId}`;
            }

            navigator.clipboard.writeText(applicationUrl).then(() => {
                alert('Application URL copied to clipboard!');
            }).catch(err => {
                console.error('Failed to copy application URL: ', err);
                alert('Failed to copy URL.');
            });
        }

        // Inline editing removed — editing moved to edit_lead.php for consistency

        function showAdminInfoHover(leadId) {
            const lead = <?= json_encode($leads) ?>.find(l => l.id == leadId);
            if (!lead) return;

            let html = `<h3 class="text-lg font-semibold mb-4">Admin Info - Lead #${lead.lead_id}</h3>`;
            html += `<div class="grid grid-cols-2 gap-4 text-sm">`;
            html += `<div><strong>Cust Type:</strong> ${lead.cust_type || '-'}</div>`;
            html += `<div><strong>Card Issued:</strong> ${lead.card_issued_date || '-'}</div>`;
            html += `<div><strong>VKYC:</strong> <span class="px-2 py-1 rounded text-xs ${getStatusClass(lead.vkyc_status)}">${lead.vkyc_status || '-'}</span></div>`;
            html += `<div><strong>BKYC:</strong> <span class="px-2 py-1 rounded text-xs ${getStatusClass(lead.bkyc_status)}">${lead.bkyc_status || '-'}</span></div>`;
            html += `<div class="col-span-2"><strong>Remark:</strong><br>${(lead.remark || '-').replace(/\n/g, '<br>')}</div>`;
            html += `<div><strong>Activation:</strong> ${lead.activation_status || '-'}</div>`;
            html += `<div><strong>Card Variant (MIS):</strong> ${lead.card_variant_mis || '-'}</div>`;
            html += `<div class="col-span-2"><strong>Application No (MIS):</strong> ${lead.application_no_mis || '-'}</div>`;
            html += `</div>`;
            html += `<div class="flex justify-end mt-4"><button onclick="hideAdminInfoHover()" class="px-4 py-2 text-slate-600 hover:text-slate-800">Close</button></div>`;

            document.getElementById('adminInfoContent').innerHTML = html;
            document.getElementById('adminInfoHover').classList.remove('hidden');
        }

        function hideAdminInfoHover() {
            document.getElementById('adminInfoHover').classList.add('hidden');
        }

        function getStatusClass(status) {
            if (!status) return 'bg-gray-100 text-gray-800';
            switch (status) {
                case 'COMPLETED': return 'bg-green-100 text-green-800';
                case 'PENDING': return 'bg-yellow-100 text-yellow-800';
                case 'EXPIRED': case 'REJECTED': return 'bg-red-100 text-red-800';
                default: return 'bg-gray-100 text-gray-800';
            }
        }

        // Bulk selection functionality
        document.addEventListener('DOMContentLoaded', function () {
            const selectAllCheckbox = document.getElementById('selectAll');
            const leadCheckboxes = document.querySelectorAll('.lead-checkbox');
            const selectedCountSpan = document.getElementById('selectedCount');
            const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');

            function updateSelectedCount() {
                const checkedBoxes = document.querySelectorAll('.lead-checkbox:checked');
                const count = checkedBoxes.length;
                selectedCountSpan.textContent = `(${count} selected)`;
                bulkDeleteBtn.disabled = count === 0;

                // Update select all checkbox state
                if (count === 0) {
                    selectAllCheckbox.indeterminate = false;
                    selectAllCheckbox.checked = false;
                } else if (count === leadCheckboxes.length) {
                    selectAllCheckbox.indeterminate = false;
                    selectAllCheckbox.checked = true;
                } else {
                    selectAllCheckbox.indeterminate = true;
                }
            }

            // Select all functionality
            if (selectAllCheckbox) {
                selectAllCheckbox.addEventListener('change', function () {
                    leadCheckboxes.forEach(checkbox => {
                        checkbox.checked = this.checked;
                    });
                    updateSelectedCount();
                });
            }

            // Individual checkbox change
            leadCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', updateSelectedCount);
            });

            // Bulk delete button
            if (bulkDeleteBtn) {
                bulkDeleteBtn.addEventListener('click', function () {
                    const checkedBoxes = document.querySelectorAll('.lead-checkbox:checked');
                    if (checkedBoxes.length === 0) return;

                    document.getElementById('deleteCount').textContent = checkedBoxes.length;

                    // Add hidden inputs for selected leads
                    const inputsContainer = document.getElementById('selectedLeadsInputs');
                    inputsContainer.innerHTML = '';
                    checkedBoxes.forEach(checkbox => {
                        const input = document.createElement('input');
                        input.type = 'hidden';
                        input.name = 'selected_leads[]';
                        input.value = checkbox.value;
                        inputsContainer.appendChild(input);
                    });

                    document.getElementById('bulkDeleteModal').classList.remove('hidden');
                });
            }
        });

        function closeBulkDeleteModal() {
            document.getElementById('bulkDeleteModal').classList.add('hidden');
        }
    </script>
    <script src="/assets/js/loading.js"></script>
</body>

</html>
