<?php
require_once '../includes/auth.php';

requireLogin();
$user = getCurrentUser();
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Finonest</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gradient-to-br from-slate-50 to-slate-100 min-h-screen pb-20">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include_once('../includes/header.php'); ?>
    
    <div class="max-w-md mx-auto px-4 pt-20">
        <!-- Profile Card -->
        <div class="bg-white rounded-3xl shadow-xl overflow-hidden">
            <!-- Header Background -->
            <div class="h-32 bg-gradient-to-r from-blue-500 to-blue-600"></div>
            
            <!-- Profile Content -->
            <div class="px-6 pb-6 -mt-16">
                <!-- Avatar -->
                <div class="w-28 h-28 mx-auto rounded-full bg-white p-2 shadow-lg mb-4">
                    <div class="w-full h-full rounded-full bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                        <i class="fas fa-user text-5xl text-blue-600"></i>
                    </div>
                </div>
                
                <!-- User Info -->
                <div class="text-center mb-6">
                    <h1 class="text-2xl font-bold text-slate-900 mb-1"><?php echo htmlspecialchars($user['name']); ?></h1>
                    <p class="text-slate-600 text-sm mb-2"><?php echo htmlspecialchars($user['email']); ?></p>
                    <span class="inline-block px-4 py-1 bg-blue-50 text-blue-600 rounded-full text-xs font-medium">Lead Management Partner</span>
                </div>
                
                <!-- Quick Actions -->
                <div class="grid grid-cols-2 gap-3 mb-6">
                    <a href="mailto:<?php echo htmlspecialchars($user['email']); ?>" class="flex items-center justify-center gap-2 p-4 bg-blue-50 rounded-xl hover:bg-blue-100 transition-all active:scale-95">
                        <i class="fas fa-envelope text-blue-600"></i>
                        <span class="text-sm font-medium text-blue-600">Email</span>
                    </a>
                    <a href="tel:<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" class="flex items-center justify-center gap-2 p-4 bg-green-50 rounded-xl hover:bg-green-100 transition-all active:scale-95">
                        <i class="fas fa-phone text-green-600"></i>
                        <span class="text-sm font-medium text-green-600">Call</span>
                    </a>
                </div>
                
                <!-- Menu Options -->
                <div class="space-y-2">
                    <a href="../adviser/dashboard.php" class="flex items-center justify-between p-4 hover:bg-slate-50 rounded-xl transition-all">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-home text-slate-600"></i>
                            <span class="text-slate-700 font-medium">Dashboard</span>
                        </div>
                        <i class="fas fa-chevron-right text-slate-400 text-sm"></i>
                    </a>
                    <a href="../leads/leads_updated.php" class="flex items-center justify-between p-4 hover:bg-slate-50 rounded-xl transition-all">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-users text-slate-600"></i>
                            <span class="text-slate-700 font-medium">My Leads</span>
                        </div>
                        <i class="fas fa-chevron-right text-slate-400 text-sm"></i>
                    </a>
                    <a href="../adviser/payouts.php" class="flex items-center justify-between p-4 hover:bg-slate-50 rounded-xl transition-all">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-money-bill-wave text-slate-600"></i>
                            <span class="text-slate-700 font-medium">Payouts</span>
                        </div>
                        <i class="fas fa-chevron-right text-slate-400 text-sm"></i>
                    </a>
                    <a href="/Auth/logout.php" class="flex items-center justify-between p-4 hover:bg-red-50 rounded-xl transition-all">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-sign-out-alt text-red-600"></i>
                            <span class="text-red-600 font-medium">Logout</span>
                        </div>
                        <i class="fas fa-chevron-right text-red-400 text-sm"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <?php include_once('../includes/footer.php'); ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
