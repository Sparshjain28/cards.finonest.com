<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/role_manager.php';
require_once __DIR__ . '/../config/database_updated.php';

requireLogin();
if (!isManager() && !isAdmin()) {
    header('Location: ../adviser/dashboard.php');
    exit();
}

$database = new Database();
$conn = $database->getConnection();
$roleManager = new RoleManager($conn);

$currentUserId = $_SESSION['user_id'];
$isCurrentUserAdmin = isAdmin();

// Get dashboard stats based on permissions and manager restrictions
$stats = [];

// Use role-based permission system
$canViewLeads = hasPermission('view_leads');
$canManageLeads = hasPermission('manage_leads');
$canViewUsers = hasPermission('view_users');
$canManageUsers = hasPermission('manage_users');
$canViewProducts = hasPermission('view_products');
$canViewPayouts = hasPermission('view_payouts');
$canManagePayouts = hasPermission('manage_payouts');
$canViewReports = hasPermission('view_reports');

if ($canViewLeads) {
    if ($isCurrentUserAdmin) {
        // Admin sees all leads
        $result = $conn->query("SELECT COUNT(*) as count FROM leads");
        $stats['total_leads'] = $result->fetch_assoc()['count'];
        
        $result = $conn->query("SELECT COUNT(*) as count FROM leads WHERE status = 'approved'");
        $stats['approved_leads'] = $result->fetch_assoc()['count'];
    } else {
        // Manager sees only assigned leads
        $managerLeadsWhere = $roleManager->getManagerLeadsQuery($currentUserId);
        
        $result = $conn->query("SELECT COUNT(*) as count FROM leads l WHERE $managerLeadsWhere");
        $stats['total_leads'] = $result->fetch_assoc()['count'];
        
        $result = $conn->query("SELECT COUNT(*) as count FROM leads l WHERE ($managerLeadsWhere) AND l.status = 'approved'");
        $stats['approved_leads'] = $result->fetch_assoc()['count'];
    }
}

if ($canViewUsers) {
    if ($isCurrentUserAdmin) {
        // Admin sees all users
        $result = $conn->query("SELECT COUNT(*) as count FROM users");
        $stats['total_users'] = $result->fetch_assoc()['count'];
    } else {
        // Manager sees only assigned users
        $result = $conn->query("SELECT COUNT(*) as count FROM users WHERE assigned_manager_id = $currentUserId OR id = $currentUserId");
        $stats['total_users'] = $result->fetch_assoc()['count'];
    }
}

if ($canViewProducts) {
    $result = $conn->query("SELECT COUNT(*) as count FROM products WHERE status = 'active'");
    $stats['active_products'] = $result->fetch_assoc()['count'];
}

if ($canViewPayouts) {
    if ($isCurrentUserAdmin) {
        // Admin sees all payouts
        $result = $conn->query("SELECT SUM(commission_amount) as total FROM payouts WHERE status = 'paid'");
        $stats['total_payouts'] = $result->fetch_assoc()['total'] ?? 0;
    } else {
        // Manager sees only assigned payouts
        $managerPayoutsWhere = $roleManager->getManagerPayoutsQuery($currentUserId);
        $result = $conn->query("SELECT SUM(p.commission_amount) as total FROM payouts p WHERE ($managerPayoutsWhere) AND p.status = 'paid'");
        $stats['total_payouts'] = $result->fetch_assoc()['total'] ?? 0;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Dashboard - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Welcome Banner -->
        <div class="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl shadow-xl p-6 mb-8 text-white">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-3xl font-bold mb-2">Manager Dashboard</h1>
                    <p class="text-blue-100">Welcome back! Manage your team and track performance.</p>
                </div>
                <div class="hidden md:block">
                    <div class="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                        <i class="fas fa-user-tie text-3xl"></i>
                    </div>
                </div>
            </div>
        </div>
        <!-- Banner Section -->
        <div class="mb-4">
            <div class="bg-orange-50 border-l-4 border-orange-400 rounded-lg p-3 flex items-center gap-2">
                <span class="text-2xl">👨‍💼</span>
                <span class="text-orange-800 text-sm font-medium lg:font-bold">Manager Dashboard <span class="hidden lg:inline">&mdash; Manage Operations with Enhanced Permissions</span></span>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Performance Overview</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php if (isset($stats['total_leads'])): ?>
                <a href="../leads/leads_updated.php" class="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-lg shadow-sm p-3 hover:border-blue-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-users text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-blue-700"><?php echo number_format($stats['total_leads']); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-blue-800">Total Leads</h3>
                        <p class="text-xs text-blue-600">All applications</p>
                    </div>
                </a>
                <?php endif; ?>

                <?php if (isset($stats['approved_leads'])): ?>
                <a href="../leads/leads_updated.php?status=approved" class="group bg-gradient-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-200 rounded-lg shadow-sm p-3 hover:border-emerald-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-check-circle text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-emerald-700"><?php echo number_format($stats['approved_leads']); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-emerald-800">Approved</h3>
                        <p class="text-xs text-emerald-600">Successfully processed</p>
                    </div>
                </a>
                <?php endif; ?>

                <?php if (isset($stats['total_users'])): ?>
                <a href="../admin/users.php" class="group bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-200 rounded-lg shadow-sm p-3 hover:border-purple-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-user-friends text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-purple-700"><?php echo number_format($stats['total_users']); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-purple-800">Total Users</h3>
                        <p class="text-xs text-purple-600">System users</p>
                    </div>
                </a>
                <?php endif; ?>

                <?php if (isset($stats['total_payouts'])): ?>
                <a href="../admin/payouts.php" class="group bg-gradient-to-br from-yellow-50 to-yellow-100 border-2 border-yellow-200 rounded-lg shadow-sm p-3 hover:border-yellow-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-money-bill-wave text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-yellow-700">₹<?php echo number_format($stats['total_payouts']); ?></div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-yellow-800">Total Payouts</h3>
                        <p class="text-xs text-yellow-600">Commission paid</p>
                    </div>
                </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Product Portfolio -->
        <div class="mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Product Portfolio</h2>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                <a href="../forms/apply_card.php" class="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-lg shadow-sm p-3 hover:border-blue-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-credit-card text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-blue-700">Active</div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-blue-800">Credit Cards</h3>
                        <p class="text-xs text-blue-600">Premium cards</p>
                    </div>
                </a>
                
                <a href="../forms/apply_personal.php" class="group bg-gradient-to-br from-emerald-50 to-emerald-100 border-2 border-emerald-200 rounded-lg shadow-sm p-3 hover:border-emerald-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-coins text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-emerald-700">Active</div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-emerald-800">Personal Loans</h3>
                        <p class="text-xs text-emerald-600">Quick loans</p>
                    </div>
                </a>
                
                <a href="../forms/apply_car.php" class="group bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-200 rounded-lg shadow-sm p-3 hover:border-orange-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-car-side text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-orange-700">Active</div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-orange-800">Car Loans</h3>
                        <p class="text-xs text-orange-600">Auto financing</p>
                    </div>
                </a>
                
                <a href="../forms/offline_pl_form.php" class="group bg-gradient-to-br from-indigo-50 to-indigo-100 border-2 border-indigo-200 rounded-lg shadow-sm p-3 hover:border-indigo-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-money-bill-wave text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-indigo-700">Active</div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-indigo-800">Offline Personal Loan</h3>
                        <p class="text-xs text-indigo-600">Direct processing</p>
                    </div>
                </a>
                
                <a href="../forms/business_loan_form.php" class="group bg-gradient-to-br from-teal-50 to-teal-100 border-2 border-teal-200 rounded-lg shadow-sm p-3 hover:border-teal-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-teal-500 to-teal-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-briefcase text-white text-xs"></i>
                        </div>
                        <div class="text-right">
                            <div class="text-xl font-bold text-teal-700">Active</div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-teal-800">Business Loan</h3>
                        <p class="text-xs text-teal-600">Business growth</p>
                    </div>
                </a>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Quick Actions</h2>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <a href="../leads/leads_updated.php" class="group bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-lg shadow-sm p-3 hover:border-blue-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-users text-white text-xs"></i>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-blue-800">Manage Leads</h3>
                        <p class="text-xs text-blue-600">View and edit leads</p>
                    </div>
                </a>

                <?php if ($canManageUsers): ?>
                <a href="../admin/users.php" class="group bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200 rounded-lg shadow-sm p-3 hover:border-green-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-user-friends text-white text-xs"></i>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-green-800">Manage Users</h3>
                        <p class="text-xs text-green-600">View and edit users</p>
                    </div>
                </a>
                <?php endif; ?>

                <?php if (hasPermission('manage_products')): ?>
                <a href="../admin/products.php" class="group bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-200 rounded-lg shadow-sm p-3 hover:border-purple-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-box text-white text-xs"></i>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-purple-800">Manage Products</h3>
                        <p class="text-xs text-purple-600">View and edit products</p>
                    </div>
                </a>
                <?php endif; ?>

                <a href="../admin/payouts.php" class="group bg-gradient-to-br from-yellow-50 to-yellow-100 border-2 border-yellow-200 rounded-lg shadow-sm p-3 hover:border-yellow-400 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between mb-2">
                        <div class="w-9 h-9 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <i class="fas fa-money-bill-wave text-white text-xs"></i>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-yellow-800">View Payouts</h3>
                        <p class="text-xs text-yellow-600">Check payout status</p>
                    </div>
                </a>
            </div>
        </div>

        <!-- Permissions Overview -->
        <div class="bg-white rounded-2xl shadow-xl border border-gray-100">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-2xl font-bold text-gray-900">Manager Access Summary</h2>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php if ($canViewLeads): ?>
                    <div class="bg-blue-50 p-4 rounded-lg">
                        <h3 class="font-medium text-blue-900 mb-2 flex items-center gap-2">
                            <i class="fas fa-users text-blue-600"></i> Lead Management
                        </h3>
                        <div class="space-y-1 text-sm text-blue-700">
                            <div>✓ View assigned leads</div>
                            <?php if ($canManageLeads): ?><div>✓ Edit lead details</div><?php endif; ?>
                            <?php if ($canViewReports): ?><div>✓ Export lead data</div><?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($canViewUsers): ?>
                    <div class="bg-green-50 p-4 rounded-lg">
                        <h3 class="font-medium text-green-900 mb-2 flex items-center gap-2">
                            <i class="fas fa-user-friends text-green-600"></i> User Management
                        </h3>
                        <div class="space-y-1 text-sm text-green-700">
                            <div>✓ View assigned users</div>
                            <?php if ($canManageUsers): ?><div>✓ Edit user details</div><?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($canViewPayouts): ?>
                    <div class="bg-purple-50 p-4 rounded-lg">
                        <h3 class="font-medium text-purple-900 mb-2 flex items-center gap-2">
                            <i class="fas fa-money-bill-wave text-purple-600"></i> Payout Access
                        </h3>
                        <div class="space-y-1 text-sm text-purple-700">
                            <div>✓ View team payouts</div>
                            <?php if ($canViewReports): ?><div>✓ Export payout reports</div><?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($canViewReports): ?>
                    <div class="bg-orange-50 p-4 rounded-lg">
                        <h3 class="font-medium text-orange-900 mb-2 flex items-center gap-2">
                            <i class="fas fa-chart-bar text-orange-600"></i> Reporting
                        </h3>
                        <div class="space-y-1 text-sm text-orange-700">
                            <div>✓ View team reports</div>
                            <div>✓ Export reports</div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <?php if (!$isCurrentUserAdmin): ?>
                <div class="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div class="flex items-center gap-2 text-yellow-800">
                        <i class="fas fa-info-circle"></i>
                        <span class="font-medium">Manager Access Note</span>
                    </div>
                    <p class="text-sm text-yellow-700 mt-1">
                        As a manager, you can only view and manage data for users assigned to you by the administrator.
                    </p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>
    
    <script>
    // Ensure logo click works correctly for manager dashboard
    document.addEventListener('DOMContentLoaded', function() {
        // Let the header.php handle logo clicks naturally without interference
        // Remove any conflicting event listeners
        var logoLinks = document.querySelectorAll('header a[href*="dashboard"], header a[href="/"], header a[href="/index.php"]');
        logoLinks.forEach(function(logo) {
            // Remove existing event listeners by cloning the element
            var newLogo = logo.cloneNode(true);
            logo.parentNode.replaceChild(newLogo, logo);
        });
    });
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>