<?php
// 404.php - Custom Not Found Page
http_response_code(404);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 Not Found</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-100 to-blue-100">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="text-center">
        <div class="w-20 h-20 mx-auto mb-6 flex items-center justify-center bg-blue-600 rounded-full shadow-lg">
            <i class="fas fa-exclamation-triangle text-4xl text-white"></i>
        </div>
        <h1 class="text-5xl font-bold text-blue-700 mb-4">404</h1>
        <p class="text-lg text-slate-700 mb-6">Sorry, the page you are looking for was not found.</p>
        <a href="../index.php" class="bg-blue-600 text-white px-6 py-3 rounded-lg shadow hover:bg-blue-700 font-semibold">Go Home</a>
    </div>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
