<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/aadhaar_verification.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['email'])) {
    header('Location: ../signup.php');
    exit();
}

$email = $_GET['email'];
$error = '';
$success = '';
$step = $_GET['step'] ?? 'aadhaar';

// API Key - Replace with your actual API key
$apiKey = "your-actual-api-key";
$kycVerifier = new KYCVerification($apiKey);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step === 'aadhaar' && isset($_POST['aadhaar'])) {
        $aadhaar = preg_replace('/\D/', '', $_POST['aadhaar']);
        
        if (strlen($aadhaar) !== 12) {
            $error = 'Please enter a valid 12-digit Aadhaar number';
        } else {
            $result = $kycVerifier->generateOTP($aadhaar);
            
            if ($result['success']) {
                $_SESSION['aadhaar_request_id'] = $result['data']['request_id'] ?? '';
                $_SESSION['aadhaar_number'] = $aadhaar;
                header('Location: ?email=' . urlencode($email) . '&step=otp');
                exit();
            } else {
                $error = 'Failed to send OTP. Please check your Aadhaar number and try again.';
            }
        }
    } elseif ($step === 'otp' && isset($_POST['otp'])) {
        $otp = $_POST['otp'];
        $requestId = $_SESSION['aadhaar_request_id'] ?? '';
        
        if (empty($otp) || empty($requestId)) {
            $error = 'Invalid OTP or session expired';
        } else {
            $result = $kycVerifier->submitOTP($requestId, $otp);
            
            if ($result['success']) {
                // Store verification status in database
                require_once '../config/database_updated.php';
                $database = new Database();
                $conn = $database->getConnection();
                
                $stmt = $conn->prepare("UPDATE users SET aadhaar_verified = 1, aadhaar_number = ? WHERE email = ?");
                $stmt->bind_param("ss", $_SESSION['aadhaar_number'], $email);
                $stmt->execute();
                
                unset($_SESSION['aadhaar_request_id'], $_SESSION['aadhaar_number']);
                header('Location: kyc.php?email=' . urlencode($email));
                exit();
            } else {
                $error = 'Invalid OTP. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aadhaar Verification - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <div class="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i class="fas fa-shield-alt text-2xl text-white"></i>
            </div>
            <h1 class="text-3xl font-bold text-slate-900 mb-2">Aadhaar Verification</h1>
            <p class="text-slate-600">Secure verification using your Aadhaar number</p>
        </div>

        <div class="card shadow-2xl border-0 bg-white">
            <div class="p-6">
                <?php if ($error): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                        <i class="fas fa-exclamation-circle mr-2"></i>
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <?php if ($step === 'aadhaar'): ?>
                    <h2 class="text-xl font-semibold mb-4">Enter Aadhaar Number</h2>
                    <form method="POST" class="space-y-4">
                        <div>
                            <label for="aadhaar" class="block text-sm font-medium text-gray-700 mb-2">
                                Aadhaar Number
                            </label>
                            <input 
                                type="text" 
                                id="aadhaar" 
                                name="aadhaar" 
                                maxlength="12" 
                                pattern="\d{12}"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Enter 12-digit Aadhaar number"
                                required
                            >
                        </div>
                        <button 
                            type="submit" 
                            class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                            Send OTP
                        </button>
                    </form>
                <?php elseif ($step === 'otp'): ?>
                    <h2 class="text-xl font-semibold mb-4">Enter OTP</h2>
                    <p class="text-sm text-gray-600 mb-4">
                        OTP has been sent to your registered mobile number linked with Aadhaar
                    </p>
                    <form method="POST" class="space-y-4">
                        <div>
                            <label for="otp" class="block text-sm font-medium text-gray-700 mb-2">
                                Enter OTP
                            </label>
                            <input 
                                type="text" 
                                id="otp" 
                                name="otp" 
                                maxlength="6"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Enter 6-digit OTP"
                                required
                            >
                        </div>
                        <button 
                            type="submit" 
                            class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                            Verify OTP
                        </button>
                    </form>
                    <div class="mt-4 text-center">
                        <a href="?email=<?php echo urlencode($email); ?>&step=aadhaar" class="text-blue-600 hover:text-blue-800 text-sm">
                            Back to Aadhaar Number
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="/assets/js/loading.js"></script>
</body>
</html>