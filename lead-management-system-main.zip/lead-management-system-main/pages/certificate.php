<?php
// Certificate Page
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
</head>
<body class="min-h-screen bg-slate-50 flex items-center justify-center">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="bg-white rounded-2xl shadow-xl p-8 text-center max-w-lg w-full border">
        <h1 class="text-2xl font-bold mb-4 text-blue-700">Certificate of Partnership</h1>
        <div class="border-4 border-blue-200 rounded-xl p-6 bg-blue-50">
            <p class="text-lg mb-2">This is to certify that</p>
            <p class="text-xl font-semibold text-slate-900 mb-2"><?php echo htmlspecialchars($user['name']); ?></p>
            <p class="text-slate-700 mb-2">has successfully joined as a Partner in the Lead Management System.</p>
            <p class="text-xs text-slate-500 mb-4">Email: <?php echo htmlspecialchars($user['email']); ?></p>
            <p class="text-sm text-slate-600">Date: <?php echo date('F d, Y'); ?></p>
        </div>
        <div class="mt-6 text-right text-xs text-slate-400">Fino Cards Team</div>
    </div>

    <!-- Bottom Navigation Bar for Mobile -->
    <nav class="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-lg flex justify-around py-2 z-50 md:hidden">
        <a href="dashboard_updated.php" class="flex flex-col items-center nav-link" id="nav-home">
            <i class="fas fa-home text-xl"></i>
            <span class="text-xs">Home</span>
        </a>
        <a href="leads_updated.php" class="flex flex-col items-center nav-link" id="nav-leads">
            <i class="fas fa-list text-xl"></i>
            <span class="text-xs">Leads</span>
        </a>
        <a href="apply.html" class="flex flex-col items-center bg-blue-600 text-white rounded-full p-3 -mt-6 shadow-lg nav-link" id="nav-add">
            <i class="fas fa-plus text-xl"></i>
        </a>
        <a href="docs_to_share" class="flex flex-col items-center nav-link" id="nav-library">
            <i class="fas fa-book text-xl"></i>
            <span class="text-xs">Library</span>
        </a>
        <a href="visiting_card" class="flex flex-col items-center nav-link" id="nav-profile">
            <i class="fas fa-user text-xl"></i>
            <span class="text-xs">Profile</span>
        </a>
    </nav>
    <script src="/assets/js/loading.js"></script>
</body>
