<?php
session_start();

// Secure error reporting for development (turn off in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Required helper includes - adjust paths if your project structure differs
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/aadhaar_verification.php';
require_once __DIR__ . '/../includes/fetch_aadhaar_details.php';
require_once __DIR__ . '/../config/database_updated.php';

// -----------------------------
// Simple helper: normalize API success
// -----------------------------
function api_is_success(array $result): bool
{
    // Check main level success
    if (isset($result['success']) && $result['success'] === true) return true;
    if (isset($result['status']) && strtolower($result['status']) === 'success') return true;
    if (isset($result['statusCode']) && (int)$result['statusCode'] === 200) return true;
    if (isset($result['code']) && (int)$result['code'] === 200) return true;
    // Some APIs return nested -> data->status
    if (isset($result['data']['status']) && strtolower($result['data']['status']) === 'success') return true;
    return false;
}

// -----------------------------
// Setup
// -----------------------------
// Load API configuration
$apiConfig = require_once __DIR__ . '/../config/api_config.php';
$kycConfig = $apiConfig['kyc_api'];

$kycVerifier = new KYCVerification(
    $kycConfig['base_url'],
    $kycConfig['client_user_id'],
    $kycConfig['secret_key'],
    $kycConfig['access_key']
);

$database = new Database();
$conn = $database->getConnection(); // mysqli

// Validate query param
if (!isset($_GET['email']) || empty($_GET['email'])) {
    header('Location: ../signup.php');
    exit();
}

$email = trim($_GET['email']);
$error = '';
$success = '';
$step = $_GET['step'] ?? null; // will determine below if null

// Ensure account_status column exists
$result = $conn->query("SHOW COLUMNS FROM users LIKE 'account_status'");
if ($result->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN account_status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending'");
}

// Fetch user record safely
$user = null;
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
if (!$stmt) {
    error_log("Prepare failed: " . $conn->error);
    die('Database error');
}
$stmt->bind_param('s', $email);
$stmt->execute();
$res = $stmt->get_result();
if ($res && $res->num_rows > 0) {
    $user = $res->fetch_assoc();
} else {
    // No user found -> redirect to signup
    header('Location: ../signup.php');
    exit();
}
$stmt->close();

// Fetch KYC data from separate tables if verified
require_once __DIR__ . '/../includes/kyc_data_handler.php';
$kycHandler = new KYCDataHandler($conn);

if (!empty($user['aadhaar_verified'])) {
    $aadhaarData = $kycHandler->getAadhaarData($user['id']);
    if ($aadhaarData) {
        $user['aadhaar_name'] = $aadhaarData['name'];
        $user['aadhaar_dob'] = $aadhaarData['dob'];
        if (!empty($aadhaarData['photo'])) {
            $user['profile_image'] = 'data:image/jpeg;base64,' . $aadhaarData['photo'];
        }
    }
}

if (!empty($user['pan_verified'])) {
    $panData = $kycHandler->getPANData($user['id']);
    if ($panData) {
        $user['pan_name'] = $panData['full_name'];
        $user['pan_number'] = $panData['pan_number'];
    }
}

// Handle retry requests
if (isset($_GET['retry'])) {
    $retryStep = $_GET['retry'];
    if ($retryStep === 'aadhaar') {
        // Reset Aadhaar verification
        $stmt = $conn->prepare("UPDATE users SET aadhaar_verified = 0 WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->close();
        $conn->query("DELETE FROM aadhaar_verifications WHERE user_email = '$email'");
        unset($_SESSION['aadhaar_session_id'], $_SESSION['aadhaar_number']);
        $step = 'aadhaar';
    } elseif ($retryStep === 'pan') {
        // Reset PAN verification
        $stmt = $conn->prepare("UPDATE users SET pan_verified = 0 WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->close();
        $conn->query("DELETE FROM pan_verifications WHERE user_email = '$email'");
        $step = 'pan';
    } elseif ($retryStep === 'bank') {
        // Reset Bank verification
        $stmt = $conn->prepare("UPDATE users SET bank_verified = 0 WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->close();
        $conn->query("DELETE FROM bank_verifications WHERE user_email = '$email'");
        $step = 'bank';
    }
}

// Determine step if not provided
if (empty($step)) {
    if (empty($user['aadhaar_verified'])) {
        $step = 'aadhaar';
    } elseif (empty($user['pan_verified'])) {
        $step = 'pan';
    } elseif (empty($user['bank_verified'])) {
        $step = 'bank';
    } elseif ($user['account_status'] === 'pending') {
        $step = 'review';
    } else {
        header('Location: ../adviser/dashboard.php');
        exit();
    }
} else {
    // Validate provided step param and skip if already verified
    $validSteps = ['aadhaar', 'otp', 'pan', 'bank', 'review'];
    if (!in_array($step, $validSteps, true)) {
        // fallback to computed step
        if (empty($user['aadhaar_verified'])) $step = 'aadhaar';
        elseif (empty($user['pan_verified'])) $step = 'pan';
        elseif (empty($user['bank_verified'])) $step = 'bank';
        else {
            header('Location: ../adviser/dashboard.php');
            exit();
        }
    }

    // Skip completed steps
    if (($step === 'aadhaar' || $step === 'otp') && !empty($user['aadhaar_verified'])) {
        header('Location: ?email=' . urlencode($email) . '&step=pan');
        exit();
    }
    if ($step === 'pan' && !empty($user['pan_verified'])) {
        header('Location: ?email=' . urlencode($email) . '&step=bank');
        exit();
    }
    if ($step === 'bank' && !empty($user['bank_verified'])) {
        header('Location: ?email=' . urlencode($email) . '&step=review');
        exit();
    }
}

// -----------------------------
// POST handling
// -----------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    error_log("POST request received - Step: $step, POST data: " . json_encode($_POST));

    // ---------- Aadhaar - Send OTP ----------
    if ($step === 'aadhaar' && isset($_POST['aadhaar'])) {
        $aadhaar = preg_replace('/\D/', '', $_POST['aadhaar']);
        if (strlen($aadhaar) !== 12) {
            $error = 'Please enter a valid 12-digit Aadhaar number';
        } else {
            $result = $kycVerifier->generateOTP((int)$aadhaar);
            error_log("Generate OTP API Response: " . json_encode($result));

            $sessionId = $result['session_id'] ?? '';

            if (api_is_success((array)$result) || !empty($sessionId)) {
                $stmt = $conn->prepare("INSERT INTO api_responses (user_email, request_id, api_type, request_data, response_data) VALUES (?, ?, 'aadhaar_otp', ?, ?)");
                $requestData = json_encode(['aadhaar' => $aadhaar]);
                $responseData = json_encode($result);
                $stmt->bind_param('ssss', $email, $sessionId, $requestData, $responseData);
                $stmt->execute();
                $stmt->close();

                $_SESSION['aadhaar_session_id'] = $sessionId;
                $_SESSION['aadhaar_number'] = $aadhaar;

                header('Location: ?email=' . urlencode($email) . '&step=otp');
                exit();
            } else {
                $error = 'Failed to send OTP. API Response: ' . json_encode($result);
            }
        }
    }

    // ---------- OTP - Submit OTP ----------
    elseif ($step === 'otp' && isset($_POST['otp'])) {
        $otp = trim($_POST['otp']);
        $sessionId = $_SESSION['aadhaar_session_id'] ?? '';

        if (empty($otp) || empty($sessionId)) {
            $error = 'OTP or session information missing. Please retry the Aadhaar OTP step.';
        } else {
            $result = $kycVerifier->submitOTP($sessionId, $otp);
            error_log("OTP Verification - Session ID: $sessionId, OTP: $otp");
            error_log("API Response: " . json_encode($result));

            // Update API response for OTP submission
            $stmt = $conn->prepare("UPDATE api_responses SET api_type = 'aadhaar_submit', request_data = ?, response_data = ? WHERE user_email = ? AND request_id = ?");
            if (!$stmt) {
                error_log("Prepare failed for aadhaar_submit API response update: " . $conn->error);
                // Continue with flow, but log error
            } else {
                $requestData = json_encode(['session_id' => $sessionId, 'otp' => $otp]);
                $responseData = json_encode($result);
                $stmt->bind_param('ssss', $requestData, $responseData, $email, $sessionId);
                if (!$stmt->execute()) {
                    error_log("Execute failed for aadhaar_submit API response update: " . $stmt->error);
                }
                $stmt->close();
            }

            // Check if API response is successful and has valid data
            if (api_is_success((array)$result) && isset($result['data']['data']) && !empty($result['data']['data']['name'])) {
                $aadhaarApiData = $result['data']['data'] ?? [];
                
                // Debug: Log the API response structure
                error_log("Aadhaar API Data: " . json_encode($aadhaarApiData));
                
                // Save to Aadhaar verification table
                require_once __DIR__ . '/../includes/kyc_data_handler.php';
                $kycHandler = new KYCDataHandler($conn);
                
                // Convert DOB from DD-MM-YYYY to YYYY-MM-DD format
                $dob = null;
                if (!empty($aadhaarApiData['dob'])) {
                    $dobParts = explode('-', $aadhaarApiData['dob']);
                    if (count($dobParts) === 3) {
                        $dob = $dobParts[2] . '-' . $dobParts[1] . '-' . $dobParts[0];
                    }
                }
                
                $aadhaarData = [
                    'aadhaar_number' => $_SESSION['aadhaar_number'] ?? '',
                    'name' => $aadhaarApiData['name'] ?? '',
                    'dob' => $dob,
                    'gender' => $aadhaarApiData['gender'] ?? '',
                    'house' => $aadhaarApiData['house'] ?? '',
                    'street' => $aadhaarApiData['street'] ?? '',
                    'locality' => $aadhaarApiData['locality'] ?? '',
                    'landmark' => $aadhaarApiData['landmark'] ?? '',
                    'district' => $aadhaarApiData['district'] ?? '',
                    'state' => $aadhaarApiData['state'] ?? '',
                    'pincode' => $aadhaarApiData['pincode'] ?? '',
                    'photo' => $aadhaarApiData['photo'] ?? ''
                ];
                
                // Debug: Log the extracted data
                error_log("Extracted Aadhaar Data: " . json_encode($aadhaarData));
                
                if ($kycHandler->saveAadhaarData($user['id'], $email, $aadhaarData)) {
                    // Update user verification status
                    $stmt = $conn->prepare("UPDATE users SET aadhaar_verified = 1 WHERE email = ?");
                    $stmt->bind_param('s', $email);
                    $stmt->execute();
                    $stmt->close();
                    
                    // Clean session keys
                    unset($_SESSION['aadhaar_session_id'], $_SESSION['aadhaar_number']);

                    // Redirect to PAN step
                    header('Location: ?email=' . urlencode($email) . '&step=pan');
                    exit();
                } else {
                    $error = 'Failed to save Aadhaar data.';
                }

            } else {
                $apiMessage = $result['data']['message'] ?? 'Invalid OTP or session expired';
                $error = $apiMessage . '. Please try again.';
            }
        }
    }

    // ---------- PAN verification ----------
    elseif ($step === 'pan' && isset($_POST['pan'])) {
        $pan = strtoupper(trim($_POST['pan']));
        if (strlen($pan) !== 10) {
            $error = 'PAN must be exactly 10 characters';
        } else {
            require_once __DIR__ . '/../includes/pan_verification.php';
            $result = verifyPAN($pan);
            error_log("PAN Verification API Response: " . json_encode($result));

            $stmt = $conn->prepare("INSERT INTO api_responses (user_email, request_id, api_type, request_data, response_data) VALUES (?, ?, 'pan', ?, ?)");
            $reqId = uniqid('pan_', true);
            $requestData = json_encode(['pan' => $pan]);
            $responseData = json_encode($result['data'] ?? $result);
            $stmt->bind_param('ssss', $email, $reqId, $requestData, $responseData);
            $stmt->execute();
            $stmt->close();

            if (api_is_success((array)$result) && isset($result['data']) && $result['success']) {
                $panApiData = $result['data'] ?? [];
                
                // Initialize KYC handler
                require_once __DIR__ . '/../includes/kyc_data_handler.php';
                require_once __DIR__ . '/../includes/name_matcher.php';
                $kycHandler = new KYCDataHandler($conn);
                $aadhaarData = $kycHandler->getAadhaarData($user['id']);

                if ($aadhaarData) {
                    $matcher = new KYCNameMatcher();
                    $result = $matcher->matchNames(
                        $aadhaarData['name'],
                        $panApiData['full_name'],
                        $aadhaarData['name'] // Use Aadhaar as fallback for bank name
                    );
                    if (!$result['approved'] && !$result['manual_review']) {
                        $error = 'PAN name does not match Aadhaar name. Score: ' . $result['score'] . '%';
                    }
                }
                
                if (empty($error)) {
                    // Convert PAN DOB from DD-MM-YYYY to YYYY-MM-DD format
                    $panDob = null;
                    if (!empty($panApiData['dob']) && $panApiData['dob'] !== '0001-07-00') {
                        if (strpos($panApiData['dob'], '-') !== false) {
                            $dobParts = explode('-', $panApiData['dob']);
                            if (count($dobParts) === 3) {
                                // Check if format is DD-MM-YYYY or YYYY-MM-DD
                                if (strlen($dobParts[0]) === 4) {
                                    $panDob = $panApiData['dob']; // Already YYYY-MM-DD
                                } else {
                                    $panDob = $dobParts[2] . '-' . $dobParts[1] . '-' . $dobParts[0]; // Convert DD-MM-YYYY to YYYY-MM-DD
                                }
                            }
                        }
                    }
                    
                    // Save to PAN verification table
                    $panData = [
                        'pan_number' => $panApiData['pan'] ?? $pan,
                        'full_name' => $panApiData['full_name'] ?? '',
                        'first_name' => $panApiData['first_name'] ?? '',
                        'middle_name' => $panApiData['middle_name'] ?? '',
                        'last_name' => $panApiData['last_name'] ?? '',
                        'dob' => $panDob,
                        'father_name' => $panApiData['father_name'] ?? '',
                        'gender' => $panApiData['gender'] ?? '',
                        'aadhaar_link_status' => $panApiData['aadhaar_link_status'] ?? ''
                    ];
                    
                    error_log("PAN Data to save: " . json_encode($panData));
                    
                    if ($kycHandler->savePANData($user['id'], $email, $panData)) {
                        // Update user verification status
                        $stmt = $conn->prepare("UPDATE users SET pan_verified = 1 WHERE email = ?");
                        $stmt->bind_param('s', $email);
                        $stmt->execute();
                        $stmt->close();
                        
                        $_SESSION['pan_success'] = "PAN verified successfully for: " . ($panData['full_name'] ?: $pan);
                        header('Location: ?email=' . urlencode($email) . '&step=bank');
                        exit();
                    } else {
                        $error = 'Failed to save PAN data.';
                    }
                }
            } else {
                $error = 'PAN verification failed. API Response: ' . json_encode($result);
            }
        }
    }

    // ---------- Bank verification ----------
    // ---------- Bank verification ----------
elseif ($step === 'bank' && isset($_POST['account']) && isset($_POST['ifsc'])) {

    error_log("Bank verification condition matched");

    $account = trim($_POST['account']);
    $ifsc = strtoupper(trim($_POST['ifsc']));

    error_log("Bank verification attempt - Account: $account, IFSC: $ifsc");

    if (empty($account) || empty($ifsc)) {
        $error = 'Please enter both account number and IFSC code';
    } else {

        // Hit API
        $result = $kycVerifier->verifyBank($account, $ifsc);

        error_log("Bank Verification API Response: " . json_encode($result));

        // Save raw API response
        $stmt = $conn->prepare("INSERT INTO api_responses 
            (user_email, request_id, api_type, request_data, response_data) 
            VALUES (?, ?, 'bank', ?, ?)");
            
        $reqId = uniqid('bank_', true);
        $requestData = json_encode(['account' => $account, 'ifsc' => $ifsc]);
        $responseData = json_encode($result);
        
        $stmt->bind_param('ssss', $email, $reqId, $requestData, $responseData);
        $stmt->execute();
        $stmt->close();

        // Extract data from Surepass API response
        $apiData = $result['data'] ?? [];
        
        error_log("Extracted API Data: " . json_encode($apiData));
        
        // Surepass API returns: full_name, account_number, ifsc_details{bank_name, branch}
        $accountHolderName = $apiData['full_name'] ?? '';
        $accountNumber = $apiData['account_number'] ?? $account;
        $ifscCode = $apiData['ifsc_details']['ifsc'] ?? $ifsc;
        $bankName = $apiData['ifsc_details']['bank_name'] ?? '';
        $branchName = $apiData['ifsc_details']['branch'] ?? '';
        $accountExists = $apiData['account_exists'] ?? false;
        
        error_log("Account Holder Name: " . $accountHolderName);
        error_log("Bank Name: " . $bankName);
        error_log("Branch Name: " . $branchName);
        error_log("Account Exists: " . ($accountExists ? 'true' : 'false'));

        if (empty($accountHolderName)) {
            $error = 'Unable to fetch account holder name from bank. Please verify account details.';
        } elseif (!$accountExists) {
            $error = 'Bank account does not exist or could not be verified.';
        } else {
            $bankData = [
                'account_number'        => $accountNumber,
                'ifsc_code'             => $ifscCode,
                'bank_name'             => $bankName,
                'account_holder_name'   => $accountHolderName,
                'branch_name'           => $branchName,
                'account_exists'        => $accountExists
            ];
            
            error_log("Bank Data to save: " . json_encode($bankData));

            // Save to DB
            require_once __DIR__ . '/../includes/kyc_data_handler.php';
            $kycHandler = new KYCDataHandler($conn);

            if ($kycHandler->saveBankData($user['id'], $email, $bankData)) {
                // Update user verification status
                $stmt = $conn->prepare("UPDATE users SET bank_verified = 1 WHERE email = ?");
                $stmt->bind_param('s', $email);
                $stmt->execute();
                $stmt->close();

                // Go to review step
                header('Location: ?email=' . urlencode($email) . '&step=review');
                exit();
            } else {
                $error = 'Failed to save bank data.';
            }
        }
    }
}

    
    // ---------- Review and Final Approval ----------
    elseif ($step === 'review' && isset($_POST['confirm'])) {
        $aadhaarData = $kycHandler->getAadhaarData($user['id']);
        $panData = $kycHandler->getPANData($user['id']);
        $bankData = $kycHandler->getBankData($user['id']);
        
        // Approve account without strict name matching
        $stmt = $conn->prepare("UPDATE users SET profile_image = ?, account_status = 'approved' WHERE email = ?");
        $profileImage = !empty($aadhaarData['photo']) ? 'data:image/jpeg;base64,' . $aadhaarData['photo'] : null;
        $stmt->bind_param('ss', $profileImage, $email);
        $stmt->execute();
        $stmt->close();
        
        $_SESSION['verification_success'] = 'Account approved! All KYC documents verified successfully.';
        header('Location: ../adviser/dashboard.php');
        exit();
    }
}

// -----------------------------
// Simple HTML output below (kept minimal). Use your existing Tailwind UI or copy the UI from your previous file.
// Note: Do not echo large amounts of the PHP file here; you can reuse your existing HTML template and only
// rely on the $step, $error, $success and $user variables.
// -----------------------------
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Verification - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include '../includes/header.php'; ?>
    <div class="flex items-center justify-center p-4 min-h-screen">
    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <div class="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i class="fas fa-shield-alt text-2xl text-white"></i>
            </div>
            <h1 class="text-3xl font-bold text-slate-900 mb-2">Complete Verification</h1>
            <p class="text-slate-600">Secure verification process</p>
        </div>

        <!-- Progress Steps (same as your UI) -->
        <div class="flex justify-between mb-8">
            <div class="flex flex-col items-center <?php echo ($step === 'aadhaar' || $step === 'otp') ? 'text-blue-600' : (!empty($user['aadhaar_verified']) ? 'text-green-600' : 'text-gray-400'); ?>">
                <div class="w-8 h-8 rounded-full border-2 flex items-center justify-center mb-2 <?php echo !empty($user['aadhaar_verified']) ? 'bg-green-600 border-green-600' : 'border-current'; ?>">
                    <?php if (!empty($user['aadhaar_verified'])): ?>
                        <i class="fas fa-check text-white text-sm"></i>
                    <?php else: ?>
                        <span class="text-sm">1</span>
                    <?php endif; ?>
                </div>
                <span class="text-xs">Aadhaar</span>
            </div>

            <div class="flex flex-col items-center <?php echo $step === 'pan' ? 'text-blue-600' : (!empty($user['pan_verified']) ? 'text-green-600' : 'text-gray-400'); ?>">
                <div class="w-8 h-8 rounded-full border-2 flex items-center justify-center mb-2 <?php echo !empty($user['pan_verified']) ? 'bg-green-600 border-green-600' : 'border-current'; ?>">
                    <?php if (!empty($user['pan_verified'])): ?>
                        <i class="fas fa-check text-white text-sm"></i>
                    <?php else: ?>
                        <span class="text-sm">2</span>
                    <?php endif; ?>
                </div>
                <span class="text-xs">PAN</span>
            </div>

            <div class="flex flex-col items-center <?php echo $step === 'bank' ? 'text-blue-600' : (!empty($user['bank_verified']) ? 'text-green-600' : 'text-gray-400'); ?>">
                <div class="w-8 h-8 rounded-full border-2 flex items-center justify-center mb-2 <?php echo !empty($user['bank_verified']) ? 'bg-green-600 border-green-600' : 'border-current'; ?>">
                    <?php if (!empty($user['bank_verified'])): ?>
                        <i class="fas fa-check text-white text-sm"></i>
                    <?php else: ?>
                        <span class="text-sm">3</span>
                    <?php endif; ?>
                </div>
                <span class="text-xs">Bank</span>
            </div>
        </div>

        <div class="card shadow-2xl border-0 bg-white">
            <div class="p-6">
                <?php if (!empty($error)): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($_SESSION['pan_success'])): ?>
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                        <?php echo htmlspecialchars($_SESSION['pan_success']); unset($_SESSION['pan_success']); ?>
                    </div>
                <?php endif; ?>

                <?php if ($step === 'aadhaar' || $step === 'otp'): ?>
                    <h2 class="text-xl font-semibold mb-4">Step 1: Aadhaar Verification</h2>
                    <?php if ($step === 'otp'): ?>
                        <form method="POST" class="space-y-4">
                            <input type="text" name="otp" maxlength="6" class="w-full px-3 py-2 border rounded-md" placeholder="Enter 6-digit OTP" required>
                            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-md">Verify OTP</button>
                        </form>
                    <?php else: ?>
                        <form method="POST" class="space-y-4">
                            <input type="text" name="aadhaar" maxlength="12" pattern="\d{12}" class="w-full px-3 py-2 border rounded-md" placeholder="Enter 12-digit Aadhaar" required>
                            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-md">Send OTP</button>
                        </form>
                    <?php endif; ?>

                <?php elseif ($step === 'pan'): ?>

                    <h2 class="text-xl font-semibold mb-4">Step 2: PAN Verification</h2>
                    <?php if (!empty($user['aadhaar_verified'])): ?>
                        <div class="bg-green-50 p-3 rounded mb-4">
                            <div class="flex items-center space-x-3">
                                <?php if (!empty($user['profile_image'])): ?>
                                    <img src="<?php echo htmlspecialchars($user['profile_image']); ?>" alt="Profile" class="w-10 h-10 rounded-full object-cover">
                                <?php endif; ?>
                                <div>
                                    <p class="text-sm text-green-700 font-semibold">✓ Aadhaar Verified</p>
                                    <?php if (!empty($user['aadhaar_name'])): ?>
                                <p class="text-xs text-green-600">Name: <?php echo htmlspecialchars($user['aadhaar_name']); ?></p>
                            <?php endif; ?>
                                    <?php if (!empty($user['aadhaar_dob']) && $user['aadhaar_dob'] !== '0000-00-00'): ?>
                                        <p class="text-xs text-green-600">DOB: <?php echo htmlspecialchars($user['aadhaar_dob']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <form method="POST" class="space-y-4">
                        <input type="text" name="pan" maxlength="10" class="w-full px-3 py-2 border rounded-md uppercase" placeholder="Enter PAN Number" required>
                        <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-md">Verify PAN</button>
                    </form>

                <?php elseif ($step === 'bank'): ?>
                    <h2 class="text-xl font-semibold mb-4">Step 3: Bank Verification</h2>

                    <?php if (!empty($user['aadhaar_verified'])): ?>
                        <div class="bg-green-50 p-3 rounded mb-2 flex justify-between items-center">
                            <p class="text-sm text-green-700 font-semibold">✓ Aadhaar: <?php echo !empty($user['aadhaar_name']) ? htmlspecialchars($user['aadhaar_name']) : 'Verified'; ?></p>
                            <a href="?email=<?php echo urlencode($email); ?>&retry=aadhaar" class="text-xs text-blue-600 hover:text-blue-800">Try Again</a>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($user['pan_verified'])): ?>
                        <div class="bg-green-50 p-3 rounded mb-4">
                            <div>
                                <p class="text-sm text-green-700 font-semibold">✓ PAN: <?php echo htmlspecialchars($user['pan_name'] ?? 'Verified'); ?></p>
                                <p class="text-xs text-green-600">PAN Number: <?php echo htmlspecialchars($user['pan_number'] ?? 'N/A'); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <form method="POST" class="space-y-4">
                        <input type="text" name="account" class="w-full px-3 py-2 border rounded-md" placeholder="Account Number" required>
                        <input type="text" name="ifsc" maxlength="11" class="w-full px-3 py-2 border rounded-md uppercase" placeholder="IFSC Code" required>
                        <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-md">Verify Bank</button>
                    </form>
                    
                    <?php if (file_exists('/var/log/apache2/error.log')): ?>
                        <div class="mt-4 bg-gray-100 p-3 rounded text-xs overflow-auto max-h-40">
                            <pre><?php echo htmlspecialchars(shell_exec('tail -20 /var/log/apache2/error.log')); ?></pre>
                        </div>
                    <?php endif; ?>

                <?php elseif ($step === 'review'): ?>
                    <?php 
                    // Fetch all KYC data for review
                    $aadhaarData = $kycHandler->getAadhaarData($user['id']);
                    $panData = $kycHandler->getPANData($user['id']);
                    $bankData = $kycHandler->getBankData($user['id']);
                    ?>
                    <h2 class="text-xl font-semibold mb-4">Review Your Information</h2>
                    <p class="text-sm text-gray-600 mb-4">Please review all your verified information before final approval.</p>
                    
                    <?php 
                    // Debug: Log bank data
                    error_log("Bank data for display: " . json_encode($bankData));
                    ?>
                    <div class="space-y-3 mb-6">
                        <div class="bg-green-50 p-4 rounded-lg border border-green-200">
                            <div class="flex items-center space-x-3">
                                <?php if (!empty($user['profile_image'])): ?>
                                    <img src="<?php echo htmlspecialchars($user['profile_image']); ?>" alt="Profile" class="w-12 h-12 rounded-full object-cover">
                                <?php endif; ?>
                                <div class="flex-1">
                                    <h3 class="font-semibold text-green-800">✓ Aadhaar Verified</h3>
                                    <p class="text-sm text-green-700">Name: <?php echo htmlspecialchars($aadhaarData['name'] ?? 'N/A'); ?></p>
                                    <p class="text-xs text-green-600">Number: ****-****-<?php echo substr($aadhaarData['aadhaar_number'] ?? '', -4); ?></p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="bg-green-50 p-4 rounded-lg border border-green-200">
                            <h3 class="font-semibold text-green-800">✓ PAN Verified</h3>
                            <p class="text-sm text-green-700">Name: <?php echo htmlspecialchars($panData['full_name'] ?? 'N/A'); ?></p>
                            <p class="text-xs text-green-600">PAN: <?php echo htmlspecialchars($panData['pan_number'] ?? 'N/A'); ?></p>
                        </div>
                        
                        <div class="bg-green-50 p-4 rounded-lg border border-green-200">
                            <h3 class="font-semibold text-green-800">✓ Bank Verified</h3>
                            <p class="text-sm text-green-700">Name: <?php echo htmlspecialchars($bankData['account_holder_name'] ?? 'N/A'); ?></p>
                            <p class="text-xs text-green-600">Bank: <?php echo htmlspecialchars($bankData['bank_name'] ?? 'N/A'); ?></p>
                            <p class="text-xs text-green-600">Account: ****<?php echo substr($bankData['account_number'] ?? '', -4); ?></p>
                        </div>
                    </div>
                    
                    <form method="POST" class="space-y-4">
                        <div class="bg-blue-50 p-4 rounded-lg border border-blue-200">
                            <p class="text-sm text-blue-800 mb-2">By confirming, you agree that all the information provided is accurate and complete.</p>
                        </div>
                        <button type="submit" name="confirm" value="1" class="w-full bg-green-600 text-white py-3 rounded-md font-semibold">Confirm & Complete Verification</button>
                    </form>
                    
                    <div class="mt-4 text-center">
                        <p class="text-xs text-gray-500 mb-2">Need to update any information?</p>
                        <div class="flex justify-center space-x-4">
                            <a href="?email=<?php echo urlencode($email); ?>&retry=aadhaar" class="text-xs text-blue-600 hover:text-blue-800">Retry Aadhaar</a>
                            <a href="?email=<?php echo urlencode($email); ?>&retry=pan" class="text-xs text-blue-600 hover:text-blue-800">Retry PAN</a>
                            <a href="?email=<?php echo urlencode($email); ?>&retry=bank" class="text-xs text-blue-600 hover:text-blue-800">Retry Bank</a>
                        </div>
                    </div>

                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>
    <?php include '../includes/footer.php'; ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
