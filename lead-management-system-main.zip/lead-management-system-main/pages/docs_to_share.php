<?php
// Docs To Share Page
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Docs To Share</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
</head>
<body class="min-h-screen bg-slate-50 flex items-center justify-center">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full">
        <h1 class="text-xl font-bold mb-4 text-blue-700">Docs To Share</h1>
        <ul class="space-y-4">
            <li class="flex items-center justify-between bg-blue-50 rounded-lg px-4 py-3">
                <span class="font-medium text-slate-800">KYC Form</span>
                <a href="#" class="text-blue-600 hover:underline"><i class="fas fa-download mr-1"></i>Download</a>
            </li>
            <li class="flex items-center justify-between bg-blue-50 rounded-lg px-4 py-3">
                <span class="font-medium text-slate-800">Bank Statement Template</span>
                <a href="#" class="text-blue-600 hover:underline"><i class="fas fa-download mr-1"></i>Download</a>
            </li>
            <li class="flex items-center justify-between bg-blue-50 rounded-lg px-4 py-3">
                <span class="font-medium text-slate-800">Income Proof Sample</span>
                <a href="#" class="text-blue-600 hover:underline"><i class="fas fa-download mr-1"></i>Download</a>
            </li>
        </ul>
    </div>

    <!-- Bottom Navigation Bar for Mobile -->
    <nav class="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-lg flex justify-around py-2 z-50 md:hidden">
        <a href="dashboard_updated.php" class="flex flex-col items-center nav-link" id="nav-home">
            <i class="fas fa-home text-xl"></i>
            <span class="text-xs">Home</span>
        </a>
        <a href="leads_updated.php" class="flex flex-col items-center nav-link" id="nav-leads">
            <i class="fas fa-list text-xl"></i>
            <span class="text-xs">Leads</span>
        </a>
        <a href="apply.html" class="flex flex-col items-center bg-blue-600 text-white rounded-full p-3 -mt-6 shadow-lg nav-link" id="nav-add">
            <i class="fas fa-plus text-xl"></i>
        </a>
        <a href="docs_to_share" class="flex flex-col items-center nav-link text-blue-600" id="nav-library">
            <i class="fas fa-book text-xl"></i>
            <span class="text-xs">Library</span>
        </a>
        <a href="visiting_card" class="flex flex-col items-center nav-link" id="nav-profile">
            <i class="fas fa-user text-xl"></i>
            <span class="text-xs">Profile</span>
        </a>
    </nav>
    <script src="/assets/js/loading.js"></script>
</body>
