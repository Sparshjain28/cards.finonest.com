<?php
// EMI Calculator Page
$emi = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $principal = floatval($_POST['principal'] ?? 0);
    $rate = floatval($_POST['rate'] ?? 0);
    $months = intval($_POST['months'] ?? 0);
    if ($principal > 0 && $rate > 0 && $months > 0) {
        $monthly_rate = $rate / (12 * 100);
        $emi = ($principal * $monthly_rate * pow(1 + $monthly_rate, $months)) / (pow(1 + $monthly_rate, $months) - 1);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMI Calculator</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
</head>
<body class="min-h-screen bg-slate-50 flex items-center justify-center">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full">
        <h1 class="text-xl font-bold mb-4 text-blue-700">EMI Calculator</h1>
        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-slate-700 mb-1">Principal Amount (₹)</label>
                <input type="number" name="principal" step="0.01" min="0" required class="w-full px-3 py-2 border rounded-lg" value="<?php echo isset($_POST['principal']) ? htmlspecialchars($_POST['principal']) : ''; ?>">
            </div>
            <div>
                <label class="block text-slate-700 mb-1">Annual Interest Rate (%)</label>
                <input type="number" name="rate" step="0.01" min="0" required class="w-full px-3 py-2 border rounded-lg" value="<?php echo isset($_POST['rate']) ? htmlspecialchars($_POST['rate']) : ''; ?>">
            </div>
            <div>
                <label class="block text-slate-700 mb-1">Tenure (Months)</label>
                <input type="number" name="months" min="1" required class="w-full px-3 py-2 border rounded-lg" value="<?php echo isset($_POST['months']) ? htmlspecialchars($_POST['months']) : ''; ?>">
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700">Calculate EMI</button>
        </form>
        <?php if ($emi !== null): ?>
            <div class="mt-6 bg-blue-50 rounded-lg p-4 text-center">
                <p class="text-slate-700">Your Monthly EMI:</p>
                <p class="text-2xl font-bold text-blue-700">₹<?php echo number_format($emi, 2); ?></p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Bottom Navigation Bar for Mobile -->
    <nav class="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-lg flex justify-around py-2 z-50 md:hidden">
        <a href="dashboard_updated.php" class="flex flex-col items-center nav-link" id="nav-home">
            <i class="fas fa-home text-xl"></i>
            <span class="text-xs">Home</span>
        </a>
        <a href="leads_updated.php" class="flex flex-col items-center nav-link" id="nav-leads">
            <i class="fas fa-list text-xl"></i>
            <span class="text-xs">Leads</span>
        </a>
        <a href="apply.html" class="flex flex-col items-center bg-blue-600 text-white rounded-full p-3 -mt-6 shadow-lg nav-link" id="nav-add">
            <i class="fas fa-plus text-xl"></i>
        </a>
        <a href="docs_to_share" class="flex flex-col items-center nav-link" id="nav-library">
            <i class="fas fa-book text-xl"></i>
            <span class="text-xs">Library</span>
        </a>
        <a href="visiting_card" class="flex flex-col items-center nav-link" id="nav-profile">
            <i class="fas fa-user text-xl"></i>
            <span class="text-xs">Profile</span>
        </a>
    </nav>
    <script src="/assets/js/loading.js"></script>
</body>
