<?php
// kyc.php - KYC step after signup
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/pan_verification.php';
require_once __DIR__ . '/../config/database_updated.php';

if (!isset($_GET['email'])) {
    header('Location: signup.php');
    exit();
}

$email = $_GET['email'];
$error = '';
$success = '';

$database = new Database();
$conn = $database->getConnection();

// Get user type and Aadhaar verification status
$stmtUser = $conn->prepare("SELECT user_type, aadhaar_verified FROM users WHERE email = ?");
$stmtUser->bind_param("s", $email);
$stmtUser->execute();
$userResult = $stmtUser->get_result();
$userRow = $userResult->fetch_assoc();
$isDSA = $userRow && $userRow['user_type'] === 'dsa';
$aadhaarVerified = $userRow && $userRow['aadhaar_verified'] == 1;

// Redirect to Aadhaar verification if not verified
if (!$aadhaarVerified) {
    header('Location: aadhaar_verify.php?email=' . urlencode($email));
    exit();
}

$stmtCheck = $conn->prepare("SELECT id FROM kyc_submissions WHERE email = ?");
$stmtCheck->bind_param("s", $email);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();
if ($resultCheck && $resultCheck->num_rows > 0) {
    if (!empty($_SESSION['is_admin'])) {
        header('Location: ../admin/dashboard.php');
    } else {
        header('Location: ../adviser/dashboard.php');
    }
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['skip_kyc']) && $isDSA) {
        header('Location: ../adviser/dashboard.php');
        exit();
    }

    $aadhar = $_POST['aadhar'] ?? '';
    $pan = $_POST['pan'] ?? '';
    $selfie = $_FILES['selfie'] ?? null;
    $pan = trim($pan);
    
    $stmtCheck = $conn->prepare("SELECT id FROM kyc_submissions WHERE email = ?");
    $stmtCheck->bind_param("s", $email);
    $stmtCheck->execute();
    $resultCheck = $stmtCheck->get_result();
    if ($resultCheck && $resultCheck->num_rows > 0) {
        $error = 'KYC already submitted for this email.';
    } elseif (!preg_match('/^\d{12}$/', $aadhar)) {
        $error = 'Invalid Aadhar number. Must be 12 digits.';
    } elseif (strlen($pan) !== 10) {
        $error = 'PAN number must be exactly 10 characters.';
    } elseif (empty($aadhar) || empty($pan) || !$selfie || $selfie['error'] !== UPLOAD_ERR_OK) {
        $error = 'Please fill all fields and upload a selfie.';
    } else {
        $pan = strtoupper($pan);
        
        // Verify PAN via Surepass API
        $panResult = verifyPAN($pan);
        
        if (!$panResult['success']) {
            $error = 'PAN verification failed. Please check the PAN number.';
        } else {
            $panName = $panResult['data']['full_name'] ?? '';
        }
        
        if (empty($error)) {
            $ext = pathinfo($selfie['name'], PATHINFO_EXTENSION);
            $filename = 'selfie_' . time() . '_' . rand(1000,9999) . '.' . $ext;
            $dest = '../uploads/' . $filename;
            if (!is_dir('../uploads')) { mkdir('../uploads', 0777, true); }
            if (move_uploaded_file($selfie['tmp_name'], $dest)) {
                $selfie_path = 'uploads/' . $filename;
                $stmt = $conn->prepare("INSERT INTO kyc_submissions (email, aadhar, pan, selfie_path, submitted_at) VALUES (?, ?, ?, ?, NOW())");
                $stmt->bind_param("ssss", $email, $aadhar, $pan, $selfie_path);
                if ($stmt->execute()) {
                    $success = 'KYC submitted successfully. You can now login.';
                    echo '<script>
                        alert("KYC submitted successfully. You can now login.");
                        window.location.replace("../index.php");
                    </script>';
                    exit();
                } else {
                    $error = 'Failed to save KYC details. Please try again.';
                }
            } else {
                $error = 'Failed to upload selfie. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KYC Verification - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="w-full max-w-md">
        <?php if (isset($_SESSION['signup_status'])): ?>
            <div class="mb-4">
                <?php if ($_SESSION['signup_status'] === 'created'): ?>
                    <div class="alert alert-success mb-2">User account created successfully.</div>
                <?php elseif ($_SESSION['signup_status'] === 'pending'): ?>
                    <div class="alert alert-warning mb-2">Signup request is pending admin approval.</div>
                <?php elseif ($_SESSION['signup_status'] === 'exists'): ?>
                    <div class="alert alert-error mb-2">Email or phone already exists.</div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <div class="text-center mb-8">
            <div class="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i class="fas fa-id-card text-2xl text-white"></i>
            </div>
            <h1 class="text-3xl font-bold text-slate-900 mb-2">KYC Verification</h1>
            <p class="text-slate-600">Please complete your KYC to activate your account</p>
            <?php if ($aadhaarVerified): ?>
            <div class="flex items-center justify-center mt-2">
                <i class="fas fa-check-circle text-green-500 mr-2"></i>
                <span class="text-sm text-green-600">Aadhaar Verified</span>
            </div>
            <?php endif; ?>
            <?php if ($isDSA): ?>
            <p class="text-sm text-blue-600 mt-2">(Optional for DSA users)</p>
            <?php endif; ?>
        </div>
        <div class="card shadow-2xl border-0 bg-white">
            <div class="p-6 pb-4">
                <h2 class="text-2xl text-center text-slate-900 font-semibold mb-2">Enter KYC Details</h2>
            </div>
            <div class="px-6 pb-6">
                <?php if ($error): ?>
                    <div class="alert alert-error mb-4">
                        <i class="fas fa-exclamation-circle mr-2"></i>
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                <form method="POST" enctype="multipart/form-data" class="space-y-4">
                    <div class="space-y-2">
                        <label for="aadhar" class="block text-slate-900 font-medium">Aadhar Number</label>
                        <input id="aadhar" name="aadhar" type="text" maxlength="12" pattern="\d{12}" class="form-input h-12" required />
                    </div>
                    <div class="space-y-2">
                        <label for="pan" class="block text-slate-900 font-medium">PAN Number</label>
                        <input id="pan" name="pan" type="text" maxlength="10" pattern=".{10}" class="form-input h-12 uppercase" required />
                    </div>
                    <div class="space-y-2">
                        <label for="selfie" class="block text-slate-900 font-medium">Upload Selfie</label>
                        <input id="selfie" name="selfie" type="file" accept="image/*" class="form-input h-12" required />
                    </div>
                    <button type="submit" class="btn-primary w-full h-12 font-medium shadow-lg mb-2">Submit KYC</button>
                    <?php if ($isDSA): ?>
                    <div class="text-center">
                        <button type="submit" name="skip_kyc" value="1" class="text-blue-600 hover:text-blue-800 font-medium text-sm">
                            Skip KYC and Continue to Dashboard
                        </button>
                    </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
    <script src="/assets/js/loading.js"></script>
</body>
</html>
