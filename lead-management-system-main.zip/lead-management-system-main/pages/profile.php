<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/kyc_data_handler.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

require_once '../config/database_updated.php';
$database = new Database();
$conn = $database->getConnection();

$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Get KYC data from separate tables
$kycHandler = new KYCDataHandler($conn);
$aadhaarData = $kycHandler->getAadhaarData($_SESSION['user_id']);
$panData = $kycHandler->getPANData($_SESSION['user_id']);
$bankData = $kycHandler->getBankData($_SESSION['user_id']);

// Fallback to users table if KYC tables are empty
if (!$aadhaarData && !empty($user['aadhar_number'])) {
    $aadhaarData = [
        'name' => $user['name'],
        'aadhaar_number' => $user['aadhar_number'],
        'dob' => $user['dob'] ?? null,
        'gender' => $user['gender'] ?? null,
        'full_address' => $user['address'] ?? null
    ];
}

if (!$panData && !empty($user['pan_number'])) {
    $panData = [
        'pan_number' => $user['pan_number'],
        'full_name' => $user['name'],
        'dob' => $user['dob'] ?? null,
        'gender' => $user['gender'] ?? null
    ];
}

if (!$bankData && !empty($user['account_number'])) {
    $bankData = [
        'account_holder_name' => $user['name'],
        'account_number' => $user['account_number'],
        'ifsc_code' => $user['ifsc_code'],
        'bank_name' => $user['bank_name'] ?? null
    ];
}

// Debug: Check what data we have
error_log("PAN Data: " . json_encode($panData));
error_log("Bank Data: " . json_encode($bankData));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <div class="max-w-6xl mx-auto p-6">
        <!-- Header -->
        <div class="bg-white rounded-2xl shadow-xl p-6 mb-6">
            <div class="flex items-center space-x-4">
                <?php if (!empty($user['profile_image'])): ?>
                    <img src="<?php echo htmlspecialchars($user['profile_image']); ?>" alt="Profile" class="w-20 h-20 rounded-full object-cover border-4 border-blue-200">
                <?php elseif (!empty($aadhaarData['photo'])): ?>
                    <img src="data:image/jpeg;base64,<?php echo $aadhaarData['photo']; ?>" alt="Profile" class="w-20 h-20 rounded-full object-cover border-4 border-blue-200">
                <?php else: ?>
                    <div class="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-user text-2xl text-white"></i>
                    </div>
                <?php endif; ?>
                <div>
                    <h1 class="text-3xl font-bold text-slate-900"><?php echo htmlspecialchars($user['name'] ?? $aadhaarData['name'] ?? 'User'); ?></h1>
                    <p class="text-slate-600"><?php echo htmlspecialchars($user['email']); ?></p>
                    <div class="mt-2">
                        <?php 
                        // Determine status based on KYC completion and account_status
                        $hasCompleteKYC = $aadhaarData && $panData && $bankData;
                        $accountStatus = $user['account_status'] ?? null;
                        
                        if ($accountStatus === 'rejected'): ?>
                            <div class="flex items-center space-x-2">
                                <span class="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium">
                                    <i class="fas fa-times-circle mr-1"></i>Account Rejected
                                </span>
                                <button onclick="startReKYC()" class="bg-orange-600 text-white px-3 py-1 rounded-full text-sm hover:bg-orange-700">
                                    <i class="fas fa-redo mr-1"></i>Re-KYC
                                </button>
                            </div>
                        <?php elseif ($accountStatus === 'approved' || $hasCompleteKYC): ?>
                            <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                                <i class="fas fa-check-circle mr-1"></i>Account Approved
                            </span>
                        <?php else: ?>
                            <div class="flex items-center space-x-2">
                                <span class="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
                                    <i class="fas fa-clock mr-1"></i>Under Review
                                </span>
                                <?php if ($accountStatus === 'under_review'): ?>
                                <button onclick="startReKYC()" class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm hover:bg-blue-700">
                                    <i class="fas fa-redo mr-1"></i>Re-KYC
                                </button>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="flex space-x-2 mt-2">
                        <?php if ($aadhaarData): ?>
                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                                <i class="fas fa-check mr-1"></i>Aadhaar Verified
                            </span>
                        <?php endif; ?>
                        <?php if ($panData): ?>
                            <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                                <i class="fas fa-check mr-1"></i>PAN Verified
                            </span>
                        <?php endif; ?>
                        <?php if ($bankData): ?>
                            <span class="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs font-medium">
                                <i class="fas fa-check mr-1"></i>Bank Verified
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- KYC Status Progress -->
        <div class="bg-white rounded-2xl shadow-xl p-6 mb-6">
            <h2 class="text-xl font-bold mb-4">KYC Verification Status</h2>
            <div class="flex justify-between items-center">
                <div class="flex flex-col items-center <?php echo $aadhaarData ? 'text-green-600' : 'text-gray-400'; ?>">
                    <div class="w-12 h-12 rounded-full border-2 flex items-center justify-center mb-2 <?php echo $aadhaarData ? 'bg-green-600 border-green-600' : 'border-current'; ?>">
                        <?php if ($aadhaarData): ?>
                            <i class="fas fa-check text-white"></i>
                        <?php else: ?>
                            <span class="text-sm">1</span>
                        <?php endif; ?>
                    </div>
                    <span class="text-sm font-medium">Aadhaar</span>
                </div>
                <div class="flex-1 h-1 mx-4 <?php echo $aadhaarData ? 'bg-green-200' : 'bg-gray-200'; ?>"></div>
                <div class="flex flex-col items-center <?php echo $panData ? 'text-blue-600' : 'text-gray-400'; ?>">
                    <div class="w-12 h-12 rounded-full border-2 flex items-center justify-center mb-2 <?php echo $panData ? 'bg-blue-600 border-blue-600' : 'border-current'; ?>">
                        <?php if ($panData): ?>
                            <i class="fas fa-check text-white"></i>
                        <?php else: ?>
                            <span class="text-sm">2</span>
                        <?php endif; ?>
                    </div>
                    <span class="text-sm font-medium">PAN</span>
                </div>
                <div class="flex-1 h-1 mx-4 <?php echo $panData ? 'bg-blue-200' : 'bg-gray-200'; ?>"></div>
                <div class="flex flex-col items-center <?php echo $bankData ? 'text-purple-600' : 'text-gray-400'; ?>">
                    <div class="w-12 h-12 rounded-full border-2 flex items-center justify-center mb-2 <?php echo $bankData ? 'bg-purple-600 border-purple-600' : 'border-current'; ?>">
                        <?php if ($bankData): ?>
                            <i class="fas fa-check text-white"></i>
                        <?php else: ?>
                            <span class="text-sm">3</span>
                        <?php endif; ?>
                    </div>
                    <span class="text-sm font-medium">Bank</span>
                </div>
            </div>
            <?php if (!$aadhaarData || !$panData || !$bankData): ?>
                <div class="mt-4 text-center">
                    <a href="complete_verification.php?email=<?php echo urlencode($user['email']); ?>" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        Complete Verification
                    </a>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Detailed Information -->
        <div class="grid lg:grid-cols-3 gap-6">
            <!-- Aadhaar Details -->
            <div class="bg-white rounded-2xl shadow-xl p-6">
                <div class="flex items-center mb-4">
                    <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                        <i class="fas fa-id-card text-green-600"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-slate-900">Aadhaar Details</h3>
                </div>
                <?php if ($aadhaarData): ?>
                    <div class="space-y-3">
                        <div>
                            <label class="text-xs font-medium text-slate-500 uppercase tracking-wide">Full Name</label>
                            <p class="text-slate-900 font-medium"><?php echo htmlspecialchars($aadhaarData['name'] ?? 'N/A'); ?></p>
                        </div>
                        <div>
                            <label class="text-xs font-medium text-slate-500 uppercase tracking-wide">Date of Birth</label>
                            <p class="text-slate-900"><?php echo htmlspecialchars($aadhaarData['dob'] ?? 'N/A'); ?></p>
                        </div>
                        <div>
                            <label class="text-xs font-medium text-slate-500 uppercase tracking-wide">Gender</label>
                            <p class="text-slate-900"><?php echo htmlspecialchars($aadhaarData['gender'] ?? 'N/A'); ?></p>
                        </div>
                        <div>
                            <label class="text-xs font-medium text-slate-500 uppercase tracking-wide">Address</label>
                            <p class="text-slate-900 text-sm leading-relaxed"><?php echo htmlspecialchars($aadhaarData['full_address'] ?? 'N/A'); ?></p>
                        </div>
                        <div>
                            <label class="text-xs font-medium text-slate-500 uppercase tracking-wide">Aadhaar Number</label>
                            <p class="text-slate-900 font-mono"><?php echo htmlspecialchars($aadhaarData['aadhaar_number'] ?? 'N/A'); ?></p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8">
                        <i class="fas fa-exclamation-circle text-4xl text-gray-300 mb-3"></i>
                        <p class="text-gray-500">Aadhaar not verified</p>
                        <a href="complete_verification.php?email=<?php echo urlencode($user['email']); ?>&step=aadhaar" class="text-blue-600 hover:text-blue-700 text-sm font-medium mt-2 inline-block">
                            Verify Now
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- PAN Details -->
            <div class="bg-white rounded-2xl shadow-xl p-6">
                <div class="flex items-center mb-4">
                    <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                        <i class="fas fa-credit-card text-blue-600"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-slate-900">PAN Details</h3>
                </div>
                <?php if ($panData): ?>
                    <div class="space-y-3">
                        <div>
                            <label class="text-xs font-medium text-slate-500 uppercase tracking-wide">PAN Number</label>
                            <p class="text-slate-900 font-mono text-lg"><?php echo htmlspecialchars($panData['pan_number'] ?? $panData['pan'] ?? 'N/A'); ?></p>
                        </div>
                        <div>
                            <label class="text-xs font-medium text-slate-500 uppercase tracking-wide">Full Name</label>
                            <p class="text-slate-900 font-medium"><?php echo htmlspecialchars($panData['full_name'] ?? 'N/A'); ?></p>
                        </div>
                        <div>
                            <label class="text-xs font-medium text-slate-500 uppercase tracking-wide">Date of Birth</label>
                            <p class="text-slate-900"><?php echo htmlspecialchars($panData['dob'] ?? 'N/A'); ?></p>
                        </div>
                        <div>
                            <label class="text-xs font-medium text-slate-500 uppercase tracking-wide">Gender</label>
                            <p class="text-slate-900"><?php echo htmlspecialchars($panData['gender'] ?? 'N/A'); ?></p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8">
                        <i class="fas fa-exclamation-circle text-4xl text-gray-300 mb-3"></i>
                        <p class="text-gray-500">PAN not verified</p>
                        <a href="complete_verification.php?email=<?php echo urlencode($user['email']); ?>&step=pan" class="text-blue-600 hover:text-blue-700 text-sm font-medium mt-2 inline-block">
                            Verify Now
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Bank Details -->
            <div class="bg-white rounded-2xl shadow-xl p-6">
                <div class="flex items-center mb-4">
                    <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                        <i class="fas fa-university text-purple-600"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-slate-900">Bank Details</h3>
                </div>
                <?php if ($bankData): ?>
                    <div class="space-y-3">
                        <div>
                            <label class="text-xs font-medium text-slate-500 uppercase tracking-wide">Account Holder</label>
                            <p class="text-slate-900"><?php echo htmlspecialchars($bankData['account_holder_name'] ?? 'N/A'); ?></p>
                        </div>
                        <div>
                            <label class="text-xs font-medium text-slate-500 uppercase tracking-wide">Account Number</label>
                            <p class="text-slate-900 font-mono"><?php echo htmlspecialchars($bankData['account_number'] ?? 'N/A'); ?></p>
                        </div>
                        <div>
                            <label class="text-xs font-medium text-slate-500 uppercase tracking-wide">IFSC Code</label>
                            <p class="text-slate-900 font-mono"><?php echo htmlspecialchars($bankData['ifsc_code'] ?? 'N/A'); ?></p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8">
                        <i class="fas fa-exclamation-circle text-4xl text-gray-300 mb-3"></i>
                        <p class="text-gray-500">Bank details not verified</p>
                        <a href="complete_verification.php?email=<?php echo urlencode($user['email']); ?>&step=bank" class="text-blue-600 hover:text-blue-700 text-sm font-medium mt-2 inline-block">
                            Verify Now
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Back to Dashboard -->
        <div class="text-center mt-8">
            <a href="../adviser/dashboard.php" class="bg-slate-600 text-white px-6 py-3 rounded-lg hover:bg-slate-700 transition-colors">
                <i class="fas fa-arrow-left mr-2"></i>Back to Dashboard
            </a>
        </div>
    </div>

    <script>
        function startReKYC() {
            if (confirm('This will clear your current KYC data and you will need to re-verify all documents. Continue?')) {
                window.location.href = 'complete_verification.php?email=<?php echo urlencode($user['email']); ?>&rekyc=1';
            }
        }
    </script>
    <script src="/assets/js/loading.js"></script>
</body>
</html>