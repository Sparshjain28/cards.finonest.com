<?php
session_start();
require_once __DIR__ . '/../config/database_updated.php';
require_once __DIR__ . '/../includes/auth.php';

// Require logged-in user - no anonymous lead creation
if (empty($_SESSION['user_id'])) {
    http_response_code(403);
    die('Unauthorized: Login required to create leads');
}

// Security headers
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die('Method not allowed');
}

// Input validation and sanitization
function validateInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function validateMobile($mobile) {
    return preg_match('/^[0-9]{10}$/', $mobile);
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Collect and validate form data
$name = validateInput($_POST['name'] ?? '');
$mobile = validateInput($_POST['mobile'] ?? '');
$email = validateInput($_POST['email'] ?? '');
$product_id = (int)($_POST['product_id'] ?? 0);

// Use logged-in user's channel code (REQUIRED)
require_once __DIR__ . '/../includes/auth.php';
if (!empty($_SESSION['user_id'])) {
    $user_stmt = $conn->prepare("SELECT channel_code FROM users WHERE id = ? LIMIT 1");
    $user_stmt->bind_param("i", $_SESSION['user_id']);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();
    if ($user_row = $user_result->fetch_assoc()) {
        if (!empty($user_row['channel_code'])) {
            $channel_code = $user_row['channel_code'];
        } else {
            http_response_code(403);
            die('Unauthorized: User account missing channel code');
        }
    } else {
        http_response_code(403);
        die('Unauthorized: Invalid user session');
    }
    $user_stmt->close();
} else {
    http_response_code(403);
    die('Unauthorized: Login required');
}

// Validation checks
$errors = [];

if (empty($name) || strlen($name) < 2) {
    $errors[] = 'Valid name is required';
}

if (!validateMobile($mobile)) {
    $errors[] = 'Valid 10-digit mobile number is required';
}

if (!validateEmail($email)) {
    $errors[] = 'Valid email address is required';
}

if ($product_id <= 0) {
    $errors[] = 'Valid product selection is required';
}


// No need to check for channel_code from POST, always set from session

// If validation fails, redirect back with error
if (!empty($errors)) {
    $error_msg = implode(', ', $errors);
    header("Location: apply.html?error=" . urlencode($error_msg));
    exit;
}

try {
    // Database connection
    $database = new Database();
    $conn = $database->getConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    // Check if mobile/email already exists for this product (only generated/pending leads)
    $check_stmt = $conn->prepare("SELECT id, lead_id FROM leads WHERE (mobile = ? OR email = ?) AND product_id = ? AND status IN ('generated', 'in_process', 'approved', 'activated', 'disbursed', 'curable') ORDER BY created_at DESC LIMIT 1");
    $check_stmt->bind_param("ssi", $mobile, $email, $product_id);
    $check_stmt->execute();
    $existing = $check_stmt->get_result();
    
    if ($existing->num_rows > 0) {
        $duplicate_lead = $existing->fetch_assoc();
        $check_stmt->close();
        
        // Get product details to build the existing link
        $product_stmt = $conn->prepare("SELECT bank_redirect_url FROM products WHERE id = ?");
        $product_stmt->bind_param("i", $product_id);
        $product_stmt->execute();
        $product_result = $product_stmt->get_result();
        $product_data = $product_result->fetch_assoc();
        $product_stmt->close();
        
        // Build existing link
        $existing_link = str_replace(
            ['{lead id}', '{leadId}', '{lead_id}'],
            $duplicate_lead['lead_id'],
            $product_data['bank_redirect_url']
        );
        
        header("Location: apply.html?error=" . urlencode('Generated application found for this product. Existing Lead ID: ' . $duplicate_lead['lead_id'] . '. Link: ' . $existing_link));
        exit;
    }
    $check_stmt->close();
    
    // Generate unique Lead ID
    $lead_id_stmt = $conn->prepare("SELECT generate_lead_id() as lead_id");
    $lead_id_stmt->execute();
    $lead_id_result = $lead_id_stmt->get_result();
    $lead_id = $lead_id_result->fetch_assoc()['lead_id'];
    $lead_id_stmt->close();
    
    // Get product details and bank redirect URL
    $product_stmt = $conn->prepare("SELECT name, bank_redirect_url, commission_rate FROM products WHERE id = ? AND status = 'active'");
    $product_stmt->bind_param("i", $product_id);
    $product_stmt->execute();
    $product_result = $product_stmt->get_result();
    
    if ($product_result->num_rows === 0) {
        throw new Exception('Invalid product selected');
    }
    
    $product = $product_result->fetch_assoc();
    $product_stmt->close();
    
    // Insert lead into database
    $insert_stmt = $conn->prepare("INSERT INTO leads (lead_id, name, mobile, email, product_id, channel_code, status, commission, created_at) VALUES (?, ?, ?, ?, ?, ?, 'generated', ?, NOW())");
    $insert_stmt->bind_param("ssssiss", $lead_id, $name, $mobile, $email, $product_id, $channel_code, $product['commission_rate']);
    
    if (!$insert_stmt->execute()) {
        throw new Exception('Failed to save lead: ' . $insert_stmt->error);
    }
    
    $lead_db_id = $conn->insert_id;
    $insert_stmt->close();
    
    // Log status change
    $history_stmt = $conn->prepare("INSERT INTO lead_status_history (lead_id, old_status, new_status, changed_by, notes) VALUES (?, NULL, 'generated', 'system', 'Lead generated from application form')");
    $history_stmt->bind_param("i", $lead_db_id);
    $history_stmt->execute();
    $history_stmt->close();
    
    // Create payout record
    $payout_stmt = $conn->prepare("INSERT INTO payouts (lead_id, channel_code, commission_amount, status) VALUES (?, ?, ?, 'pending')");
    $payout_stmt->bind_param("isd", $lead_db_id, $channel_code, $product['commission_rate']);
    $payout_stmt->execute();
    $payout_stmt->close();
    
    // Check for referral bonus (5% of commission when lead is activated)
    $user_stmt = $conn->prepare("SELECT id, referred_by FROM users WHERE channel_code = ?");
    $user_stmt->bind_param("s", $channel_code);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();
    if ($user_row = $user_result->fetch_assoc()) {
        if (!empty($user_row['referred_by'])) {
            // Find referral_users record
            $ref_user_stmt = $conn->prepare("SELECT id, referrer_user_id FROM referral_users WHERE referred_user_id = ?");
            $ref_user_stmt->bind_param("i", $user_row['id']);
            $ref_user_stmt->execute();
            $ref_user_result = $ref_user_stmt->get_result();
            
            if ($ref_user_row = $ref_user_result->fetch_assoc()) {
                $bonus_amount = $product['commission_rate'] * 0.05; // 5% bonus
                
                // Insert referral bonus
                $bonus_stmt = $conn->prepare("INSERT INTO referral_bonuses (referrer_id, referred_user_id, lead_id, bonus_amount, referral_user_id, status) VALUES (?, ?, ?, ?, ?, 'pending')");
                $bonus_stmt->bind_param("iiidi", $ref_user_row['referrer_user_id'], $user_row['id'], $lead_db_id, $bonus_amount, $ref_user_row['id']);
                $bonus_stmt->execute();
                $bonus_stmt->close();
                
                // Update referral_users first lead date if not set
                $update_ref_stmt = $conn->prepare("UPDATE referral_users SET first_lead_date = COALESCE(first_lead_date, NOW()) WHERE id = ?");
                $update_ref_stmt->bind_param("i", $ref_user_row['id']);
                $update_ref_stmt->execute();
                $update_ref_stmt->close();
            }
            $ref_user_stmt->close();
        }
    }
    $user_stmt->close();
    
    $database->closeConnection();
    
    // Build redirect URL with all codes if present
    $redirect_url = $product['bank_redirect_url'];
    $params = [
        'Channel' => !empty($_POST['Channel']) ? $_POST['Channel'] : 'DSA',
        'DSACode' => !empty($_POST['DSACode']) ? $_POST['DSACode'] : 'XCHC',
        'SMCode' => !empty($_POST['SMCode']) ? $_POST['SMCode'] : 'S42824',
        'LGCode' => !empty($_POST['LGCode']) ? $_POST['LGCode'] : 'DGPI',
        'LCCode' => !empty($_POST['LCCode']) ? $_POST['LCCode'] : 'M2CHC11',
        'LC2' => $lead_id
    ];
    // Ensure all params are present in URL, replace if exists, else add
    foreach ($params as $p => $v) {
        if ($v !== '') {
            if (preg_match('/([?&])'.preg_quote($p,'/').'=[^&]*/i', $redirect_url)) {
                $redirect_url = preg_replace('/([?&])'.preg_quote($p,'/').'=[^&]*/i', '$1'.$p.'='.urlencode($v), $redirect_url);
            } else {
                $redirect_url .= (strpos($redirect_url, '?') !== false ? '&' : '?') . $p.'='.urlencode($v);
            }
        }
    }
    // Always add lead_id for tracking
    $redirect_url .= (strpos($redirect_url, '?') !== false ? '&' : '?') . "lead_id=" . urlencode($lead_id);
    
    // Optional: Send data to bank API server-to-server
    sendToBankAPI($lead_id, $name, $mobile, $email, $channel_code, $product['name']);
    
    // Redirect to bank website
    header("Location: " . $redirect_url);
    exit;
    
} catch (Exception $e) {
    error_log("Lead submission error: " . $e->getMessage());
    header("Location: apply.html?error=" . urlencode('Application submission failed. Please try again.'));
    exit;
}

/**
 * Send lead data to bank API (optional server-to-server)
 */
function sendToBankAPI($lead_id, $name, $mobile, $email, $channel_code, $product_name) {
    $api_url = "https://bank-api.example.com/leads"; // Replace with actual bank API URL
    
    $data = [
        'lead_id' => $lead_id,
        'name' => $name,
        'mobile' => $mobile,
        'email' => $email,
        'channel_code' => $channel_code,
        'product' => $product_name,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $api_url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer YOUR_API_TOKEN', // Replace with actual token
            'User-Agent: FinoCards-LeadSystem/1.0'
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => true
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if (curl_errno($ch)) {
        error_log("Bank API cURL error: " . curl_error($ch));
    } elseif ($http_code !== 200) {
        error_log("Bank API HTTP error: " . $http_code . " - " . $response);
    } else {
        error_log("Lead sent to bank API successfully: " . $lead_id);
    }
    
    curl_close($ch);
}

/*
SAMPLE cURL COMMAND for testing the bank API:

curl -X POST https://bank-api.example.com/leads \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -H "User-Agent: FinoCards-LeadSystem/1.0" \
  -d '{
    "lead_id": "LD000001",
    "name": "John Doe",
    "mobile": "9876543210",
    "email": "john@example.com",
    "channel_code": "CHANNEL123",
    "product": "HDFC Credit Card",
    "timestamp": "2024-01-15 10:30:00"
  }'

Expected Response:
{
  "status": "success",
  "message": "Lead received successfully",
  "lead_id": "LD000001",
  "bank_reference": "BNK123456"
}
*/
?>