const CACHE_NAME = 'finocards-v1';
const ASSETS = ['/', '/manifest.json', '/assets/logo.jpeg'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)));
});

self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(res => res || fetch(e.request)));
});