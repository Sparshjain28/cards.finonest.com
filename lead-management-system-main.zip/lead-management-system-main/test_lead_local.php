<?php
$_SERVER['HTTP_X_API_KEY'] = 'lms_8188272ffd90118df860b5e768fe6681';
$_SERVER['REQUEST_METHOD'] = 'POST';
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';

$data = json_encode([
    'name' => 'Test User',
    'mobile' => '9876543210',
    'email' => 'test@example.com',
    'product_id' => 23
]);

$_SERVER['CONTENT_TYPE'] = 'application/json';
$_SERVER['CONTENT_LENGTH'] = strlen($data);

$tmpfile = tmpfile();
fwrite($tmpfile, $data);
fseek($tmpfile, 0);
stream_filter_append($tmpfile, 'string.toupper', STREAM_FILTER_READ);

$old_stdin = fopen('php://stdin', 'r');
$GLOBALS['HTTP_RAW_POST_DATA'] = $data;

ob_start();
include 'api/leads.php';
$output = ob_get_clean();

echo $output;
?>
