<?php
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$email = $input['email'] ?? '';
if (!$email) { http_response_code(400); echo json_encode(['error' => 'email required']); exit; }

$challenge = random_bytes(32);
$challenge_b64 = rtrim(strtr(base64_encode($challenge), '+/', '-_'), '=');
$_SESSION['webauthn_challenge'] = $challenge_b64;

// Find stored credentials for this user (prototype)
$storeDir = __DIR__ . '/../uploads/webauthn/';
$allowed = [];
if (is_dir($storeDir)) {
    foreach (glob($storeDir . '*.json') as $f) {
        $rec = json_decode(file_get_contents($f), true);
        if ($rec && ($rec['email'] ?? '') === $email) {
            $allowed[] = ['type' => 'public-key', 'id' => $rec['credentialId']];
        }
    }
}

$options = [
    'challenge' => $challenge_b64,
    'timeout' => 60000,
    'rpId' => $_SERVER['HTTP_HOST'],
    'allowCredentials' => $allowed,
    'userVerification' => 'preferred'
];

echo json_encode($options);
