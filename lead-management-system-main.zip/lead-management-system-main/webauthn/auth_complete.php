<?php
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) { http_response_code(400); echo json_encode(['error' => 'invalid']); exit; }

$credentialId = $data['id'] ?? null;
$email = $data['email'] ?? null;

// Prototype: verify credentialId belongs to email
$storeDir = __DIR__ . '/../uploads/webauthn/';
$found = false;
if (is_dir($storeDir)) {
    foreach (glob($storeDir . '*.json') as $f) {
        $rec = json_decode(file_get_contents($f), true);
        if ($rec && $rec['credentialId'] === $credentialId && $rec['email'] === $email) {
            $found = true; break;
        }
    }
}

if ($found) {
    // Successful prototype authentication: set session similar to password login
    require_once __DIR__ . '/../config/database_updated.php';
    $database = new Database();
    $db = $database->getConnection();
    $query = "SELECT id, name, email, channel_code, is_admin FROM users WHERE email = ? LIMIT 1";
    $stmt = $db->prepare($query);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
    // Use centralized session helper to set session values and LAST_ACTIVITY
    loginUserSession($user);
        echo json_encode(['success' => true]);
    } else {
        // user not found in DB
        http_response_code(401);
        echo json_encode(['error' => 'user_not_found']);
    }
} else {
    http_response_code(401);
    echo json_encode(['error' => 'not_found']);
}
