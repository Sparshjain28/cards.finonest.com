<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database_updated.php';

requireLogin();

$database = new Database();
$conn = $database->getConnection();
$user = getCurrentUser();

// Check if banking details already exist
$stmt = $conn->prepare("SELECT bank_name FROM users WHERE id = ?");
$stmt->bind_param('i', $user['id']);
$stmt->execute();
$existing = $stmt->get_result()->fetch_assoc();
$stmt->close();

$is_readonly = !empty($existing['bank_name']);

// Handle form submission (only if not readonly)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_readonly) {
    $bank_name = $_POST['bank_name'];
    $account_number = $_POST['account_number'];
    $ifsc_code = $_POST['ifsc_code'];
    $pan_number = $_POST['pan_number'];
    $aadhar_number = $_POST['aadhar_number'];
    
    $stmt = $conn->prepare("UPDATE users SET bank_name = ?, account_number = ?, ifsc_code = ?, pan_number = ?, aadhar_number = ? WHERE id = ?");
    $stmt->bind_param('sssssi', $bank_name, $account_number, $ifsc_code, $pan_number, $aadhar_number, $user['id']);
    
    if ($stmt->execute()) {
        $stmt->close();
        header("Location: " . ($_GET['redirect'] ?? 'adviser/dashboard.php') . "?banking_updated=1");
        exit;
    }
    $stmt->close();
}

// Get current banking details
$stmt = $conn->prepare("SELECT bank_name, account_number, ifsc_code, pan_number, aadhar_number FROM users WHERE id = ?");
$stmt->bind_param('i', $user['id']);
$stmt->execute();
$banking_details = $stmt->get_result()->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banking Details - Fino Cards</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/loading.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-50">
    <div id="loader" class="loader"><div class="spinner"></div></div>
    <?php include __DIR__ . '/includes/header.php'; ?>

    <main class="w-full max-w-2xl mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow border p-6">
            <div class="mb-6">
                <h1 class="text-2xl font-bold text-slate-900 mb-2"><?= $is_readonly ? 'Banking Details' : 'Banking Details Required' ?></h1>
                <p class="text-slate-600"><?= $is_readonly ? 'Your banking information is saved and cannot be modified.' : 'Please complete your banking information to create leads and receive payouts.' ?></p>
            </div>

            <?php if ($is_readonly): ?>
            <!-- Read-only view -->
            <div class="space-y-4">
                <div class="flex justify-between py-3 border-b">
                    <span class="font-medium text-slate-700">Bank Name</span>
                    <span class="text-slate-900"><?= htmlspecialchars($banking_details['bank_name'] ?? 'N/A') ?></span>
                </div>
                <div class="flex justify-between py-3 border-b">
                    <span class="font-medium text-slate-700">Account Number</span>
                    <span class="text-slate-900"><?= htmlspecialchars($banking_details['account_number'] ?? 'N/A') ?></span>
                </div>
                <div class="flex justify-between py-3 border-b">
                    <span class="font-medium text-slate-700">IFSC Code</span>
                    <span class="text-slate-900"><?= htmlspecialchars($banking_details['ifsc_code'] ?? 'N/A') ?></span>
                </div>
                <div class="flex justify-between py-3 border-b">
                    <span class="font-medium text-slate-700">PAN Number</span>
                    <span class="text-slate-900"><?= htmlspecialchars($banking_details['pan_number'] ?? 'N/A') ?></span>
                </div>
                <div class="flex justify-between py-3 border-b">
                    <span class="font-medium text-slate-700">Aadhar Number</span>
                    <span class="text-slate-900"><?= htmlspecialchars($banking_details['aadhar_number'] ?? 'N/A') ?></span>
                </div>
                <div class="pt-4">
                    <div class="w-full bg-green-100 text-green-800 px-4 py-2 rounded-lg text-center font-medium">
                        <i class="fas fa-check-circle mr-2"></i>Banking Details Verified
                    </div>
                </div>
            </div>
            <?php else: ?>
            <!-- Editable form -->
            <form method="POST" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">Bank Name *</label>
                    <input type="text" name="bank_name" value="<?= htmlspecialchars($banking_details['bank_name'] ?? '') ?>" 
                           required class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">Account Number *</label>
                    <input type="text" name="account_number" value="<?= htmlspecialchars($banking_details['account_number'] ?? '') ?>" 
                           required class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">IFSC Code *</label>
                    <input type="text" name="ifsc_code" value="<?= htmlspecialchars($banking_details['ifsc_code'] ?? '') ?>" 
                           required pattern="[A-Z]{4}0[A-Z0-9]{6}" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">PAN Number *</label>
                    <input type="text" name="pan_number" value="<?= htmlspecialchars($banking_details['pan_number'] ?? '') ?>" 
                           required pattern="[A-Z]{5}[0-9]{4}[A-Z]{1}" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">Aadhar Number *</label>
                    <input type="text" name="aadhar_number" value="<?= htmlspecialchars($banking_details['aadhar_number'] ?? '') ?>" 
                           required pattern="[0-9]{12}" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                <div class="pt-4">
                    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium">
                        <i class="fas fa-save mr-2"></i>Save Banking Details
                    </button>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </main>

    <?php include __DIR__ . '/includes/footer.php'; ?>
    <script src="/assets/js/loading.js"></script>
</body>
</html>