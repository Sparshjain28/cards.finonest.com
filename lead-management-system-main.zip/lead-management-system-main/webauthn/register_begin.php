<?php
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$email = $input['email'] ?? '';
if (!$email) {
    http_response_code(400);
    echo json_encode(['error' => 'email required']);
    exit;
}

// generate challenge
$challenge = random_bytes(32);
$challenge_b64 = rtrim(strtr(base64_encode($challenge), '+/', '-_'), '=');
$_SESSION['webauthn_challenge'] = $challenge_b64;
$_SESSION['webauthn_register_email'] = $email;

$user_id = rtrim(strtr(base64_encode($email), '+/', '-_'), '=');

$options = [
    'challenge' => $challenge_b64,
    'rp' => ['name' => 'Fino Cards'],
    'user' => [
        'id' => $user_id,
        'name' => $email,
        'displayName' => $email
    ],
    'pubKeyCredParams' => [
        ['type' => 'public-key', 'alg' => -7], // ES256
    ],
    'timeout' => 60000,
    'attestation' => 'direct'
];

echo json_encode($options);
