<?php
require_once __DIR__ . '/../includes/auth.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) { http_response_code(400); echo json_encode(['error' => 'invalid']); exit; }

$email = $_SESSION['webauthn_register_email'] ?? null;
$challenge = $_SESSION['webauthn_challenge'] ?? null;

// NOTE: This is a prototype — production must verify attestation properly using a WebAuthn library
// For the prototype we'll store the credentialId and rawClientDataJSON for later matching

$credentialId = $data['id'] ?? null;
$clientData = $data['clientDataJSON'] ?? null;
$attestation = $data['attestationObject'] ?? null;

if (!$email || !$credentialId) { http_response_code(400); echo json_encode(['error' => 'missing']); exit; }

$storeDir = __DIR__ . '/../uploads/webauthn/';
if (!is_dir($storeDir)) mkdir($storeDir, 0755, true);

$record = [
    'email' => $email,
    'credentialId' => $credentialId,
    'clientDataJSON' => $clientData,
    'attestationObject' => $attestation,
    'created' => time()
];

// Use a hashed filename to avoid unsafe characters in credentialId
$filename = $storeDir . sha1($credentialId) . '.json';
file_put_contents($filename, json_encode($record));

echo json_encode(['success' => true]);
